# توثيق بنية وقواعد بيانات مشروع «دفتر ديون» (DATABASE_SCHEMA.md)

> **حالة التحقق:** مُوثّق بالكامل استناداً إلى الكود المصدري الفعلي في `server.ts` و`src/services/turso.ts` وفحص قواعد البيانات السحابية الحية (`libsql pipeline v2`).
> **تاريخ التوثيق:** 13 أكتوبر 2026

---

## 1. المعمارية العامة لقواعد البيانات (Multi-Shard Database Architecture)

يعتمد التطبيق على محرك **libSQL / Turso Cloud** المتوافق مع بروتوكول SQLite، مقسم إلى ثلاث قواعد سحابية أساسية بالإضافة إلى إمكانية ربط قواعد مخصصة للمدراء:

1. **القاعدة الأساسية (Primary Database Shard):**
   - الرابط الداخلي: `_primaryRawUrl` (مستخرج عبر محرك التشفير `_reconstructFortress` في `src/aldion.ts`).
   - الوظيفة: قاعدة البيانات المركزية الافتراضية لجميع المدراء والمستخدمين والديون والأقساط.
2. **القاعدة الثانوية الرديفة للمزامنة المباشرة (Secondary Shard - AWS Mumbai / `aldin-albasrawia2026`):**
   - الوظيفة: قاعدة متطابقة يتم نسخ كل استعلام كتابة (`INSERT` / `UPDATE` / `DELETE`) إليها تلقائياً وآنياً (Dual-Write / Replication) عبر السيرفر والواجهة الأمامية لضمان عدم ضياع أي سجل.
   - تعمل أيضاً كـ Failover تلقائي عند تعذر الوصول للقاعدة الأساسية.
3. **القاعدة الثالثة المنفصلة (Third Shard - AWS Mumbai / `alidion2`):**
   - الوظيفة: شارد مستقل تماماً مخصص لمدراء وفروع فرعية مستقلة لعزل بياناتهم وحصتهم التخزينية.
4. **القواعد المخصصة الإضافية (`databases_registry`):**
   - يمكن للمدير العام إضافة قواعد Turso سحابية جديدة من خلال واجهة الإعدادات وربط أي مدير بها مباشرة (`database_id`).

---

## 2. الجداول الفعلية وهيكلها بالتفصيل

### 2.1 جدول المستخدمين والمدراء (`users`)
يُخزن بيانات تسجيل دخول المدراء وحالات اشتراكاتهم وصلاحياتهم.

| اسم الحقل | النوع الفعلي | القيمة الافتراضية | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | تلقائي | `PRIMARY KEY AUTOINCREMENT` | المعرّف الفريد للمستخدم/المدير |
| `username` | `TEXT` | لا يوجد | `UNIQUE NOT NULL` | اسم المستخدم (أو رقم الهاتف) |
| `password` | `TEXT` | لا يوجد | `NOT NULL` | تجزئة كلمة المرور (Bcrypt Hash) |
| `role` | `TEXT` | `'user'` | - | الرتبة: `'admin'` (مدير عام) أو `'manager'` (مدير فرع) أو `'trial'` |
| `branch_name` | `TEXT` | `'الفرع الرئيسي'` | - | اسم الفرع أو المتجر |
| `phone_or_email` | `TEXT` | `NULL` | - | رقم الهاتف (11 رقماً) أو البريد الإلكتروني |
| `is_active` | `INTEGER` | `1` | `1 = نشط, 0 = موقوف` | حالة تفعيل الحساب |
| `is_new_registration` | `INTEGER` | `0` | `1 = جديد بانتظار الموافقة` | علامة تدل على تسجيل المستخدم ذاتياً عبر شاشة الدخول |
| `subscription_type` | `TEXT` | `'permanent'` | - | نوع الاشتراك: `'permanent'`, `'yearly'`, `'monthly'`, `'local_permanent'`, `'trial'` |
| `subscription_expires_at` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ انتهاء الاشتراك الشهري/السنوي |
| `plain_password` | `TEXT` | `NULL` | - | كلمة المرور بصيغة نصية (تُعرض للمدير العام فقط في لوحة التحكم) |
| `allowed_modules` | `TEXT` | `'both'` | - | الوحدات المسموح بها: `'both'`, `'all'`, `'debts'`, `'installments'`, `'suppliers'`, إلخ |
| `layout_theme` | `TEXT` | `'classic'` | - | سمة الواجهة المفضلة للمدير (من أصل 10 سمات) |
| `database_id` | `TEXT` | `NULL` | - | معرّف قاعدة البيانات السحابية المرتبطة بهذا المدير |
| `birth_date` | `TEXT` | `NULL` | - | تاريخ ميلاد المدير (يستخدم في التحقق والاسترداد) |
| `created_at` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ ووقت إنشاء الحساب |

- **الفهارس (Indexes):**
  - `CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);`

---

### 2.2 جدول المدينين والدائنين (`debtors`)
يُخزن سجلات الزبائن وأرصدة ديونهم وتاريخ معاملاتهم.

| اسم الحقل | النوع الفعلي | القيمة الافتراضية | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | تلقائي | `PRIMARY KEY AUTOINCREMENT` | المعرّف الفريد للزبون (قد يكون Timestamp عند الإنشاء محلياً) |
| `name` | `TEXT` | لا يوجد | `NOT NULL` | اسم الزبون |
| `phone` | `TEXT` | `NULL` | - | رقم هاتف الزبون |
| `amount` | `REAL` | `0` | - | المبلغ المتبقي الحالي في ذمة الزبون |
| `status` | `TEXT` | `'دين مرتفع'` / `'مستمر'` | - | تصنيف السجل: `'دين مرتفع'`, `'مسدد بالكامل'`, إلخ |
| `user_id` | `INTEGER` | `1` | `Index` | معرّف المدير/الفرع المالك لهذا السجل (عزل البيانات) |
| `created_at` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ فتح الحساب/إضافة الدين |
| `last_debt_date` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ آخر حركة دين أو تسديد |
| `history` | `TEXT` | `NULL` | `JSON Array String` | مصفوفة الحركات المالية بتنسيق JSON: `[{id, type, amount, balanceAfter, date, description, notes, paymentMethod}]` |
| `type` | `TEXT` | `'debtor'` | - | نوع السجل: `'debtor'` (دين لك على الزبون) أو `'creditor'` (دين عليك للزبون) |

- **الفهارس (Indexes):**
  - `CREATE INDEX IF NOT EXISTS idx_debtors_user_id ON debtors(user_id);`
  - `CREATE INDEX IF NOT EXISTS idx_debtors_name ON debtors(name);`

---

### 2.3 جدول نظام الأقساط المنفصل (`installments`)
يُخزن سجلات الأقساط الشهرية والتسديدات والكفلاء للزبائن بصورة مستقلة تماماً عن دفتر الديون اليومي.

| اسم الحقل | النوع الفعلي | القيمة الافتراضية | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | تلقائي | `PRIMARY KEY AUTOINCREMENT` | معرّف سجل القسط الفريد |
| `name` | `TEXT` | لا يوجد | `NOT NULL` | اسم صاحب الأقساط |
| `phone` | `TEXT` | `NULL` | - | رقم هاتف صاحب الأقساط (11 رقماً) |
| `item` | `TEXT` | لا يوجد | `NOT NULL` | السلعة أو الغرض المشترى بالأقساط |
| `total_amount` | `REAL` | `0` | - | إجمالي مبلغ الأقساط المتفق عليه |
| `down_payment` | `REAL` | `0` | - | الدفعة المقدمة عند الشراء |
| `remaining_amount` | `REAL` | `0` | - | المبلغ المتبقي = الإجمالي - المقدمة - مجموع التسديدات |
| `monthly_installment_amount` | `REAL` | `0` | - | قيمة القسط الشهري المتفق عليه |
| `registration_date` | `TEXT` | `NULL` | `YYYY-MM-DD` | تاريخ تسجيل وتفعيل القسط |
| `next_due_date` | `TEXT` | `NULL` | `YYYY-MM-DD` | تاريخ استحقاق القسط القادم |
| `status` | `TEXT` | `'active'` | `Index` | حالة القسط: `'active'`, `'due'`, `'overdue'`, `'completed'` |
| `user_id` | `INTEGER` | `1` | `Index` | معرّف المدير/الفرع المالك للسجل |
| `notes` | `TEXT` | `NULL` | - | ملاحظات تفصيلية حول القسط |
| `payments` | `TEXT` | `NULL` | `JSON Array String` | مصفوفة الدفعات المستلمة بتنسيق JSON: `[{id, installmentId, amount, date, remainingAfter, notes, paymentMethod}]` |
| `national_id` | `TEXT` | `NULL` | - | رقم البطاقة الوطنية لصاحب القسط (12 رقماً) |
| `address` | `TEXT` | `NULL` | - | عنوان السكن وأقرب نقطة دالة |
| `guarantor_enabled` | `INTEGER` | `0` | `1 = مفعل, 0 = معطل` | هل تم تسجيل بيانات كفيل ضامن للقسط |
| `guarantor_name` | `TEXT` | `NULL` | - | اسم الكفيل الضامن |
| `guarantor_phone` | `TEXT` | `NULL` | - | رقم هاتف الكفيل الضامن |
| `guarantor_address` | `TEXT` | `NULL` | - | عنوان سكن الكفيل |
| `guarantor_job` | `TEXT` | `NULL` | - | مهنة الكفيل ووظيفته |
| `guarantor_relation` | `TEXT` | `NULL` | - | صلة القرابة بين الكفيل وصاحب القسط |
| `created_at` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ ووقت إنشاء السجل |

- **الفهارس (Indexes):**
  - `CREATE INDEX IF NOT EXISTS idx_installments_user_id ON installments(user_id);`
  - `CREATE INDEX IF NOT EXISTS idx_installments_status ON installments(status);`
  - `CREATE INDEX IF NOT EXISTS idx_installments_next_due_date ON installments(next_due_date);`

---

### 2.4 جدول الموردين والشركات (`suppliers`)
يُخزن سجلات الموردين والشركات التي يتم التعامل التجاري معها.

| اسم الحقل | النوع الفعلي | القيمة الافتراضية | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | تلقائي | `PRIMARY KEY AUTOINCREMENT` | المعرّف الفريد للمورد |
| `name` | `TEXT` | لا يوجد | `NOT NULL` | اسم المورد أو المندوب |
| `phone` | `TEXT` | `NULL` | - | رقم هاتف المورد |
| `company_name` | `TEXT` | `NULL` | - | اسم الشركة أو المعمل |
| `item_type` | `TEXT` | `NULL` | - | نوع البضاعة أو التصنيف |
| `amount` | `REAL` | `0` | - | الرصيد الحالي المتبقي في ذمة المتجر للمورد |
| `status` | `TEXT` | `'active'` | - | حالة المورد: `'active'` أو غير ذلك |
| `user_id` | `INTEGER` | `1` | - | معرّف المدير/الفرع المالك للسجل |
| `created_at` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ إنشاء السجل |
| `last_transaction_date` | `TEXT` | `NULL` | `ISO 8601 String` | تاريخ آخر معاملة شراء أو تسديد |
| `history` | `TEXT` | `NULL` | `JSON Array String` | مصفوفة الحركات السابقة: `[{id, type, amount, balanceAfter, date, notes, description, itemType, paymentMethod}]` |
| `notes` | `TEXT` | `NULL` | - | ملاحظات عامة حول المورد |

---

### 2.5 جدول حركات الموردين التفصيلية (`supplier_transactions`)
جدول بديل مُعرّف في السيرفر لتوثيق حركات الموردين بشكل منفصل إذا لزم:
- `id` (`TEXT PRIMARY KEY`)
- `supplier_id` (`INTEGER`)
- `type` (`TEXT`)
- `amount` (`REAL`)
- `balance_after` (`REAL`)
- `date` (`TEXT`)
- `notes` (`TEXT`)
- `description` (`TEXT`)
- `item_type` (`TEXT`)

---

### 2.6 جدول إعدادات المستخدمين السحابية (`user_settings`)
يُخزن إعدادات كل مدير الفردية في السحابة لتبقى متزامنة عبر أجهزته المتعددة.

| اسم الحقل | النوع الفعلي | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- |
| `user_id` | `INTEGER` | `PRIMARY KEY` | معرّف المدير (مرتبط بـ `users.id`) |
| `settings_json` | `TEXT` | `NOT NULL` | كائن إعدادات JSON الكامل (`AppSettings`): التنبيهات، المظهر، الخط، الشركة، PIN الأمان |
| `updated_at` | `TEXT` | `ISO 8601 String` | وقت وتاريخ آخر تعديل |

---

### 2.7 جدول سجل القواعد السحابية المخصصة (`databases_registry`)
يُسجل القواعد السحابية المتعددة (Turso Shards) التي يضيفها المدير العام للنظام.

| اسم الحقل | النوع الفعلي | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- |
| `id` | `TEXT` | `PRIMARY KEY` | معرّف القاعدة الداخلي |
| `name` | `TEXT` | `NOT NULL` | الاسم المعروض للقاعدة |
| `url` | `TEXT` | `NOT NULL` | رابط الاتصال (بصيغة `libsql://` أو `https://.../v2/pipeline`) |
| `token` | `TEXT` | `NOT NULL` | مفتاح التوكن السري للقاعدة |
| `description` | `TEXT` | `NULL` | وصف القاعدة ومنطقة الخادم |
| `is_default` | `INTEGER` | `DEFAULT 0` | هل هي القاعدة الافتراضية |
| `created_at` | `TEXT` | `ISO 8601 String` | وقت وتاريخ الإضافة |

---

### 2.8 جدول سجلات الحذف للمزامنة والتنظيف (`deleted_records`)
جدول بالغ الأهمية يضمن دقة المزامنة التامة بين عدة أجهزة ويمنع عودة السجلات المحذوفة.

| اسم الحقل | النوع الفعلي | المفتاح / القيود | الوصف والوظيفة |
| :--- | :--- | :--- | :--- |
| `id` | `TEXT` | `PRIMARY KEY (id, entity_type, user_id)` | معرّف السجل الذي تم حذفه |
| `entity_type` | `TEXT` | `PRIMARY KEY` | نوع الكيان: `'debtor'`, `'creditor'`, `'installment'`, `'supplier'` |
| `user_id` | `INTEGER` | `PRIMARY KEY` | معرّف المدير صاحب السجل |
| `deleted_at` | `TEXT` | `DEFAULT datetime('now')` | وقت الحذف |

- **الفهارس (Indexes):**
  - `CREATE INDEX IF NOT EXISTS idx_deleted_records_user ON deleted_records(user_id, entity_type);`
- **التنظيف التلقائي الذكي (`autoPurgeExpiredDeletedRecords`):**
  - يتم حذف السجلات التي مضى عليها أكثر من 30 يوماً تلقائياً مرة واحدة يومياً بدون أي تدخل من المستخدم للحفاظ التام على الحصة السحابية المجانية:
  ```sql
  DELETE FROM deleted_records WHERE deleted_at IS NOT NULL AND deleted_at < datetime('now', '-' || ? || ' days');
  ```

---

## 3. قاعدة البيانات المحلية في المتصفح (`IndexedDB: DaftarAldionDB`)

يعتمد النظام معمارية **Local-First** عبر مكتبة IndexedDB باسم `DaftarAldionDB` بإصدار `DB_VERSION = 4`.

### مخازن الكائنات (Object Stores):
1. **`debtors` (KeyPath: `id`):**
   - فهارس: `userId` (unique: false).
2. **`installments` (KeyPath: `id`):**
   - فهارس: `userId`, `status`, `nextDueDate`.
3. **`suppliers` (KeyPath: `id`):**
   - فهارس: `userId`, `status`.
4. **`keyval` (KeyPath: `key`):**
   - يُخزن الإعدادات والإحصائيات والميتاداتا ونسخ الذاكرة الخفية للمدراء.
5. **`sync_outbox` (KeyPath: `id`):**
   - صندوق الحركات المؤجلة عند انقطاع الإنترنت.
   - فهارس: `userId`, `timestamp`.

---

## 4. القيود وعزل البيانات (Multi-Tenancy Isolation)

1. **العزل الإجباري بحسب `user_id`:**
   - كل استعلام من الواجهة الأمامية يُقيد بشرط `WHERE user_id = ?`.
   - لا يمكن لأي مدير رؤية ديون أو أقساط أو إعدادات مدير آخر.
2. **استثناء المدير العام (`admin`):**
   - الحساب برتبة `admin` (معرّف 1 أو اسم admin) يملك الوصول لقائمة المدراء وجدول `users` وتهيئة القواعد السحابية.
3. **الحساب التجريبي (`trial` / `id: 999999`):**
   - بياناته تبقى محصورة محلياً في الذاكرة وIndexedDB ولا تُرسل إلى السحابة لحماية موارد Turso Cloud.
   - يقتصر على إمكانية إضافة سجلين اثنين فقط في كل وحدة (2 مدينين، 2 أقساط).
