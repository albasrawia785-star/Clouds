import React from 'react';
import { X, Printer, FileText } from 'lucide-react';
import { AppSettings, InvoiceItem, PaperSize, PaymentMethod } from '../types';
import { InvoiceReceipt } from './InvoiceReceipt';

interface PrintPreviewModalProps {
  isOpen: boolean;
  isPrinting?: boolean;
  onClose: () => void;
  onConfirmPrint: () => void;
  onChangePaperSize: (size: PaperSize) => void;
  settings: AppSettings;
  serialNumber: string;
  dateDisplay: string;
  timeDisplay: string;
  customerName: string;
  customerPhone: string;
  customerNotes: string;
  items: InvoiceItem[];
  paymentMethod: PaymentMethod;
  totalIqd: number;
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({
  isOpen,
  isPrinting = false,
  onClose,
  onConfirmPrint,
  onChangePaperSize,
  settings,
  serialNumber,
  dateDisplay,
  timeDisplay,
  customerName,
  customerPhone,
  customerNotes,
  items,
  paymentMethod,
  totalIqd,
}) => {
  if (!isOpen) return null;

  const isA4 = settings.paperSize === 'A4_PORTRAIT';

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-[#0A1B36]/75 p-2 sm:p-4 print:hidden"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="print-preview-title"
    >
      <div
        className="w-full max-w-6xl mx-auto flex-1 max-h-[95vh] bg-[#DDE6F0] rounded-2xl shadow-2xl border border-[#B5CDE8] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Preview Toolbar */}
        <div className="px-4 sm:px-6 py-3 bg-[#102E5A] text-white flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-[#FFD000] shrink-0" />
            <h2 id="print-preview-title" className="text-base sm:text-lg font-extrabold">
              معاينة الوصل قبل الطباعة
            </h2>
            <span
              dir="ltr"
              className="px-2.5 py-0.5 rounded-md bg-white/15 text-[#FFD000] text-xs font-black tabular-nums"
            >
              {serialNumber}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Quick Paper Size Switch */}
            <div className="flex items-center gap-1 p-1 rounded-lg bg-white/10 border border-white/15">
              <button
                type="button"
                onClick={() => onChangePaperSize('A5_LANDSCAPE')}
                className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  !isA4 ? 'bg-[#FFD000] text-[#0E2A52]' : 'text-white/85 hover:text-white'
                }`}
              >
                A5 عرضي
              </button>
              <button
                type="button"
                onClick={() => onChangePaperSize('A4_PORTRAIT')}
                className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  isA4 ? 'bg-[#FFD000] text-[#0E2A52]' : 'text-white/85 hover:text-white'
                }`}
              >
                A4 عمودي
              </button>
            </div>

            {/* Print Now CTA */}
            <button
              type="button"
              disabled={isPrinting}
              onClick={onConfirmPrint}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-[#289643] hover:bg-[#217F38] disabled:opacity-60 disabled:cursor-not-allowed text-white font-extrabold text-sm shadow-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <Printer className="w-4.5 h-4.5" />
              <span>{isPrinting ? 'جارٍ الإرسال للطابعة...' : 'طباعة الآن'}</span>
            </button>

            {/* Close / Back to Edit */}
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/12 hover:bg-white/20 text-white font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <X className="w-4 h-4" />
              <span>رجوع للتعديل</span>
            </button>
          </div>
        </div>

        {/* Paper Preview Stage */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-7 flex flex-col items-center">
          <div className="text-xs font-bold text-[#35537A] mb-3 text-center">
            {isA4
              ? 'معاينة مطابقة لورق A4 عمودي (210 × 297 ملم) — نسخة الطباعة النهائية'
              : 'معاينة مطابقة لورق A5 عرضي (210 × 148 ملم) — نسخة الطباعة النهائية'}
          </div>

          {/* Realistic Paper Sheet */}
          <div
            className={`w-full bg-white shadow-[0_14px_40px_rgba(14,42,82,0.22)] border border-[#BCCCE0] overflow-hidden transition-all ${
              isA4 ? 'max-w-[794px]' : 'max-w-[860px]'
            }`}
          >
            <InvoiceReceipt
              settings={settings}
              serialNumber={serialNumber}
              dateDisplay={dateDisplay}
              timeDisplay={timeDisplay}
              customerName={customerName}
              customerPhone={customerPhone}
              customerNotes={customerNotes}
              items={items}
              paymentMethod={paymentMethod}
              totalIqd={totalIqd}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
