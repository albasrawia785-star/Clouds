import React, { useState, useEffect, useMemo } from 'react';
import { User, Debtor, InstallmentRecord, Supplier, SupervisorUser } from '../types';
import { loadSupervisors, createSupervisor, updateSupervisor, deleteSupervisor } from '../services/supervisorService';
import { formatDateDigits, formatNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { openWhatsAppUrlDirect } from '../utils/whatsapp';

interface SupervisorManagementTabProps {
  currentUser: User;
  allDebtors: Debtor[];
  installments: InstallmentRecord[];
  suppliers: Supplier[];
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

interface AuditLogItem {
  id: string;
  supervisorName: string;
  system: 'debtor' | 'creditor' | 'installment' | 'supplier';
  systemLabel: string;
  actionType: 'add' | 'pay' | 'delete' | 'edit';
  actionLabel: string;
  customerName: string;
  amount: number;
  date: string;
  notes?: string;
}

export const SupervisorManagementTab: React.FC<SupervisorManagementTabProps> = ({
  currentUser,
  allDebtors,
  installments,
  suppliers,
  onShowToast,
}) => {
  const { t, numberFormat, dir } = useI18n();

  const [supervisors, setSupervisors] = useState<SupervisorUser[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Modal / Form state for adding new supervisor
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [supName, setSupName] = useState<string>('');
  const [supPhone, setSupPhone] = useState<string>('');
  const [supPassword, setSupPassword] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Filter state for Audit Log Feed
  const [auditSystemFilter, setAuditSystemFilter] = useState<'all' | 'debtor' | 'creditor' | 'installment' | 'supplier'>('all');
  const [auditSupervisorFilter, setAuditSupervisorFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Password editing state per supervisor
  const [editingPasswordId, setEditingPasswordId] = useState<number | null>(null);
  const [editingPasswordInput, setEditingPasswordInput] = useState<string>('');
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, boolean>>({});

  const parentManagerId = currentUser.role === 'supervisor' && currentUser.parentManagerId ? currentUser.parentManagerId : currentUser.id;

  // Load supervisors on mount or when parentManagerId changes
  const fetchSupervisors = async () => {
    try {
      setLoading(true);
      const list = await loadSupervisors(parentManagerId);
      setSupervisors(list);
    } catch (err) {
      console.warn("Failed loading supervisors:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSupervisors();
  }, [parentManagerId]);

  // Helper to map any username, phone, or raw string to supervisor's real full name
  const resolveSupervisorDisplayName = React.useCallback((rawName: string): string => {
    if (!rawName || !rawName.trim()) return 'المشرف';
    const clean = rawName.trim();
    const matched = supervisors.find(
      (s) =>
        s.name === clean ||
        s.username === clean ||
        (s as any).phoneOrEmail === clean ||
        String(s.id) === clean
    );
    if (matched && matched.name) {
      return matched.name;
    }
    return clean;
  }, [supervisors]);

  // Aggregate Audit Logs from all 4 systems
  const auditLogs = useMemo<AuditLogItem[]>(() => {
    const logs: AuditLogItem[] = [];

    // 1. Debtors & Creditors History
    allDebtors.forEach((debtor) => {
      const isCreditor = debtor.type === 'creditor';
      const history = debtor.history || [];
      history.forEach((tx) => {
        if (tx.performedBy && tx.performedBy.trim()) {
          const resolvedName = resolveSupervisorDisplayName(tx.performedBy);
          const rawType = (tx as any).type || 'add';
          const isPay = rawType === 'pay';
          const isEdit = rawType === 'edit';
          const isDelete = rawType === 'delete';
          const actType: 'add' | 'pay' | 'delete' | 'edit' = isPay ? 'pay' : isEdit ? 'edit' : isDelete ? 'delete' : 'add';
          const actLabel = isPay
            ? 'تسديد دين'
            : isEdit
            ? 'تعديل بيانات العميل'
            : isDelete
            ? 'حذف حساب / دين'
            : rawType === 'add'
            ? 'إضافة دين جديد'
            : 'فتح حساب';

          logs.push({
            id: `debtor-tx-${tx.id || Math.random()}`,
            supervisorName: resolvedName,
            system: isCreditor ? 'creditor' : 'debtor',
            systemLabel: isCreditor ? 'سجل ديون عليّ' : 'دفتر الديون',
            actionType: actType,
            actionLabel: actLabel,
            customerName: debtor.name,
            amount: tx.amount || 0,
            date: tx.date || debtor.createdAt || new Date().toISOString(),
            notes: tx.description || tx.notes,
          });
        }
      });
    });

    // 2. Installments Payments
    installments.forEach((inst) => {
      const payments = inst.payments || [];
      payments.forEach((pay) => {
        if (pay.performedBy && pay.performedBy.trim()) {
          const resolvedName = resolveSupervisorDisplayName(pay.performedBy);
          logs.push({
            id: `inst-pay-${pay.id || Math.random()}`,
            supervisorName: resolvedName,
            system: 'installment',
            systemLabel: 'نظام الأقساط',
            actionType: 'pay',
            actionLabel: 'تسديد قسط',
            customerName: `${inst.name} (${inst.item})`,
            amount: pay.amount || 0,
            date: pay.date || inst.registrationDate || new Date().toISOString(),
            notes: pay.notes,
          });
        }
      });
    });

    // 3. Suppliers History
    suppliers.forEach((sup) => {
      const history = sup.history || [];
      history.forEach((tx) => {
        if (tx.performedBy && tx.performedBy.trim()) {
          const resolvedName = resolveSupervisorDisplayName(tx.performedBy);
          const isPay = tx.type === 'pay' || tx.type === 'pay_supplier';
          logs.push({
            id: `sup-tx-${tx.id || Math.random()}`,
            supervisorName: resolvedName,
            system: 'supplier',
            systemLabel: 'نظام الموردين',
            actionType: isPay ? 'pay' : 'add',
            actionLabel: isPay ? 'تسديد حساب للمورد' : 'إضافة فواتير ومستحقات لمورد',
            customerName: `${sup.name}${sup.companyName ? ` (${sup.companyName})` : ''}`,
            amount: tx.amount || 0,
            date: tx.date || sup.createdAt || new Date().toISOString(),
            notes: tx.description || tx.notes,
          });
        }
      });
    });

    // Sort by Date descending
    return logs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [allDebtors, installments, suppliers, resolveSupervisorDisplayName]);

  // Filtered Audit Logs
  const filteredAuditLogs = useMemo(() => {
    return auditLogs.filter((log) => {
      // System Filter
      if (auditSystemFilter !== 'all' && log.system !== auditSystemFilter) return false;
      // Supervisor Filter
      if (auditSupervisorFilter !== 'all' && log.supervisorName !== auditSupervisorFilter) return false;
      // Search term
      if (searchTerm.trim()) {
        const q = searchTerm.trim().toLowerCase();
        const matchesName = log.supervisorName.toLowerCase().includes(q);
        const matchesCustomer = log.customerName.toLowerCase().includes(q);
        const matchesLabel = log.actionLabel.toLowerCase().includes(q);
        if (!matchesName && !matchesCustomer && !matchesLabel) return false;
      }
      return true;
    });
  }, [auditLogs, auditSystemFilter, auditSupervisorFilter, searchTerm]);

  // Unique Supervisor Names present in audit logs for filter dropdown
  const uniqueAuditSupervisorNames = useMemo(() => {
    const set = new Set<string>();
    supervisors.forEach(s => {
      if (s.name) set.add(s.name);
    });
    auditLogs.forEach((l) => {
      const resolved = resolveSupervisorDisplayName(l.supervisorName);
      if (resolved) set.add(resolved);
    });
    return Array.from(set);
  }, [supervisors, auditLogs, resolveSupervisorDisplayName]);

  // Group Filtered Audit Logs per Supervisor (capped at 50 items per supervisor)
  const groupedAuditLogsBySupervisor = useMemo(() => {
    const groups: {
      supervisorName: string;
      logs: AuditLogItem[];
      totalCount: number;
      totalAmount: number;
    }[] = [];

    // Gather supervisor names to process
    const namesToProcess = auditSupervisorFilter !== 'all' 
      ? [auditSupervisorFilter] 
      : uniqueAuditSupervisorNames;

    namesToProcess.forEach((name) => {
      const supLogs = filteredAuditLogs.filter((l) => l.supervisorName === name);
      const totalAmount = supLogs.reduce((sum, l) => sum + (l.amount || 0), 0);
      const cappedLogs = supLogs.slice(0, 50);

      groups.push({
        supervisorName: name,
        logs: cappedLogs,
        totalCount: supLogs.length,
        totalAmount,
      });
    });

    // Fallback if no names matched or filter is 'all' with unassigned logs
    if (groups.length === 0 && filteredAuditLogs.length > 0) {
      const totalAmount = filteredAuditLogs.reduce((sum, l) => sum + (l.amount || 0), 0);
      groups.push({
        supervisorName: 'كافة المشرفين والمدراء',
        logs: filteredAuditLogs.slice(0, 50),
        totalCount: filteredAuditLogs.length,
        totalAmount,
      });
    }

    return groups;
  }, [filteredAuditLogs, auditSupervisorFilter, uniqueAuditSupervisorNames]);

  // Create New Supervisor Handler
  const handleCreateSupervisorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanName = supName.trim();
    const cleanPhone = supPhone.trim();
    const cleanPass = supPassword.trim();

    if (!cleanName || !cleanPhone || !cleanPass) {
      setFormError('يرجى ملء جميع الحقول المطلوبة بشكل صحيح (الاسم، رقم الهاتف، والرمز السري)');
      return;
    }

    if (cleanPass.length < 3) {
      setFormError('الرمز السري يجب أن لا يقل عن 3 خانات');
      return;
    }

    try {
      setIsSubmitting(true);
      const newSup = await createSupervisor(parentManagerId, currentUser.branch_name || 'الفرع الرئيسي', {
        name: cleanName,
        username: cleanPhone,
        password: cleanPass,
      });

      setSupervisors((prev) => [newSup, ...prev.filter((s) => s.id !== newSup.id)]);
      setShowAddModal(false);
      setSupName('');
      setSupPhone('');
      setSupPassword('');

      if (onShowToast) {
        onShowToast(`تمت إضافة المشرف (${cleanName}) بنجاح!`, 'success');
      }
    } catch (err: any) {
      setFormError(err.message || 'حدث خطأ أثناء إضافة المشرف');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle Supervisor Status
  const handleToggleStatus = async (sup: SupervisorUser) => {
    try {
      const nextActive = !sup.isActive;
      await updateSupervisor(sup.id, parentManagerId, { isActive: nextActive });
      setSupervisors((prev) => prev.map((s) => (s.id === sup.id ? { ...s, isActive: nextActive } : s)));
      if (onShowToast) {
        onShowToast(
          nextActive ? `تم تفعيل حساب المشرف (${sup.name})` : `تم تعطيل حساب المشرف (${sup.name})`,
          nextActive ? 'success' : 'info'
        );
      }
    } catch (err: any) {
      if (onShowToast) onShowToast('تعذر تغيير حالة المشرف', 'error');
    }
  };

  // Update Password
  const handleSavePassword = async (supId: number) => {
    const trimmed = editingPasswordInput.trim();
    if (!trimmed || trimmed.length < 3) {
      if (onShowToast) onShowToast('الرمز السري يجب أن لا يقل عن 3 خانات', 'error');
      return;
    }
    try {
      await updateSupervisor(supId, parentManagerId, { password: trimmed });
      setSupervisors((prev) => prev.map((s) => (s.id === supId ? { ...s, plainPassword: trimmed } : s)));
      setEditingPasswordId(null);
      setEditingPasswordInput('');
      if (onShowToast) onShowToast('تم تحديث الرمز السري للمشرف بنجاح', 'success');
    } catch (err) {
      if (onShowToast) onShowToast('فشل تحديث الرمز السري', 'error');
    }
  };

  // Delete Supervisor
  const handleDelete = async (sup: SupervisorUser) => {
    if (!window.confirm(`هل أنت تأكد من حذف المشرف (${sup.name}) نهائياً؟`)) return;
    try {
      await deleteSupervisor(sup.id, parentManagerId);
      setSupervisors((prev) => prev.filter((s) => s.id !== sup.id));
      if (onShowToast) onShowToast(`تم حذف المشرف (${sup.name}) بنجاح`, 'info');
    } catch (err) {
      if (onShowToast) onShowToast('فشل حذف المشرف', 'error');
    }
  };

  // Share Credentials via WhatsApp
  const handleShareWhatsApp = (sup: SupervisorUser) => {
    const pwd = sup.plainPassword || '••••••';
    const message = `مرحباً بك المشرف (${sup.name})\nتم إنشاء حساب مشرف خاص بك:\nرقم الهاتف (اسم المستخدم): ${sup.username}\nالرمز السري: ${pwd}\nتطبيق دفتر الديون والأقساط.`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
    openWhatsAppUrlDirect(url);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300" dir={dir}>
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,rgba(59,130,246,0.25),transparent_60%)] pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-bold mb-2">
              <i className="fa-solid fa-user-shield text-blue-400"></i>
              <span>نظام إدارة وتتبع المشرفين والموظفين</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              سجل وتتبع حركة المشرفين
            </h2>
            <p className="text-xs sm:text-sm text-blue-100/80 mt-1 max-w-2xl leading-relaxed">
              قم بإنشاء حسابات المشرفين برقم الهاتف والرمز السري، ومتابعة سجل كافة العمليات (إضافة ديون، تسديد، أقساط، وموردين) بدقة لحظية عبر جميع الأنظمة.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg shadow-emerald-900/30 transition-all cursor-pointer flex items-center justify-center gap-2 shrink-0 active:scale-95"
          >
            <i className="fa-solid fa-user-plus text-sm"></i>
            <span>إضافة مشرف جديد</span>
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-4 border-t border-white/10 relative z-10">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-blue-200 font-medium block">إجمالي المشرفين</span>
            <span className="text-xl font-black text-white mt-0.5 block">{supervisors.length}</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-200 font-medium block">المشرفون النشطون</span>
            <span className="text-xl font-black text-emerald-300 mt-0.5 block">
              {supervisors.filter((s) => s.isActive).length}
            </span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-amber-200 font-medium block">عمليات اليوم/الكل</span>
            <span className="text-xl font-black text-amber-300 mt-0.5 block">{auditLogs.length}</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-purple-200 font-medium block">الأنظمة المشمولة</span>
            <span className="text-xl font-black text-purple-300 mt-0.5 block">4 أنظمة</span>
          </div>
        </div>
      </div>

      {/* SECTION 1: Supervisors Roster (قائمة المشرفين الحالية) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm font-bold shadow-xs">
              <i className="fa-solid fa-users"></i>
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">حسابات المشرفين التابعين لهذا الفرع</h3>
              <p className="text-xs text-slate-500">المشرفون المخولون بإجراء العمليات باسم الفرع</p>
            </div>
          </div>

          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
            {supervisors.length} مشرف
          </span>
        </div>

        {loading ? (
          <div className="text-center py-8 text-slate-400 text-xs flex items-center justify-center gap-2">
            <i className="fa-solid fa-circle-notch fa-spin text-sm text-blue-600"></i>
            <span>جاري تحميل قائمة المشرفين...</span>
          </div>
        ) : supervisors.length === 0 ? (
          <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
            <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center text-xl mx-auto">
              <i className="fa-solid fa-user-plus"></i>
            </div>
            <h4 className="font-bold text-slate-800 text-sm">لا يوجد مشرفين مضافين حالياً</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              انقر على زر "إضافة مشرف جديد" لإنشاء حساب مشرف برقم هاتف ورمز سري لتسهيل عمل الموظفين ومتابعة سجل عملياتهم.
            </p>
            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="mt-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>إضافة أول مشرف</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {supervisors.map((sup) => {
              const pass = sup.plainPassword || '••••••';
              const isRevealed = !!revealedPasswords[sup.id];
              const isEditing = editingPasswordId === sup.id;

              return (
                <div
                  key={sup.id}
                  className={`rounded-2xl p-4 border transition-all space-y-3 ${
                    sup.isActive
                      ? 'bg-white border-slate-200/90 hover:border-blue-300 shadow-2xs hover:shadow-xs'
                      : 'bg-rose-50/30 border-rose-200/80'
                  }`}
                >
                  {/* Top Bar: Name & Active Status Badge */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow-xs ${
                        sup.isActive ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-500'
                      }`}>
                        <i className="fa-solid fa-user"></i>
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-bold text-sm text-slate-900 truncate">{sup.name}</h4>
                        <span className="text-[11px] text-slate-500 font-mono block truncate" dir="ltr">
                          {sup.username}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleStatus(sup)}
                      className={`text-[10px] font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer shrink-0 ${
                        sup.isActive
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                      }`}
                    >
                      {sup.isActive ? 'مفعل' : 'معطل'}
                    </button>
                  </div>

                  {/* Credentials Info Box */}
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/70 text-xs space-y-2">
                    {/* Username / Phone */}
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">رقم الهاتف:</span>
                      <span className="font-bold text-blue-700 font-mono" dir="ltr">
                        {sup.username}
                      </span>
                    </div>

                    {/* PIN Code / Password */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/50">
                      <span className="text-slate-500">الرمز السري:</span>
                      {!isEditing ? (
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-slate-900">
                            {isRevealed ? pass : '••••••'}
                          </span>
                          <button
                            type="button"
                            onClick={() => setRevealedPasswords((prev) => ({ ...prev, [sup.id]: !prev[sup.id] }))}
                            className="p-1 text-slate-500 hover:text-slate-800 cursor-pointer text-xs"
                            title="إظهار الرمز"
                          >
                            <i className={`fa-solid ${isRevealed ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingPasswordId(sup.id);
                              setEditingPasswordInput(pass === '••••••' ? '' : pass);
                            }}
                            className="p-1 text-blue-600 hover:text-blue-800 cursor-pointer text-xs"
                            title="تعديل الرمز السري"
                          >
                            <i className="fa-solid fa-pen-to-square"></i>
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <input
                            type="text"
                            value={editingPasswordInput}
                            onChange={(e) => setEditingPasswordInput(e.target.value)}
                            placeholder="رمز جديد..."
                            className="w-20 bg-white border border-blue-400 text-xs font-mono font-bold px-2 py-0.5 rounded-md outline-none"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => handleSavePassword(sup.id)}
                            className="bg-blue-600 text-white px-2 py-0.5 rounded-md text-[10px] font-bold cursor-pointer hover:bg-blue-700"
                          >
                            حفظ
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingPasswordId(null)}
                            className="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold cursor-pointer"
                          >
                            إلغاء
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Registration Date */}
                    {sup.createdAt && (
                      <div className="flex items-center justify-between pt-1 border-t border-slate-200/50 text-[11px]">
                        <span className="text-slate-400">تاريخ الإضافة:</span>
                        <span className="text-slate-500 font-mono">
                          {formatDateDigits(sup.createdAt)}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Actions Row */}
                  <div className="flex items-center justify-between pt-1 gap-2">
                    <button
                      type="button"
                      onClick={() => handleShareWhatsApp(sup)}
                      className="py-1.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/80 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <i className="fa-brands fa-whatsapp text-sm"></i>
                      <span>إرسال الحساب</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(sup)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      title="حذف المشرف"
                    >
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* SECTION 2: Audit Feed Across All 4 Systems (سجل عمليات المشرفين) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-sm font-bold shadow-xs">
              <i className="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">سجل عمليات المشرفين والمدراء عبر كافة الأنظمة</h3>
              <p className="text-xs text-slate-500">تتبع حي ومباشر لعمليات إضافة وتحديث وتسديد الديون والأقساط والموردين</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
              {filteredAuditLogs.length} حركة مسجلة
            </span>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
          {/* System Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              التصفية حسب النظام:
            </label>
            <select
              value={auditSystemFilter}
              onChange={(e) => setAuditSystemFilter(e.target.value as any)}
              className="w-full bg-white border border-slate-200 text-xs font-bold p-2 rounded-xl outline-none text-slate-800"
            >
              <option value="all">كافة الأنظمة الأربعة (شامل)</option>
              <option value="debtor">دفتر الديون (المدينين)</option>
              <option value="creditors">سجل ديون عليّ (الدائنين)</option>
              <option value="installment">نظام الأقساط</option>
              <option value="supplier">نظام الموردين</option>
            </select>
          </div>

          {/* Supervisor Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              التصفية حسب المشرف:
            </label>
            <select
              value={auditSupervisorFilter}
              onChange={(e) => setAuditSupervisorFilter(e.target.value)}
              className="w-full bg-white border border-slate-200 text-xs font-bold p-2 rounded-xl outline-none text-slate-800"
            >
              <option value="all">جميع المشرفين والمدراء</option>
              {uniqueAuditSupervisorNames.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          {/* Search Input */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              البحث بآسم العميل أو العملية:
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث..."
                className="w-full bg-white border border-slate-200 text-xs font-medium pl-8 pr-3 py-2 rounded-xl outline-none text-slate-800"
              />
              <i className="fa-solid fa-magnifying-glass absolute left-2.5 top-2.5 text-slate-400 text-xs"></i>
            </div>
          </div>
        </div>

        {/* Audit Log Timeline (Grouped per Supervisor) */}
        {groupedAuditLogsBySupervisor.length === 0 || groupedAuditLogsBySupervisor.every(g => g.logs.length === 0) ? (
          <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
            <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-500 flex items-center justify-center text-lg mx-auto">
              <i className="fa-solid fa-receipt"></i>
            </div>
            <h4 className="font-bold text-slate-700 text-xs">لا توجد عمليات مسجلة متطابقة</h4>
            <p className="text-[11px] text-slate-400">
              عندما يقوم المشرفون بإضافة ديون جديدة أو إضافة عملاء أو تسديد الأقساط والموردين ستظهر حركاتهم هنا مقسمة لكل مشرف.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {groupedAuditLogsBySupervisor.map((group) => {
              if (group.logs.length === 0) return null;
              return (
                <div
                  key={group.supervisorName}
                  className="bg-slate-50/70 border border-slate-200/90 rounded-3xl p-4 sm:p-5 space-y-3 shadow-xs"
                >
                  {/* Supervisor Group Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-slate-200/70">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-base font-black shadow-xs shrink-0">
                        <i className="fa-solid fa-user-gear"></i>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-black text-sm text-slate-900">
                            سجل حركات المشرف: <span className="text-indigo-700">{group.supervisorName}</span>
                          </h4>
                          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200">
                            أحدث 50 حركة ⚡
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          تُعرض فقط الحركات الخاصة بـ ({group.supervisorName}) عبر كافة الأنظمة
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap text-xs self-start sm:self-auto">
                      <span className="font-bold px-3 py-1 rounded-xl bg-white border border-slate-200 text-slate-700 shadow-2xs">
                        عدد الحركات: <strong className="text-slate-900">{group.totalCount}</strong>
                      </span>
                      <span className="font-bold px-3 py-1 rounded-xl bg-white border border-slate-200 text-emerald-700 shadow-2xs font-mono" dir="ltr">
                        {formatNumber(group.totalAmount, numberFormat)} د.ع
                      </span>
                    </div>
                  </div>

                  {/* Movements List for this Supervisor (Max 50) */}
                  <div className="space-y-2.5">
                    {group.logs.map((log) => {
                      const isPay = log.actionType === 'pay';
                      const isEdit = log.actionType === 'edit';
                      const isDelete = log.actionType === 'delete';

                      const iconBg = isPay
                        ? 'bg-emerald-600 text-white'
                        : isEdit
                        ? 'bg-amber-600 text-white'
                        : isDelete
                        ? 'bg-rose-700 text-white'
                        : 'bg-blue-600 text-white';

                      const iconClass = isPay
                        ? 'fa-arrow-down-left'
                        : isEdit
                        ? 'fa-pen-to-square'
                        : isDelete
                        ? 'fa-trash-can'
                        : 'fa-plus';

                      const badgeClass = isPay
                        ? 'bg-emerald-100 text-emerald-800'
                        : isEdit
                        ? 'bg-amber-100 text-amber-800'
                        : isDelete
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-blue-100 text-blue-800';

                      return (
                        <div
                          key={log.id}
                          className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                            isPay
                              ? 'bg-white border-emerald-200/80 hover:border-emerald-300'
                              : isEdit
                              ? 'bg-white border-amber-200/80 hover:border-amber-300'
                              : isDelete
                              ? 'bg-white border-rose-200/80 hover:border-rose-300'
                              : 'bg-white border-blue-200/80 hover:border-blue-300'
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <div
                              className={`w-9 h-9 rounded-2xl flex items-center justify-center text-sm shrink-0 shadow-2xs mt-0.5 ${iconBg}`}
                            >
                              <i className={`fa-solid ${iconClass}`}></i>
                            </div>

                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-extrabold text-xs sm:text-sm text-slate-900">
                                  {log.supervisorName}
                                </span>
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                    log.system === 'debtor'
                                      ? 'bg-blue-50 text-blue-800 border-blue-200'
                                      : log.system === 'creditor'
                                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                                      : log.system === 'installment'
                                      ? 'bg-purple-50 text-purple-800 border-purple-200'
                                      : 'bg-teal-50 text-teal-800 border-teal-200'
                                  }`}
                                >
                                  {log.systemLabel}
                                </span>
                                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${badgeClass}`}>
                                  {log.actionLabel}
                                </span>
                              </div>

                              <div className="text-xs text-slate-700 font-medium">
                                العميل / الطرف الآخر: <span className="font-bold text-slate-900">{log.customerName}</span>
                              </div>

                              {log.notes && (
                                <div className="text-[11px] text-slate-500 italic">
                                  "{log.notes}"
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex sm:flex-col items-center sm:items-end justify-between shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
                            <div
                              className={`text-xs sm:text-sm font-black font-mono ${
                                isPay ? 'text-emerald-700' : 'text-rose-700'
                              }`}
                              dir="ltr"
                            >
                              {isPay ? '-' : '+'}{formatNumber(log.amount, numberFormat)} د.ع
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono">
                              {formatDateDigits(log.date)}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* MODAL: ADD SUPERVISOR FORM */}
      {showAddModal && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200"
          onClick={() => setShowAddModal(false)}
        >
          <div
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-user-plus"></i>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">إضافة مشرف جديد للفرع</h3>
                  <p className="text-[11px] text-slate-500">إنشاء حساب بتسجيل الدخول برقم الهاتف والرمز السري</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl border border-rose-200 flex items-center gap-2">
                <i className="fa-solid fa-circle-exclamation shrink-0"></i>
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreateSupervisorSubmit} className="space-y-3.5">
              {/* Field 1: Supervisor Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  1. اسم المشرف / الموظف <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  placeholder="مثال: أحمد علي"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                  required
                />
              </div>

              {/* Field 2: Phone Number as Username */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  2. رقم الهاتف (اسم المستخدم للدخول) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={supPhone}
                  onChange={(e) => setSupPhone(e.target.value)}
                  placeholder="مثال: 07701234567"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-mono font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                  dir="ltr"
                  required
                />
              </div>

              {/* Field 3: PIN Code / Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  3. الرمز السري / كلمة السر <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={supPassword}
                  onChange={(e) => setSupPassword(e.target.value)}
                  placeholder="مثال: 1234"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-mono font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                  required
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all cursor-pointer flex items-center gap-2 shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الإنشاء...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-plus text-xs"></i>
                      <span>إنشاء المشرف</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
