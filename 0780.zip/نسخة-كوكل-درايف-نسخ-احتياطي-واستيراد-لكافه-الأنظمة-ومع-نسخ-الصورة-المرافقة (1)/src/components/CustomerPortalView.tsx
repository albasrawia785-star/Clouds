import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  RefreshCw,
  Clock,
  TrendingUp,
  AlertCircle,
  FileText,
  Lock,
  Wallet,
  Coins,
  CreditCard,
  Phone,
  Building2,
  Package,
  Calendar,
  UserCheck,
  BookOpen,
  ArrowLeft,
} from 'lucide-react';
import { PortalType } from '../utils/qrUtils';
import { formatNumber } from '../utils/formatters';
import { queryTurso, queryAllDatabasesForAccount, getBackendBaseUrl, isStaticOrNetlifyEnv } from '../services/turso';

interface CustomerPortalViewProps {
  type: PortalType;
  id: number;
  onGoToLogin?: () => void;
}

// Clean date formatting helper to prevent raw ISO string leaking
function formatPortalDate(dateStr?: string | null): string {
  if (!dateStr) return '-';
  try {
    const cleanStr = String(dateStr).trim();
    if (cleanStr.includes('T')) {
      const parts = cleanStr.split('T');
      const datePart = parts[0];
      const timePart = parts[1] ? parts[1].substring(0, 5) : '';
      return timePart && timePart !== '00:00' ? `${datePart} (${timePart})` : datePart;
    }
    return cleanStr;
  } catch {
    return String(dateStr);
  }
}

export const CustomerPortalView: React.FC<CustomerPortalViewProps> = ({
  type,
  id,
  onGoToLogin,
}) => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchLiveStatement = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);

    try {
      // 1. Query server-side proxy API if running in Express environment
      if (!isStaticOrNetlifyEnv()) {
        try {
          const baseUrl = getBackendBaseUrl();
          const res = await fetch(`${baseUrl}/api/public/statement?type=${type}&id=${id}`);
          if (res.ok) {
            const json = await res.json();
            if (json.success && json.data) {
              setData(json.data);
              setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
              setLoading(false);
              setRefreshing(false);
              return;
            }
          }
        } catch {
          // Fall through to direct Turso multi-database search
        }
      }

      // 2. Query ALL Turso databases directly across cluster
      const tableName = (type === 'supplier') ? 'suppliers' : (type === 'installment') ? 'installments' : 'debtors';
      const searchRes = await queryAllDatabasesForAccount(tableName, id);

      if (searchRes && searchRes.row) {
        const row = searchRes.row;
        if (type === 'debtor' || type === 'creditor') {
          let history = [];
          try {
            history = row.history ? (typeof row.history === 'string' ? JSON.parse(row.history) : row.history) : [];
          } catch {}

          const remainingAmount = Number(row.amount || 0);
          let paidAmount = 0;
          if (Array.isArray(history)) {
            paidAmount = history
              .filter((h: any) => h && h.type === 'pay')
              .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
          }
          const totalAmount = remainingAmount + paidAmount;

          setData({
            id: Number(row.id),
            name: String(row.name || ''),
            phone: String(row.phone || ''),
            amount: totalAmount,
            paidAmount,
            remainingAmount,
            debtDate: String(row.created_at || row.createdAt || row.last_debt_date || new Date().toISOString()),
            notes: String(row.notes || ''),
            history,
            userId: Number(row.user_id || row.userId || 1),
            updatedAt: String(row.created_at || row.createdAt || new Date().toISOString()),
            branchName: 'دفتر الديون والأقساط',
            accountCategory: type === 'creditor' ? 'creditor' : (row.type || 'debtor'),
          });
          setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
          setLoading(false);
          setRefreshing(false);
          return;
        } else if (type === 'supplier') {
          let history = [];
          try {
            history = row.history ? (typeof row.history === 'string' ? JSON.parse(row.history) : row.history) : [];
          } catch {}

          const remainingAmount = Number(row.amount || 0);
          let paidAmount = 0;
          if (Array.isArray(history)) {
            paidAmount = history
              .filter((h: any) => h && (h.type === 'pay_supplier' || h.type === 'pay'))
              .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
          }
          const totalAmount = remainingAmount + paidAmount;

          setData({
            id: Number(row.id),
            name: String(row.name || ''),
            phone: String(row.phone || ''),
            companyName: String(row.company_name || row.companyName || ''),
            amount: totalAmount,
            paidAmount,
            remainingAmount,
            itemType: String(row.item_type || row.itemType || ''),
            notes: String(row.notes || ''),
            userId: Number(row.user_id || row.userId || 1),
            history,
            updatedAt: String(row.created_at || row.createdAt || new Date().toISOString()),
            branchName: 'نظام الموردين والدائنين',
            accountCategory: 'supplier',
          });
          setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
          setLoading(false);
          setRefreshing(false);
          return;
        } else {
          // Installment system
          let payments = [];
          try {
            payments = row.payments ? (typeof row.payments === 'string' ? JSON.parse(row.payments) : row.payments) : [];
          } catch {}

          setData({
            id: Number(row.id),
            debtorName: String(row.name || row.debtorName || ''),
            phoneNumber: String(row.phone || row.phoneNumber || ''),
            itemName: String(row.item || row.itemName || ''),
            totalAmount: Number(row.total_amount || row.totalAmount || 0),
            downPayment: Number(row.down_payment || row.downPayment || 0),
            remainingAmount: Number(row.remaining_amount || row.remainingAmount || 0),
            monthlyInstallment: Number(row.monthly_installment_amount || row.monthlyInstallment || 0),
            registrationDate: String(row.registration_date || row.registrationDate || ''),
            nextDueDate: String(row.next_due_date || row.nextDueDate || ''),
            status: String(row.status || 'active'),
            notes: String(row.notes || ''),
            payments,
            userId: Number(row.user_id || row.userId || 1),
            updatedAt: String(row.created_at || row.createdAt || new Date().toISOString()),
            guarantorName: String(row.guarantor_name || row.guarantorName || ''),
            guarantorPhone: String(row.guarantor_phone || row.guarantorPhone || ''),
            branchName: 'نظام الأقساط المباشر',
            accountCategory: 'installment',
          });
          setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
          setLoading(false);
          setRefreshing(false);
          return;
        }
      }

      // 3. Fallback to direct Turso query
      if (type === 'debtor' || type === 'creditor') {
        const queryRes = await queryTurso(
          `SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
          [id, String(id), `%${id}%`]
        );
        const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

        if (rows.length > 0) {
          const row = rows[0];
          const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
          let history = [];
          try {
            history = val(7) ? JSON.parse(String(val(7))) : [];
          } catch {}

          const remainingAmount = Number(val(3) || 0);
          let paidAmount = 0;
          if (Array.isArray(history)) {
            paidAmount = history
              .filter((h: any) => h && h.type === 'pay')
              .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
          }
          const totalAmount = remainingAmount + paidAmount;

          setData({
            id: Number(val(0)),
            name: String(val(1) || ''),
            phone: String(val(2) || ''),
            amount: totalAmount,
            paidAmount,
            remainingAmount,
            debtDate: String(val(6) || new Date().toISOString()),
            notes: '',
            history,
            userId: Number(val(5) || 1),
            updatedAt: String(val(6) || new Date().toISOString()),
            branchName: 'دفتر الديون والأقساط',
            accountCategory: type === 'creditor' ? 'creditor' : 'debtor',
          });
          setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
          setLoading(false);
          setRefreshing(false);
          return;
        }
      } else if (type === 'supplier') {
        const queryRes = await queryTurso(
          `SELECT id, name, phone, company_name, amount, item_type, notes, user_id, history, created_at FROM suppliers WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
          [id, String(id), `%${id}%`]
        );
        const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

        if (rows.length > 0) {
          const row = rows[0];
          const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
          let history = [];
          try {
            history = val(8) ? JSON.parse(String(val(8))) : [];
          } catch {}

          const remainingAmount = Number(val(4) || 0);
          let paidAmount = 0;
          if (Array.isArray(history)) {
            paidAmount = history
              .filter((h: any) => h && (h.type === 'pay_supplier' || h.type === 'pay'))
              .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
          }
          const totalAmount = remainingAmount + paidAmount;

          setData({
            id: Number(val(0)),
            name: String(val(1) || ''),
            phone: String(val(2) || ''),
            companyName: String(val(3) || ''),
            amount: totalAmount,
            paidAmount,
            remainingAmount,
            itemType: String(val(5) || ''),
            notes: String(val(6) || ''),
            userId: Number(val(7) || 1),
            history,
            updatedAt: String(val(9) || new Date().toISOString()),
            branchName: 'نظام الموردين والدائنين',
            accountCategory: 'supplier',
          });
          setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
          setLoading(false);
          setRefreshing(false);
          return;
        }
      } else {
        const queryRes = await queryTurso(
          `SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, status, notes, payments, user_id, created_at, guarantor_name, guarantor_phone FROM installments WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
          [id, String(id), `%${id}%`]
        );
        const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

        if (rows.length > 0) {
          const row = rows[0];
          const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
          let payments = [];
          try {
            payments = val(12) ? JSON.parse(String(val(12))) : [];
          } catch {}

          setData({
            id: Number(val(0)),
            debtorName: String(val(1) || ''),
            phoneNumber: String(val(2) || ''),
            itemName: String(val(3) || ''),
            totalAmount: Number(val(4) || 0),
            downPayment: Number(val(5) || 0),
            remainingAmount: Number(val(6) || 0),
            monthlyInstallment: Number(val(7) || 0),
            registrationDate: String(val(8) || ''),
            nextDueDate: String(val(9) || ''),
            status: String(val(10) || 'active'),
            notes: String(val(11) || ''),
            payments,
            userId: Number(val(13) || 1),
            updatedAt: String(val(14) || new Date().toISOString()),
            guarantorName: String(val(15) || ''),
            guarantorPhone: String(val(16) || ''),
            branchName: 'نظام الأقساط المباشر',
            accountCategory: 'installment',
          });
          setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
          setLoading(false);
          setRefreshing(false);
          return;
        }
      }

      // Local storage fallback
      if (typeof window !== 'undefined' && window.localStorage) {
        if (type === 'debtor' || type === 'creditor') {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('debtors_user_') || key === 'local_debtors')) {
              try {
                const debtors = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(debtors)) {
                  const found = debtors.find((d: any) => Number(d.id) === Number(id));
                  if (found) {
                    const history = found.history || [];
                    const remainingAmount = Number(found.amount || 0);
                    const paidAmount = history
                      .filter((h: any) => h && h.type === 'pay')
                      .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
                    const totalAmount = remainingAmount + paidAmount;

                    setData({
                      id: Number(found.id),
                      name: String(found.name || ''),
                      phone: String(found.phone || ''),
                      amount: totalAmount,
                      paidAmount,
                      remainingAmount,
                      debtDate: found.createdAt || new Date().toISOString(),
                      notes: '',
                      history,
                      userId: found.userId || 1,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      branchName: 'دفتر الديون والأقساط',
                      accountCategory: type === 'creditor' ? 'creditor' : (found.type || 'debtor'),
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        } else if (type === 'supplier') {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('suppliers_user_') || key === 'local_suppliers')) {
              try {
                const suppliers = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(suppliers)) {
                  const found = suppliers.find((s: any) => Number(s.id) === Number(id));
                  if (found) {
                    const history = found.history || [];
                    const remainingAmount = Number(found.amount || 0);
                    const paidAmount = history
                      .filter((h: any) => h && (h.type === 'pay_supplier' || h.type === 'pay'))
                      .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
                    const totalAmount = remainingAmount + paidAmount;

                    setData({
                      id: Number(found.id),
                      name: String(found.name || ''),
                      phone: String(found.phone || ''),
                      companyName: String(found.companyName || ''),
                      amount: totalAmount,
                      paidAmount,
                      remainingAmount,
                      itemType: String(found.itemType || ''),
                      notes: String(found.notes || ''),
                      userId: found.userId || 1,
                      history,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      branchName: 'نظام الموردين والدائنين',
                      accountCategory: 'supplier',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        } else {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('installments_user_') || key === 'local_installments')) {
              try {
                const installments = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(installments)) {
                  const found = installments.find((inst: any) => Number(inst.id) === Number(id));
                  if (found) {
                    const payments = found.payments || [];
                    const totalAmount = Number(found.totalAmount || 0);
                    const remainingAmount = Number(found.remainingAmount || 0);

                    setData({
                      id: Number(found.id),
                      debtorName: String(found.name || found.debtorName || ''),
                      phoneNumber: String(found.phone || found.phoneNumber || ''),
                      itemName: String(found.item || found.itemName || ''),
                      totalAmount,
                      downPayment: Number(found.downPayment || 0),
                      remainingAmount,
                      monthlyInstallment: Number(found.monthlyInstallment || 0),
                      registrationDate: String(found.registrationDate || ''),
                      nextDueDate: String(found.nextDueDate || ''),
                      status: String(found.status || 'active'),
                      notes: String(found.notes || ''),
                      payments,
                      userId: found.userId || 1,
                      updatedAt: found.registrationDate || new Date().toISOString(),
                      guarantorName: String(found.guarantorName || ''),
                      guarantorPhone: String(found.guarantorPhone || ''),
                      branchName: 'نظام الأقساط المباشر',
                      accountCategory: 'installment',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        }
      }

      setError('لم يتم العثور على سجل هذا الحساب في قاعدة البيانات.');
    } catch (err: any) {
      console.error('Portal Error:', err);
      setError(err?.message || 'تعذر تحميل بيانات الكشف المالي.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLiveStatement();
  }, [type, id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-sky-950 text-white flex flex-col items-center justify-center p-4 dir-rtl font-sans">
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-6 max-w-sm w-full text-center shadow-lg">
          <div className="w-12 h-12 rounded-2xl bg-white/15 text-white flex items-center justify-center mx-auto mb-3 animate-spin">
            <RefreshCw className="w-6 h-6 text-sky-200" />
          </div>
          <h2 className="text-base font-bold text-white mb-1">جاري تحميل كشف الحساب...</h2>
          <p className="text-sky-200 text-xs">يتم الاتصال بالمخدم وتدقيق البيانات المعتمدة</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col items-center justify-center p-4 dir-rtl font-sans">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-sm w-full text-center shadow-md">
          <div className="w-12 h-12 bg-sky-50 rounded-2xl flex items-center justify-center mx-auto mb-3 text-sky-700">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-slate-900 mb-1">تعذر العثور على الحساب</h2>
          <p className="text-slate-500 text-xs mb-4">{error || 'السجل المطلوب غير متوفر'}</p>
          <button
            onClick={() => fetchLiveStatement(true)}
            className="w-full py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-bold text-xs rounded-2xl flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
          >
            <RefreshCw className="w-4 h-4" />
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  // System category determination across 4 systems
  const isInstallment = type === 'installment';
  const isSupplier = type === 'supplier';
  const isCreditor = type === 'creditor' || data.accountCategory === 'creditor';

  let systemCategoryTitle = 'حساب مدين (ديون مالية)';
  if (isSupplier) systemCategoryTitle = 'حساب مجهز (مورد)';
  else if (isInstallment) systemCategoryTitle = 'عقد قسط آجل';
  else if (isCreditor) systemCategoryTitle = 'حساب دائن (مستحقات)';

  const name = isSupplier ? data.name : isInstallment ? data.debtorName : data.name;
  const phone = isSupplier ? data.phone : isInstallment ? data.phoneNumber : data.phone;
  const totalAmount = isSupplier ? data.amount : isInstallment ? data.totalAmount : data.amount;
  const remainingAmount = data.remainingAmount ?? 0;
  const paidAmount = isSupplier
    ? data.paidAmount ?? 0
    : isInstallment
    ? totalAmount - remainingAmount
    : data.paidAmount ?? (totalAmount - remainingAmount);

  const percentage = totalAmount > 0 ? Math.min(100, Math.round((paidAmount / totalAmount) * 100)) : 0;
  const rawTransactions = isInstallment ? data.payments || [] : data.history || [];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans dir-rtl pb-10">
      {/* Top Header Shell with Royal Blue Theme */}
      <div className="bg-gradient-to-b from-sky-700 via-sky-800 to-blue-900 text-white pt-5 pb-16 px-4 rounded-b-[2.5rem] shadow-md">
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              {data.branchName || 'دفتر الديون والأقساط'}
            </h1>
            <div className="flex items-center gap-1.5 text-xs text-sky-200 mt-0.5 font-medium">
              <span>{systemCategoryTitle}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">#{phone ? phone : data.id}</span>
            </div>
          </div>

          <button
            onClick={() => fetchLiveStatement(true)}
            disabled={refreshing}
            className="px-4 py-2 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/25 text-white transition-all flex items-center gap-2 text-xs font-bold cursor-pointer backdrop-blur-xs shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            <span>تحديث</span>
          </button>
        </div>
      </div>

      {/* Floating Main Content Viewport */}
      <main className="max-w-md mx-auto px-4 -mt-10 space-y-4">
        {/* Account Owner Card */}
        {name && (
          <div className="bg-white rounded-3xl p-4 border border-sky-100 shadow-sm flex items-center justify-between gap-3">
            <div className="min-w-0">
              <span className="text-[11px] font-bold text-sky-600 block mb-0.5">صاحب الحساب:</span>
              <h2 className="text-lg font-black text-slate-900 truncate tracking-tight">{name}</h2>
              {phone && (
                <div className="flex items-center gap-1 text-slate-500 text-xs font-mono dir-ltr justify-end sm:justify-start mt-0.5">
                  <Phone className="w-3 h-3 text-slate-400" />
                  <span>{phone}</span>
                </div>
              )}
            </div>

            <div className="bg-sky-50 px-3 py-1.5 rounded-2xl border border-sky-100 text-right shrink-0">
              <span className="text-[10px] font-bold text-sky-700 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-sky-600" />
                <span>حساب موثّق</span>
              </span>
            </div>
          </div>
        )}

        {/* Primary Financial Balance Hero Card */}
        <div className="bg-white rounded-3xl p-5 border border-sky-100 shadow-md space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-slate-500 block mb-1">المبلغ المتبقي حالياً</span>
              <div className="text-3xl font-black font-mono tracking-tight text-sky-950 flex items-baseline gap-1.5">
                <span>{formatNumber(remainingAmount)}</span>
                <span className="text-sm font-bold text-sky-700">د.ع</span>
              </div>
            </div>

            <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-700 border border-sky-100 flex items-center justify-center shrink-0 shadow-2xs">
              <Wallet className="w-6 h-6 text-sky-600" />
            </div>
          </div>

          {/* Secondary Financial Indicators */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="bg-sky-50/80 p-3.5 rounded-2xl border border-sky-100 text-right space-y-1">
              <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-sky-600" />
                <span>{isSupplier ? 'المجموع المستند' : 'المجموع المسدد'}</span>
              </span>
              <div className="text-base font-black font-mono text-sky-900">
                {formatNumber(paidAmount)} <span className="text-[10px] font-semibold text-sky-700">د.ع</span>
              </div>
            </div>

            <div className="bg-sky-50/80 p-3.5 rounded-2xl border border-sky-100 text-right space-y-1">
              <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-sky-600" />
                <span>المبلغ الكلي</span>
              </span>
              <div className="text-base font-black font-mono text-sky-900">
                {formatNumber(totalAmount)} <span className="text-[10px] font-semibold text-sky-700">د.ع</span>
              </div>
            </div>
          </div>

          {/* Smooth Progress Bar */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-600 text-[11px]">نسبة السداد المسجلة</span>
              <span className="font-mono text-sky-900">{percentage}%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200/60 p-0.5">
              <div
                className="bg-sky-700 h-full rounded-full transition-all duration-700 ease-out"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        </div>

        {/* System Specs Details Box */}
        {(isInstallment || isSupplier) && (
          <div className="bg-white rounded-3xl p-4 border border-sky-100 shadow-sm grid grid-cols-2 gap-3 text-xs">
            {isInstallment && (
              <>
                <div>
                  <span className="text-slate-400 block text-[11px] font-semibold">السلعة / المادة:</span>
                  <span className="font-bold text-slate-800">{data.itemName || 'قسط آجل'}</span>
                </div>
                {data.nextDueDate && (
                  <div>
                    <span className="text-slate-400 block text-[11px] font-semibold">تاريخ القسط القادم:</span>
                    <span className="font-bold text-slate-800">{formatPortalDate(data.nextDueDate)}</span>
                  </div>
                )}
                {data.monthlyInstallment > 0 && (
                  <div>
                    <span className="text-slate-400 block text-[11px] font-semibold">القسط الشهري:</span>
                    <span className="font-mono font-bold text-sky-900">{formatNumber(data.monthlyInstallment)} د.ع</span>
                  </div>
                )}
                {data.guarantorName && (
                  <div>
                    <span className="text-slate-400 block text-[11px] font-semibold">الضامن:</span>
                    <span className="font-bold text-slate-800">{data.guarantorName}</span>
                  </div>
                )}
              </>
            )}

            {isSupplier && (
              <>
                {data.companyName && (
                  <div>
                    <span className="text-slate-400 block text-[11px] font-semibold">المكتب / الشركة:</span>
                    <span className="font-bold text-slate-800">{data.companyName}</span>
                  </div>
                )}
                {data.itemType && (
                  <div>
                    <span className="text-slate-400 block text-[11px] font-semibold">نوع التعامل:</span>
                    <span className="font-bold text-slate-800">{data.itemType}</span>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Transaction History Section */}
        <div className="bg-white rounded-3xl p-5 border border-sky-100 shadow-md space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-sky-700" />
              <span>سجل الحركات والتسديدات</span>
            </h3>
            <span className="text-xs font-bold font-mono text-sky-900 bg-sky-100/80 border border-sky-200 px-3 py-1 rounded-full">
              {rawTransactions.length} حركة
            </span>
          </div>

          {rawTransactions.length === 0 ? (
            <div className="text-center py-8 text-slate-400 space-y-1.5">
              <FileText className="w-8 h-8 mx-auto text-sky-300" />
              <p className="text-xs font-bold text-slate-500">لا توجد حركات مسجلة في هذا الحساب</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {rawTransactions.map((tx: any, idx: number) => {
                const txType = tx.type || (isSupplier ? 'add_debt' : isInstallment ? 'pay' : 'add');
                const isSupplierPay = isSupplier && (txType === 'pay_supplier' || txType === 'pay');
                const isPay = !isSupplier && txType === 'pay';
                const isInitial = txType === 'initial';
                const txAmount = Number(tx.amount || 0);

                let badgeText = isSupplier ? 'إضافة ديون جديدة / بضاعة' : 'إضافة ديون جديدة';
                let isCreditAction = false;

                if (isSupplierPay) {
                  badgeText = 'تسديد دفعة للمورد';
                  isCreditAction = true;
                } else if (isPay) {
                  badgeText = 'تسديد دفعة مالية';
                  isCreditAction = true;
                } else if (isInitial) {
                  badgeText = 'رصيد أولي';
                }

                const rawNote = (tx.notes || tx.description || '').trim();
                const isGenericNote =
                  !rawNote ||
                  rawNote === 'فتح حساب وتسجيل الرصيد الأولي' ||
                  rawNote === 'رصيد أولي' ||
                  rawNote === 'تسديد دفعة' ||
                  rawNote === 'إضافة مبلغ جديد';
                const formattedDate = formatPortalDate(tx.date || tx.createdAt);

                return (
                  <div key={tx.id || idx} className="py-3.5 flex items-center justify-between gap-3 text-xs">
                    <div className="min-w-0 space-y-0.5">
                      <h4 className="font-black text-slate-900 text-xs">
                        {badgeText}
                      </h4>

                      <div className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>({formattedDate})</span>
                      </div>

                      {!isGenericNote && (
                        <p className="text-[11px] text-slate-600 font-medium truncate pt-0.5">
                          {rawNote}
                        </p>
                      )}
                    </div>

                    <div className="text-left shrink-0 space-y-0.5">
                      <div
                        className={`px-3 py-1.5 rounded-xl border font-black font-mono text-xs shadow-2xs ${
                          isCreditAction
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : 'bg-sky-50 text-sky-950 border-sky-200'
                        }`}
                      >
                        {isCreditAction ? '-' : '+'}{formatNumber(txAmount)} <span className="text-[10px] font-semibold">د.ع</span>
                      </div>

                      {tx.remainingAfter !== undefined && (
                        <div className="text-[10px] font-mono text-slate-400 text-left pt-0.5">
                          المتبقي: {formatNumber(tx.remainingAfter)}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* System Trial Action Card */}
        <div className="pt-1">
          <button
            type="button"
            onClick={() => {
              if (onGoToLogin) {
                onGoToLogin();
              } else {
                window.location.href = window.location.origin;
              }
            }}
            className="w-full bg-white hover:bg-sky-50/70 text-sky-950 rounded-3xl p-4 border border-sky-100 shadow-sm transition-all flex items-center justify-between text-xs font-bold cursor-pointer active:scale-[0.99] group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-sky-50 text-sky-700 border border-sky-100 flex items-center justify-center shrink-0">
                <BookOpen className="w-4 h-4 text-sky-700" />
              </div>
              <div className="text-right">
                <span className="block font-black text-slate-900 text-xs">تجربة نظام دفتر الديون والأقساط</span>
                <span className="text-[11px] text-slate-500 font-medium">نظام الديون والأقساط وكشوفات الحساب الذكية</span>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-sky-700 group-hover:-translate-x-1 transition-transform shrink-0" />
          </button>
        </div>

        {/* Security Verified Footer Box */}
        <div className="bg-sky-50/80 rounded-3xl p-4 border border-sky-100 text-center space-y-1 shadow-2xs">
          <div className="flex items-center justify-center gap-1.5 text-sky-950 font-bold text-xs">
            <Lock className="w-3.5 h-3.5 text-sky-700" />
            <span>كشف حساب مالي آمن وموثّق</span>
            {lastUpdated && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-sky-800">محدّث: {lastUpdated}</span>
              </>
            )}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            جميع الحقوق محفوظة © دفتر الديون والأقساط
          </p>
        </div>
      </main>
    </div>
  );
};
