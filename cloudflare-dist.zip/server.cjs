var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_express_rate_limit = __toESM(require("express-rate-limit"), 1);

// src/aldion.ts
var MANUAL_OVERRIDE_TURSO_URL = "";
var MANUAL_OVERRIDE_TURSO_TOKEN = "";
var _INV_S_BOX = [225, 196, 171, 142, 117, 80, 63, 26, 200, 237, 130, 167, 92, 121, 22, 51, 179, 150, 249, 220, 39, 2, 109, 72, 154, 191, 208, 245, 14, 43, 68, 97, 69, 96, 15, 42, 209, 244, 155, 190, 108, 73, 38, 3, 248, 221, 178, 151, 23, 50, 93, 120, 131, 166, 201, 236, 62, 27, 116, 81, 170, 143, 224, 197, 168, 141, 226, 199, 60, 25, 118, 83, 129, 164, 203, 238, 21, 48, 95, 122, 250, 223, 176, 149, 110, 75, 36, 1, 211, 246, 153, 188, 71, 98, 13, 40, 12, 41, 70, 99, 152, 189, 210, 247, 37, 0, 111, 74, 177, 148, 251, 222, 94, 123, 20, 49, 202, 239, 128, 165, 119, 82, 61, 24, 227, 198, 169, 140, 115, 86, 57, 28, 231, 194, 173, 136, 90, 127, 16, 53, 206, 235, 132, 161, 33, 4, 107, 78, 181, 144, 255, 218, 8, 45, 66, 103, 156, 185, 214, 243, 215, 242, 157, 184, 67, 102, 9, 44, 254, 219, 180, 145, 106, 79, 32, 5, 133, 160, 207, 234, 17, 52, 91, 126, 172, 137, 230, 195, 56, 29, 114, 87, 58, 31, 112, 85, 174, 139, 228, 193, 19, 54, 89, 124, 135, 162, 205, 232, 104, 77, 34, 7, 252, 217, 182, 147, 65, 100, 11, 46, 213, 240, 159, 186, 158, 187, 212, 241, 10, 47, 64, 101, 183, 146, 253, 216, 35, 6, 105, 76, 204, 233, 134, 163, 88, 125, 18, 55, 229, 192, 175, 138, 113, 84, 59, 30];
function _reconstructFortress(s1, s2, s3, seed) {
  let result = "";
  for (let i = 0; i < s1.length; i++) {
    const enc = (s1[i] ^ s2[i] ^ s3[i]) & 255;
    let k = (seed ^ i * 2654435769) >>> 0;
    k = (k ^ k >>> 16) * 2246822507 >>> 0;
    k = (k ^ k >>> 13) * 3266489909 >>> 0;
    k = (k ^ k >>> 16) & 255;
    const sub = (enc ^ k ^ i * 13 + 37 & 255) & 255;
    const orig = _INV_S_BOX[sub];
    result += String.fromCharCode(orig);
  }
  return result;
}
var _P_URL_S1 = [115, 86, 7, 61, 217, 208, 140, 139, 36, 160, 19, 112, 168, 198, 38, 21, 15, 106, 63, 56, 110, 15, 5, 68, 160, 149, 109, 15, 33, 254, 243, 209, 68, 85, 129, 223, 164, 88, 91, 203, 245, 125, 184, 91, 147, 242, 249, 255, 247, 106, 59, 115, 39, 119, 165, 32, 101, 79, 21];
var _P_URL_S2 = [177, 83, 235, 85, 250, 215, 40, 246, 237, 122, 115, 249, 57, 235, 223, 176, 253, 34, 202, 221, 87, 101, 199, 4, 176, 253, 56, 42, 15, 224, 241, 41, 162, 22, 102, 188, 139, 167, 111, 143, 54, 241, 154, 68, 215, 71, 222, 119, 227, 40, 93, 223, 3, 248, 22, 163, 76, 23, 110];
var _P_URL_S3 = [13, 235, 58, 176, 153, 88, 104, 239, 198, 97, 27, 64, 148, 6, 131, 52, 157, 23, 1, 52, 51, 4, 26, 21, 111, 83, 67, 62, 6, 179, 138, 95, 190, 222, 208, 117, 12, 130, 60, 126, 58, 8, 226, 62, 133, 166, 244, 169, 205, 23, 149, 227, 198, 165, 121, 231, 72, 220, 232];
var _P_URL_SEED = 48291;
var _P_TOK_S1 = [185, 28, 231, 197, 70, 27, 249, 107, 178, 147, 225, 4, 40, 20, 101, 107, 189, 194, 231, 84, 100, 167, 220, 89, 180, 142, 170, 170, 10, 195, 76, 203, 207, 119, 219, 13, 154, 214, 90, 120, 172, 229, 113, 127, 241, 76, 165, 192, 41, 79, 157, 68, 103, 183, 157, 40, 88, 230, 52, 236, 23, 197, 222, 233, 240, 163, 90, 209, 157, 10, 9, 127, 153, 242, 57, 131, 115, 9, 221, 187, 201, 197, 243, 107, 240, 62, 97, 85, 41, 125, 116, 39, 153, 22, 7, 125, 145, 2, 100, 64, 119, 250, 63, 153, 53, 230, 161, 212, 205, 87, 66, 149, 215, 170, 101, 211, 129, 163, 79, 98, 10, 252, 211, 51, 183, 182, 104, 244, 49, 173, 5, 36, 59, 96, 137, 184, 228, 245, 107, 133, 104, 34, 201, 4, 53, 210, 37, 245, 102, 147, 189, 228, 156, 147, 11, 159, 40, 148, 185, 123, 125, 172, 230, 175, 14, 23, 107, 135, 160, 255, 85, 198, 87, 55, 202, 47, 193, 82, 248, 32, 38, 149, 178, 161, 39, 166, 106, 30, 134, 123, 105, 243, 76, 150, 237, 191, 79, 41, 229, 213, 25, 224, 93, 168, 36, 217, 224, 231, 73, 99, 165, 73, 247, 159, 223, 108, 63, 161, 49, 196, 93, 22, 244, 1, 253, 134, 177, 20, 40, 96, 123, 187, 78, 192, 222, 185, 156, 253, 69, 134, 75, 35, 81, 102, 135, 126, 163, 182, 39, 111, 160, 101, 129, 24, 225, 37, 8, 225, 254, 60, 80, 225, 225, 175, 209, 136, 127, 134, 151, 134, 54, 169, 225, 69, 252, 148, 27, 11, 128, 101, 200, 227, 91, 252, 198, 93, 109, 210, 191, 57, 65, 238, 123, 163, 2, 3, 4, 178, 205, 20, 119, 228, 134, 103, 61, 67, 89, 198, 32, 177, 233, 141, 85, 96, 30, 195, 95, 208, 189, 177, 157, 254, 89, 58, 135, 135, 7, 164, 230, 244, 63, 113, 114, 8, 39, 99, 215, 235, 97, 13, 142, 246, 225, 217, 239, 76, 171, 109];
var _P_TOK_S2 = [18, 44, 226, 21, 172, 214, 208, 44, 95, 111, 220, 190, 15, 216, 133, 136, 231, 81, 49, 63, 66, 178, 41, 54, 217, 182, 118, 203, 134, 177, 51, 179, 166, 244, 245, 164, 22, 182, 55, 151, 113, 77, 104, 41, 246, 89, 27, 250, 81, 88, 145, 67, 54, 183, 111, 1, 107, 117, 172, 144, 20, 153, 67, 191, 147, 184, 174, 77, 164, 232, 244, 190, 59, 61, 11, 150, 246, 63, 4, 40, 253, 79, 248, 155, 104, 15, 212, 142, 13, 197, 202, 237, 113, 91, 238, 123, 114, 3, 4, 162, 217, 175, 253, 35, 170, 83, 111, 203, 208, 103, 119, 191, 101, 241, 254, 31, 80, 21, 184, 189, 94, 194, 186, 59, 117, 70, 153, 103, 33, 193, 65, 209, 91, 249, 103, 51, 0, 141, 120, 18, 121, 43, 245, 234, 81, 28, 139, 129, 3, 205, 22, 17, 16, 91, 251, 79, 90, 111, 236, 187, 1, 142, 41, 86, 205, 120, 32, 213, 10, 171, 210, 21, 66, 133, 194, 32, 74, 72, 161, 60, 154, 185, 132, 46, 101, 183, 109, 20, 83, 189, 178, 158, 156, 192, 68, 98, 225, 162, 237, 96, 81, 173, 96, 217, 237, 52, 216, 67, 226, 120, 253, 59, 237, 134, 123, 175, 228, 199, 23, 246, 97, 221, 4, 251, 154, 232, 8, 200, 146, 95, 229, 222, 178, 203, 51, 25, 100, 158, 40, 50, 31, 46, 134, 154, 170, 17, 128, 86, 154, 20, 204, 159, 154, 26, 231, 3, 9, 68, 185, 143, 76, 76, 184, 8, 26, 33, 203, 58, 237, 17, 248, 151, 96, 28, 217, 126, 124, 161, 154, 82, 5, 165, 44, 254, 34, 148, 130, 101, 144, 47, 71, 58, 213, 201, 73, 74, 195, 178, 58, 184, 236, 159, 136, 89, 205, 47, 193, 74, 155, 176, 120, 29, 40, 147, 183, 241, 53, 60, 246, 146, 86, 199, 106, 229, 165, 91, 100, 5, 237, 76, 3, 29, 26, 223, 178, 209, 18, 188, 21, 81, 68, 122, 15, 2, 37, 228, 64, 40];
var _P_TOK_S3 = [103, 189, 100, 111, 82, 136, 177, 235, 51, 78, 209, 224, 137, 76, 83, 75, 106, 207, 74, 17, 35, 122, 124, 130, 48, 112, 17, 19, 169, 232, 174, 1, 94, 243, 84, 39, 23, 71, 207, 12, 91, 168, 68, 93, 130, 43, 38, 47, 2, 211, 191, 148, 245, 140, 27, 123, 30, 165, 197, 205, 10, 210, 50, 246, 94, 151, 178, 175, 57, 138, 50, 176, 128, 213, 28, 184, 93, 191, 20, 170, 162, 230, 200, 217, 33, 74, 168, 72, 80, 229, 82, 22, 100, 74, 250, 60, 2, 217, 176, 46, 41, 12, 157, 174, 213, 11, 142, 0, 5, 11, 231, 76, 24, 234, 214, 221, 240, 58, 131, 72, 78, 202, 185, 223, 76, 154, 183, 191, 183, 108, 41, 160, 237, 184, 207, 12, 1, 82, 26, 12, 191, 176, 4, 4, 122, 139, 159, 47, 216, 99, 208, 38, 13, 203, 92, 58, 125, 87, 239, 159, 122, 102, 214, 67, 210, 17, 182, 15, 153, 99, 2, 77, 31, 230, 36, 145, 154, 232, 238, 133, 227, 248, 185, 93, 119, 110, 198, 103, 24, 226, 176, 168, 99, 23, 96, 15, 202, 98, 57, 24, 64, 184, 34, 250, 65, 174, 81, 121, 143, 111, 46, 80, 194, 27, 40, 128, 188, 103, 226, 219, 243, 97, 117, 95, 155, 162, 237, 202, 182, 199, 132, 213, 246, 129, 251, 223, 174, 178, 250, 253, 44, 228, 106, 210, 228, 170, 210, 28, 186, 190, 112, 254, 38, 214, 10, 171, 117, 56, 155, 52, 53, 15, 89, 104, 195, 177, 198, 81, 206, 78, 34, 155, 64, 195, 236, 3, 92, 150, 143, 220, 141, 119, 78, 6, 171, 54, 103, 175, 240, 126, 171, 121, 149, 217, 44, 202, 75, 76, 39, 116, 172, 161, 79, 235, 34, 249, 30, 14, 167, 185, 241, 255, 199, 104, 122, 88, 12, 194, 103, 103, 111, 81, 108, 249, 235, 222, 208, 50, 160, 67, 129, 72, 65, 220, 124, 182, 130, 112, 105, 73, 175, 116, 115, 178, 82, 45, 175, 149];
var _P_TOK_SEED = 61928;
var _S_URL_S1 = [142, 167, 92, 117, 98, 27, 48, 41, 198, 255, 148, 141, 186, 83, 72, 97, 30, 55, 44, 197, 242, 235, 128, 185, 86, 79, 100, 29, 10, 35, 216, 241, 238, 135, 188, 85, 66, 123, 16, 9, 38, 223, 244, 237, 154, 179, 168, 65, 126, 23, 12, 37, 210];
var _S_URL_S2 = [173, 122, 51, 200, 129, 94, 23, 44, 229, 178, 75, 0, 217, 150, 175, 100, 61, 202, 131, 88, 17, 46, 231, 188, 117, 2, 219, 144, 169, 102, 63, 244, 141, 90, 19, 40, 225, 190, 119, 12, 197, 146, 171, 96, 57, 246, 143, 68, 29, 42, 227, 184, 113];
var _S_URL_S3 = [84, 191, 135, 8, 228, 135, 204, 70, 122, 88, 146, 111, 185, 81, 217, 221, 190, 138, 171, 22, 21, 131, 116, 58, 198, 216, 234, 56, 75, 251, 206, 12, 39, 119, 139, 100, 215, 236, 130, 133, 92, 236, 201, 76, 197, 243, 172, 145, 171, 2, 27, 216, 106];
var _S_URL_SEED = 27929;
var _S_TOK_S1 = [41, 198, 255, 148, 141, 186, 83, 72, 97, 30, 55, 44, 197, 242, 235, 128, 185, 86, 79, 100, 29, 10, 35, 216, 241, 238, 135, 188, 85, 66, 123, 16, 9, 38, 223, 244, 237, 154, 179, 168, 65, 126, 23, 12, 37, 210, 203, 224, 153, 182, 175, 68, 125, 106, 3, 56, 209, 206, 231, 156, 181, 162, 91, 112, 105, 6, 63, 212, 205, 250, 147, 136, 161, 94, 119, 108, 5, 50, 43, 192, 249, 150, 143, 164, 93, 74, 99, 24, 49, 46, 199, 252, 149, 130, 187, 80, 73, 102, 31, 52, 45, 218, 243, 232, 129, 190, 87, 76, 101, 18, 11, 32, 217, 246, 239, 132, 189, 170, 67, 120, 17, 14, 39, 220, 245, 226, 155, 176, 169, 70, 127, 20, 13, 58, 211, 200, 225, 158, 183, 172, 69, 114, 107, 0, 57, 214, 207, 228, 157, 138, 163, 88, 113, 110, 7, 60, 213, 194, 251, 144, 137, 166, 95, 116, 109, 26, 51, 40, 193, 254, 151, 140, 165, 82, 75, 96, 25, 54, 47, 196, 253, 234, 131, 184, 81, 78, 103, 28, 53, 34, 219, 240, 233, 134, 191, 84, 77, 122, 19, 8, 33, 222, 247, 236, 133, 178, 171, 64, 121, 22, 15, 36, 221, 202, 227, 152, 177, 174, 71, 124, 21, 2, 59, 208, 201, 230, 159, 180, 173, 90, 115, 104, 1, 62, 215, 204, 229, 146, 139, 160, 89, 118, 111, 4, 61, 42, 195, 248, 145, 142, 167, 92, 117, 98, 27, 48, 41, 198, 255, 148, 141, 186, 83, 72, 97, 30, 55, 44, 197, 242, 235, 128, 185, 86, 79, 100, 29, 10, 35, 216, 241, 238, 135, 188, 85, 66, 123, 16, 9, 38, 223, 244, 237, 154, 179, 168, 65, 126, 23, 12, 37, 210, 203, 224, 153, 182, 175, 68, 125, 106, 3, 56, 209, 206, 231, 156, 181, 162, 91, 112, 105, 6, 63, 212, 205, 250, 147, 136, 161, 94, 119, 108, 5, 50, 43, 192, 249, 150, 143, 164, 93, 74, 99, 24, 49, 46, 199, 252];
var _S_TOK_S2 = [8, 193, 158, 87, 108, 37, 242, 139, 64, 25, 214, 239, 164, 125, 10, 195, 152, 81, 110, 39, 252, 181, 66, 27, 208, 233, 166, 127, 52, 205, 154, 83, 104, 33, 254, 183, 76, 5, 210, 235, 160, 121, 54, 207, 132, 93, 106, 35, 248, 177, 78, 7, 220, 149, 162, 123, 48, 201, 134, 95, 20, 45, 250, 179, 72, 1, 222, 151, 172, 101, 50, 203, 128, 89, 22, 47, 228, 189, 74, 3, 216, 145, 174, 103, 60, 245, 130, 91, 16, 41, 230, 191, 116, 13, 218, 147, 168, 97, 62, 247, 140, 69, 18, 43, 224, 185, 118, 15, 196, 157, 170, 99, 56, 241, 142, 71, 28, 213, 226, 187, 112, 9, 198, 159, 84, 109, 58, 243, 136, 65, 30, 215, 236, 165, 114, 11, 192, 153, 86, 111, 36, 253, 138, 67, 24, 209, 238, 167, 124, 53, 194, 155, 80, 105, 38, 255, 180, 77, 26, 211, 232, 161, 126, 55, 204, 133, 82, 107, 32, 249, 182, 79, 4, 221, 234, 163, 120, 49, 206, 135, 92, 21, 34, 251, 176, 73, 6, 223, 148, 173, 122, 51, 200, 129, 94, 23, 44, 229, 178, 75, 0, 217, 150, 175, 100, 61, 202, 131, 88, 17, 46, 231, 188, 117, 2, 219, 144, 169, 102, 63, 244, 141, 90, 19, 40, 225, 190, 119, 12, 197, 146, 171, 96, 57, 246, 143, 68, 29, 42, 227, 184, 113, 14, 199, 156, 85, 98, 59, 240, 137, 70, 31, 212, 237, 186, 115, 8, 193, 158, 87, 108, 37, 242, 139, 64, 25, 214, 239, 164, 125, 10, 195, 152, 81, 110, 39, 252, 181, 66, 27, 208, 233, 166, 127, 52, 205, 154, 83, 104, 33, 254, 183, 76, 5, 210, 235, 160, 121, 54, 207, 132, 93, 106, 35, 248, 177, 78, 7, 220, 149, 162, 123, 48, 201, 134, 95, 20, 45, 250, 179, 72, 1, 222, 151, 172, 101, 50, 203, 128, 89, 22, 47, 228, 189, 74, 3, 216, 145, 174, 103, 60, 245, 130, 91, 16, 41, 230, 191];
var _S_TOK_S3 = [230, 97, 192, 42, 36, 33, 238, 187, 137, 206, 161, 47, 14, 111, 72, 218, 66, 202, 232, 103, 15, 79, 226, 72, 247, 141, 82, 136, 61, 68, 27, 183, 194, 83, 114, 199, 34, 27, 65, 249, 174, 54, 65, 146, 78, 149, 201, 225, 134, 247, 21, 213, 163, 105, 198, 196, 229, 25, 247, 23, 216, 106, 85, 82, 77, 13, 115, 254, 46, 105, 177, 91, 218, 162, 6, 53, 127, 133, 114, 191, 106, 89, 113, 145, 43, 129, 136, 92, 74, 227, 95, 143, 156, 174, 53, 212, 58, 32, 92, 146, 45, 41, 32, 119, 236, 70, 75, 6, 89, 218, 172, 142, 74, 210, 111, 159, 56, 170, 211, 44, 235, 156, 35, 112, 25, 158, 50, 218, 133, 253, 119, 104, 82, 164, 72, 41, 28, 169, 47, 59, 215, 68, 59, 54, 143, 118, 116, 238, 28, 84, 177, 227, 144, 107, 57, 154, 183, 193, 143, 144, 45, 151, 81, 59, 248, 120, 9, 166, 155, 107, 11, 40, 116, 18, 97, 245, 192, 47, 51, 161, 29, 10, 65, 122, 238, 208, 200, 30, 169, 221, 228, 152, 46, 74, 236, 180, 200, 215, 217, 217, 59, 85, 177, 150, 148, 97, 35, 251, 173, 170, 224, 143, 178, 207, 54, 32, 155, 151, 131, 148, 84, 198, 124, 164, 209, 229, 206, 219, 150, 17, 175, 25, 168, 28, 71, 57, 88, 232, 27, 110, 117, 202, 186, 243, 233, 57, 131, 175, 159, 227, 129, 197, 147, 101, 117, 227, 184, 172, 18, 33, 85, 63, 113, 70, 198, 221, 56, 222, 48, 28, 90, 70, 35, 158, 61, 122, 51, 110, 172, 187, 188, 46, 238, 195, 138, 242, 234, 42, 243, 204, 74, 254, 164, 132, 101, 55, 75, 98, 250, 50, 194, 49, 113, 253, 244, 99, 240, 29, 112, 158, 53, 47, 14, 68, 139, 107, 25, 12, 80, 21, 98, 55, 79, 22, 109, 193, 134, 59, 233, 77, 164, 192, 74, 142, 192, 218, 111, 89, 188, 55, 20, 100, 99, 210, 179, 72, 103, 177];
var _S_TOK_SEED = 11916;
function normalizeTursoUrl(rawUrl) {
  if (!rawUrl) return "";
  let clean = rawUrl.trim();
  if (clean.startsWith("libsql://")) {
    clean = "https://" + clean.slice("libsql://".length);
  } else if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
    clean = "https://" + clean;
  }
  clean = clean.replace(/\/+$/, "");
  if (!clean.endsWith("/v2/pipeline")) {
    clean = clean + "/v2/pipeline";
  }
  return clean;
}
var _primaryRawUrl = _reconstructFortress(_P_URL_S1, _P_URL_S2, _P_URL_S3, _P_URL_SEED);
var _primaryToken = _reconstructFortress(_P_TOK_S1, _P_TOK_S2, _P_TOK_S3, _P_TOK_SEED);
var _secondaryRawUrl = _reconstructFortress(_S_URL_S1, _S_URL_S2, _S_URL_S3, _S_URL_SEED);
var _secondaryToken = _reconstructFortress(_S_TOK_S1, _S_TOK_S2, _S_TOK_S3, _S_TOK_SEED);
var _finalRawUrl = MANUAL_OVERRIDE_TURSO_URL && MANUAL_OVERRIDE_TURSO_URL.trim() ? MANUAL_OVERRIDE_TURSO_URL.trim() : _primaryRawUrl;
var _finalToken = MANUAL_OVERRIDE_TURSO_TOKEN && MANUAL_OVERRIDE_TURSO_TOKEN.trim() ? MANUAL_OVERRIDE_TURSO_TOKEN.trim() : _primaryToken;
var ALDION_DATABASE_CONFIG = {
  url: normalizeTursoUrl(_finalRawUrl),
  rawUrl: _finalRawUrl,
  token: _finalToken
};
var SECONDARY_DATABASE_CONFIG = {
  url: normalizeTursoUrl(_secondaryRawUrl),
  rawUrl: _secondaryRawUrl,
  token: _secondaryToken
};
var BACKUP_SYNC_DATABASES = [
  {
    name: "\u0627\u0644\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u062B\u0627\u0646\u0648\u064A\u0629 1 (AWS Mumbai)",
    url: normalizeTursoUrl(_secondaryRawUrl),
    rawUrl: _secondaryRawUrl,
    token: _secondaryToken
  }
];

// server.ts
var getTursoConfig = () => {
  const rawUrl = process.env.TURSO_URL || ALDION_DATABASE_CONFIG.url;
  const url = normalizeTursoUrl(rawUrl);
  const token = process.env.TURSO_TOKEN || ALDION_DATABASE_CONFIG.token;
  return { url, token };
};
async function ensureUsersSchema() {
  const targets = [
    getTursoConfig(),
    ...Array.isArray(BACKUP_SYNC_DATABASES) ? BACKUP_SYNC_DATABASES : []
  ];
  const createStatements = [
    `CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL
    );`,
    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      branch_name TEXT DEFAULT '\u0627\u0644\u0641\u0631\u0639 \u0627\u0644\u0631\u0626\u064A\u0633\u064A',
      is_active INTEGER DEFAULT 1,
      subscription_type TEXT DEFAULT 'permanent',
      subscription_expires_at TEXT,
      plain_password TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS debtors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      amount REAL DEFAULT 0,
      status TEXT DEFAULT '\u062F\u064A\u0646 \u0645\u0631\u062A\u0641\u0639',
      user_id INTEGER DEFAULT 1,
      created_at TEXT,
      history TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS installments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      item TEXT NOT NULL,
      total_amount REAL DEFAULT 0,
      down_payment REAL DEFAULT 0,
      remaining_amount REAL DEFAULT 0,
      monthly_installment_amount REAL DEFAULT 0,
      registration_date TEXT,
      next_due_date TEXT,
      user_id INTEGER DEFAULT 1,
      status TEXT DEFAULT 'active',
      notes TEXT,
      payments TEXT,
      created_at TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      company_name TEXT,
      item_type TEXT,
      amount REAL DEFAULT 0,
      status TEXT DEFAULT 'active',
      user_id INTEGER DEFAULT 1,
      created_at TEXT,
      history TEXT,
      last_transaction_date TEXT,
      notes TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS supplier_transactions (
      id TEXT PRIMARY KEY,
      supplier_id INTEGER,
      type TEXT,
      amount REAL DEFAULT 0,
      balance_after REAL DEFAULT 0,
      date TEXT,
      notes TEXT,
      description TEXT,
      item_type TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS user_settings (
      user_id INTEGER PRIMARY KEY,
      settings_json TEXT NOT NULL,
      updated_at TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS databases_registry (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      url TEXT NOT NULL,
      token TEXT NOT NULL,
      description TEXT,
      is_default INTEGER DEFAULT 0,
      created_at TEXT
    );`,
    "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1;",
    "ALTER TABLE users ADD COLUMN subscription_type TEXT DEFAULT 'permanent';",
    "ALTER TABLE users ADD COLUMN subscription_expires_at TEXT;",
    "ALTER TABLE users ADD COLUMN plain_password TEXT;",
    "ALTER TABLE users ADD COLUMN allowed_modules TEXT;",
    "ALTER TABLE users ADD COLUMN phone_or_email TEXT;",
    "ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;",
    "ALTER TABLE users ADD COLUMN created_at TEXT;",
    "ALTER TABLE debtors ADD COLUMN created_at TEXT;",
    "ALTER TABLE debtors ADD COLUMN history TEXT;",
    "ALTER TABLE debtors ADD COLUMN last_debt_date TEXT;",
    "ALTER TABLE debtors ADD COLUMN type TEXT DEFAULT 'debtor';",
    "ALTER TABLE installments ADD COLUMN notes TEXT;",
    "ALTER TABLE installments ADD COLUMN payments TEXT;",
    "ALTER TABLE installments ADD COLUMN created_at TEXT;",
    "ALTER TABLE installments ADD COLUMN national_id TEXT;",
    "ALTER TABLE installments ADD COLUMN address TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;",
    "ALTER TABLE installments ADD COLUMN guarantor_name TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_address TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_job TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;",
    "ALTER TABLE suppliers ADD COLUMN company_name TEXT;",
    "ALTER TABLE suppliers ADD COLUMN item_type TEXT;",
    "ALTER TABLE suppliers ADD COLUMN history TEXT;",
    "ALTER TABLE suppliers ADD COLUMN last_transaction_date TEXT;",
    "ALTER TABLE suppliers ADD COLUMN notes TEXT;",
    "ALTER TABLE suppliers ADD COLUMN user_id INTEGER DEFAULT 1;"
  ];
  for (const target of targets) {
    if (!target || !target.url || !target.token) continue;
    for (const sql of createStatements) {
      try {
        await fetch(target.url, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${target.token}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            requests: [
              { type: "execute", stmt: { sql, args: [] } },
              { type: "close" }
            ]
          })
        });
      } catch {
      }
    }
  }
}
async function startServer() {
  ensureUsersSchema().catch((err) => console.warn("Schema initialization notice:", err?.message || err));
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.set("trust proxy", 1);
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Shield-Client, X-Shield-Timestamp, X-Shield-Nonce, X-Shield-Signature");
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    next();
  });
  app.use(import_express.default.json({ limit: "1mb" }));
  const apiLimiter = (0, import_express_rate_limit.default)({
    windowMs: 15 * 60 * 1e3,
    // 15 minutes
    max: 600,
    // max 600 requests per 15 minutes per IP
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: { error: "\u062A\u0645 \u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062F \u0627\u0644\u0645\u0633\u0645\u0648\u062D \u0645\u0646 \u0627\u0644\u0637\u0644\u0628\u0627\u062A\u060C \u064A\u0631\u062C\u0649 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0644\u0627\u062D\u0642\u0627\u064B \u0628\u0639\u062F \u0639\u062F\u0629 \u062F\u0642\u0627\u0626\u0642" }
  });
  const dbLimiter = (0, import_express_rate_limit.default)({
    windowMs: 1 * 60 * 1e3,
    // 1 minute
    max: 120,
    // max 120 database operations per minute per IP
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: { error: "\u0637\u0644\u0628\u0627\u062A \u0645\u062A\u0643\u0631\u0631\u0629 \u0628\u0633\u0631\u0639\u0629 \u0643\u0628\u064A\u0631\u0629\u060C \u064A\u0631\u062C\u0649 \u0627\u0644\u062A\u0645\u0647\u0644" }
  });
  app.use("/api/", apiLimiter);
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/turso/test-connection", async (_req, res) => {
    const { url, token } = getTursoConfig();
    if (!url || !token) {
      return res.status(400).json({
        success: false,
        message: "\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0641\u064A \u0645\u0644\u0641 aldion \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644\u0629 (\u0627\u0644\u0631\u0627\u0628\u0637 \u0623\u0648 \u0627\u0644\u0631\u0645\u0632 \u0645\u0641\u0642\u0648\u062F)"
      });
    }
    try {
      const startTime = Date.now();
      const testResponse = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql: "SELECT 1 as test_connection;", args: [] } },
            { type: "close" }
          ]
        })
      });
      const responseTime = Date.now() - startTime;
      if (!testResponse.ok) {
        const errorText = await testResponse.text();
        return res.status(testResponse.status).json({
          success: false,
          statusCode: testResponse.status,
          message: `\u0641\u0634\u0644 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A (${testResponse.status}): ${errorText}`
        });
      }
      let host = "";
      try {
        const urlObj = new URL(url);
        host = urlObj.hostname;
      } catch {
        host = "Turso Cloud";
      }
      return res.json({
        success: true,
        message: "\u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0646\u0627\u062C\u062D \u0648\u0645\u0633\u062A\u0642\u0631!",
        host,
        responseTimeMs: responseTime
      });
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: `\u062A\u0639\u0630\u0631 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u062E\u0627\u062F\u0645 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A: ${err?.message || "\u062E\u0637\u0623 \u0634\u0628\u0643\u0629"}`
      });
    }
  });
  const _SEEN_NONCES = /* @__PURE__ */ new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [nonce, ts] of _SEEN_NONCES.entries()) {
      if (now - ts > 6e4) {
        _SEEN_NONCES.delete(nonce);
      }
    }
  }, 3e5);
  app.post("/api/turso", dbLimiter, async (req, res) => {
    try {
      const shieldTimestamp = req.headers["x-shield-timestamp"];
      const shieldNonce = req.headers["x-shield-nonce"];
      if (shieldTimestamp && shieldNonce) {
        const reqTime = parseInt(String(shieldTimestamp), 10);
        const now = Date.now();
        if (Math.abs(now - reqTime) > 12e4) {
          return res.status(403).json({ error: "\u0627\u0646\u062A\u0647\u062A \u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0637\u0644\u0628 \u0627\u0644\u0623\u0645\u0646\u064A\u060C \u064A\u0631\u062C\u0649 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629" });
        }
        const nonceKey = String(shieldNonce);
        if (_SEEN_NONCES.has(nonceKey)) {
          return res.status(403).json({ error: "\u062A\u0645 \u062D\u0638\u0631 \u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0639\u0627\u062F\u0629 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0637\u0644\u0628 (Replay Attack Detected)" });
        }
        _SEEN_NONCES.set(nonceKey, now);
      }
      const { sql, args = [] } = req.body;
      if (!sql || typeof sql !== "string") {
        return res.status(400).json({ error: "Missing or invalid SQL statement" });
      }
      const trimmedSql = sql.trim();
      const forbiddenKeywords = /\b(DROP|TRUNCATE|ALTER|GRANT|REVOKE|PRAGMA|ATTACH|DETACH|EXEC|VACUUM)\b/i;
      if (forbiddenKeywords.test(trimmedSql)) {
        console.warn(`[Security Alert] Blocked suspicious SQL execution attempt: ${trimmedSql}`);
        return res.status(403).json({ error: "\u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0645\u062D\u0638\u0648\u0631\u0629 \u0644\u062F\u0648\u0627\u0639\u064A \u0623\u0645\u0646\u064A\u0629" });
      }
      const withoutTrailingSemicolon = trimmedSql.replace(/;\s*$/, "");
      if (withoutTrailingSemicolon.includes(";")) {
        console.warn(`[Security Alert] Blocked multi-statement SQL attempt: ${trimmedSql}`);
        return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0646\u0641\u064A\u0630 \u0623\u0643\u062B\u0631 \u0645\u0646 \u062A\u0639\u0644\u064A\u0645\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u064A \u0627\u0644\u0637\u0644\u0628" });
      }
      if (!/^(SELECT|INSERT|UPDATE|DELETE)\b/i.test(trimmedSql)) {
        return res.status(403).json({ error: "\u0646\u0648\u0639 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D \u0628\u0647" });
      }
      if (/\b(FROM|INTO|UPDATE)\b/i.test(trimmedSql)) {
        const allowedTables = /\b(debtors|installments|users|user_settings|messages|suppliers|supplier_transactions|databases_registry)\b/i;
        if (!allowedTables.test(trimmedSql)) {
          return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u062F\u0648\u0644 \u0644\u062F\u0648\u0627\u0639\u064A \u0623\u0645\u0646\u064A\u0629" });
        }
      }
      if (/\b(FROM|INTO|UPDATE)\s+users\b/i.test(trimmedSql) || /\bJOIN\s+users\b/i.test(trimmedSql)) {
        if (/SELECT\s+\*\s+FROM\s+users/i.test(trimmedSql)) {
          console.warn(`[Security Alert] Blocked wildcard dump of users table: ${trimmedSql}`);
          return res.status(403).json({ error: "\u0645\u062D\u0627\u0648\u0644\u0629 \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647\u0627 \u0639\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646" });
        }
        if (/\bpassword\b/i.test(trimmedSql) && /^SELECT\b/i.test(trimmedSql)) {
          const hasStrictWhere = /\bWHERE\s+([^;]+)/i.exec(trimmedSql);
          const whereClause = hasStrictWhere ? hasStrictWhere[1] : "";
          const isTargeted = /\b(username\s*=|phone_or_email\s*=|id\s*=|role\s*=\s*'manager')/i.test(whereClause);
          if (!isTargeted) {
            console.warn(`[Security Alert] Blocked unconstrained password query on users table: ${trimmedSql}`);
            return res.status(403).json({ error: "\u0627\u0644\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0639\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u0645\u062D\u0638\u0648\u0631 \u0644\u062F\u0648\u0627\u0639\u064A \u0623\u0645\u0646\u064A\u0629" });
          }
        }
      }
      const formattedArgs = args.map((a) => {
        if (typeof a === "number") {
          return Number.isInteger(a) ? { type: "integer", value: String(a) } : { type: "float", value: a };
        }
        if (a === null || a === void 0) {
          return { type: "null" };
        }
        return { type: "text", value: String(a ?? "") };
      });
      const { url, token } = getTursoConfig();
      const isWrite = /^(INSERT|UPDATE|DELETE)/i.test(trimmedSql);
      const tursoResponse = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql: trimmedSql, args: formattedArgs } },
            { type: "close" }
          ]
        })
      });
      if (!tursoResponse.ok) {
        if (Array.isArray(BACKUP_SYNC_DATABASES) && BACKUP_SYNC_DATABASES.length > 0) {
          for (const backupDb of BACKUP_SYNC_DATABASES) {
            if (backupDb.url && backupDb.token) {
              try {
                const fbRes = await fetch(backupDb.url, {
                  method: "POST",
                  headers: {
                    Authorization: `Bearer ${backupDb.token}`,
                    "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                    requests: [
                      { type: "execute", stmt: { sql: trimmedSql, args: formattedArgs } },
                      { type: "close" }
                    ]
                  })
                });
                if (fbRes.ok) {
                  const fbData = await fbRes.json();
                  return res.json(fbData);
                }
              } catch {
              }
            }
          }
        }
        const errText = await tursoResponse.text();
        return res.status(tursoResponse.status).json({
          error: `Turso API error (${tursoResponse.status}): ${errText}`
        });
      }
      if (isWrite && Array.isArray(BACKUP_SYNC_DATABASES) && BACKUP_SYNC_DATABASES.length > 0) {
        const backupPromises = BACKUP_SYNC_DATABASES.map(async (backupDb) => {
          if (backupDb.url && backupDb.token) {
            try {
              const bRes = await fetch(backupDb.url, {
                method: "POST",
                headers: {
                  Authorization: `Bearer ${backupDb.token}`,
                  "Content-Type": "application/json"
                },
                body: JSON.stringify({
                  requests: [
                    { type: "execute", stmt: { sql: trimmedSql, args: formattedArgs } },
                    { type: "close" }
                  ]
                })
              });
              if (!bRes.ok) {
                const bErr = await bRes.text().catch(() => "");
                console.warn(`[MultiSync] Secondary DB (${backupDb.name}) write returned ${bRes.status}: ${bErr.slice(0, 80)}`);
              }
            } catch (e) {
              console.warn(`[MultiSync] Secondary DB (${backupDb.name}) replication notice:`, e?.message || e);
            }
          }
        });
        await Promise.allSettled(backupPromises);
      }
      const data = await tursoResponse.json();
      return res.json(data);
    } catch (err) {
      console.error("Server Turso proxy error:", err);
      return res.status(500).json({ error: err?.message || "Internal server error connecting to Turso" });
    }
  });
  app.get("/api/public/statement", async (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    try {
      const type = String(req.query.type || "");
      const idStr = String(req.query.id || "");
      const id = parseInt(idStr, 10);
      if (!idStr || type !== "debtor" && type !== "installment") {
        return res.status(400).json({ success: false, error: "\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629" });
      }
      const { url, token } = getTursoConfig();
      if (!url || !token) {
        return res.status(500).json({ success: false, error: "\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0635\u0644\u0629" });
      }
      let sql = "";
      if (type === "debtor") {
        sql = "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE id = ? OR CAST(id AS TEXT) = ? LIMIT 1;";
      } else {
        sql = "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, status, notes, payments, user_id, created_at, guarantor_name, guarantor_phone FROM installments WHERE id = ? OR CAST(id AS TEXT) = ? LIMIT 1;";
      }
      let tursoRes = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          requests: [
            {
              type: "execute",
              stmt: {
                sql,
                args: [
                  { type: "integer", value: String(isNaN(id) ? 0 : id) },
                  { type: "text", value: idStr }
                ]
              }
            },
            { type: "close" }
          ]
        })
      });
      if (!tursoRes.ok) {
        return res.status(500).json({ success: false, error: "\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0645\u0646 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A" });
      }
      let data = await tursoRes.json();
      let rows = data?.results?.[0]?.response?.result?.rows || [];
      if (!rows || rows.length === 0) {
        return res.status(404).json({
          success: false,
          error: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0633\u062C\u0644 \u0643\u0634\u0641 \u0627\u0644\u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u0637\u0644\u0648\u0628. \u064A\u0631\u062C\u0649 \u0627\u0644\u062A\u0623\u0643\u062F \u0645\u0646 \u0635\u062D\u0629 \u0627\u0644\u0631\u0627\u0628\u0637 \u0623\u0648 \u0627\u0644\u0628\u0627\u0631\u0643\u0648\u062F."
        });
      }
      const row = rows[0];
      const val = (idx) => {
        const item = row[idx];
        if (!item) return null;
        if (typeof item === "object" && "value" in item) return item.value;
        return item;
      };
      let branchName = "\u0627\u0644\u0641\u0631\u0639 \u0627\u0644\u0631\u0626\u064A\u0633\u064A";
      const userId = val(type === "debtor" ? 5 : 13);
      if (userId) {
        try {
          const userRes = await fetch(url, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              requests: [
                {
                  type: "execute",
                  stmt: {
                    sql: "SELECT branch_name FROM users WHERE id = ? LIMIT 1;",
                    args: [{ type: "integer", value: String(userId) }]
                  }
                },
                { type: "close" }
              ]
            })
          });
          if (userRes.ok) {
            const uData = await userRes.json();
            const uRows = uData?.results?.[0]?.response?.result?.rows || [];
            if (uRows.length > 0 && uRows[0][0]) {
              const uVal = uRows[0][0];
              branchName = typeof uVal === "object" && "value" in uVal ? uVal.value : uVal;
            }
          }
        } catch {
        }
      }
      if (type === "debtor") {
        const historyRaw = val(7);
        let history = [];
        try {
          history = historyRaw ? JSON.parse(String(historyRaw)) : [];
        } catch {
        }
        const remainingAmount = Number(val(3) || 0);
        let paidAmount = 0;
        if (Array.isArray(history)) {
          paidAmount = history.filter((h) => h && h.type === "pay").reduce((sum, h) => sum + (Number(h.amount) || 0), 0);
        }
        const totalAmount = remainingAmount + paidAmount;
        const debtorRecord = {
          id: Number(val(0)),
          name: String(val(1) || ""),
          phone: String(val(2) || ""),
          amount: totalAmount,
          paidAmount,
          remainingAmount,
          debtDate: String(val(6) || (/* @__PURE__ */ new Date()).toISOString()),
          notes: "",
          history,
          userId: Number(val(5) || 1),
          updatedAt: String(val(6) || (/* @__PURE__ */ new Date()).toISOString()),
          branchName
        };
        return res.json({ success: true, type: "debtor", data: debtorRecord });
      } else {
        const paymentsRaw = val(12);
        let payments = [];
        try {
          payments = paymentsRaw ? JSON.parse(String(paymentsRaw)) : [];
        } catch {
        }
        const installmentRecord = {
          id: Number(val(0)),
          debtorName: String(val(1) || ""),
          phoneNumber: String(val(2) || ""),
          itemName: String(val(3) || ""),
          totalAmount: Number(val(4) || 0),
          downPayment: Number(val(5) || 0),
          remainingAmount: Number(val(6) || 0),
          monthlyInstallment: Number(val(7) || 0),
          registrationDate: String(val(8) || ""),
          nextDueDate: String(val(9) || ""),
          status: String(val(10) || "active"),
          notes: String(val(11) || ""),
          payments,
          userId: Number(val(13) || 1),
          updatedAt: String(val(14) || (/* @__PURE__ */ new Date()).toISOString()),
          guarantorName: String(val(15) || ""),
          guarantorPhone: String(val(16) || ""),
          branchName
        };
        return res.json({ success: true, type: "installment", data: installmentRecord });
      }
    } catch (err) {
      console.error("Public statement endpoint error:", err);
      return res.status(500).json({ success: false, error: "\u062A\u0639\u0630\u0631 \u062A\u062D\u0645\u064A\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u0643\u0634\u0641 \u0627\u0644\u062D\u0633\u0627\u0628" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      try {
        const fs = await import("fs");
        let template = fs.readFileSync(import_path.default.resolve(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        next(e);
      }
    });
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
