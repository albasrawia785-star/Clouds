import React, { useEffect, useRef, useState } from 'react';
import {
  X,
  Upload,
  RotateCcw,
  Printer,
  FileText,
  MapPin,
  Phone,
  Image as ImageIcon,
  RefreshCw,
  Check,
  Info,
} from 'lucide-react';
import { AppSettings, ElectronPrinter, PaperSize } from '../types';
import { compressImageToDataUrl } from '../utils/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (nextSettings: AppSettings) => void;
  onTestPrint: (draftSettings: AppSettings) => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
  onTestPrint,
  onNotify,
}) => {
  const [draft, setDraft] = useState<AppSettings>(settings);
  const [printers, setPrinters] = useState<ElectronPrinter[]>([]);
  const [loadingPrinters, setLoadingPrinters] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const hasElectronPrinters =
    typeof window !== 'undefined' && typeof window.electronAPI?.getPrinters === 'function';

  useEffect(() => {
    if (isOpen) {
      setDraft(settings);
      if (hasElectronPrinters) {
        fetchPrinters();
      }
    }
  }, [isOpen, settings, hasElectronPrinters]);

  const fetchPrinters = async () => {
    if (!window.electronAPI?.getPrinters) return;
    setLoadingPrinters(true);
    try {
      const list = await window.electronAPI.getPrinters();
      setPrinters(Array.isArray(list) ? list : []);
    } catch {
      onNotify('error', 'تعذر جلب قائمة الطابعات من النظام');
    } finally {
      setLoadingPrinters(false);
    }
  };

  const handleBannerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      onNotify('error', 'يرجى اختيار ملف صورة صالح (JPG / PNG / WebP)');
      return;
    }

    setUploadingBanner(true);
    try {
      const dataUrl = await compressImageToDataUrl(file, 1400, 0.85);
      setDraft((prev) => ({ ...prev, bannerImage: dataUrl }));
      onNotify('info', 'تم تحميل صورة الترويسة — اضغط "حفظ الإعدادات" لتثبيتها');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'فشل معالجة الصورة');
    } finally {
      setUploadingBanner(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleResetBanner = () => {
    setDraft((prev) => ({ ...prev, bannerImage: null }));
    onNotify('info', 'تمت استعادة الترويسة الافتراضية');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(draft);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0A1B36]/60 p-4 print:hidden"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] bg-white rounded-2xl shadow-2xl border border-[#C3D8EE] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#102E5A] text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <Printer className="w-5 h-5 text-[#FFD000]" />
            <h2 id="settings-modal-title" className="text-lg font-bold">
              إعدادات النظام والطباعة
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-6">
          {/* 1. Banner Image Section */}
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-[#0E2A52] font-bold text-base">
              <ImageIcon className="w-4 h-4 text-[#1669C9]" />
              <span>صورة الترويسة العلوية (Banner)</span>
            </div>

            <div className="rounded-xl border border-[#CBDDF0] bg-[#F5F9FD] p-4 space-y-3">
              <div className="relative h-24 w-full rounded-lg overflow-hidden border border-[#B5CDE8] bg-gradient-to-b from-[#62B4F5] to-[#D7ECFC] flex items-center justify-center">
                {draft.bannerImage ? (
                  <img
                    src={draft.bannerImage}
                    alt="معاينة الترويسة"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-sm font-bold text-[#0E2A52]">
                    التصميم الافتراضي مفعل (ترويسة تجارية رسمية)
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleBannerUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={uploadingBanner}
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1669C9] hover:bg-[#1258B8] text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-60"
                >
                  <Upload className="w-4 h-4" />
                  <span>{uploadingBanner ? 'جارٍ المعالجة...' : 'رفع أو تغيير صورة الترويسة'}</span>
                </button>

                {draft.bannerImage && (
                  <button
                    type="button"
                    onClick={handleResetBanner}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white hover:bg-[#FEECEC] text-[#D11A2A] border border-[#F2B8BE] text-sm font-bold transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>استعادة الافتراضي</span>
                  </button>
                )}
              </div>
            </div>
          </section>

          {/* 2. Shop Footer Info */}
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-[#0E2A52] font-bold text-base">
              <MapPin className="w-4 h-4 text-[#1669C9]" />
              <span>بيانات المحل في تذييل الفاتورة (عند الطباعة)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-[#1D3B68] mb-1.5">
                  عنوان المحل
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-[#5D7B9E] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={draft.shopAddress}
                    onChange={(e) => setDraft({ ...draft, shopAddress: e.target.value })}
                    placeholder="مثال: بغداد - شارع الصناعة"
                    className="w-full pr-9 pl-3 py-2.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-[#1669C9]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-[#1D3B68] mb-1.5">
                  رقم هاتف المحل
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#5D7B9E] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    dir="ltr"
                    value={draft.shopPhone}
                    onChange={(e) => setDraft({ ...draft, shopPhone: e.target.value })}
                    placeholder="0770 000 0000"
                    className="w-full pr-9 pl-3 py-2.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] font-semibold text-sm text-right tabular-nums focus:outline-none focus:ring-2 focus:ring-[#1669C9]"
                  />
                </div>
              </div>
            </div>
          </section>

          {/* 3. Paper Size */}
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-[#0E2A52] font-bold text-base">
              <FileText className="w-4 h-4 text-[#1669C9]" />
              <span>حجم ورق الطباعة</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(
                [
                  {
                    value: 'A5_LANDSCAPE' as PaperSize,
                    title: 'ورق A5 عرضي (Landscape)',
                    desc: 'الافتراضي — مثالي لوصلات البيع القياسية',
                  },
                  {
                    value: 'A4_PORTRAIT' as PaperSize,
                    title: 'ورق A4 عمودي (Portrait)',
                    desc: 'مناسب للطابعات المكتبية والفواتير الطويلة',
                  },
                ] as const
              ).map((opt) => {
                const selected = draft.paperSize === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setDraft({ ...draft, paperSize: opt.value })}
                    className={`text-right p-3.5 rounded-xl border-2 transition-colors cursor-pointer flex items-start justify-between gap-2 ${
                      selected
                        ? 'border-[#1669C9] bg-[#EAF3FD]'
                        : 'border-[#D4E3F3] bg-white hover:border-[#9BBCE0]'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-sm text-[#0E2A52]">{opt.title}</div>
                      <div className="text-xs text-[#4A6587] mt-0.5">{opt.desc}</div>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                        selected
                          ? 'bg-[#1669C9] text-white'
                          : 'border-2 border-[#B5CDE8] bg-white'
                      }`}
                    >
                      {selected && <Check className="w-3.5 h-3.5" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 4. Direct Printer Settings (Electron Windows EXE Ready) */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#0E2A52] font-bold text-base">
                <Printer className="w-4 h-4 text-[#1669C9]" />
                <span>إعدادات الطابعة المباشرة</span>
              </div>

              {hasElectronPrinters && (
                <button
                  type="button"
                  onClick={fetchPrinters}
                  disabled={loadingPrinters}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#1669C9] hover:text-[#102E5A] cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingPrinters ? 'animate-spin' : ''}`} />
                  <span>تحديث القائمة</span>
                </button>
              )}
            </div>

            {hasElectronPrinters ? (
              <div className="rounded-xl border border-[#CBDDF0] bg-[#F5F9FD] p-4 space-y-4">
                <div>
                  <label className="block text-sm font-bold text-[#1D3B68] mb-1.5">
                    الطابعة الافتراضية
                  </label>
                  <select
                    value={draft.selectedPrinter}
                    onChange={(e) => setDraft({ ...draft, selectedPrinter: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-[#1669C9]"
                  >
                    <option value="">الطابعة الافتراضية للنظام (تلقائي)</option>
                    {printers.map((p) => (
                      <option key={p.name} value={p.name}>
                        {p.displayName || p.name}
                        {p.isDefault ? ' (الافتراضية)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <label className="flex items-center justify-between gap-3 cursor-pointer select-none pt-1">
                  <div>
                    <div className="font-bold text-sm text-[#0E2A52]">
                      الطباعة الفورية الصامتة (بدون نافذة معاينة)
                    </div>
                    <div className="text-xs text-[#4A6587]">
                      يرسل الفاتورة مباشرةً إلى الطابعة المختارة عند الضغط على "طباعة الفاتورة"
                    </div>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={draft.silentPrint}
                    onClick={() => setDraft({ ...draft, silentPrint: !draft.silentPrint })}
                    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors cursor-pointer ${
                      draft.silentPrint ? 'bg-[#289643]' : 'bg-[#B9C9DC]'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        draft.silentPrint ? '-translate-x-6' : '-translate-x-1'
                      }`}
                    />
                  </button>
                </label>
              </div>
            ) : (
              <div className="rounded-xl border border-[#CBDDF0] bg-[#F5F9FD] p-4 flex items-start gap-3">
                <Info className="w-5 h-5 text-[#1669C9] shrink-0 mt-0.5" />
                <div className="text-sm text-[#2A466D] leading-relaxed">
                  أنت تعمل حالياً من خلال المتصفح؛ عند ربط طابعة عبر كيبل USB، اخترها من نافذة
                  الطباعة وتأكد من تفعيل خيار <strong>رسومات الخلفية (Background Graphics)</strong>{' '}
                  عند الحاجة. عند تشغيل التطبيق كبرنامج سطح مكتب (Windows EXE / Electron)، ستظهر
                  قائمة طابعات الكيبل المثبتة وخيار الطباعة الصامتة تلقائياً هنا.
                </div>
              </div>
            )}

            {/* Quick USB / Cable Printer Test Print */}
            <div className="pt-1 flex items-center justify-between gap-3 flex-wrap">
              <span className="text-xs font-semibold text-[#4A6587]">
                تأكد من توصيل كيبل الطابعة وتشغيلها ثم اضغط لاختبار الطباعة الفورية:
              </span>
              <button
                type="button"
                onClick={() => onTestPrint(draft)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#0E2A52] bg-white hover:bg-[#F1F5F9] text-[#0E2A52] text-xs font-extrabold transition-colors cursor-pointer whitespace-nowrap"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة تجريبية لفحص الطابعة</span>
              </button>
            </div>
          </section>

          {/* Actions Footer */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#DCE8F5]">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-[#B5CDE8] bg-white hover:bg-[#F2F7FC] text-[#1D3B68] font-bold text-sm transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-[#289643] hover:bg-[#217D37] text-white font-bold text-sm transition-colors shadow-sm cursor-pointer"
            >
              حفظ الإعدادات
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
