import React from 'react';

export interface InvoiceAttachmentFieldProps {
  value?: string | null;
  onChange?: (dataUrl?: string) => void;
  allowUpload?: boolean;
  label?: string;
  helperText?: string;
  required?: boolean;
}

export const InvoiceAttachmentField: React.FC<InvoiceAttachmentFieldProps> = () => {
  // Completely disabled and removed as requested: "حذف حقل ارفاق الصور"
  return null;
};
