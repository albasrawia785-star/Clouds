import bcrypt from 'bcryptjs';
import { SupervisorPermissions, SupervisorUser, DEFAULT_SUPERVISOR_PERMISSIONS, User } from '../types';
import { queryTurso, saveOfflineUserVault } from './turso';
import { setSecuredPassword, getSecuredPassword } from '../utils/sanitize';

const SUPERVISORS_KEY_PREFIX = 'aldion_supervisors_mgr_';

export function getLocalSupervisors(parentManagerId: number): SupervisorUser[] {
  try {
    const raw = localStorage.getItem(`${SUPERVISORS_KEY_PREFIX}${parentManagerId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {}
  return [];
}

export function setLocalSupervisors(parentManagerId: number, list: SupervisorUser[]) {
  try {
    localStorage.setItem(`${SUPERVISORS_KEY_PREFIX}${parentManagerId}`, JSON.stringify(list));
  } catch {}
}

/**
 * جلب قائمة المشرفين التابعين للمدير الفرعي من السحابة والذاكرة المحلية
 */
export async function loadSupervisors(parentManagerId: number): Promise<SupervisorUser[]> {
  const local = getLocalSupervisors(parentManagerId);
  try {
    const sql = `SELECT id, username, phone_or_email, plain_password, is_active, permissions, branch_name, created_at 
                 FROM users 
                 WHERE role = 'supervisor' AND parent_manager_id = ? 
                 ORDER BY id DESC;`;
    let res;
    try {
      res = await queryTurso(sql, [parentManagerId]);
    } catch {
      await queryTurso("ALTER TABLE users ADD COLUMN parent_manager_id INTEGER;").catch(() => {});
      await queryTurso("ALTER TABLE users ADD COLUMN permissions TEXT;").catch(() => {});
      res = await queryTurso(sql, [parentManagerId]);
    }

    let rows: any[] = [];
    if (res?.results?.[0]?.response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }

    const cloudSupervisors: SupervisorUser[] = rows.map((r: any) => {
      const id = parseInt(r[0]?.value || '0', 10);
      const username = r[1]?.value || '';
      const name = r[2]?.value || username;
      const plainPassword = r[3]?.value || getSecuredPassword(id) || getSecuredPassword(username) || '';
      const isActiveVal = r[4]?.value;
      const isActive = isActiveVal === 0 || isActiveVal === '0' || isActiveVal === false ? false : true;
      let permissions = DEFAULT_SUPERVISOR_PERMISSIONS;
      if (r[5]?.value) {
        try {
          const parsed = typeof r[5].value === 'string' ? JSON.parse(r[5].value) : r[5].value;
          permissions = { ...DEFAULT_SUPERVISOR_PERMISSIONS, ...parsed };
        } catch {}
      }
      const branchName = r[6]?.value || '';
      const createdAt = r[7]?.value || new Date().toISOString();

      return {
        id,
        username,
        name,
        plainPassword,
        parentManagerId,
        branchName,
        isActive,
        permissions,
        createdAt,
      };
    });

    if (cloudSupervisors.length > 0 || local.length === 0) {
      setLocalSupervisors(parentManagerId, cloudSupervisors);
      // حفظ المشرفين أيضاً في خزينة أوفلاين
      cloudSupervisors.forEach((s) => {
        const u: User = {
          id: s.id,
          username: s.username,
          role: 'supervisor',
          branch_name: s.branchName,
          phoneOrEmail: s.name,
          password: s.plainPassword,
          isActive: s.isActive,
          parentManagerId: s.parentManagerId,
          permissions: s.permissions,
        };
        saveOfflineUserVault(u, s.plainPassword);
      });
      return cloudSupervisors;
    }
  } catch (err) {
    console.warn('Could not fetch supervisors from cloud, using cached:', err);
  }

  return local;
}

/**
 * إنشاء حساب مشرف جديد وتخزينه سحابياً ومحلياً
 */
export async function createSupervisor(
  parentManagerId: number,
  branchName: string,
  data: {
    username: string;
    name: string;
    password: string;
    permissions?: SupervisorPermissions;
  }
): Promise<SupervisorUser> {
  const cleanUser = data.username.trim();
  const cleanName = data.name.trim();
  const cleanPass = data.password.trim();
  const permissions = data.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;
  const permissionsJson = JSON.stringify(permissions);

  const hash = bcrypt.hashSync(cleanPass, 10);
  const tempId = Date.now();
  const now = new Date().toISOString();

  const newSupervisor: SupervisorUser = {
    id: tempId,
    username: cleanUser,
    name: cleanName,
    plainPassword: cleanPass,
    parentManagerId,
    branchName,
    isActive: true,
    permissions,
    createdAt: now,
  };

  // 1. التحديث المحلي الفوري (Instant Optimistic Local Storage)
  const current = getLocalSupervisors(parentManagerId);
  const updated = [newSupervisor, ...current.filter((s) => s.username.toLowerCase() !== cleanUser.toLowerCase())];
  setLocalSupervisors(parentManagerId, updated);

  // تخزين الأمان
  setSecuredPassword(tempId, cleanPass);
  setSecuredPassword(cleanUser, cleanPass);

  const vaultUser: User = {
    id: tempId,
    username: cleanUser,
    role: 'supervisor',
    branch_name: branchName,
    phoneOrEmail: cleanName,
    password: cleanPass,
    isActive: true,
    parentManagerId,
    permissions,
  };
  saveOfflineUserVault(vaultUser, cleanPass);

  // 2. المزامنة السحابية في جدول المستخدمين
  try {
    const insertSql = `INSERT INTO users (username, password, role, branch_name, phone_or_email, is_active, plain_password, parent_manager_id, permissions, created_at)
                       VALUES (?, ?, 'supervisor', ?, ?, 1, ?, ?, ?, ?)
                       ON CONFLICT(username) DO UPDATE SET
                         password=excluded.password,
                         branch_name=excluded.branch_name,
                         phone_or_email=excluded.phone_or_email,
                         is_active=excluded.is_active,
                         plain_password=excluded.plain_password,
                         parent_manager_id=excluded.parent_manager_id,
                         permissions=excluded.permissions;`;
    await queryTurso(insertSql, [
      cleanUser,
      hash,
      branchName,
      cleanName,
      cleanPass,
      parentManagerId,
      permissionsJson,
      now,
    ]);
  } catch (err: any) {
    try {
      await queryTurso("ALTER TABLE users ADD COLUMN parent_manager_id INTEGER;").catch(() => {});
      await queryTurso("ALTER TABLE users ADD COLUMN permissions TEXT;").catch(() => {});
      await queryTurso(
        `INSERT INTO users (username, password, role, branch_name, phone_or_email, is_active, plain_password, parent_manager_id, permissions, created_at)
         VALUES (?, ?, 'supervisor', ?, ?, 1, ?, ?, ?, ?);`,
        [cleanUser, hash, branchName, cleanName, cleanPass, parentManagerId, permissionsJson, now]
      );
    } catch (e) {
      console.warn("Could not save supervisor to cloud main DB:", e);
    }
  }

  return newSupervisor;
}

/**
 * تعديل أذونات أو بيانات المشرف
 */
export async function updateSupervisor(
  supervisorId: number,
  parentManagerId: number,
  data: {
    name?: string;
    password?: string;
    permissions?: SupervisorPermissions;
    isActive?: boolean;
  }
): Promise<SupervisorUser | null> {
  const current = getLocalSupervisors(parentManagerId);
  const target = current.find((s) => s.id === supervisorId);
  if (!target) return null;

  const cleanName = data.name !== undefined ? data.name.trim() : target.name;
  const cleanPass = data.password !== undefined && data.password.trim() ? data.password.trim() : target.plainPassword;
  const newPermissions = data.permissions !== undefined ? data.permissions : target.permissions;
  const newActive = data.isActive !== undefined ? data.isActive : target.isActive;

  const updatedSupervisor: SupervisorUser = {
    ...target,
    name: cleanName,
    plainPassword: cleanPass,
    permissions: newPermissions,
    isActive: newActive,
  };

  const updatedList = current.map((s) => (s.id === supervisorId ? updatedSupervisor : s));
  setLocalSupervisors(parentManagerId, updatedList);

  if (cleanPass) {
    setSecuredPassword(supervisorId, cleanPass);
    setSecuredPassword(target.username, cleanPass);
  }

  const vaultUser: User = {
    id: supervisorId,
    username: target.username,
    role: 'supervisor',
    branch_name: target.branchName,
    phoneOrEmail: cleanName,
    password: cleanPass,
    isActive: newActive,
    parentManagerId,
    permissions: newPermissions,
  };
  saveOfflineUserVault(vaultUser, cleanPass);

  // سحابياً
  try {
    const permissionsJson = JSON.stringify(newPermissions);
    let updateSql = `UPDATE users SET phone_or_email = ?, is_active = ?, permissions = ?`;
    const params: any[] = [cleanName, newActive ? 1 : 0, permissionsJson];

    if (data.password && data.password.trim()) {
      const hash = bcrypt.hashSync(data.password.trim(), 10);
      updateSql += `, password = ?, plain_password = ?`;
      params.push(hash, data.password.trim());
    }

    updateSql += ` WHERE (id = ? OR LOWER(username) = LOWER(?)) AND parent_manager_id = ?;`;
    params.push(supervisorId, target.username, parentManagerId);

    await queryTurso(updateSql, params);
  } catch (err) {
    console.warn("Could not update supervisor in cloud:", err);
  }

  return updatedSupervisor;
}

/**
 * حذف حساب المشرف نهائياً
 */
export async function deleteSupervisor(supervisorId: number, parentManagerId: number): Promise<void> {
  const current = getLocalSupervisors(parentManagerId);
  const target = current.find((s) => s.id === supervisorId);
  const updatedList = current.filter((s) => s.id !== supervisorId);
  setLocalSupervisors(parentManagerId, updatedList);

  try {
    const targetUser = target ? target.username : '';
    await queryTurso(
      `DELETE FROM users WHERE (id = ? OR LOWER(username) = LOWER(?)) AND parent_manager_id = ?;`,
      [supervisorId, targetUser, parentManagerId]
    );
  } catch (err) {
    console.warn("Could not delete supervisor from cloud:", err);
  }
}
