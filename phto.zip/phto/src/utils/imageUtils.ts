/**
 * Utility functions for handling single and multi-image attachments
 */

/**
 * Combines single invoiceImage string and invoiceImages array into a clean deduplicated list.
 */
export function normalizeInvoiceImages(
  singleImage?: string | string[] | null,
  multiImages?: string[] | null
): string[] {
  const result: string[] = [];

  if (Array.isArray(multiImages)) {
    multiImages.forEach((img) => {
      if (img && typeof img === 'string' && img.trim() && !result.includes(img.trim())) {
        result.push(img.trim());
      }
    });
  }

  if (singleImage) {
    if (Array.isArray(singleImage)) {
      (singleImage as string[]).forEach((img) => {
        if (img && typeof img === 'string' && img.trim() && !result.includes(img.trim())) {
          result.push(img.trim());
        }
      });
    } else if (typeof singleImage === 'string' && singleImage.trim()) {
      const trimmed = singleImage.trim();
      if (!result.includes(trimmed)) {
        result.unshift(trimmed);
      }
    }
  }

  return result;
}

/**
 * Compresses an image file client-side and returns a compressed JPEG Base64 Data URL.
 */
export function compressAndReadImage(
  file: File,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.75
): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) {
      return reject(new Error('Invalid image file'));
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed reading file'));
    reader.onload = (e) => {
      const src = e.target?.result as string;
      if (!src) return reject(new Error('Empty file result'));

      const img = new Image();
      img.onerror = () => reject(new Error('Failed loading image element'));
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          return resolve(src); // Fallback to raw data url if canvas ctx unavailable
        }

        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Reads and compresses multiple image files concurrently.
 */
export async function readMultipleImageFiles(
  files: FileList | File[] | null | undefined
): Promise<string[]> {
  if (!files || files.length === 0) return [];
  const fileArray = Array.from(files).filter((f) => f.type.startsWith('image/'));
  if (fileArray.length === 0) return [];

  const promises = fileArray.map((file) => compressAndReadImage(file).catch(() => ''));
  const results = await Promise.all(promises);
  return results.filter((url) => Boolean(url && url.length > 0));
}
