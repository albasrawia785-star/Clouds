import React, { useState, useRef } from 'react';
import { Camera, Image as ImageIcon, Trash2, Eye, Paperclip, Loader2, Plus, FileImage } from 'lucide-react';
import { InvoiceImageViewerModal } from './InvoiceImageViewerModal';
import { readMultipleImageFiles, normalizeInvoiceImages } from '../utils/imageUtils';

export interface InvoiceAttachmentFieldProps {
  value?: string | string[] | null;
  values?: string[] | null;
  onChange?: (images: string[] | string | undefined) => void;
  onChangeImages?: (images: string[]) => void;
  allowUpload?: boolean;
  label?: string;
  helperText?: string;
  required?: boolean;
  maxCount?: number;
}

export const InvoiceAttachmentField: React.FC<InvoiceAttachmentFieldProps> = ({
  value,
  values,
  onChange,
  onChangeImages,
  allowUpload = true,
  label = 'صور الفواتير / المستندات (اختياري)',
  helperText = 'يمكنك التقاط صورة أو تحديد عدة صور دفعة واحدة من المعرض',
  maxCount = 10,
}) => {
  const [compressing, setCompressing] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Derive current normalized image list
  const currentImages = normalizeInvoiceImages(value, values);

  // Respect admin permission check
  if (!allowUpload) {
    return null;
  }

  const handleNotifyChange = (newImages: string[]) => {
    if (onChangeImages) {
      onChangeImages(newImages);
    }
    if (onChange) {
      // If consumer expects string or array, passing newImages works seamlessly
      onChange(newImages.length > 0 ? (newImages as any) : undefined);
    }
  };

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setCompressing(true);
    try {
      const freshImages = await readMultipleImageFiles(files);
      if (freshImages.length > 0) {
        // Merge and cap at maxCount
        const combined = [...currentImages];
        freshImages.forEach((img) => {
          if (!combined.includes(img)) {
            combined.push(img);
          }
        });
        const capped = combined.slice(0, maxCount);
        handleNotifyChange(capped);
      }
    } catch (err) {
      console.error('Failed to compress images:', err);
      alert('حدث خطأ أثناء معالجة الصور. يرجى إعادة المحاولة.');
    } finally {
      setCompressing(false);
      if (e.target) e.target.value = '';
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    const updated = currentImages.filter((_, idx) => idx !== indexToRemove);
    handleNotifyChange(updated);
  };

  const handleOpenPreview = (index: number) => {
    setPreviewIndex(index);
    setPreviewModalOpen(true);
  };

  return (
    <div className="space-y-2 text-right dir-rtl">
      {/* Label Header */}
      <div className="flex items-center justify-between">
        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
          <Paperclip className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
          <span>{label}</span>
        </label>
        {currentImages.length > 0 && (
          <span className="text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
            <FileImage className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
            <span>
              تم إرفاق {currentImages.length} {currentImages.length === 1 ? 'صورة' : 'صور'}
            </span>
          </span>
        )}
      </div>

      {/* Hidden File Inputs supporting multiple files */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFilesSelected}
        accept="image/*"
        multiple
        className="hidden"
      />
      <input
        type="file"
        ref={cameraInputRef}
        onChange={handleFilesSelected}
        accept="image/*"
        capture="environment"
        className="hidden"
      />

      {/* Main Content Area */}
      {currentImages.length > 0 ? (
        <div className="space-y-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-3 shadow-2xs">
          {/* Thumbnails Grid */}
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
            {currentImages.map((imgUrl, idx) => (
              <div
                key={idx}
                className="relative group aspect-square rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 shadow-2xs hover:shadow-md transition-all"
              >
                <img
                  src={imgUrl}
                  alt={`المستند ${idx + 1}`}
                  className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
                />

                {/* Badge Number */}
                <span className="absolute top-1 right-1 bg-black/60 backdrop-blur-xs text-white text-[9.5px] font-bold px-1.5 py-0.5 rounded-md">
                  #{idx + 1}
                </span>

                {/* Overlay Action Buttons */}
                <div className="absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-1">
                  <button
                    type="button"
                    onClick={() => handleOpenPreview(idx)}
                    className="p-1.5 rounded-lg bg-white/90 text-slate-800 hover:bg-white hover:scale-110 active:scale-95 transition-all shadow-xs cursor-pointer"
                    title="معاينة المكبرة"
                  >
                    <Eye className="w-3.5 h-3.5 text-sky-600" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(idx)}
                    className="p-1.5 rounded-lg bg-rose-600/90 text-white hover:bg-rose-600 hover:scale-110 active:scale-95 transition-all shadow-xs cursor-pointer"
                    title="حذف هذه الصورة"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {/* Add More Photos Card inside Grid */}
            {currentImages.length < maxCount && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={compressing}
                className="aspect-square rounded-xl border-2 border-dashed border-sky-300 dark:border-sky-600/60 hover:border-sky-500 dark:hover:border-sky-400 bg-sky-50/50 dark:bg-sky-950/20 hover:bg-sky-100/50 dark:hover:bg-sky-900/30 transition-all flex flex-col items-center justify-center p-2 text-sky-700 dark:text-sky-300 gap-1 cursor-pointer"
              >
                {compressing ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Plus className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                    <span className="text-[10px] font-bold leading-tight text-center">إضافة المزيد</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* Action Row for Adding via Gallery / Camera */}
          <div className="pt-2 border-t border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              انقر على الصورة لمعاينتها أو حذفها
            </span>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                disabled={compressing}
                className="px-2.5 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                title="التقاط صورة جديدة بالكاميرا"
              >
                <Camera className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                <span>كاميرا</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={compressing}
                className="px-2.5 py-1.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
                title="اختيار صور إضافية من المعرض"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>إضافة صور</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Empty Upload Dropzone */
        <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-sky-400 dark:hover:border-sky-500 rounded-2xl p-4 bg-slate-50/60 dark:bg-slate-800/40 transition-all text-center space-y-2">
          {compressing ? (
            <div className="flex flex-col items-center justify-center py-2 space-y-1.5 text-sky-600 dark:text-sky-400">
              <Loader2 className="w-6 h-6 animate-spin" />
              <span className="text-xs font-bold">جاري ضغط وتجهيز الصور...</span>
            </div>
          ) : (
            <>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {helperText}
              </p>
              <div className="flex items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <ImageIcon className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                  <span>معرض الصور (تحديد متعدّد)</span>
                </button>
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Camera className="w-4 h-4 text-white" />
                  <span>التقاط بالكاميرا</span>
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* Full Screen Image Lightbox Viewer Modal */}
      {previewModalOpen && currentImages.length > 0 && (
        <InvoiceImageViewerModal
          isOpen={previewModalOpen}
          imageUrls={currentImages}
          initialIndex={previewIndex}
          title="معاينة صور الفاتورة / المستندات"
          onClose={() => setPreviewModalOpen(false)}
        />
      )}
    </div>
  );
};
