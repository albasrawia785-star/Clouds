import React, { useRef, useState } from 'react';
import { compressInvoiceImage, formatFileSize, estimateBase64Kb } from '../utils/imageCompressor';
import { InvoiceImageViewerModal } from './InvoiceImageViewerModal';

export interface InvoiceAttachmentFieldProps {
  value?: string | null;
  onChange: (dataUrl?: string) => void;
  allowUpload?: boolean;
  label?: string;
  helperText?: string;
  required?: boolean;
}

export const InvoiceAttachmentField: React.FC<InvoiceAttachmentFieldProps> = ({
  value,
  onChange,
  allowUpload = true,
  label = 'صورة الفاتورة / الوصل (اختياري)',
  helperText = 'يتم ضغط الصورة تلقائياً بجودة عالية وحجم خفيف جداً (~80 كيلوبايت)',
}) => {
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressionError, setCompressionError] = useState<string | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  // If uploading invoices is not permitted for this manager/user, hide completely
  if (!allowUpload) return null;

  const currentSizeKb = value ? estimateBase64Kb(value) : 0;

  const processSelectedFile = async (file: File) => {
    setCompressionError(null);

    // Validate that the chosen file is indeed an image (by MIME or by extension)
    const isImageMime = file.type && file.type.startsWith('image/');
    const isImageExt = /\.(jpe?g|png|webp|bmp|gif|heic|svg)$/i.test(file.name || '');

    if (!isImageMime && !isImageExt) {
      setCompressionError('الملف المختار ليس صورة صالحة. يرجى اختيار ملف بصيغة (JPG, PNG, WebP)');
      return;
    }

    setIsCompressing(true);

    try {
      const result = await compressInvoiceImage(file);
      onChange(result.dataUrl);
    } catch (err: any) {
      console.error('Invoice compression failed:', err);
      setCompressionError(err.message || 'فشل ضغط الصورة، يرجى تجربة صورة أخرى');
    } finally {
      setIsCompressing(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset input value so re-selecting the same file fires change event
    e.target.value = '';
    await processSelectedFile(file);
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(undefined);
    setCompressionError(null);
  };

  const handleTriggerGallery = () => {
    if (isCompressing) return;
    galleryInputRef.current?.click();
  };

  const handleTriggerCamera = () => {
    if (isCompressing) return;
    cameraInputRef.current?.click();
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processSelectedFile(file);
    }
  };

  return (
    <div className="space-y-1.5 pt-1">
      <div className="flex items-center justify-between text-xs font-bold text-slate-700">
        <span className="flex items-center gap-1.5">
          <i className="fa-solid fa-receipt text-blue-600 text-[11px]"></i>
          <span>{label}</span>
        </span>
        {value && (
          <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/80">
            {formatFileSize(currentSizeKb)} • جودة عالية
          </span>
        )}
      </div>

      {/* Hidden Gallery Input */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Hidden Direct Camera Input (capture=environment launches Camera immediately) */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* State 1: Compressing */}
      {isCompressing && (
        <div className="p-3 bg-blue-50/70 border border-blue-200/80 rounded-2xl flex items-center justify-center gap-2 text-xs font-bold text-blue-800 animate-pulse">
          <i className="fa-solid fa-circle-notch fa-spin text-blue-600"></i>
          <span>جاري تحسين وضغط صورة الفاتورة بدقة عالية...</span>
        </div>
      )}

      {/* State 2: Image Attached */}
      {!isCompressing && value && (
        <div className="p-2.5 bg-slate-50 border border-slate-200/90 rounded-2xl flex items-center justify-between gap-3 shadow-2xs">
          <div
            onClick={() => setIsViewerOpen(true)}
            className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
            title="انقر لتكبير ومعاينة الفاتورة"
          >
            <div className="w-12 h-12 rounded-xl border border-slate-200 bg-white shrink-0 relative shadow-2xs group-hover:ring-2 group-hover:ring-blue-500/50 transition-all overflow-hidden">
              <img
                src={value}
                alt="معاينة الفاتورة"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-slate-900/30 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs transition-opacity">
                <i className="fa-solid fa-magnifying-glass-plus"></i>
              </div>
            </div>

            <div className="min-w-0">
              <span className="text-xs font-bold text-slate-900 block truncate group-hover:text-blue-600 transition-colors">
                تم إرفاق الفاتورة بنجاح
              </span>
              <span className="text-[10.5px] text-slate-500 font-mono block">
                انقر للمعاينة والتكبير ({formatFileSize(currentSizeKb)})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setIsViewerOpen(true)}
              className="h-9 px-2.5 sm:px-3 rounded-xl bg-blue-50 hover:bg-blue-100 active:bg-blue-200 text-blue-700 text-xs font-bold border border-blue-200/80 transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 touch-manipulation shadow-2xs"
              title="معاينة وتكبير الفاتورة"
            >
              <i className="fa-solid fa-magnifying-glass-plus text-xs"></i>
              <span>تكبير</span>
            </button>

            <button
              type="button"
              onClick={handleTriggerCamera}
              className="h-9 px-2 sm:px-2.5 rounded-xl bg-white hover:bg-slate-100 active:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200 transition-all cursor-pointer flex items-center gap-1 active:scale-95 touch-manipulation shadow-2xs"
              title="إعادة التقاط صورة بالكاميرا"
            >
              <i className="fa-solid fa-camera text-xs text-blue-600"></i>
              <span className="hidden sm:inline">كاميرا</span>
            </button>

            <button
              type="button"
              onClick={handleTriggerGallery}
              className="h-9 px-2 sm:px-2.5 rounded-xl bg-white hover:bg-slate-100 active:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200 transition-all cursor-pointer flex items-center gap-1 active:scale-95 touch-manipulation shadow-2xs"
              title="استبدال من المعرض"
            >
              <i className="fa-solid fa-images text-xs text-emerald-600"></i>
              <span className="hidden sm:inline">معرض</span>
            </button>

            <button
              type="button"
              onClick={handleRemove}
              className="w-9 h-9 rounded-xl bg-rose-50 hover:bg-rose-100 active:bg-rose-200 text-rose-600 flex items-center justify-center transition-all cursor-pointer border border-rose-200/60 active:scale-95 touch-manipulation shadow-2xs"
              title="حذف الصورة"
            >
              <i className="fa-solid fa-trash-can text-xs"></i>
            </button>
          </div>
        </div>
      )}

      {/* State 3: No Image Attached (Dual Choice: Camera or Gallery) */}
      {!isCompressing && !value && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`transition-all rounded-2xl ${
            isDragging ? 'ring-2 ring-blue-500 bg-blue-50/60' : ''
          }`}
        >
          <div className="grid grid-cols-2 gap-2.5">
            {/* Button 1: Camera */}
            <button
              type="button"
              onClick={handleTriggerCamera}
              className="min-h-[52px] py-2.5 px-3 bg-white hover:bg-blue-50/60 active:bg-blue-100/70 border border-slate-200 hover:border-blue-400 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all cursor-pointer group shadow-2xs active:scale-[0.98] touch-manipulation"
              title="فتح الكاميرا والتقاط صورة الفاتورة فوراً"
            >
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-2xs border border-blue-100 group-hover:scale-105 transition-transform shrink-0">
                <i className="fa-solid fa-camera text-sm"></i>
              </div>
              <div className="text-right min-w-0">
                <span className="font-extrabold block text-slate-900 group-hover:text-blue-700 transition-colors truncate">
                  فتح الكاميرا
                </span>
                <span className="text-[10px] text-slate-400 font-normal block truncate">
                  التقاط فوري
                </span>
              </div>
            </button>

            {/* Button 2: Gallery */}
            <button
              type="button"
              onClick={handleTriggerGallery}
              className="min-h-[52px] py-2.5 px-3 bg-white hover:bg-emerald-50/60 active:bg-emerald-100/70 border border-slate-200 hover:border-emerald-400 rounded-2xl flex items-center gap-2.5 text-xs font-bold transition-all cursor-pointer group shadow-2xs active:scale-[0.98] touch-manipulation"
              title="اختيار صورة من استوديو الصور / المعرض"
            >
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-2xs border border-emerald-100 group-hover:scale-105 transition-transform shrink-0">
                <i className="fa-solid fa-images text-sm"></i>
              </div>
              <div className="text-right min-w-0">
                <span className="font-extrabold block text-slate-900 group-hover:text-emerald-700 transition-colors truncate">
                  استوديو الصور
                </span>
                <span className="text-[10px] text-slate-400 font-normal block truncate">
                  اختيار من المعرض
                </span>
              </div>
            </button>
          </div>
        </div>
      )}

      {compressionError && (
        <p className="text-[11px] font-bold text-rose-600 flex items-center gap-1 mt-1">
          <i className="fa-solid fa-circle-exclamation text-xs"></i>
          <span>{compressionError}</span>
        </p>
      )}

      {!value && !compressionError && helperText && (
        <p className="text-[10px] text-slate-400">
          {helperText}
        </p>
      )}

      {/* Lightbox Viewer */}
      {value && (
        <InvoiceImageViewerModal
          isOpen={isViewerOpen}
          onClose={() => setIsViewerOpen(false)}
          imageUrl={value}
          title="معاينة صورة الفاتورة"
        />
      )}
    </div>
  );
};
