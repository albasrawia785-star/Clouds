import React from 'react';
import { User } from '../types';
import { formatDateDigits } from '../utils/formatters';

interface SubscriptionExpiredModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
}

export const SubscriptionExpiredModal: React.FC<SubscriptionExpiredModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[99999] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn select-none"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-rose-200 dark:border-rose-900/50 text-center space-y-4 animate-scaleUp">
        {/* Header Icon */}
        <div className="w-14 h-14 rounded-2xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto shadow-inner border border-rose-200 dark:border-rose-800/40">
          <svg
            className="w-7 h-7"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
            />
          </svg>
        </div>

        {/* Title & Description */}
        <div className="space-y-1.5">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            انتهت صلاحية اشتراك الفرع
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-xs mx-auto">
            لقد انتهت فترة الاشتراك الشهري الخاصة بحساب الفرع بتاريخ{' '}
            <span className="font-mono font-bold text-rose-700 dark:text-rose-400 dir-ltr inline-block">
              {formatDateDigits(currentUser?.subscriptionExpiresAt)}
            </span>
            . تم إيقاف عمليات إضافة الأسماء وتسجيل الدفعات والتسديد لحين قيام الإدارة العامة بتجديد الاشتراك.
          </p>
        </div>

        {/* Account Details Summary */}
        <div className="bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-800/40 rounded-xl p-3 text-xs text-start space-y-2">
          <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
            <span className="text-slate-500 dark:text-slate-400">اسم الفرع:</span>
            <span className="font-bold text-slate-900 dark:text-white">
              {currentUser?.branch_name || 'الفرع'}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 border-t border-rose-200/50 dark:border-rose-800/30 pt-1.5">
            <span className="text-slate-500 dark:text-slate-400">اسم المستخدم:</span>
            <span className="font-bold font-mono text-slate-900 dark:text-white">
              @{currentUser?.username}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 border-t border-rose-200/50 dark:border-rose-800/30 pt-1.5">
            <span className="text-slate-500 dark:text-slate-400">حالة العمليات:</span>
            <span className="font-bold text-rose-700 dark:text-rose-400 bg-rose-100 dark:bg-rose-900/40 px-2 py-0.5 rounded">
              موقوف (قراءة فقط)
            </span>
          </div>
        </div>

        {/* Action Notice */}
        <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/40 rounded-xl text-[11px] text-amber-900 dark:text-amber-200 text-start flex items-start gap-2 leading-relaxed">
          <svg
            className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span>
            لتفعيل وتجديد الاشتراك واستئناف عمليات الإضافة والتسديد، يرجى التواصل مباشرة مع الإدارة العامة.
          </span>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <a
            href={`https://wa.me/?text=${encodeURIComponent(
              `مرحباً الإدارة العامة، أرجو تجديد الاشتراك الشهري لفرع: (${currentUser?.branch_name}) - اسم المستخدم: (${currentUser?.username})`
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z" />
            </svg>
            <span>طلب تجديد الاشتراك عبر واتساب الإدارة العامة</span>
          </a>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
