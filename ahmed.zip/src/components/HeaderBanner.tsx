import React, { useState } from 'react';
import { ClipboardList, Settings, Eye, Calendar, Clock } from 'lucide-react';

interface HeaderBannerProps {
  bannerImage: string | null;
  serialNumber: string;
  isSavedInvoice: boolean;
  dateDisplay: string;
  timeDisplay: string;
  savedCount: number;
  onOpenInventory: () => void;
  onOpenPreview: () => void;
  onOpenSettings: () => void;
}

/**
 * Authoritative enterprise desktop POS top bar.
 * Compact, single-row layout with clean unboxed metadata, clear visual hierarchy,
 * and optional custom uploaded shop banner strip.
 */
export const HeaderBanner: React.FC<HeaderBannerProps> = ({
  bannerImage,
  serialNumber,
  isSavedInvoice,
  dateDisplay,
  timeDisplay,
  savedCount,
  onOpenInventory,
  onOpenPreview,
  onOpenSettings,
}) => {
  const [imgError, setImgError] = useState(false);
  const showCustomBanner = Boolean(bannerImage) && !imgError;

  return (
    <header className="w-full bg-white border-b border-[#D8E1EC] select-none">
      {/* Subtle 3px brand identity accent line (Crimson + Gold + Deep Navy) */}
      <div aria-hidden="true" className="flex h-[3px] w-full">
        <div className="w-40 bg-[#C8102E]" />
        <div className="w-12 bg-[#C99712]" />
        <div className="flex-1 bg-[#0E2A52]" />
      </div>

      {/* Optional user-uploaded shop banner image strip */}
      {showCustomBanner && bannerImage && (
        <div className="relative w-full h-24 sm:h-28 overflow-hidden border-b border-[#D8E1EC]">
          <img
            src={bannerImage}
            alt="ترويسة أحمد القيسي للإطارات والبطاريات"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0E2A52]/40 via-transparent to-transparent" />
        </div>
      )}

      {/* Main Single-Row Commercial POS Bar */}
      <div className="max-w-[1380px] mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Zone 1: Brand Identity */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-1.5 h-10 bg-[#C8102E] rounded-xs shrink-0" aria-hidden="true" />
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-[#0E2A52] tracking-tight leading-none">
                أحمد القيسي
              </h1>
              <span className="text-sm sm:text-base font-bold text-[#C8102E] whitespace-nowrap">
                للإطارات والبطاريات
              </span>
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#64748B]">
              <span>جودة</span>
              <span aria-hidden="true">·</span>
              <span>ثقة</span>
              <span aria-hidden="true">·</span>
              <span>أسعار مناسبة</span>
            </div>
          </div>
        </div>

        {/* Zone 2: Quiet Unboxed Session Context (Serial · Date · Time) */}
        <div className="hidden lg:flex items-center gap-3 text-sm text-[#334155] tabular-nums">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-[#64748B]">
              {isSavedInvoice ? 'فاتورة محفوظة' : 'رقم الفاتورة'}
            </span>
            <span dir="ltr" className="font-extrabold text-[#0E2A52]">
              {serialNumber}
            </span>
          </div>
          <span className="text-[#CBD5E1]" aria-hidden="true">
            |
          </span>
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-[#64748B]" />
            <span dir="ltr" className="font-bold text-[#0E2A52]">
              {dateDisplay}
            </span>
          </div>
          <span className="text-[#CBD5E1]" aria-hidden="true">
            |
          </span>
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-[#64748B]" />
            <span className="font-bold text-[#0E2A52]">{timeDisplay}</span>
          </div>
        </div>

        {/* Zone 3: Primary Workspace Utilities */}
        <nav aria-label="أدوات النظام" className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenInventory}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFC] hover:border-[#94A3B8] text-[#0E2A52] text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <ClipboardList className="w-4 h-4 text-[#475569]" />
            <span>جرد وسجل الفواتير</span>
            {savedCount > 0 && (
              <span className="text-xs font-extrabold text-[#1258B8] tabular-nums">
                ({savedCount.toLocaleString('en-US')})
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onOpenPreview}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFC] hover:border-[#94A3B8] text-[#0E2A52] text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Eye className="w-4 h-4 text-[#475569]" />
            <span className="hidden sm:inline">معاينة الوصل</span>
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            className="inline-flex items-center justify-center p-2 rounded-lg border border-[#CBD5E1] bg-white hover:bg-[#F8FAFC] hover:border-[#94A3B8] text-[#334155] hover:text-[#0E2A52] transition-colors cursor-pointer"
            title="إعدادات النظام والطباعة"
            aria-label="إعدادات النظام والطباعة"
          >
            <Settings className="w-4.5 h-4.5" />
          </button>
        </nav>
      </div>
    </header>
  );
};
