import React, { useState, useMemo } from 'react';
import { Debtor, DebtorTransaction, User } from '../types';
import {
  formatNumber,
  formatIraqiPhoneNumber,
  formatDateDigits,
} from '../utils/formatters';
import { openWhatsAppDirect } from '../utils/whatsapp';
import { getPortalUrl } from '../utils/qrUtils';
import { isDemoDebtor } from '../utils/mockDebtors';
import { useI18n } from '../i18n/index.tsx';

interface DebtorShareModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  currentUser?: User | null;
  storeName?: string;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DebtorShareModal: React.FC<DebtorShareModalProps> = ({
  isOpen,
  debtor,
  currentUser,
  storeName,
  onClose,
  onShowToast,
}) => {
  const { t, numberFormat, getCurrencySymbol, dir } = useI18n();
  const [shareMode, setShareMode] = useState<'statement' | 'summary'>('statement');
  const [customPhone, setCustomPhone] = useState('');
  const [copied, setCopied] = useState(false);
  const [showBarcode, setShowBarcode] = useState<boolean>(false);

  // Compute portal URL
  const activePortalUrl = useMemo(() => {
    if (!debtor || isDemoDebtor(debtor)) return '';
    return getPortalUrl('debtor', debtor.id, debtor.phone);
  }, [debtor]);

  // Sync phone when debtor changes
  React.useEffect(() => {
    if (debtor?.phone) {
      setCustomPhone(debtor.phone);
    } else {
      setCustomPhone('');
    }
    setCopied(false);
  }, [debtor]);

  const defaultStoreName = t('common.appName', 'دفتر الديون والأقساط');
  const activeStoreName = storeName?.trim() || defaultStoreName;

  // Generate formatted text based on mode
  const generatedText = useMemo(() => {
    if (!debtor) return '';

    const currentBalance = debtor.amount || 0;
    const clientName = (debtor.name || '').trim();
    const currSym = getCurrencySymbol();

    // Build history list
    const rawHistory: DebtorTransaction[] = debtor.history && debtor.history.length > 0
      ? debtor.history
      : [
          {
            id: `initial-${debtor.id}`,
            debtorId: debtor.id,
            type: 'initial',
            amount: debtor.amount,
            balanceAfter: debtor.amount,
            date: debtor.createdAt || new Date().toISOString(),
            description: t('debtorShare.initialType', 'رصيد أولي'),
          },
        ];

    const sortedHistory = [...rawHistory].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    const totalAdded = rawHistory
      .filter((h) => h.type === 'add' || h.type === 'initial')
      .reduce((sum, h) => sum + h.amount, 0);

    const totalPaid = rawHistory
      .filter((h) => h.type === 'pay')
      .reduce((sum, h) => sum + h.amount, 0);

    const isCreditor = debtor.type === 'creditor';
    const issueDate = formatDateDigits(new Date().toISOString(), numberFormat);
    const isDemo = isDemoDebtor(debtor);
    const portalUrl = (isDemo || !showBarcode) ? '' : activePortalUrl;

    if (shareMode === 'statement') {
      if (isCreditor) {
        let text = `📑 كشف حساب مالي | رقم الحساب: #${debtor.id}\n`;
        text += `الجهة: ${clientName}\n`;
        text += `تاريخ الإصدار: ${issueDate}\n\n`;
        text += `الخلاصة المالية:\n`;
        text += `• المستحق لكم بذمتنا: ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
        text += `• إجمالي الإضافات: ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
        text += `• إجمالي المسدد لكم: ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;

        if (sortedHistory.length > 0) {
          text += `\nآخر سجل حركة:\n`;
          sortedHistory.slice(0, 5).forEach((tx) => {
            const typeLabel =
              tx.type === 'pay'
                ? 'تسديد لكم'
                : tx.type === 'initial'
                ? 'رصيد أولي'
                : 'إضافة مبلغ';
            const sign = tx.type === 'pay' ? '-' : '+';
            const dateStr = formatDateDigits(tx.date, numberFormat);
            text += `• ${typeLabel} (${sign}${formatNumber(tx.amount, numberFormat)} ${currSym}) — ${dateStr}\n`;
          });
        }

        if (!isDemo && portalUrl) {
          text += `\nلـعرض البوابة المباشرة لكشف الحساب والتفاصيل كاملة:\n`;
          text += `${portalUrl}\n\n`;
        } else {
          text += `\n`;
        }
        text += `— ${activeStoreName} | النظام المالي المعتمد`;
        return text;
      } else {
        let text = `📑 كشف حساب مالي | رقم الحساب: #${debtor.id}\n`;
        text += `الاسم: ${clientName}\n`;
        text += `تاريخ الإصدار: ${issueDate}\n\n`;
        text += `الخلاصة المالية:\n`;
        text += `• المبلغ المتبقي: ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
        text += `• إجمالي الديون: ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
        text += `• إجمالي الدفعات المسددة: ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;

        if (sortedHistory.length > 0) {
          text += `\nآخر سجل حركة:\n`;
          sortedHistory.slice(0, 5).forEach((tx) => {
            const typeLabel =
              tx.type === 'pay'
                ? 'تسديد'
                : tx.type === 'initial'
                ? 'رصيد أولي'
                : 'دين جديد';
            const sign = tx.type === 'pay' ? '-' : '+';
            const dateStr = formatDateDigits(tx.date, numberFormat);
            text += `• ${typeLabel} (${sign}${formatNumber(tx.amount, numberFormat)} ${currSym}) — ${dateStr}\n`;
          });
        }

        if (!isDemo && portalUrl) {
          text += `\nلـعرض البوابة المباشرة لكشف الحساب والتفاصيل كاملة:\n`;
          text += `${portalUrl}\n\n`;
        } else {
          text += `\n`;
        }
        text += `— ${activeStoreName} | النظام المالي المعتمد`;
        return text;
      }
    } else {
      // Summary mode
      let text = `📑 إشعار حساب مالي | #${debtor.id}\n`;
      text += `الاسم: ${clientName}\n`;
      text += `تاريخ الإصدار: ${issueDate}\n\n`;
      if (isCreditor) {
        text += `• إجمالي المبلغ المستحق لكم: ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
      } else {
        text += `• المبلغ المتبقي المستحق: ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
      }
      if (!isDemo && portalUrl) {
        text += `\nلـعرض البوابة المباشرة لكشف الحساب بالتفصيل:\n`;
        text += `${portalUrl}\n\n`;
      } else {
        text += `\n`;
      }
      text += `— ${activeStoreName} | النظام المالي المعتمد`;
      return text;
    }
  }, [shareMode, debtor, activeStoreName, t, numberFormat, getCurrencySymbol, activePortalUrl, showBarcode]);

  // If not open or no debtor, return null after all hooks have been invoked
  if (!isOpen || !debtor) return null;

  const currentBalance = debtor.amount || 0;

  const handleCopyText = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(generatedText);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = generatedText;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      onShowToast(t('toast.copiedToClipboard', 'تم النسخ إلى الحافظة بنجاح'), 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onShowToast(t('toast.copyFailed', 'تعذر نسخ النص إلى الحافظة'), 'error');
    }
  };

  const handleSendWhatsApp = () => {
    const targetPhone = customPhone.trim() || debtor.phone?.trim();
    if (!targetPhone) {
      onShowToast(t('toast.phoneRequiredWhatsApp', 'يرجى تحديد أو كتابة رقم هاتف العميل أولاً للإرسال عبر واتساب'), 'error');
      return;
    }

    const formatted = formatIraqiPhoneNumber(targetPhone);
    if (!formatted || formatted.length < 9) {
      onShowToast(t('toast.invalidPhone', 'رقم الهاتف غير صالح'), 'error');
      return;
    }

    openWhatsAppDirect(formatted, generatedText);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${t('debtorShare.modalTitle', 'كشف حساب')} - ${debtor.name}`,
          text: generatedText,
        });
        onShowToast(t('toast.copiedToClipboard', 'تمت المشاركة بنجاح'), 'success');
      } catch {
        // User cancelled or share failed silently
      }
    } else {
      handleCopyText();
    }
  };

  const handleDownloadOrShareQR = async () => {
    if (!debtor) return;
    const portalUrl = activePortalUrl || getPortalUrl('debtor', debtor.id);
    const qrImgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(portalUrl)}`;

    try {
      onShowToast('جاري تحضير صورة الباركود للمشاركة...', 'info');
      const response = await fetch(qrImgUrl);
      const blob = await response.blob();
      const cleanName = (debtor.name || 'حساب').replace(/[\s/\\:*?"<>|]+/g, '_');
      const fileName = `باركود_كشف_حساب_${cleanName}_#${debtor.id}.png`;
      const file = new File([blob], fileName, { type: 'image/png' });

      if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: `باركود كشف حساب - ${debtor.name}`,
          text: `رمز كشف الحساب المباشر الخاص بالسيد/الجهة: ${debtor.name}`,
          files: [file],
        });
        onShowToast('تم مشاركة صورة الباركود بنجاح', 'success');
        return;
      }

      // Fallback: trigger direct file download
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
      onShowToast('تم تحميل صورة الباركود بنجاح', 'success');
    } catch (err) {
      console.warn('Direct file share failed, opening image in tab:', err);
      window.open(qrImgUrl, '_blank');
      onShowToast('تم فتح صورة الباركود للمشاركة والتحميل', 'info');
    }
  };

  return (
    <div
      id="debtorShareModalBackdrop"
      className="fixed inset-0 bg-slate-950/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      onClick={onClose}
      dir={dir}
    >
      <div
        id="debtorShareModal"
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <span>{t('debtorShare.modalTitle', 'مشاركة كشف الحساب المالي')}</span>
            </h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-slate-600">
                {t('common.name', 'العميل')}: <strong className="text-slate-900 font-bold">{debtor.name}</strong>
              </span>
              <span className="text-slate-300">•</span>
              <span className="text-xs font-bold text-slate-800 bg-slate-100 border border-slate-200/90 px-2 py-0.5 rounded-md font-mono dir-ltr">
                {formatNumber(currentBalance, numberFormat)} {getCurrencySymbol()}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-300 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs transition-colors cursor-pointer"
            title={t('common.close', 'إغلاق')}
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* Format Selector Tabs */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              {t('common.status', 'صيغة ونوع الرسالة')}:
            </label>
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-2xl border border-slate-200/60">
              <button
                type="button"
                onClick={() => setShareMode('statement')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  shareMode === 'statement'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-file-invoice-dollar text-xs"></i>
                <span>{t('debtorShare.statementMode', 'كشف حساب تفصيلي')}</span>
              </button>
              <button
                type="button"
                onClick={() => setShareMode('summary')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  shareMode === 'summary'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-bell text-xs"></i>
                <span>{t('debtorShare.summaryMode', 'تذكير مباشر وتفاصيل الدين')}</span>
              </button>
            </div>
          </div>

          {/* Optional Phone input if empty or needs correction */}
          <div>
            <div className="mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-phone text-[11px] text-slate-400"></i>
                <span>{t('debtorShare.recipientPhone', 'رقم هاتف المستلم (واتساب):')}</span>
              </label>
            </div>
            <input
              type="tel"
              value={customPhone}
              onChange={(e) => setCustomPhone(e.target.value)}
              placeholder="07XXXXXXXXX"
              className="w-full py-2.5 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white text-left dir-ltr transition-colors"
            />
          </div>

          {/* QR Code Visual Card & Toggle Switch (Real accounts only) */}
          {!isDemoDebtor(debtor) && (
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-3 shadow-xs">
              {/* Toggle switch for showing / hiding barcode */}
              <div className="flex items-center justify-between">
                <label
                  onClick={() => setShowBarcode(!showBarcode)}
                  className="text-xs font-bold text-slate-800 flex items-center gap-2 cursor-pointer select-none"
                >
                  <i className="fa-solid fa-qrcode text-blue-600 text-sm"></i>
                  <span>إظهار الباركود والرابط المباشر في الرسالة</span>
                </label>
                <button
                  type="button"
                  dir="ltr"
                  onClick={() => setShowBarcode(!showBarcode)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    showBarcode ? 'bg-blue-600' : 'bg-slate-300'
                  }`}
                  role="switch"
                  aria-checked={showBarcode}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                      showBarcode ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {showBarcode && (
                <div className="space-y-3 pt-2 border-t border-slate-200/60 animate-in fade-in duration-150">
                  <div className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-slate-200/70">
                    <div className="bg-white p-1.5 rounded-xl shrink-0 border border-slate-200 shadow-xs">
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(activePortalUrl)}`}
                        alt="QR Code"
                        className="w-13 h-13 object-contain rounded-md"
                        onError={(e) => {
                          e.currentTarget.src = `https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl=${encodeURIComponent(activePortalUrl)}`;
                        }}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-0.5">
                        <i className="fa-solid fa-qrcode text-blue-600"></i>
                        <span>بوابة كشف الحساب المباشر (QR)</span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono truncate dir-ltr text-left">
                        {activePortalUrl.replace(/^https?:\/\//, '')}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        يتيح للعميل فتح الرابط المباشر لمتابعة حسابه الحقيقي على جميع الأجهزة
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons: Copy Link & Share/Download QR Code Image */}
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-200/60">
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await navigator.clipboard.writeText(activePortalUrl);
                          onShowToast('تم نسخ رابط كشف الحساب المباشر بنجاح', 'success');
                        } catch {
                          onShowToast('تعذر نسخ الرابط', 'error');
                        }
                      }}
                      className="flex-1 py-2 px-3 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs active:scale-98"
                      title="نسخ رابط كشف الحساب"
                    >
                      <i className="fa-regular fa-copy text-xs text-blue-600"></i>
                      <span>نسخ الرابط</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleDownloadOrShareQR}
                      className="flex-1 py-2 px-3 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200/90 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs active:scale-98"
                      title="إرسال أو تحميل صورة الباركود"
                    >
                      <i className="fa-solid fa-qrcode text-xs text-blue-600"></i>
                      <span>إرسال صورة الباركود</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Formatted Text Preview */}
          <div>
            <div className="mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-regular fa-message text-[11px] text-slate-400"></i>
                <span>{t('debtorShare.preview', 'معاينة نص كشف الحساب للمشاركة:')}</span>
              </label>
            </div>

            <div className="relative group">
              <textarea
                readOnly
                value={generatedText}
                rows={7}
                className="w-full p-3.5 bg-slate-50 border border-slate-200/90 rounded-2xl text-[12px] leading-relaxed text-slate-800 font-sans resize-none focus:outline-none select-all"
              />
              <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                <span>{t('debtorShare.readyToSend', 'النص منسق وجاهز للإرسال الفوري')}</span>
                <span>{generatedText.length} {t('debtorShare.characters', 'حرف')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-2.5">
          {/* WhatsApp Primary Action Button */}
          <button
            type="button"
            id="btnShareWhatsApp"
            onClick={handleSendWhatsApp}
            className="flex-1 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fa-brands fa-whatsapp text-base"></i>
            <span>إرسال الكشف عبر واتساب</span>
          </button>

          {/* Copy Formatted Text Button */}
          <button
            type="button"
            id="btnCopyFormattedStatement"
            onClick={handleCopyText}
            className={`py-3 px-4 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer border ${
              copied
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 active:scale-[0.99] shadow-xs'
            }`}
          >
            <i className={`fa-regular ${copied ? 'fa-circle-check text-emerald-600' : 'fa-copy text-blue-600'}`}></i>
            <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
          </button>

          {/* Native Share button (if supported) */}
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              type="button"
              id="btnNativeShare"
              onClick={handleNativeShare}
              className="py-3 px-3.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-slate-200"
              title="تطبيقات أخرى"
            >
              <i className="fa-solid fa-share-nodes text-xs text-slate-500"></i>
              <span className="hidden sm:inline">تطبيقات أخرى</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
