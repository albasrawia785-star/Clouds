import { User } from '../types';

/**
 * Returns a dynamically translated display name for a user based on the current active language.
 */
export function getUserDisplayName(
  user: User | null | undefined,
  t?: (key: string, fallback?: string, params?: Record<string, string | number>) => string
): string {
  if (!user) return '';
  const tr = t || ((_k: string, fb?: string) => fb || '');
  if (user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) {
    return tr('login.trialUsername', 'حساب تجريبي');
  }
  if (user.role === 'admin' && (user.username === 'admin' || !user.username)) {
    return tr('settings.adminRole', 'مدير عام');
  }
  if (user.role === 'supervisor') {
    return user.name ? `${user.name} (${user.username})` : user.username;
  }
  return user.username;
}

/**
 * Returns a dynamically translated display branch name for a user based on the current active language.
 */
export function getUserBranchDisplayName(
  user: User | null | undefined,
  t?: (key: string, fallback?: string, params?: Record<string, string | number>) => string
): string {
  if (!user) return '';
  const tr = t || ((_k: string, fb?: string) => fb || '');
  if (user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) {
    if (user.allowedModules === 'debts') {
      return tr('login.trialDebtsBranch', 'تجريبي - دفتر الديون');
    }
    if (user.allowedModules === 'installments') {
      return tr('login.trialInstallmentsBranch', 'تجريبي - نظام الأقساط');
    }
    return tr('login.trialBothBranch', 'تجريبي - شامل النظامين');
  }
  if (user.role === 'admin') {
    if (
      !user.branch_name ||
      user.branch_name === 'الإدارة العامة' ||
      user.branch_name === 'General Administration' ||
      user.branch_name === 'بەڕێوەبەرایەتی گشتی' ||
      user.branch_name === 'main_admin'
    ) {
      return tr('header.adminManagement', 'الإدارة العامة');
    }
    return user.branch_name;
  }
  if (user.role === 'supervisor') {
    return user.branch_name ? `${user.branch_name} (مشرف مفوض)` : 'مشرف فرع';
  }
  return user.branch_name || tr('settings.mainBranch', 'الفرع الرئيسي');
}

/**
 * Returns a dynamically translated display role badge for a user based on the current active language.
 */
export function getUserRoleDisplayName(
  user: User | null | undefined,
  t?: (key: string, fallback?: string, params?: Record<string, string | number>) => string
): string {
  if (!user) return '';
  const tr = t || ((_k: string, fb?: string) => fb || '');
  if (user.role === 'admin') {
    return tr('settings.adminRole', 'مدير عام');
  }
  if (user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) {
    return tr('settings.trialRole', 'حساب تجريبي');
  }
  if (user.role === 'supervisor') {
    return 'مشرف / موظف مفوض';
  }
  return tr('settings.managerRole', 'مدير فرع');
}

