const ONES = [
  '',
  'واحد',
  'اثنان',
  'ثلاثة',
  'أربعة',
  'خمسة',
  'ستة',
  'سبعة',
  'ثمانية',
  'تسعة',
  'عشرة',
  'أحد عشر',
  'اثنا عشر',
  'ثلاثة عشر',
  'أربعة عشر',
  'خمسة عشر',
  'ستة عشر',
  'سبعة عشر',
  'ثمانية عشر',
  'تسعة عشر',
];

const TENS = [
  '',
  '',
  'عشرون',
  'ثلاثون',
  'أربعون',
  'خمسون',
  'ستون',
  'سبعون',
  'ثمانون',
  'تسعون',
];

const HUNDREDS = [
  '',
  'مائة',
  'مائتان',
  'ثلاثمائة',
  'أربعمائة',
  'خمسمائة',
  'ستمائة',
  'سبعمائة',
  'ثمانمائة',
  'تسعمائة',
];

function convertUnder1000(num: number): string {
  const parts: string[] = [];
  const h = Math.floor(num / 100);
  const rem = num % 100;

  if (h > 0) {
    parts.push(HUNDREDS[h]);
  }

  if (rem > 0) {
    if (rem < 20) {
      parts.push(ONES[rem]);
    } else {
      const ones = rem % 10;
      const tens = Math.floor(rem / 10);
      if (ones > 0) {
        parts.push(`${ONES[ones]} و${TENS[tens]}`);
      } else {
        parts.push(TENS[tens]);
      }
    }
  }

  return parts.join(' و');
}

function formatScaleGroup(
  groupValue: number,
  singular: string,
  dual: string,
  plural: string
): string {
  if (groupValue === 0) return '';
  if (groupValue === 1) return singular;
  if (groupValue === 2) return dual;
  if (groupValue >= 3 && groupValue <= 10) {
    return `${convertUnder1000(groupValue)} ${plural}`;
  }
  return `${convertUnder1000(groupValue)} ${singular}`;
}

/**
 * Converts an integer Iraqi Dinar amount into formal Arabic commercial receipt wording (التفقيط).
 * Example: 646000 -> "فقط ستمائة وستة وأربعون ألف دينار عراقي لا غير"
 */
export function numberToArabicIqdWords(rawAmount: number): string {
  const amount = Number.isFinite(rawAmount) ? Math.max(0, Math.round(rawAmount)) : 0;
  if (amount === 0) {
    return 'صفر دينار عراقي';
  }

  const billions = Math.floor(amount / 1_000_000_000);
  const millions = Math.floor((amount % 1_000_000_000) / 1_000_000);
  const thousands = Math.floor((amount % 1_000_000) / 1_000);
  const remainder = amount % 1_000;

  const segments: string[] = [];

  if (billions > 0) {
    segments.push(formatScaleGroup(billions, 'مليار', 'ملياران', 'مليارات'));
  }
  if (millions > 0) {
    segments.push(formatScaleGroup(millions, 'مليون', 'مليونان', 'ملايين'));
  }
  if (thousands > 0) {
    segments.push(formatScaleGroup(thousands, 'ألف', 'ألفان', 'آلاف'));
  }
  if (remainder > 0) {
    segments.push(convertUnder1000(remainder));
  }

  return `فقط ${segments.join(' و')} دينار عراقي لا غير`;
}
