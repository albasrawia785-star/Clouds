import { Debtor, InstallmentRecord } from '../types';
import { formatFullDateTime } from './formatters';
import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';
import { getPortalUrl } from './qrUtils';
import { isTrialOrLocalUser, getLocalSession } from '../services/turso';

export function formatNoticeDateTime(dateStr?: string | null): string {
  if (!dateStr) {
    const d = new Date();
    return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
  }
  try {
    const rawDate = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr.split(' ')[0];
    const parts = rawDate.split('-');
    if (parts.length === 3 && parts[0].length === 4) {
      return `${parts[0]}/${parts[1].padStart(2, '0')}/${parts[2].padStart(2, '0')}`;
    }
  } catch {
    // fallback
  }
  return dateStr.split('T')[0].replace(/-/g, '/');
}

/**
 * Formats a phone number for WhatsApp URL.
 * Handles Iraqi phone numbers (07xxxxxxxxx -> 9647xxxxxxxxx)
 * and cleans up any spaces, dashes, or non-numeric characters.
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Handle + prefix
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // Handle 00964...
  if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  }

  // If starts with 07..., convert to 9647...
  if (cleaned.startsWith('07')) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.length === 10 && cleaned.startsWith('7')) {
    cleaned = '964' + cleaned;
  }

  return cleaned;
}

/**
 * Generates the full WhatsApp URL for sending a message using the universal HTTPS protocol.
 * Using https://api.whatsapp.com/send works natively on Web, iOS, Android, and APK WebViews
 * without throwing ERR_UNKNOWN_URL_SCHEME errors.
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  const safeMessage = (message || '')
    .replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F]/g, '')
    .trim()
    .slice(0, 3800);
  const encodedText = encodeURIComponent(safeMessage);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * Opens any WhatsApp URL safely and directly.
 * Uses Android Intent on Android devices to launch the WhatsApp app directly
 * and prevents the in-app WebView from intercepting redirects with ERR_UNKNOWN_URL_SCHEME.
 */
export async function openWhatsAppUrlDirect(url: string): Promise<boolean> {
  if (!url) return false;
  try {
    const targetUrl = url.trim();

    // Extract phone and text
    let phone = '';
    let text = '';
    try {
      let cleanUrl = targetUrl;
      if (cleanUrl.startsWith('whatsapp://')) {
        cleanUrl = cleanUrl.replace(/^whatsapp:\/\/?(send\/?)?/, 'https://api.whatsapp.com/send');
      }
      const u = new URL(cleanUrl.startsWith('http') ? cleanUrl : `https://${cleanUrl}`);
      phone = u.searchParams.get('phone') || u.pathname.replace(/^\//, '').split('?')[0] || '';
      text = u.searchParams.get('text') || '';
    } catch {
      const mPhone = targetUrl.match(/[?&]phone=([^&]+)/) || targetUrl.match(/wa\.me\/([^?]+)/);
      const mText = targetUrl.match(/[?&]text=([^&]+)/);
      if (mPhone) phone = decodeURIComponent(mPhone[1]);
      if (mText) text = decodeURIComponent(mText[1]);
    }

    const cleanPhone = formatPhoneNumberForWhatsApp(phone);
    const encodedText = encodeURIComponent(text);
    const apiWhatsAppUrl = cleanPhone
      ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`
      : `https://api.whatsapp.com/send?text=${encodedText}`;
    const androidIntentUrl = cleanPhone
      ? `intent://send?phone=${cleanPhone}&text=${encodedText}#Intent;scheme=whatsapp;package=com.whatsapp;end`
      : `intent://send?text=${encodedText}#Intent;scheme=whatsapp;package=com.whatsapp;end`;

    const waNativeUrl = cleanPhone
      ? `whatsapp://send?phone=${cleanPhone}&text=${encodedText}`
      : `whatsapp://send?text=${encodedText}`;

    const isIOS = typeof navigator !== 'undefined' && /iPhone|iPad|iPod/i.test(navigator.userAgent);
    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
    const isCapacitor = Capacitor.isNativePlatform() || (typeof window !== 'undefined' && !!(window as any).Capacitor);

    // 1. Capacitor Native Platform (Android / iOS app)
    if (isCapacitor) {
      try {
        await Browser.open({ url: waNativeUrl, windowName: '_system' });
        return true;
      } catch {
        try {
          window.location.href = waNativeUrl;
          return true;
        } catch (capErr) {
          console.warn('Capacitor WhatsApp launch warning:', capErr);
        }
      }
    }

    // 2. iOS Safari / iOS PWA / iOS WebViews: direct native scheme redirect to open WhatsApp app immediately
    if (isIOS) {
      try {
        const waMeUrl = cleanPhone
          ? `https://wa.me/${cleanPhone}?text=${encodedText}`
          : `https://api.whatsapp.com/send?text=${encodedText}`;

        // Directly trigger the native WhatsApp protocol
        window.location.href = waNativeUrl;

        // Fallback to wa.me only if WhatsApp is not installed after timeout
        setTimeout(() => {
          if (document.visibilityState === 'visible') {
            window.location.href = waMeUrl;
          }
        }, 500);

        return true;
      } catch (iosErr) {
        console.warn('iOS WhatsApp launch warning:', iosErr);
      }
    }

    // 3. Android Web / Android WebView / Android APK: direct native scheme trigger
    if (isAndroid) {
      try {
        // Direct location navigation triggers WhatsApp app immediately without opening Chrome web preview page
        window.location.href = waNativeUrl;

        // Fallback to intent URL for WebViews if scheme was intercepted
        setTimeout(() => {
          if (document.visibilityState === 'visible') {
            try {
              window.location.href = androidIntentUrl;
            } catch {}
          }
        }, 400);

        return true;
      } catch (androidErr) {
        console.warn('Android WhatsApp scheme trigger failed:', androidErr);
      }
    }

    // 4. Desktop Web / other browsers
    try {
      const desktopWebUrl = cleanPhone
        ? `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`
        : apiWhatsAppUrl;
      const a = document.createElement('a');
      a.href = desktopWebUrl;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        if (document.body.contains(a)) {
          document.body.removeChild(a);
        }
      }, 200);
      return true;
    } catch {
      window.location.href = apiWhatsAppUrl;
      return true;
    }
    return true;
  } catch (err) {
    console.warn('Could not open WhatsApp URL directly:', err);
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Directly opens WhatsApp without any intermediate UI or scheme errors
 */
export async function openWhatsAppDirect(phone: string, message: string): Promise<boolean> {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  if (!formattedPhone) return false;

  const safeMessage = (message || '')
    .replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F]/g, '')
    .trim()
    .slice(0, 3800);
  const encodedText = encodeURIComponent(safeMessage);

  const webUrl = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
  return openWhatsAppUrlDirect(webUrl);
}

export interface WhatsAppNotificationData {
  customerName: string;
  phone: string;
  title: string;
  message: string;
  url: string;
}

/**
 * Helper to identify whether a record is a demo/sample account.
 * For demo accounts, no portal URLs or statement links are attached.
 */
export function isDemoRecord(record: any): boolean {
  try {
    const session = getLocalSession();
    if (
      session &&
      (session.subscriptionType === 'trial' ||
        session.subscriptionType === 'local_permanent' ||
        session.role === 'trial' ||
        session.id === 999999 ||
        session.isGuest ||
        session.isNewRegistration)
    ) {
      return true;
    }
  } catch {}
  if (!record) return false;
  if (record.isDemo === true) return true;
  if (typeof record.id === 'number' && record.id < 0) return true;
  if (typeof record.id === 'string' && (record.id.startsWith('demo-') || record.id.includes('demo'))) return true;
  if (typeof record.phone === 'string' && (record.phone.includes('*') || record.phone.includes('X') || record.phone === '077********')) return true;
  if (typeof record.name === 'string' && (record.name.includes('(تجريبي)') || record.name.includes('تجريبي'))) return true;
  if (isTrialOrLocalUser(record?.userId || record?.user_id, record)) return true;
  return false;
}

/**
 * Helper to build the payment options block when electronic payment is enabled in Settings
 */
export function getPaymentMethodsBlock(mastercardNumber?: string, enableElectronicPayment?: boolean): string {
  if (enableElectronicPayment === false) return '';
  if (!mastercardNumber || !mastercardNumber.trim()) return '';
  return `\n\n━━━━━━━━━━━━━━━━━━━\nطرق التسديد المتاحة:\n• نقداً (كاش)\n• إلكترونياً (ماستر كارد):\n💳 رقم الماستر كارد: ${mastercardNumber.trim()}\n(يرجى إرسال إشعار التحويل بعد الإيداع لتأكيد السداد)\n━━━━━━━━━━━━━━━━━━━`;
}

export function formatPaymentMethodLabel(paymentMethod?: string): string {
  if (!paymentMethod) return 'نقداً (كاش)';
  return paymentMethod === 'electronic' ? 'دفع إلكتروني (ماستر كارد)' : 'نقداً (كاش)';
}

/**
 * 1. عند إضافة عميل مدين جديد (New Debtor)
 */
export function createNewDebtorWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  _storeName: string = 'دفتر الديون',
  mastercardNumber?: string,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dateStr = debtor.createdAt
    ? debtor.createdAt.split('T')[0]
    : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const notesStr = debtor.notes && debtor.notes.trim() ? `\nالملاحظات: ${debtor.notes.trim()}` : '';
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);
  const isDemo = isDemoRecord(debtor);
  const portalBlock = (isDemo || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('debtor', debtor.id, debtor.phone)}`;

  const message = `السيد/ ${debtor.name}${companyLine} المحترم

نوع العملية: تسجيل دين

تم فتح حساب مالي باسمكم وتسجيل مبلغ مستحق بذمتكم بتاريخ ${dateStr}.

إجمالي المبلغ المستحق بذمتكم: ${formattedAmount} ${currencySymbol}${notesStr}

يرجى تسديد المبلغ المستحق في أقرب وقت ممكن.${paymentBlock}${portalBlock}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار تسجيل دين',
    message,
    url,
  };
}

/**
 * 2. عند إضافة دين إضافي لعميل مدين (Add Debt)
 */
export function createAddDebtWhatsAppNotice(
  debtor: Debtor,
  addedAmount: number,
  newTotalAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون',
  mastercardNumber?: string,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const previousAmount = Math.max(0, newTotalAmount - (addedAmount || 0));
  const formattedPrevious = previousAmount.toLocaleString('en-US');
  const formattedAdded = (addedAmount || 0).toLocaleString('en-US');
  const formattedTotal = newTotalAmount.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(txDate);

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const notesStr = notes && notes.trim() ? `\nالملاحظات: ${notes.trim()}` : '';
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);
  const isDemo = isDemoRecord(debtor);
  const portalBlock = (isDemo || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('debtor', debtor.id, debtor.phone)}`;

  const message = `السيد/ ${debtor.name}${companyLine}

نوع العملية: إضافة دين

تم تحديث حسابكم وإضافة مبلغ جديد بتاريخ ووقت ${dateStr}.

• الدين السابق: ${formattedPrevious} ${currencySymbol}
• المبلغ المضاف الجديد: ${formattedAdded} ${currencySymbol}
• إجمالي المبلغ المستحق بذمتكم: ${formattedTotal} ${currencySymbol}${notesStr}

يرجى تسديد المبلغ المستحق بأقرب وقت ممكن.${paymentBlock}${portalBlock}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار إضافة دين',
    message,
    url,
  };
}

/**
 * 3. عند تسديد دفعة من عميل مدين (Pay Debt - سند قبض)
 */
export function createPayDebtWhatsAppNotice(
  debtor: Debtor,
  paidAmount: number,
  remainingAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون',
  paymentMethod?: string,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const previousAmount = (remainingAmount || 0) + (paidAmount || 0);
  const formattedPrevious = previousAmount.toLocaleString('en-US');
  const formattedPaid = (paidAmount || 0).toLocaleString('en-US');
  const formattedRemaining = remainingAmount.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(txDate);

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const notesStr = notes && notes.trim() ? `\nالملاحظات: ${notes.trim()}` : '';
  const methodStr = formatPaymentMethodLabel(paymentMethod);
  const isDemo = isDemoRecord(debtor);
  const portalBlock = (isDemo || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('debtor', debtor.id, debtor.phone)}`;

  const message = `السيد/ ${debtor.name}${companyLine} المحترم
سند قبض مالي 🧾

تم بنجاح تسجيل استلام دفعة من حسابكم:
• الدين قبل التسديد: ${formattedPrevious} ${currencySymbol}
• المبلغ المسدد: ${formattedPaid} ${currencySymbol}
• طريقة الدفع: ${methodStr}
• التاريخ والوقت: ${dateStr}
• إجمالي المبلغ المتبقي بذمتكم: ${formattedRemaining} ${currencySymbol}${notesStr}

شكراً لتعاملكم وحسن التزامكم.${portalBlock}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'سند قبض - تسديد دفعة',
    message,
    url,
  };
}

/**
 * 4. عند إضافة عقد قسط جديد (New Installment)
 */
export function createNewInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  currencySymbol: string,
  storeName: string = 'نظام الأقساط',
  mastercardNumber?: string,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedTotal = Number(inst.totalAmount || 0).toLocaleString('en-US');
  const formattedDown = Number(inst.downPayment || 0).toLocaleString('en-US');
  const formattedRemaining = Number(inst.remainingAmount || 0).toLocaleString('en-US');
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);
  const isDemo = isDemoRecord(inst);
  const portalBlock = (isDemo || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('installment', inst.id, inst.phone)}`;

  const message = `مرحباً ${inst.name}
تم تسجيل معاملة قسط جديدة لكم لدى (${storeName}):

السلعة: ${inst.item}
إجمالي قيمة الأقساط: ${formattedTotal} ${currencySymbol}
الدفعة المقدمة: ${formattedDown} ${currencySymbol}
المبلغ المتبقي: ${formattedRemaining} ${currencySymbol}
تاريخ القسط القادم: ${inst.nextDueDate}
${inst.notes ? `ملاحظات: ${inst.notes}\n` : ''}${paymentBlock}${portalBlock}

شكراً لثقتكم بنا.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'تسجيل معاملة قسط جديدة',
    message,
    url,
  };
}

/**
 * 5. عند تسديد قسط (Pay Installment)
 */
export function createPayInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  paidAmount: number,
  newRemaining: number,
  nextDueDate: string,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  storeName: string = 'نظام الأقساط',
  paymentMethod?: string,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const previousRemaining = (newRemaining || 0) + (paidAmount || 0);
  const formattedPrevious = previousRemaining.toLocaleString('en-US');
  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemaining.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(payDate);
  const methodStr = formatPaymentMethodLabel(paymentMethod);
  const isDemo = isDemoRecord(inst);
  const portalBlock = (isDemo || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('installment', inst.id, inst.phone)}`;

  const isCompleted = newRemaining <= 0;
  const statusLine = isCompleted
    ? 'تم تسديد كامل الأقساط بنجاح واكتمل العقد بالكامل.'
    : `• إجمالي المتبقي الكلي بذمتكم: ${formattedRemaining} ${currencySymbol}\n• موعد القسط القادم: ${nextDueDate}`;

  const message = `مرحباً ${inst.name}
إيصال تسديد قسط لدى (${storeName}):

السلعة: ${inst.item}
• المبلغ المتبقي السابق: ${formattedPrevious} ${currencySymbol}
• المبلغ المسدد الآن: ${formattedPaid} ${currencySymbol}
• طريقة الدفع: ${methodStr}
• تاريخ ووقت الدفع: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}${portalBlock}

شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'إيصال تسديد قسط',
    message,
    url,
  };
}

/**
 * 6. عند تسجيل دائن جديد في دفتر الديون (الذين يطلبوني)
 */
export function createNewSupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  notes?: string,
  _itemType?: string,
  supplierId?: number,
  isDemoProp?: boolean,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(new Date().toISOString());
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const isDemo = isDemoProp || isDemoRecord({ id: supplierId, phone: supplierPhone, name: supplierName });
  const portalBlock = (isDemo || !supplierId || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('supplier', supplierId, supplierPhone)}`;

  const message = `إشعار حساب دائن
السيد/ ${supplierName}${companyLine}

تم تسجيل مبلغ مستحق لكم بذمتنا، وفق التفاصيل التالية:

• المبلغ المقيد: ${formattedAmount} ${currencySymbol}
• تاريخ ووقت القيد: ${dateStr}
• إجمالي المستحق لكم: ${formattedAmount} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}${portalBlock}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار حساب دائن',
    message,
    url,
  };
}

/**
 * 6.b. عند إضافة دين جديد للدائن (قيد مالي إضافي)
 */
export function createAddSupplierDebtWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  addedAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  notes?: string,
  _itemType?: string,
  txDate?: string,
  supplierId?: number,
  isDemoProp?: boolean,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const previousAmount = Math.max(0, (newRemainingAmount || 0) - (addedAmount || 0));
  const formattedPrevious = previousAmount.toLocaleString('en-US');
  const formattedAdded = Number(addedAmount || 0).toLocaleString('en-US');
  const formattedTotal = Number(newRemainingAmount || 0).toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(txDate);
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const isDemo = isDemoProp || isDemoRecord({ id: supplierId, phone: supplierPhone, name: supplierName });
  const portalBlock = (isDemo || !supplierId || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('supplier', supplierId, supplierPhone)}`;

  const message = `السيد/ ${supplierName}${companyLine}
إشعار إضافة مبلغ

تم تسجيل مبلغ مستحق لكم بذمتنا:

• الرصيد السابق لكم: ${formattedPrevious} ${currencySymbol}
• المبلغ المضاف الجديد: ${formattedAdded} ${currencySymbol}
• التاريخ والوقت: ${dateStr}
• إجمالي المستحق لكم: ${formattedTotal} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}${portalBlock}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار إضافة مبلغ',
    message,
    url,
  };
}

/**
 * 7. عند تسديد دفعة مالية للدائن
 */
export function createPaySupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  paidAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  _itemType?: string,
  paymentMethod?: string,
  supplierId?: number,
  isDemoProp?: boolean,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const previousAmount = (newRemainingAmount || 0) + (paidAmount || 0);
  const formattedPrevious = previousAmount.toLocaleString('en-US');
  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemainingAmount.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(payDate);
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';
  const methodStr = formatPaymentMethodLabel(paymentMethod);

  const isDemo = isDemoProp || isDemoRecord({ id: supplierId, phone: supplierPhone, name: supplierName });
  const portalBlock = (isDemo || !supplierId || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('supplier', supplierId, supplierPhone)}`;

  const message = `السيد/ ${supplierName}${companyLine}
إشعار تسديد دفعة 🧾

تم تسجيل تسديد دفعة مالية من حسابكم:

• الرصيد المستحق السابق: ${formattedPrevious} ${currencySymbol}
• المبلغ المسدد: ${formattedPaid} ${currencySymbol}
• طريقة الدفع: ${methodStr}
• التاريخ والوقت: ${dateStr}
• المتبقي المستحق لكم: ${formattedRemaining} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}${portalBlock}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار تسديد',
    message,
    url,
  };
}

/**
 * 8. تذكير أو مطابقة رصيد حساب دائن
 */
export function createSupplierReminderWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  _itemType?: string,
  supplierId?: number,
  isDemoProp?: boolean,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const isDemo = isDemoProp || isDemoRecord({ id: supplierId, phone: supplierPhone, name: supplierName });
  const portalBlock = (isDemo || !supplierId || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('supplier', supplierId, supplierPhone)}`;

  const message = `إشعار مطابقة رصيد حساب دائن

السيد/ ${supplierName}${companyLine}
تحية طيبة وبعد،

نود إشعاركم بمطابقة رصيد حسابكم المالي المسجل لدينا:

• إجمالي الرصيد المستحق لكم: ${formattedAmount} ${currencySymbol}${portalBlock}`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار مطابقة رصيد دائن',
    message,
    url,
  };
}

/**
 * 9. تذكير ودّي بالدين المستحق للعميل المدين
 */
export function createDebtorReminderWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  _storeName: string = 'دفتر الديون',
  mastercardNumber?: string,
  enablePortalLink: boolean = true
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);
  const isDemo = isDemoRecord(debtor);
  const portalBlock = (isDemo || enablePortalLink === false)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('debtor', debtor.id, debtor.phone)}`;

  const dateStr = debtor.lastDebtDate
    ? formatNoticeDateTime(debtor.lastDebtDate)
    : (debtor as any).lastTransactionDate
    ? formatNoticeDateTime((debtor as any).lastTransactionDate)
    : debtor.createdAt
    ? formatNoticeDateTime(debtor.createdAt)
    : new Date().toISOString().split('T')[0];

  const message = `السيد/ ${debtor.name}${companyLine} المحترم
تحية طيبة وبعد،

نود تذكيركم بلطف برصيد الحساب المالي المسجل لدينا:

• إجمالي الدين المستحق بذمتكم: ${formattedAmount} ${currencySymbol}
• تاريخ آخر حركة: ${dateStr}

يرجى تسديد المبلغ عند التيسر.${paymentBlock}${portalBlock}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'تذكير ودّي بالدين المستحق',
    message,
    url,
  };
}
