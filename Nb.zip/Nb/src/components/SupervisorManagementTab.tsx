import React, { useState, useEffect, useMemo } from 'react';
import {
  User,
  Debtor,
  InstallmentRecord,
  Supplier,
  SupervisorUser,
  SupervisorPermissions,
  DEFAULT_SUPERVISOR_PERMISSIONS,
  FULL_SUPERVISOR_PERMISSIONS,
  ADD_AND_PAY_ONLY_PERMISSIONS,
  VIEW_ONLY_SUPERVISOR_PERMISSIONS,
} from '../types';
import { loadSupervisors, createSupervisor, updateSupervisor, deleteSupervisor } from '../services/supervisorService';
import { formatDateDigits, formatNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { openWhatsAppUrlDirect } from '../utils/whatsapp';

interface SupervisorManagementTabProps {
  currentUser: User;
  allDebtors: Debtor[];
  installments: InstallmentRecord[];
  suppliers: Supplier[];
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

interface AuditLogItem {
  id: string;
  supervisorName: string;
  system: 'debtor' | 'creditor' | 'installment' | 'supplier';
  systemLabel: string;
  actionType: 'add' | 'pay' | 'delete' | 'edit';
  actionLabel: string;
  customerName: string;
  amount: number;
  date: string;
  notes?: string;
}

type PermissionPresetKey = 'full' | 'add_pay_only' | 'view_only' | 'custom';

// Helper to identify preset type from permissions object
function detectPermissionPreset(perms?: SupervisorPermissions): PermissionPresetKey {
  if (!perms) return 'add_pay_only';

  const isFull =
    perms.canAddDebts &&
    perms.canAddPayments &&
    perms.canEditDebtors &&
    perms.canDeleteDebtors &&
    perms.canManageInstallments &&
    perms.canManageSuppliers &&
    perms.canUploadInvoices &&
    perms.canExportData;

  if (isFull) return 'full';

  const isAddPayOnly =
    perms.canAddDebts &&
    perms.canAddPayments &&
    perms.canManageInstallments &&
    perms.canManageSuppliers &&
    !perms.canEditDebtors &&
    !perms.canDeleteDebtors;

  if (isAddPayOnly) return 'add_pay_only';

  const isViewOnly =
    !perms.canAddDebts &&
    !perms.canAddPayments &&
    !perms.canEditDebtors &&
    !perms.canDeleteDebtors &&
    !perms.canManageInstallments &&
    !perms.canManageSuppliers &&
    !perms.canUploadInvoices;

  if (isViewOnly) return 'view_only';

  return 'custom';
}

function getPresetInfo(preset: PermissionPresetKey) {
  switch (preset) {
    case 'full':
      return {
        key: 'full' as PermissionPresetKey,
        title: 'كامل الصلاحيات',
        subtitle: 'إمكانية الإضافة والتسديد والتعديل والحذف وإدارة جميع الأقسام',
        badgeText: '🛡️ كامل الصلاحيات',
        badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        icon: 'fa-shield-check',
        color: 'emerald',
      };
    case 'add_pay_only':
      return {
        key: 'add_pay_only' as PermissionPresetKey,
        title: 'إضافة وتسديد فقط (بدون تعديل أو حذف)',
        subtitle: 'يمكنه إضافة الديون والأسماء وتسجيل الدفعات، ويُمْنَع من التعديل والحذف',
        badgeText: '📝 إضافة وتسديد فقط',
        badgeBg: 'bg-blue-50 text-blue-800 border-blue-200',
        icon: 'fa-pen-to-square',
        color: 'blue',
      };
    case 'view_only':
      return {
        key: 'view_only' as PermissionPresetKey,
        title: 'عرض ومتابعة فقط (مشاهدة)',
        subtitle: 'يرى كافة البيانات والقوائم، وعند محاولة الإضافة أو التسديد ينبهه النظام بأنها لمدير الحساب',
        badgeText: '👁️ عرض ومتابعة فقط',
        badgeBg: 'bg-indigo-50 text-indigo-800 border-indigo-200',
        icon: 'fa-eye',
        color: 'indigo',
      };
    case 'custom':
    default:
      return {
        key: 'custom' as PermissionPresetKey,
        title: 'صلاحيات مخصصة',
        subtitle: 'تحديد الخيارات والأذونات الفردية يدوياً لمتطلبات خاصة',
        badgeText: '⚙️ صلاحيات مخصصة',
        badgeBg: 'bg-amber-50 text-amber-800 border-amber-200',
        icon: 'fa-sliders',
        color: 'amber',
      };
  }
}

export const SupervisorManagementTab: React.FC<SupervisorManagementTabProps> = ({
  currentUser,
  allDebtors,
  installments,
  suppliers,
  onShowToast,
}) => {
  const { numberFormat, dir } = useI18n();

  const [supervisors, setSupervisors] = useState<SupervisorUser[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Modal / Form state for adding new supervisor
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [supName, setSupName] = useState<string>('');
  const [supPhone, setSupPhone] = useState<string>('');
  const [supPassword, setSupPassword] = useState<string>('');
  const [addPresetKey, setAddPresetKey] = useState<PermissionPresetKey>('add_pay_only');
  const [addPermissions, setAddPermissions] = useState<SupervisorPermissions>(ADD_AND_PAY_ONLY_PERMISSIONS);
  const [showAddCustomDetails, setShowAddCustomDetails] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Modal state for editing existing supervisor permissions
  const [editingPermissionsSupervisor, setEditingPermissionsSupervisor] = useState<SupervisorUser | null>(null);
  const [editPresetKey, setEditPresetKey] = useState<PermissionPresetKey>('add_pay_only');
  const [editPermissions, setEditPermissions] = useState<SupervisorPermissions>(ADD_AND_PAY_ONLY_PERMISSIONS);
  const [showEditCustomDetails, setShowEditCustomDetails] = useState<boolean>(false);
  const [isSavingPermissions, setIsSavingPermissions] = useState<boolean>(false);

  // Modal state for deleting supervisor confirmation
  const [deletingSupervisor, setDeletingSupervisor] = useState<SupervisorUser | null>(null);
  const [isDeletingSupervisor, setIsDeletingSupervisor] = useState<boolean>(false);

  // Filter state for Audit Log Feed
  const [auditSystemFilter, setAuditSystemFilter] = useState<'all' | 'debtor' | 'creditor' | 'installment' | 'supplier'>('all');
  const [auditSupervisorFilter, setAuditSupervisorFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Password editing state per supervisor
  const [editingPasswordId, setEditingPasswordId] = useState<number | null>(null);
  const [editingPasswordInput, setEditingPasswordInput] = useState<string>('');
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, boolean>>({});

  const parentManagerId =
    currentUser.role === 'supervisor' && currentUser.parentManagerId
      ? currentUser.parentManagerId
      : currentUser.id;

  // Load supervisors on mount or when parentManagerId changes
  const fetchSupervisors = async () => {
    try {
      setLoading(true);
      const list = await loadSupervisors(parentManagerId);
      setSupervisors(list);
    } catch (err) {
      console.warn('Failed loading supervisors:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSupervisors();
  }, [parentManagerId]);

  // Helper to map preset selection
  const handleSelectAddPreset = (preset: PermissionPresetKey) => {
    setAddPresetKey(preset);
    if (preset === 'full') {
      setAddPermissions(FULL_SUPERVISOR_PERMISSIONS);
      setShowAddCustomDetails(false);
    } else if (preset === 'add_pay_only') {
      setAddPermissions(ADD_AND_PAY_ONLY_PERMISSIONS);
      setShowAddCustomDetails(false);
    } else if (preset === 'view_only') {
      setAddPermissions(VIEW_ONLY_SUPERVISOR_PERMISSIONS);
      setShowAddCustomDetails(false);
    } else {
      setShowAddCustomDetails(true);
    }
  };

  const handleSelectEditPreset = (preset: PermissionPresetKey) => {
    setEditPresetKey(preset);
    if (preset === 'full') {
      setEditPermissions(FULL_SUPERVISOR_PERMISSIONS);
      setShowEditCustomDetails(false);
    } else if (preset === 'add_pay_only') {
      setEditPermissions(ADD_AND_PAY_ONLY_PERMISSIONS);
      setShowEditCustomDetails(false);
    } else if (preset === 'view_only') {
      setEditPermissions(VIEW_ONLY_SUPERVISOR_PERMISSIONS);
      setShowEditCustomDetails(false);
    } else {
      setShowEditCustomDetails(true);
    }
  };

  const handleOpenEditPermissions = (sup: SupervisorUser) => {
    setEditingPermissionsSupervisor(sup);
    const p = sup.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;
    const detected = detectPermissionPreset(p);
    setEditPresetKey(detected);
    setEditPermissions(p);
    setShowEditCustomDetails(detected === 'custom');
  };

  const handleSaveEditedPermissionsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPermissionsSupervisor) return;
    try {
      setIsSavingPermissions(true);
      await updateSupervisor(editingPermissionsSupervisor.id, parentManagerId, {
        permissions: editPermissions,
      });

      setSupervisors((prev) =>
        prev.map((s) => (s.id === editingPermissionsSupervisor.id ? { ...s, permissions: editPermissions } : s))
      );

      setEditingPermissionsSupervisor(null);
      if (onShowToast) {
        onShowToast(`تم تحديث صلاحيات المشرف (${editingPermissionsSupervisor.name}) بنجاح!`, 'success');
      }
    } catch (err: any) {
      if (onShowToast) onShowToast(err.message || 'فشل تحديث صلاحيات المشرف', 'error');
    } finally {
      setIsSavingPermissions(false);
    }
  };

  // Helper to map any username, phone, or raw string to supervisor's real full name
  const resolveSupervisorDisplayName = React.useCallback(
    (rawName: string): string => {
      if (!rawName || !rawName.trim()) return 'المشرف';
      const clean = rawName.trim();
      const matched = supervisors.find(
        (s) =>
          s.name === clean ||
          s.username === clean ||
          (s as any).phoneOrEmail === clean ||
          String(s.id) === clean
      );
      if (matched && matched.name) {
        return matched.name;
      }
      return clean;
    },
    [supervisors]
  );

  // Aggregate Audit Logs from all 4 systems
  const auditLogs = useMemo<AuditLogItem[]>(() => {
    const logs: AuditLogItem[] = [];

    // 1. Debtors & Creditors History
    allDebtors.forEach((debtor) => {
      const isCreditor = debtor.type === 'creditor';
      const history = debtor.history || [];
      history.forEach((tx) => {
        if (tx.performedBy && tx.performedBy.trim()) {
          const resolvedName = resolveSupervisorDisplayName(tx.performedBy);
          const rawType = (tx as any).type || 'add';
          const isPay = rawType === 'pay';
          const isEdit = rawType === 'edit';
          const isDelete = rawType === 'delete';
          const actType: 'add' | 'pay' | 'delete' | 'edit' = isPay ? 'pay' : isEdit ? 'edit' : isDelete ? 'delete' : 'add';
          const actLabel = isPay
            ? 'تسديد دين'
            : isEdit
            ? 'تعديل بيانات العميل'
            : isDelete
            ? 'حذف حساب / دين'
            : rawType === 'add'
            ? 'إضافة دين جديد'
            : 'فتح حساب';

          logs.push({
            id: `debtor-tx-${tx.id || Math.random()}`,
            supervisorName: resolvedName,
            system: isCreditor ? 'creditor' : 'debtor',
            systemLabel: isCreditor ? 'سجل ديون عليّ' : 'دفتر الديون',
            actionType: actType,
            actionLabel: actLabel,
            customerName: debtor.name,
            amount: tx.amount || 0,
            date: tx.date || debtor.createdAt || new Date().toISOString(),
            notes: tx.description || tx.notes,
          });
        }
      });
    });

    // 2. Installments Payments
    installments.forEach((inst) => {
      const payments = inst.payments || [];
      payments.forEach((pay) => {
        if (pay.performedBy && pay.performedBy.trim()) {
          const resolvedName = resolveSupervisorDisplayName(pay.performedBy);
          logs.push({
            id: `inst-pay-${pay.id || Math.random()}`,
            supervisorName: resolvedName,
            system: 'installment',
            systemLabel: 'نظام الأقساط',
            actionType: 'pay',
            actionLabel: 'تسديد قسط',
            customerName: `${inst.name} (${inst.item})`,
            amount: pay.amount || 0,
            date: pay.date || inst.registrationDate || new Date().toISOString(),
            notes: pay.notes,
          });
        }
      });
    });

    // 3. Suppliers History
    suppliers.forEach((sup) => {
      const history = sup.history || [];
      history.forEach((tx) => {
        if (tx.performedBy && tx.performedBy.trim()) {
          const resolvedName = resolveSupervisorDisplayName(tx.performedBy);
          const isPay = tx.type === 'pay' || tx.type === 'pay_supplier';
          logs.push({
            id: `sup-tx-${tx.id || Math.random()}`,
            supervisorName: resolvedName,
            system: 'supplier',
            systemLabel: 'نظام الموردين',
            actionType: isPay ? 'pay' : 'add',
            actionLabel: isPay ? 'تسديد حساب للمورد' : 'إضافة فواتير ومستحقات لمورد',
            customerName: `${sup.name}${sup.companyName ? ` (${sup.companyName})` : ''}`,
            amount: tx.amount || 0,
            date: tx.date || sup.createdAt || new Date().toISOString(),
            notes: tx.description || tx.notes,
          });
        }
      });
    });

    // Sort newest first
    return logs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [allDebtors, installments, suppliers, resolveSupervisorDisplayName]);

  // Unique supervisor names found in audit logs
  const uniqueAuditSupervisorNames = useMemo<string[]>(() => {
    const setNames = new Set<string>();
    auditLogs.forEach((log) => {
      if (log.supervisorName) setNames.add(log.supervisorName);
    });
    return Array.from(setNames);
  }, [auditLogs]);

  // Helper to determine if a name belongs to a Manager / Account Owner or a sub-supervisor
  const isManagerAccount = React.useCallback(
    (name: string) => {
      if (!name) return true;
      const clean = name.trim();
      if (
        clean === '7777' ||
        clean === currentUser.username ||
        clean === currentUser.name ||
        clean === currentUser.branch_name ||
        clean === 'المدير' ||
        clean === 'مدير الحساب' ||
        clean === 'مدير الفرع'
      ) {
        return true;
      }
      const isSupervisor = supervisors.some(
        (s) => s.name === clean || s.username === clean || (s as any).phoneOrEmail === clean || String(s.id) === clean
      );
      return !isSupervisor;
    },
    [currentUser, supervisors]
  );

  // Filtered Audit Logs
  const filteredAuditLogs = useMemo<AuditLogItem[]>(() => {
    return auditLogs.filter((log) => {
      // System filter
      if (auditSystemFilter !== 'all') {
        if (auditSystemFilter === 'creditor' && log.system !== 'creditor') return false;
        if (auditSystemFilter === 'debtor' && log.system !== 'debtor') return false;
        if (auditSystemFilter === 'installment' && log.system !== 'installment') return false;
        if (auditSystemFilter === 'supplier' && log.system !== 'supplier') return false;
      }

      // Supervisor filter
      if (auditSupervisorFilter !== 'all' && log.supervisorName !== auditSupervisorFilter) {
        return false;
      }

      // Search term
      if (searchTerm.trim()) {
        const term = searchTerm.trim().toLowerCase();
        const matchCust = log.customerName.toLowerCase().includes(term);
        const matchSup = log.supervisorName.toLowerCase().includes(term);
        const matchAct = log.actionLabel.toLowerCase().includes(term);
        const matchSys = log.systemLabel.toLowerCase().includes(term);
        const matchNotes = (log.notes || '').toLowerCase().includes(term);
        if (!matchCust && !matchSup && !matchAct && !matchSys && !matchNotes) return false;
      }

      return true;
    });
  }, [auditLogs, auditSystemFilter, auditSupervisorFilter, searchTerm]);

  // Grouped audit logs per supervisor
  const groupedAuditLogsBySupervisor = useMemo(() => {
    const map = new Map<string, AuditLogItem[]>();

    filteredAuditLogs.forEach((log) => {
      const name = log.supervisorName || 'أخرى';
      if (!map.has(name)) {
        map.set(name, []);
      }
      map.get(name)!.push(log);
    });

    const groups: { supervisorName: string; logs: AuditLogItem[]; totalAmount: number; totalCount: number }[] = [];

    if (auditSupervisorFilter !== 'all') {
      const logs = map.get(auditSupervisorFilter) || [];
      const totalAmount = logs.reduce((sum, item) => sum + (item.amount || 0), 0);
      groups.push({
        supervisorName: auditSupervisorFilter,
        logs: logs.slice(0, 200),
        totalCount: logs.length,
        totalAmount,
      });
      return groups;
    }

    map.forEach((logs, supervisorName) => {
      const totalAmount = logs.reduce((sum, item) => sum + (item.amount || 0), 0);
      groups.push({
        supervisorName,
        logs: logs.slice(0, 200),
        totalCount: logs.length,
        totalAmount,
      });
    });

    return groups;
  }, [filteredAuditLogs, auditSupervisorFilter]);

  // Create New Supervisor Handler
  const handleCreateSupervisorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanName = supName.trim();
    const cleanPhone = supPhone.trim();
    const cleanPass = supPassword.trim();

    if (!cleanName || !cleanPhone || !cleanPass) {
      setFormError('يرجى ملء جميع الحقول المطلوبة بشكل صحيح (الاسم، رقم الهاتف، والرمز السري)');
      return;
    }

    if (cleanPass.length < 3) {
      setFormError('الرمز السري يجب أن لا يقل عن 3 خانات');
      return;
    }

    try {
      setIsSubmitting(true);
      const newSup = await createSupervisor(parentManagerId, currentUser.branch_name || 'الفرع الرئيسي', {
        name: cleanName,
        username: cleanPhone,
        password: cleanPass,
        permissions: addPermissions,
      });

      setSupervisors((prev) => [newSup, ...prev.filter((s) => s.id !== newSup.id)]);
      setShowAddModal(false);
      setSupName('');
      setSupPhone('');
      setSupPassword('');
      setAddPresetKey('add_pay_only');
      setAddPermissions(ADD_AND_PAY_ONLY_PERMISSIONS);

      if (onShowToast) {
        onShowToast(`تمت إضافة المشرف (${cleanName}) وتحديد صلاحياته بنجاح!`, 'success');
      }
    } catch (err: any) {
      setFormError(err.message || 'حدث خطأ أثناء إضافة المشرف');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle Supervisor Status
  const handleToggleStatus = async (sup: SupervisorUser) => {
    try {
      const nextActive = !sup.isActive;
      await updateSupervisor(sup.id, parentManagerId, { isActive: nextActive });
      setSupervisors((prev) => prev.map((s) => (s.id === sup.id ? { ...s, isActive: nextActive } : s)));
      if (onShowToast) {
        onShowToast(
          nextActive ? `تم تفعيل حساب المشرف (${sup.name})` : `تم تعطيل حساب المشرف (${sup.name})`,
          nextActive ? 'success' : 'info'
        );
      }
    } catch (err) {
      if (onShowToast) onShowToast('تعذر تغيير حالة المشرف', 'error');
    }
  };

  // Update Password
  const handleSavePassword = async (supId: number) => {
    const trimmed = editingPasswordInput.trim();
    if (!trimmed || trimmed.length < 3) {
      if (onShowToast) onShowToast('الرمز السري يجب أن لا يقل عن 3 خانات', 'error');
      return;
    }
    try {
      await updateSupervisor(supId, parentManagerId, { password: trimmed });
      setSupervisors((prev) => prev.map((s) => (s.id === supId ? { ...s, plainPassword: trimmed } : s)));
      setEditingPasswordId(null);
      setEditingPasswordInput('');
      if (onShowToast) onShowToast('تم تحديث الرمز السري للمشرف بنجاح', 'success');
    } catch (err) {
      if (onShowToast) onShowToast('فشل تحديث الرمز السري', 'error');
    }
  };

  // Delete Supervisor Handler with Modal Confirmation
  const handleConfirmDelete = async () => {
    if (!deletingSupervisor) return;
    try {
      setIsDeletingSupervisor(true);
      await deleteSupervisor(deletingSupervisor.id, parentManagerId);
      setSupervisors((prev) => prev.filter((s) => s.id !== deletingSupervisor.id));
      if (onShowToast) onShowToast(`تم حذف المشرف (${deletingSupervisor.name}) بنجاح`, 'info');
      setDeletingSupervisor(null);
    } catch (err) {
      if (onShowToast) onShowToast('فشل حذف المشرف', 'error');
    } finally {
      setIsDeletingSupervisor(false);
    }
  };

  // Share Credentials via WhatsApp
  const handleShareWhatsApp = (sup: SupervisorUser) => {
    const pwd = sup.plainPassword || '••••••';
    const message = `مرحباً بك المشرف (${sup.name})\nتم إنشاء حساب مشرف خاص بك:\nرقم الهاتف (اسم المستخدم): ${sup.username}\nالرمز السري: ${pwd}\nتطبيق دفتر الديون والأقساط.`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
    openWhatsAppUrlDirect(url);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300" dir={dir}>
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,rgba(59,130,246,0.25),transparent_60%)] pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-bold mb-2">
              <i className="fa-solid fa-user-shield text-blue-400"></i>
              <span>نظام إدارة وتتبع المشرفين والموظفين</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              سجل وتتبع حركة المشرفين
            </h2>
            <p className="text-xs sm:text-sm text-blue-100/80 mt-1 max-w-2xl leading-relaxed">
              قم بإنشاء حسابات المشرفين وتخصيص أدوارهم (عرض فقط، إضافة وتسديد، أو صلاحيات كاملة)، ومتابعة سجل كافة عملياتهم بدقة لحظية عبر جميع الأنظمة.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setAddPresetKey('add_pay_only');
              setAddPermissions(ADD_AND_PAY_ONLY_PERMISSIONS);
              setShowAddCustomDetails(false);
              setShowAddModal(true);
            }}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg shadow-emerald-900/30 transition-all cursor-pointer flex items-center justify-center gap-2 shrink-0 active:scale-95"
          >
            <i className="fa-solid fa-user-plus text-sm"></i>
            <span>إضافة مشرف جديد</span>
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-4 border-t border-white/10 relative z-10">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-blue-200 font-medium block">إجمالي المشرفين</span>
            <span className="text-xl font-black text-white mt-0.5 block">{supervisors.length}</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-200 font-medium block">المشرفون النشطون</span>
            <span className="text-xl font-black text-emerald-300 mt-0.5 block">
              {supervisors.filter((s) => s.isActive).length}
            </span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-amber-200 font-medium block">عمليات اليوم/الكل</span>
            <span className="text-xl font-black text-amber-300 mt-0.5 block">{auditLogs.length}</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
            <span className="text-[11px] text-purple-200 font-medium block">الأنظمة المشمولة</span>
            <span className="text-xl font-black text-purple-300 mt-0.5 block">4 أنظمة</span>
          </div>
        </div>
      </div>

      {/* SECTION 1: Supervisors Roster (قائمة المشرفين بطاقات ناعمة وواضحة) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm font-bold shadow-xs">
              <i className="fa-solid fa-users"></i>
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">حسابات المشرفين وصلاحياتهم بالفرع</h3>
              <p className="text-xs text-slate-500">بطاقات المشرفين المخولين وتحديد مستويات الوصول لكل حساب</p>
            </div>
          </div>

          <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            {supervisors.length} مشرف
          </span>
        </div>

        {loading ? (
          <div className="text-center py-8 text-slate-400 text-xs flex items-center justify-center gap-2">
            <i className="fa-solid fa-circle-notch fa-spin text-sm text-blue-600"></i>
            <span>جاري تحميل قائمة المشرفين...</span>
          </div>
        ) : supervisors.length === 0 ? (
          <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
            <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center text-xl mx-auto">
              <i className="fa-solid fa-user-plus"></i>
            </div>
            <h4 className="font-bold text-slate-800 text-sm">لا يوجد مشرفين مضافين حالياً</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              انقر على زر "إضافة مشرف جديد" لإنشاء حساب مشرف وتحديد مستوى الصلاحية المناسب له (عرض فقط، إضافة وتسديد فقط، أو كامل الصلاحيات).
            </p>
            <button
              type="button"
              onClick={() => {
                setAddPresetKey('add_pay_only');
                setAddPermissions(ADD_AND_PAY_ONLY_PERMISSIONS);
                setShowAddCustomDetails(false);
                setShowAddModal(true);
              }}
              className="mt-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>إضافة أول مشرف</span>
            </button>
          </div>
        ) : (
          /* Redesigned Soft Elegant Cards Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {supervisors.map((sup) => {
              const pass = sup.plainPassword || '••••••';
              const isRevealed = !!revealedPasswords[sup.id];
              const isEditing = editingPasswordId === sup.id;
              const presetKey = detectPermissionPreset(sup.permissions);
              const presetInfo = getPresetInfo(presetKey);

              return (
                <div
                  key={sup.id}
                  className={`rounded-3xl p-4 sm:p-5 border transition-all space-y-3.5 relative overflow-hidden ${
                    sup.isActive
                      ? 'bg-white border-slate-200/90 hover:border-indigo-300/80 shadow-2xs hover:shadow-xs'
                      : 'bg-rose-50/20 border-rose-200/70'
                  }`}
                >
                  {/* Top Bar: Name & Active Switch Badge */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-base shrink-0 shadow-xs ${
                          sup.isActive ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-200 text-slate-500'
                        }`}
                      >
                        <i className="fa-solid fa-user-shield"></i>
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-sm text-slate-900 truncate">{sup.name}</h4>
                        <span className="text-[11px] text-slate-500 font-mono block truncate" dir="ltr">
                          {sup.username}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleStatus(sup)}
                      className={`text-[10px] font-extrabold px-3 py-1 rounded-full transition-all cursor-pointer shrink-0 border ${
                        sup.isActive
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100'
                      }`}
                    >
                      {sup.isActive ? 'مفعل ✓' : 'معطل ✕'}
                    </button>
                  </div>

                  {/* Permission Role Badge */}
                  <div className="pt-0.5">
                    <span
                      className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-2xl border ${presetInfo.badgeBg}`}
                    >
                      <i className={`fa-solid ${presetInfo.icon} text-xs`}></i>
                      <span>{presetInfo.badgeText}</span>
                    </span>
                  </div>

                  {/* Soft Credentials Info Box */}
                  <div className="p-3 bg-slate-50/80 rounded-2xl border border-slate-200/70 text-xs space-y-2">
                    {/* Username / Phone */}
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-medium">رقم الدخول:</span>
                      <span className="font-extrabold text-indigo-700 font-mono" dir="ltr">
                        {sup.username}
                      </span>
                    </div>

                    {/* PIN Code / Password */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                      <span className="text-slate-500 font-medium">الرمز السري:</span>
                      {!isEditing ? (
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-slate-900">
                            {isRevealed ? pass : '••••••'}
                          </span>
                          <button
                            type="button"
                            onClick={() => setRevealedPasswords((prev) => ({ ...prev, [sup.id]: !prev[sup.id] }))}
                            className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer text-xs"
                            title="إظهار الرمز"
                          >
                            <i className={`fa-solid ${isRevealed ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingPasswordId(sup.id);
                              setEditingPasswordInput(pass === '••••••' ? '' : pass);
                            }}
                            className="p-1 text-blue-600 hover:text-blue-800 cursor-pointer text-xs"
                            title="تعديل الرمز السري"
                          >
                            <i className="fa-solid fa-pen-to-square"></i>
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <input
                            type="text"
                            value={editingPasswordInput}
                            onChange={(e) => setEditingPasswordInput(e.target.value)}
                            placeholder="رمز جديد..."
                            className="w-20 bg-white border border-blue-400 text-xs font-mono font-bold px-2 py-0.5 rounded-md outline-none"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => handleSavePassword(sup.id)}
                            className="bg-blue-600 text-white px-2 py-0.5 rounded-md text-[10px] font-bold cursor-pointer hover:bg-blue-700"
                          >
                            حفظ
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingPasswordId(null)}
                            className="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold cursor-pointer"
                          >
                            إلغاء
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Registration Date */}
                    {sup.createdAt && (
                      <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                        <span className="text-slate-400">تاريخ الإضافة:</span>
                        <span className="text-slate-500 font-mono">
                          {formatDateDigits(sup.createdAt)}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Clean Action Buttons Bar */}
                  <div className="flex items-center justify-between pt-1 gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => handleOpenEditPermissions(sup)}
                      className="py-1.5 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200/80 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                      title="تعديل أذونات وصلاحيات المشرف"
                    >
                      <i className="fa-solid fa-sliders text-indigo-600 text-xs"></i>
                      <span>تعديل الصلاحيات</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleShareWhatsApp(sup)}
                      className="py-1.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                      title="إرسال بيانات الحساب عبر واتساب"
                    >
                      <i className="fa-brands fa-whatsapp text-emerald-600 text-sm"></i>
                      <span>إرسال الحساب</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeletingSupervisor(sup)}
                      className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-xl text-xs font-bold transition-all cursor-pointer mr-auto flex items-center justify-center min-w-[32px] min-h-[32px]"
                      title="حذف المشرف"
                    >
                      <i className="fa-solid fa-trash-can text-sm"></i>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* SECTION 2: Audit Feed Across All 4 Systems (سجل عمليات المشرفين والمدراء) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-sm font-bold shadow-xs">
              <i className="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">سجل عمليات المشرفين والمدراء عبر كافة الأنظمة</h3>
              <p className="text-xs text-slate-500">تتبع حي ومباشر لعمليات إضافة وتحديث وتسديد الديون والأقساط والموردين</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
              {filteredAuditLogs.length} حركة مسجلة
            </span>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
          {/* System Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              التصفية حسب النظام:
            </label>
            <select
              value={auditSystemFilter}
              onChange={(e) => setAuditSystemFilter(e.target.value as any)}
              className="w-full bg-white border border-slate-200 text-xs font-bold p-2 rounded-xl outline-none text-slate-800"
            >
              <option value="all">كافة الأنظمة الأربعة (شامل)</option>
              <option value="debtor">دفتر الديون (المدينين)</option>
              <option value="creditor">سجل ديون عليّ (الدائنين)</option>
              <option value="installment">نظام الأقساط</option>
              <option value="supplier">نظام الموردين</option>
            </select>
          </div>

          {/* Supervisor Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              التصفية حسب الحساب / المشرف:
            </label>
            <select
              value={auditSupervisorFilter}
              onChange={(e) => setAuditSupervisorFilter(e.target.value)}
              className="w-full bg-white border border-slate-200 text-xs font-bold p-2 rounded-xl outline-none text-slate-800"
            >
              <option value="all">جميع المشرفين والمدراء</option>
              {uniqueAuditSupervisorNames.map((name) => (
                <option key={name} value={name}>
                  {isManagerAccount(name) ? `👑 ${name} (مدير الحساب)` : `🛡️ ${name} (مشرف)`}
                </option>
              ))}
            </select>
          </div>

          {/* Search Input */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              البحث باسم العميل أو العملية:
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث باسم العميل أو نوع العملية..."
                className="w-full bg-white border border-slate-200 text-xs font-medium pr-9 pl-3 py-2 rounded-xl outline-none text-slate-800 transition-all focus:border-indigo-400"
                dir="rtl"
              />
              <i className="fa-solid fa-magnifying-glass absolute right-3 top-2.5 text-slate-400 text-xs pointer-events-none"></i>
            </div>
          </div>
        </div>

        {/* Audit Log Timeline (Grouped per Supervisor or Manager) */}
        {groupedAuditLogsBySupervisor.length === 0 || groupedAuditLogsBySupervisor.every((g) => g.logs.length === 0) ? (
          <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
            <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-500 flex items-center justify-center text-lg mx-auto">
              <i className="fa-solid fa-receipt"></i>
            </div>
            <h4 className="font-bold text-slate-700 text-xs">لا توجد عمليات مسجلة متطابقة</h4>
            <p className="text-[11px] text-slate-400">
              عندما يقوم المشرفون والمدراء بإضافة ديون جديدة أو إضافة عملاء أو تسديد الأقساط والموردين ستظهر حركاتهم هنا مقسمة لكل حساب.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {groupedAuditLogsBySupervisor.map((group) => {
              if (group.logs.length === 0) return null;
              const isManager = isManagerAccount(group.supervisorName);

              return (
                <div
                  key={group.supervisorName}
                  className="bg-slate-50/70 border border-slate-200/90 rounded-3xl p-4 sm:p-5 space-y-3 shadow-xs"
                >
                  {/* Supervisor/Manager Group Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-slate-200/70">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center text-base font-black shadow-xs shrink-0 ${
                          isManager ? 'bg-amber-500 text-white' : 'bg-indigo-600 text-white'
                        }`}
                      >
                        <i className={`fa-solid ${isManager ? 'fa-user-tie' : 'fa-user-gear'}`}></i>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-black text-sm text-slate-900">
                            {isManager ? 'سجل حركات مدير الحساب / الفرع:' : 'سجل حركات المشرف:'}{' '}
                            <span className={isManager ? 'text-amber-700 font-extrabold' : 'text-indigo-700 font-extrabold'}>
                              {group.supervisorName}
                            </span>
                          </h4>
                          <span
                            className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                              isManager
                                ? 'bg-amber-100 text-amber-900 border-amber-300'
                                : 'bg-indigo-100 text-indigo-800 border-indigo-200'
                            }`}
                          >
                            {isManager ? '👑 مدير الفرع / الحساب' : '🛡️ مشرف الفرع'}
                          </span>
                          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-800 border border-indigo-200">
                            أحدث 200 حركة ⚡
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          تُعرض الحركات المنفذة بواسطة {isManager ? 'مدير الحساب' : 'المشرف'} ({group.supervisorName}) عبر كافة الأنظمة
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap text-xs self-start sm:self-auto">
                      <span className="font-bold px-3 py-1 rounded-xl bg-white border border-slate-200 text-slate-700 shadow-2xs">
                        عدد الحركات: <strong className="text-slate-900">{group.totalCount}</strong>
                      </span>
                      <span className="font-bold px-3 py-1 rounded-xl bg-white border border-slate-200 text-emerald-700 shadow-2xs font-mono" dir="ltr">
                        {formatNumber(group.totalAmount, numberFormat)} د.ع
                      </span>
                    </div>
                  </div>

                  {/* Movements List for this Account (Max 50) */}
                  <div className="space-y-2.5">
                    {group.logs.map((log) => {
                      const isPay = log.actionType === 'pay';
                      const isEdit = log.actionType === 'edit';
                      const isDelete = log.actionType === 'delete';
                      const itemIsManager = isManagerAccount(log.supervisorName);

                      const iconBg = isPay
                        ? 'bg-emerald-600 text-white'
                        : isEdit
                        ? 'bg-amber-600 text-white'
                        : isDelete
                        ? 'bg-rose-700 text-white'
                        : 'bg-blue-600 text-white';

                      const iconClass = isPay
                        ? 'fa-arrow-down-left'
                        : isEdit
                        ? 'fa-pen-to-square'
                        : isDelete
                        ? 'fa-trash-can'
                        : 'fa-plus';

                      const badgeClass = isPay
                        ? 'bg-emerald-100 text-emerald-800'
                        : isEdit
                        ? 'bg-amber-100 text-amber-800'
                        : isDelete
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-blue-100 text-blue-800';

                      return (
                        <div
                          key={log.id}
                          className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                            isPay
                              ? 'bg-white border-emerald-200/80 hover:border-emerald-300'
                              : isEdit
                              ? 'bg-white border-amber-200/80 hover:border-amber-300'
                              : isDelete
                              ? 'bg-white border-rose-200/80 hover:border-rose-300'
                              : 'bg-white border-blue-200/80 hover:border-blue-300'
                          }`}
                        >
                          {/* Right Side: Icon + Details */}
                          <div className="flex items-start gap-3 min-w-0 flex-1">
                            <div
                              className={`w-9 h-9 rounded-2xl flex items-center justify-center text-sm shrink-0 shadow-2xs mt-0.5 ${iconBg}`}
                            >
                              <i className={`fa-solid ${iconClass}`}></i>
                            </div>

                            <div className="space-y-1.5 min-w-0 flex-1">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-extrabold text-xs sm:text-sm text-slate-900">
                                  {log.supervisorName}
                                </span>
                                <span
                                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                                    itemIsManager
                                      ? 'bg-amber-50 text-amber-900 border-amber-200'
                                      : 'bg-indigo-50 text-indigo-800 border-indigo-200'
                                  }`}
                                >
                                  {itemIsManager ? '👑 مدير الحساب' : '🛡️ مشرف'}
                                </span>
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                    log.system === 'debtor'
                                      ? 'bg-blue-50 text-blue-800 border-blue-200'
                                      : log.system === 'creditor'
                                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                                      : log.system === 'installment'
                                      ? 'bg-purple-50 text-purple-800 border-purple-200'
                                      : 'bg-teal-50 text-teal-800 border-teal-200'
                                  }`}
                                >
                                  {log.systemLabel}
                                </span>
                                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${badgeClass}`}>
                                  {log.actionLabel}
                                </span>
                              </div>

                              <div className="text-xs text-slate-800 font-medium whitespace-normal break-words leading-relaxed">
                                العميل / الطرف الآخر: <span className="font-bold text-slate-950">{log.customerName}</span>
                              </div>

                              {log.notes && (
                                <div className="text-[11px] text-slate-600 italic bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-100 whitespace-normal break-words leading-relaxed">
                                  "{log.notes}"
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Left Side: Amount + Date */}
                          <div className="flex flex-col items-end justify-start shrink-0 text-left pt-0.5">
                            <div
                              className={`text-xs sm:text-sm font-black font-mono ${
                                isPay ? 'text-emerald-700' : 'text-rose-700'
                              }`}
                              dir="ltr"
                            >
                              {isPay ? '-' : '+'}{formatNumber(log.amount, numberFormat)} د.ع
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono mt-0.5">
                              {formatDateDigits(log.date)}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* MODAL 1: ADD SUPERVISOR FORM */}
      {showAddModal && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200 overflow-y-auto"
          onClick={() => setShowAddModal(false)}
        >
          <div
            className="w-full max-w-lg bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-100 space-y-4 my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-user-plus"></i>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">إضافة مشرف جديد للفرع</h3>
                  <p className="text-[11px] text-slate-500">إنشاء حساب جديد وتحديد القالب وصلاحيات الوصول</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl border border-rose-200 flex items-center gap-2">
                <i className="fa-solid fa-circle-exclamation shrink-0"></i>
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreateSupervisorSubmit} className="space-y-4">
              {/* Field 1: Supervisor Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  1. اسم المشرف / الموظف <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  placeholder="مثال: أحمد علي"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                  required
                />
              </div>

              {/* Field 2: Phone Number as Username */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  2. رقم الهاتف (اسم المستخدم للدخول) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={supPhone}
                  onChange={(e) => setSupPhone(e.target.value)}
                  placeholder="077xxxxxxxx"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-mono font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                  dir="ltr"
                  required
                />
              </div>

              {/* Field 3: PIN Code / Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  3. الرمز السري / كلمة السر <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={supPassword}
                  onChange={(e) => setSupPassword(e.target.value)}
                  placeholder="مثال: 1234"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-mono font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                  required
                />
              </div>

              {/* Field 4: Permission Role Presets */}
              <div className="space-y-2 pt-1 border-t border-slate-100">
                <label className="block text-xs font-bold text-slate-800">
                  4. حدد نموذج وصلاحيات المشرف:
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {/* Preset 1: Full */}
                  <button
                    type="button"
                    onClick={() => handleSelectAddPreset('full')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      addPresetKey === 'full'
                        ? 'bg-emerald-50/90 border-emerald-400 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        addPresetKey === 'full' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-shield-check"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">كامل الصلاحيات</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        إضافة، تسديد، تعديل، وحذف لكافة الأقسام
                      </div>
                    </div>
                  </button>

                  {/* Preset 2: Add & Pay Only */}
                  <button
                    type="button"
                    onClick={() => handleSelectAddPreset('add_pay_only')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      addPresetKey === 'add_pay_only'
                        ? 'bg-blue-50/90 border-blue-400 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        addPresetKey === 'add_pay_only' ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-pen-to-square"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">إضافة وتسديد فقط</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        إضافة الديون والتسديد (يُمْنَع من التعديل والحذف)
                      </div>
                    </div>
                  </button>

                  {/* Preset 3: View Only */}
                  <button
                    type="button"
                    onClick={() => handleSelectAddPreset('view_only')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      addPresetKey === 'view_only'
                        ? 'bg-indigo-50/90 border-indigo-400 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        addPresetKey === 'view_only' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-eye"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">عرض ومتابعة فقط</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        مشاهدة البيانات فقط وعند أي زر يظهر تنبيه للمدير
                      </div>
                    </div>
                  </button>

                  {/* Preset 4: Custom */}
                  <button
                    type="button"
                    onClick={() => handleSelectAddPreset('custom')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      addPresetKey === 'custom'
                        ? 'bg-amber-50/90 border-amber-400 ring-2 ring-amber-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        addPresetKey === 'custom' ? 'bg-amber-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-sliders"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">تخصيص يدوي</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        تحديد وتفعيل كل خيار بشكل فردي يدويًا
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Custom Details Toggles */}
              {(showAddCustomDetails || addPresetKey === 'custom') && (
                <div className="p-3 bg-amber-50/40 border border-amber-200/80 rounded-2xl space-y-2 text-xs animate-in fade-in duration-200">
                  <div className="font-bold text-slate-800 text-[11px] mb-1">
                    تخصيص الأذونات الفردية:
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addPermissions.canAddDebts}
                        onChange={(e) =>
                          setAddPermissions((prev) => ({ ...prev, canAddDebts: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>إضافة ديون وأسماء جديدة</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addPermissions.canAddPayments}
                        onChange={(e) =>
                          setAddPermissions((prev) => ({ ...prev, canAddPayments: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>تسجيل استلام وتكتيب الدفعات</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addPermissions.canEditDebtors}
                        onChange={(e) =>
                          setAddPermissions((prev) => ({ ...prev, canEditDebtors: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>تعديل بيانات الحساب والأسماء</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addPermissions.canDeleteDebtors}
                        onChange={(e) =>
                          setAddPermissions((prev) => ({ ...prev, canDeleteDebtors: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>حذف الحسابات والحركات</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addPermissions.canManageInstallments}
                        onChange={(e) =>
                          setAddPermissions((prev) => ({ ...prev, canManageInstallments: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>إدارة نظام الأقساط</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={addPermissions.canManageSuppliers}
                        onChange={(e) =>
                          setAddPermissions((prev) => ({ ...prev, canManageSuppliers: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>إدارة حسابات الموردين</span>
                    </label>
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all cursor-pointer flex items-center gap-2 shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الإنشاء...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-plus text-xs"></i>
                      <span>إنشاء المشرف</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: EDIT PERMISSIONS FOR EXISTING SUPERVISOR */}
      {editingPermissionsSupervisor && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200 overflow-y-auto"
          onClick={() => setEditingPermissionsSupervisor(null)}
        >
          <div
            className="w-full max-w-lg bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-100 space-y-4 my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-sliders"></i>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    تعديل صلاحيات المشرف ({editingPermissionsSupervisor.name})
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    تغيير القالب المستهدف أو تخصيص الأذونات الفردية
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setEditingPermissionsSupervisor(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <form onSubmit={handleSaveEditedPermissionsSubmit} className="space-y-4">
              {/* Presets Selection */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-800">
                  اختر النموذج والصلاحية المناسبة:
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {/* Preset 1: Full */}
                  <button
                    type="button"
                    onClick={() => handleSelectEditPreset('full')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      editPresetKey === 'full'
                        ? 'bg-emerald-50/90 border-emerald-400 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        editPresetKey === 'full' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-shield-check"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">كامل الصلاحيات</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        إضافة، تسديد، تعديل، وحذف لكافة الأقسام
                      </div>
                    </div>
                  </button>

                  {/* Preset 2: Add & Pay Only */}
                  <button
                    type="button"
                    onClick={() => handleSelectEditPreset('add_pay_only')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      editPresetKey === 'add_pay_only'
                        ? 'bg-blue-50/90 border-blue-400 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        editPresetKey === 'add_pay_only' ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-pen-to-square"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">إضافة وتسديد فقط</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        إضافة الديون والتسديد (يُمْنَع من التعديل والحذف)
                      </div>
                    </div>
                  </button>

                  {/* Preset 3: View Only */}
                  <button
                    type="button"
                    onClick={() => handleSelectEditPreset('view_only')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      editPresetKey === 'view_only'
                        ? 'bg-indigo-50/90 border-indigo-400 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        editPresetKey === 'view_only' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-eye"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">عرض ومتابعة فقط</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        مشاهدة البيانات فقط وعند أي زر يظهر تنبيه للمدير
                      </div>
                    </div>
                  </button>

                  {/* Preset 4: Custom */}
                  <button
                    type="button"
                    onClick={() => handleSelectEditPreset('custom')}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                      editPresetKey === 'custom'
                        ? 'bg-amber-50/90 border-amber-400 ring-2 ring-amber-500/20 shadow-xs'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100/60'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 mt-0.5 ${
                        editPresetKey === 'custom' ? 'bg-amber-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <i className="fa-solid fa-sliders"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">تخصيص يدوي</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">
                        تحديد وتفعيل كل خيار بشكل فردي يدويًا
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Custom Details Toggles */}
              {(showEditCustomDetails || editPresetKey === 'custom') && (
                <div className="p-3 bg-amber-50/40 border border-amber-200/80 rounded-2xl space-y-2 text-xs animate-in fade-in duration-200">
                  <div className="font-bold text-slate-800 text-[11px] mb-1">
                    تخصيص الأذونات الفردية:
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editPermissions.canAddDebts}
                        onChange={(e) =>
                          setEditPermissions((prev) => ({ ...prev, canAddDebts: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>إضافة ديون وأسماء جديدة</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editPermissions.canAddPayments}
                        onChange={(e) =>
                          setEditPermissions((prev) => ({ ...prev, canAddPayments: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>تسجيل استلام وتكتيب الدفعات</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editPermissions.canEditDebtors}
                        onChange={(e) =>
                          setEditPermissions((prev) => ({ ...prev, canEditDebtors: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>تعديل بيانات الحساب والأسماء</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editPermissions.canDeleteDebtors}
                        onChange={(e) =>
                          setEditPermissions((prev) => ({ ...prev, canDeleteDebtors: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>حذف الحسابات والحركات</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editPermissions.canManageInstallments}
                        onChange={(e) =>
                          setEditPermissions((prev) => ({ ...prev, canManageInstallments: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>إدارة نظام الأقساط</span>
                    </label>

                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editPermissions.canManageSuppliers}
                        onChange={(e) =>
                          setEditPermissions((prev) => ({ ...prev, canManageSuppliers: e.target.checked }))
                        }
                        className="w-4 h-4 rounded text-blue-600"
                      />
                      <span>إدارة حسابات الموردين</span>
                    </label>
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingPermissionsSupervisor(null)}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSavingPermissions}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 transition-all cursor-pointer flex items-center gap-2 shadow-xs disabled:opacity-50"
                >
                  {isSavingPermissions ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الحفظ...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-check text-xs"></i>
                      <span>حفظ الصلاحيات الجديدة</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: DELETE SUPERVISOR CONFIRMATION MODAL */}
      {deletingSupervisor && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200 overflow-y-auto"
          onClick={() => setDeletingSupervisor(null)}
        >
          <div
            className="w-full max-w-md bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-100 space-y-4 my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center text-lg shrink-0 shadow-xs">
                  <i className="fa-solid fa-trash-can"></i>
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                    تأكيد حذف المشرف نهائياً
                  </h3>
                  <p className="text-[11px] text-slate-500">إلغاء الوصول وحذف حساب المشرف من الفرع</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setDeletingSupervisor(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="p-4 bg-rose-50/70 border border-rose-200/80 rounded-2xl space-y-2.5 text-xs">
              <p className="font-extrabold text-rose-900 leading-relaxed text-sm">
                هل أنت متأكد من حذف حساب المشرف ({deletingSupervisor.name}) نهائياً؟
              </p>
              <div className="space-y-1 text-slate-700 text-[11px] leading-snug">
                <p>• سيتم إلغاء صلاحياته وحذف حسابه نهائياً من الفرع.</p>
                <p>• إذا كان المشرف يسجل دخوله حالياً من أي جهاز آخر، سيتم تسجيل خروجه فوراً وفي نفس اللحظة.</p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeletingSupervisor(null)}
                disabled={isDeletingSupervisor}
                className="px-4 py-2.5 rounded-xl font-bold text-xs text-slate-700 bg-slate-100 hover:bg-slate-200 transition-all cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeletingSupervisor}
                className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 transition-all cursor-pointer flex items-center gap-2 shadow-xs disabled:opacity-50"
              >
                {isDeletingSupervisor ? (
                  <>
                    <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                    <span>جاري الحذف...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-trash-can text-xs"></i>
                    <span>نعم، تأكيد الحذف</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
