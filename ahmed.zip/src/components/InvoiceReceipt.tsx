import React from 'react';
import { AppSettings, InvoiceItem, PaymentMethod } from '../types';
import { formatIqd, getPaymentMethodLabel } from '../utils/storage';
import { numberToArabicIqdWords } from '../utils/arabicTafqeet';

export interface InvoiceReceiptProps {
  settings: AppSettings;
  serialNumber: string;
  dateDisplay: string;
  timeDisplay: string;
  customerName: string;
  customerPhone: string;
  customerNotes: string;
  items: InvoiceItem[];
  paymentMethod: PaymentMethod;
  totalIqd: number;
}

/**
 * Print-grade commercial invoice letterhead & ledger.
 * Calibrated for exact physical printable height on A5 Landscape (148mm height -> <= 485px)
 * and A4 Portrait (297mm height) so physical USB/cable printers never spill onto a blank page 2.
 */
export const InvoiceReceipt: React.FC<InvoiceReceiptProps> = ({
  settings,
  serialNumber,
  dateDisplay,
  timeDisplay,
  customerName,
  customerPhone,
  customerNotes,
  items,
  paymentMethod,
  totalIqd,
}) => {
  const isA4 = settings.paperSize === 'A4_PORTRAIT';

  const populatedItems = items.filter(
    (it) => it.name.trim() !== '' || it.unitPrice > 0 || it.notes.trim() !== ''
  );
  const activeItems = populatedItems.length > 0 ? populatedItems : items;

  const totalPieces = activeItems.reduce(
    (sum, it) => sum + (Number.isFinite(it.quantity) ? it.quantity : 0),
    0
  );

  // Calibrated minimum ruled rows:
  // A4 Portrait: 9 rows fits comfortably with balanced whitespace.
  // A5 Landscape: 4 rows guarantees total sheet height stays strictly <= 485px (1 single A5 page!).
  const minRuledRows = isA4 ? 9 : 4;
  const blankRowCount = Math.max(0, minRuledRows - activeItems.length);
  const tafqeetText = numberToArabicIqdWords(totalIqd);

  return (
    <article
      dir="rtl"
      className={`w-full bg-white text-[#0E2240] select-text print:p-0 ${
        isA4 ? 'p-4 sm:p-5' : 'p-2.5 sm:p-3'
      }`}
    >
      {/* Formal Double-Rule Stationery Frame */}
      <div className="border-2 border-[#0E2A52] p-[2px] bg-white">
        <div className="border border-[#B7C8DC] flex flex-col justify-between">
          {/* =========================================================
              1. OFFICIAL COMMERCIAL LETTERHEAD
             ========================================================= */}
          <header className="relative bg-white overflow-hidden print-avoid-break">
            {/* Subtle top architectural accent bar (Navy + Crimson + Gold) */}
            <div className="flex h-1 w-full">
              <div className="w-[38%] bg-[#C8102E]" />
              <div className="w-[10%] bg-[#D4A017]" />
              <div className="flex-1 bg-[#0E2A52]" />
            </div>

            {settings.bannerImage ? (
              /* Custom User-Uploaded Banner + Crisp Metadata Strip */
              <div>
                <div
                  className={`w-full overflow-hidden border-b border-[#C5D4E6] ${
                    isA4 ? 'h-28' : 'h-16'
                  }`}
                >
                  <img
                    src={settings.bannerImage}
                    alt="أحمد القيسي للإطارات والبطاريات"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                <div className="px-3.5 py-1.5 bg-[#F6F9FC] border-b-2 border-[#0E2A52] flex items-center justify-between gap-3 text-[11px]">
                  <div className="font-black text-[#0E2A52] text-xs">
                    فاتورة مبيعات — أحمد القيسي للإطارات والبطاريات
                  </div>
                  <div className="flex items-center gap-3 tabular-nums font-bold text-[#1B355B]">
                    <span>
                      رقم الفاتورة:{' '}
                      <strong dir="ltr" className="text-[#C8102E] font-black">
                        {serialNumber}
                      </strong>
                    </span>
                    <span>
                      التاريخ: <strong dir="ltr">{dateDisplay}</strong>
                    </span>
                    <span>
                      الوقت: <strong>{timeDisplay}</strong>
                    </span>
                    <span>
                      الدفع: <strong>{getPaymentMethodLabel(paymentMethod)}</strong>
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              /* Master Studio Commercial Letterhead (Clean 3-Zone Print Grid) */
              <div
                className={`relative px-4 ${
                  isA4 ? 'py-3.5' : 'py-2'
                } bg-[#F9FBFE] border-b-2 border-[#0E2A52]`}
              >
                <div className="relative z-10 grid grid-cols-12 items-center gap-2.5">
                  {/* RIGHT ZONE (5 cols): Brand Wordmark & Identity */}
                  <div className="col-span-5 flex items-stretch gap-2.5">
                    <div className="w-1.5 bg-[#C8102E] shrink-0 rounded-xs" />
                    <div className="flex flex-col justify-center">
                      <h1
                        className={`font-black text-[#C8102E] leading-[1.06] tracking-tight ${
                          isA4 ? 'text-[1.75rem]' : 'text-[1.35rem]'
                        }`}
                      >
                        أحمد القيسي
                      </h1>
                      <div
                        className={`font-extrabold text-[#0E2A52] leading-tight mt-0.5 ${
                          isA4 ? 'text-[1rem]' : 'text-[0.85rem]'
                        }`}
                      >
                        للإطارات والبطاريات
                      </div>
                      <div className="mt-1 inline-flex items-center gap-1.5 text-[10px] font-bold text-[#4A5E7A]">
                        <span>جودة</span>
                        <span className="text-[#C99612]">◆</span>
                        <span>ثقة</span>
                        <span className="text-[#C99612]">◆</span>
                        <span>أسعار مناسبة</span>
                      </div>
                    </div>
                  </div>

                  {/* CENTER ZONE (3 cols): Official Document Title Crest */}
                  <div className="col-span-3 flex flex-col items-center justify-center text-center">
                    <div className={`px-3 border-y-2 border-[#0E2A52] bg-white ${isA4 ? 'py-1.5' : 'py-1'}`}>
                      <div
                        className={`font-black text-[#0E2A52] leading-tight whitespace-nowrap ${
                          isA4 ? 'text-base' : 'text-xs'
                        }`}
                      >
                        فاتورة مبيعات
                      </div>
                      <div className="text-[8.5px] font-bold tracking-[0.16em] text-[#6B7F99] uppercase mt-0.5 whitespace-nowrap">
                        SALES INVOICE
                      </div>
                    </div>
                  </div>

                  {/* LEFT ZONE (4 cols): Formal Invoice Metadata Table */}
                  <div className="col-span-4">
                    <div
                      className={`border border-[#B7C8DC] bg-white ${
                        isA4 ? 'text-xs' : 'text-[10.5px]'
                      }`}
                    >
                      <div className="grid grid-cols-2 border-b border-[#D5E1EE]">
                        <div className={`px-2 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE] ${isA4 ? 'py-1' : 'py-0.5'}`}>
                          رقم الفاتورة
                        </div>
                        <div
                          dir="ltr"
                          className={`px-2 font-black text-[#C8102E] text-center tabular-nums ${isA4 ? 'py-1' : 'py-0.5'}`}
                        >
                          {serialNumber}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 border-b border-[#D5E1EE]">
                        <div className={`px-2 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE] ${isA4 ? 'py-1' : 'py-0.5'}`}>
                          التاريخ
                        </div>
                        <div
                          dir="ltr"
                          className={`px-2 font-extrabold text-[#0E2A52] text-center tabular-nums ${isA4 ? 'py-1' : 'py-0.5'}`}
                        >
                          {dateDisplay}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 border-b border-[#D5E1EE]">
                        <div className={`px-2 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE] ${isA4 ? 'py-1' : 'py-0.5'}`}>
                          الوقت
                        </div>
                        <div className={`px-2 font-bold text-[#0E2A52] text-center tabular-nums ${isA4 ? 'py-1' : 'py-0.5'}`}>
                          {timeDisplay}
                        </div>
                      </div>
                      <div className="grid grid-cols-2">
                        <div className={`px-2 bg-[#F2F6FB] font-bold text-[#3D5575] border-l border-[#D5E1EE] ${isA4 ? 'py-1' : 'py-0.5'}`}>
                          طريقة الدفع
                        </div>
                        <div className={`px-2 font-extrabold text-[#0E2A52] text-center ${isA4 ? 'py-1' : 'py-0.5'}`}>
                          {getPaymentMethodLabel(paymentMethod)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </header>

          {/* =========================================================
              2. CUSTOMER INFORMATION LEDGER BAR
             ========================================================= */}
          <section className={`px-4 print-avoid-break ${isA4 ? 'pt-3 pb-2.5' : 'pt-2 pb-1.5'}`}>
            <div
              className={`grid grid-cols-12 border border-[#B7C8DC] bg-[#F8FAFD] ${
                isA4 ? 'text-xs sm:text-[13px]' : 'text-[11px]'
              }`}
            >
              <div className={`col-span-5 flex items-center gap-1.5 px-2.5 border-l border-[#C8D6E5] min-w-0 ${isA4 ? 'py-1.5' : 'py-1'}`}>
                <span className="font-bold text-[#4A6282] whitespace-nowrap shrink-0">
                  السيد / الزبون :
                </span>
                <span className="font-extrabold text-[#0E2240] truncate">
                  {customerName.trim() || 'زبون نقدي'}
                </span>
              </div>

              <div className={`col-span-3 flex items-center gap-1.5 px-2.5 border-l border-[#C8D6E5] min-w-0 ${isA4 ? 'py-1.5' : 'py-1'}`}>
                <span className="font-bold text-[#4A6282] whitespace-nowrap shrink-0">
                  الهاتف :
                </span>
                <span
                  dir="ltr"
                  className="font-bold text-[#0E2240] tabular-nums truncate"
                >
                  {customerPhone.trim() || '—'}
                </span>
              </div>

              <div className={`col-span-4 flex items-center gap-1.5 px-2.5 min-w-0 ${isA4 ? 'py-1.5' : 'py-1'}`}>
                <span className="font-bold text-[#4A6282] whitespace-nowrap shrink-0">
                  ملاحظات :
                </span>
                <span className="font-bold text-[#0E2240] truncate">
                  {customerNotes.trim() || '—'}
                </span>
              </div>
            </div>
          </section>

          {/* =========================================================
              3. MAIN ITEMS LEDGER TABLE
             ========================================================= */}
          <section className="px-4">
            <table
              className={`w-full border-collapse border border-[#0E2A52] ${
                isA4 ? 'text-xs sm:text-[13px]' : 'text-[11.5px]'
              }`}
            >
              <thead>
                <tr className="bg-[#0E2A52] text-white border-b-2 border-[#D4A017]">
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-1.5 font-extrabold border-l border-white/20 text-center w-[34px]`}>
                    ت
                  </th>
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-2.5 font-extrabold border-l border-white/20 text-right`}>
                    التفاصيل / الصنف
                  </th>
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-1.5 font-extrabold border-l border-white/20 text-center w-[56px]`}>
                    الكمية
                  </th>
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-2 font-extrabold border-l border-white/20 text-center w-[108px] whitespace-nowrap`}>
                    سعر الوحدة (د.ع)
                  </th>
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-1.5 font-extrabold border-l border-white/20 text-center w-[80px]`}>
                    الضمان
                  </th>
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-2 font-extrabold border-l border-white/20 text-center w-[114px] whitespace-nowrap`}>
                    المبلغ الكلي (د.ع)
                  </th>
                  <th className={`${isA4 ? 'py-2' : 'py-1.5'} px-2 font-extrabold text-center w-[100px]`}>
                    ملاحظات
                  </th>
                </tr>
              </thead>
              <tbody>
                {activeItems.map((item, idx) => {
                  const qty = Number.isFinite(item.quantity) ? item.quantity : 0;
                  const unitPrice = Number.isFinite(item.unitPrice) ? item.unitPrice : 0;
                  const rowTotal = Math.round(qty * unitPrice);
                  const cellPad = isA4 ? 'py-2' : 'py-1.5';

                  return (
                    <tr
                      key={item.id}
                      className={`${
                        idx % 2 === 1 ? 'bg-[#F7FAFD]' : 'bg-white'
                      } border-b border-[#C8D6E5]`}
                    >
                      <td className={`${cellPad} px-1.5 text-center font-bold text-[#3D5575] border-l border-[#C8D6E5] tabular-nums`}>
                        {idx + 1}
                      </td>
                      <td className={`${cellPad} px-2.5 text-right font-extrabold text-[#0E2240] border-l border-[#C8D6E5]`}>
                        {item.name.trim() || '—'}
                      </td>
                      <td className={`${cellPad} px-1.5 text-center font-extrabold text-[#0E2240] border-l border-[#C8D6E5] tabular-nums`}>
                        {qty}
                      </td>
                      <td className={`${cellPad} px-2 text-center font-bold text-[#0E2240] border-l border-[#C8D6E5] tabular-nums`}>
                        {formatIqd(unitPrice)}
                      </td>
                      <td className={`${cellPad} px-1.5 text-center font-bold text-[#1F3A60] border-l border-[#C8D6E5]`}>
                        {item.warranty.trim() || 'بدون ضمان'}
                      </td>
                      <td className={`${cellPad} px-2 text-center font-black text-[#0E2A52] border-l border-[#C8D6E5] tabular-nums`}>
                        {formatIqd(rowTotal)}
                      </td>
                      <td className={`${cellPad} px-2 text-center font-semibold text-[#3D5575]`}>
                        {item.notes.trim() || '—'}
                      </td>
                    </tr>
                  );
                })}

                {/* Authentic Ruled Blank Ledger Lines */}
                {Array.from({ length: blankRowCount }).map((_, idx) => {
                  const rowIndex = activeItems.length + idx;
                  return (
                    <tr
                      key={`blank-${idx}`}
                      className={`${
                        rowIndex % 2 === 1 ? 'bg-[#FAFCFF]' : 'bg-white'
                      } border-b border-[#DCE6F1] ${isA4 ? 'h-8' : 'h-5'}`}
                    >
                      <td className="border-l border-[#DCE6F1]" />
                      <td className="border-l border-[#DCE6F1]" />
                      <td className="border-l border-[#DCE6F1]" />
                      <td className="border-l border-[#DCE6F1]" />
                      <td className="border-l border-[#DCE6F1]" />
                      <td className="border-l border-[#DCE6F1]" />
                      <td />
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </section>

          {/* =========================================================
              4. TOTALS, ARABIC TAFQEET & COMMERCIAL TERMS
             ========================================================= */}
          <section
            className={`px-4 print-avoid-break ${
              isA4 ? 'pt-3.5 pb-3.5' : 'pt-2 pb-2'
            } grid grid-cols-12 gap-3 items-stretch`}
          >
            {/* RIGHT (7 cols): Amount in Arabic Words (التفقيط) + Warranty Terms */}
            <div className="col-span-7 flex flex-col justify-between gap-2">
              <div className={`border border-[#B7C8DC] bg-[#F8FAFD] px-3 ${isA4 ? 'py-2' : 'py-1.5'}`}>
                <div className="text-[10px] font-bold text-[#4A6282]">المبلغ كتابةً :</div>
                <div
                  className={`font-extrabold text-[#0E2A52] leading-snug ${
                    isA4 ? 'text-[13px] mt-0.5' : 'text-[11.5px]'
                  }`}
                >
                  {tafqeetText}
                </div>
              </div>

              <div className={`border border-[#DCE6F1] bg-white px-3 text-[#4A6282] leading-snug ${isA4 ? 'py-1.5 text-[11px]' : 'py-1 text-[10px]'}`}>
                <span className="font-extrabold text-[#0E2A52]">ملاحظة الضمان: </span>
                <span>
                  يُرجى الاحتفاظ بهذا الوصل لمراجعة الضمان عند الحاجة؛ يشمل الضمان العيوب المصنعية
                  فقط وفق المدة المثبتة أعلاه.
                </span>
              </div>
            </div>

            {/* LEFT (5 cols): Accounting Summary Table */}
            <div className="col-span-5 flex flex-col justify-between border border-[#0E2A52] bg-white">
              <div className={`divide-y divide-[#D5E1EE] ${isA4 ? 'text-xs' : 'text-[11px]'}`}>
                <div className={`flex items-center justify-between px-3 ${isA4 ? 'py-1.5' : 'py-1'}`}>
                  <span className="font-bold text-[#4A6282]">عدد الأصناف / القطع</span>
                  <span className="font-extrabold text-[#0E2240] tabular-nums">
                    {activeItems.length} صنف ({totalPieces} قطعة)
                  </span>
                </div>
                <div className={`flex items-center justify-between px-3 ${isA4 ? 'py-1.5' : 'py-1'}`}>
                  <span className="font-bold text-[#4A6282]">طريقة التسديد</span>
                  <span className="font-extrabold text-[#0E2240]">
                    {getPaymentMethodLabel(paymentMethod)}
                  </span>
                </div>
              </div>

              {/* Grand Total Bar — Single Authoritative Figure */}
              <div
                className={`bg-[#0E2A52] text-white px-3 border-t-2 border-[#D4A017] flex items-center justify-between gap-2 ${
                  isA4 ? 'py-2' : 'py-1.5'
                }`}
              >
                <span className={`font-extrabold whitespace-nowrap ${isA4 ? 'text-sm' : 'text-xs'}`}>
                  المجموع الكلي
                </span>
                <div className="text-left tabular-nums whitespace-nowrap">
                  <span className={`font-black text-[#FFD000] ${isA4 ? 'text-2xl' : 'text-lg'}`}>
                    {formatIqd(totalIqd)}
                  </span>
                  <span className="text-[11px] font-bold text-white/90 mr-1">د.ع</span>
                </div>
              </div>
            </div>
          </section>

          {/* =========================================================
              5. SIGNATURES & OFFICIAL FOOTER
             ========================================================= */}
          <footer className="mt-auto print-avoid-break">
            {/* Signatures Row */}
            <div
              className={`px-6 grid grid-cols-2 gap-8 ${
                isA4 ? 'pt-5 pb-4 text-xs' : 'pt-2 pb-2 text-[11px]'
              }`}
            >
              <div className="text-center">
                <div className="font-bold text-[#3D5575]">توقيع المستلم (الزبون)</div>
                <div
                  className={`mx-auto w-40 border-b border-dashed border-[#8EA5C2] ${
                    isA4 ? 'mt-5' : 'mt-3.5'
                  }`}
                />
              </div>
              <div className="text-center">
                <div className="font-bold text-[#3D5575]">توقيع وختم البائع</div>
                <div
                  className={`mx-auto w-40 border-b border-dashed border-[#8EA5C2] ${
                    isA4 ? 'mt-5' : 'mt-3.5'
                  }`}
                />
              </div>
            </div>

            {/* Bottom Contact Bar */}
            <div
              className={`bg-[#0E2A52] text-white border-t-2 border-[#D4A017] px-4 flex flex-wrap items-center justify-between gap-3 ${
                isA4 ? 'py-2 text-xs' : 'py-1.5 text-[11px]'
              }`}
            >
              <div className="font-extrabold text-[#FFD000]">
                شكراً لثقتكم — نتشرف بخدمتكم دائماً
              </div>

              <div className="flex flex-wrap items-center gap-2.5 font-bold text-white/95">
                {settings.shopAddress && <span>العنوان: {settings.shopAddress}</span>}
                {settings.shopAddress && settings.shopPhone && (
                  <span className="text-[#D4A017]" aria-hidden="true">
                    |
                  </span>
                )}
                {settings.shopPhone && (
                  <span>
                    الهاتف:{' '}
                    <span dir="ltr" className="tabular-nums font-extrabold">
                      {settings.shopPhone}
                    </span>
                  </span>
                )}
              </div>
            </div>
          </footer>
        </div>
      </div>
    </article>
  );
};
