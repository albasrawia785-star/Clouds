import { Debtor, InstallmentRecord } from '../types';

/**
 * Utility for compressing Base64 images to prevent high memory & database bloat.
 * Downscales camera photos to a max width/height of 1000px at 75% JPEG quality.
 */
export async function compressImageBase64(
  base64Str: string,
  maxWidth = 1000,
  maxHeight = 1000,
  quality = 0.75
): Promise<string> {
  if (!base64Str || typeof window === 'undefined') return base64Str;
  if (!base64Str.startsWith('data:image/')) return base64Str;

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      let { width, height } = img;

      if (width > maxWidth || height > maxHeight) {
        if (width > height) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        } else {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(base64Str);
        return;
      }

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      const compressed = canvas.toDataURL('image/jpeg', quality);
      resolve(compressed.length < base64Str.length ? compressed : base64Str);
    };

    img.onerror = () => resolve(base64Str);
    img.src = base64Str;
  });
}

/**
 * Format bytes into human-readable text (KB, MB).
 */
export function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 كيلوبايت';
  if (bytes < 1024) return `${bytes} بايت`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} كيلوبايت`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} ميجابايت`;
}

/**
 * Calculates storage consumption of attached invoice images across installments.
 */
export function calculateInvoiceImagesUsage(installments: InstallmentRecord[]): {
  count: number;
  totalBytes: number;
  formattedSize: string;
} {
  let count = 0;
  let totalBytes = 0;

  if (Array.isArray(installments)) {
    for (const inst of installments) {
      if (inst.invoiceImage && typeof inst.invoiceImage === 'string' && inst.invoiceImage.trim().length > 0) {
        count++;
        totalBytes += inst.invoiceImage.length;
      }
    }
  }

  return {
    count,
    totalBytes,
    formattedSize: formatBytes(totalBytes),
  };
}

/**
 * Purges invoice images from settled/paid installments or records older than `keepDays`.
 */
export function purgeOldInvoiceImages(
  installments: InstallmentRecord[],
  keepDays = 30
): {
  updatedInstallments: InstallmentRecord[];
  purgedCount: number;
  savedBytes: number;
} {
  let purgedCount = 0;
  let savedBytes = 0;
  const now = Date.now();
  const maxAgeMs = keepDays * 24 * 60 * 60 * 1000;

  const updatedInstallments = installments.map((inst) => {
    if (!inst.invoiceImage) return inst;

    const isSettled = inst.status === 'completed' || inst.remainingAmount <= 0;
    const regDateMs = inst.createdAt ? new Date(inst.createdAt).getTime() : 0;
    const isOld = regDateMs > 0 && now - regDateMs > maxAgeMs;

    if (isSettled || isOld) {
      purgedCount++;
      savedBytes += inst.invoiceImage.length;
      return {
        ...inst,
        invoiceImage: undefined,
      };
    }

    return inst;
  });

  return {
    updatedInstallments,
    purgedCount,
    savedBytes,
  };
}

/**
 * Purges all attached invoice images across all installments to free maximum memory.
 */
export function purgeAllInvoiceImages(
  installments: InstallmentRecord[]
): {
  updatedInstallments: InstallmentRecord[];
  purgedCount: number;
  savedBytes: number;
} {
  let purgedCount = 0;
  let savedBytes = 0;

  const updatedInstallments = installments.map((inst) => {
    if (inst.invoiceImage && typeof inst.invoiceImage === 'string' && inst.invoiceImage.length > 0) {
      purgedCount++;
      savedBytes += inst.invoiceImage.length;
      return {
        ...inst,
        invoiceImage: undefined,
      };
    }
    return inst;
  });

  return {
    updatedInstallments,
    purgedCount,
    savedBytes,
  };
}
