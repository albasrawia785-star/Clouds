import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  RefreshCw,
  Calendar,
  Phone,
  Clock,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  FileText,
  Building2,
  Lock,
  PlusCircle,
  CreditCard,
  Sparkles,
  ArrowLeft,
  BookOpen,
} from 'lucide-react';
import { PortalType } from '../utils/qrUtils';
import { formatNumber } from '../utils/formatters';
import { queryTurso, queryAllDatabasesForAccount, getBackendBaseUrl, isStaticOrNetlifyEnv } from '../services/turso';

interface CustomerPortalViewProps {
  type: PortalType;
  id: number;
  onGoToLogin?: () => void;
}

// Clean date formatting helper to prevent raw ISO string leaking (e.g., "2026-10-30T00:00:00.000Z")
function formatPortalDate(dateStr?: string | null): string {
  if (!dateStr) return '-';
  try {
    const cleanStr = String(dateStr).trim();
    if (cleanStr.includes('T')) {
      const parts = cleanStr.split('T');
      const datePart = parts[0];
      const timePart = parts[1] ? parts[1].substring(0, 5) : '';
      return timePart && timePart !== '00:00' ? `${datePart} (${timePart})` : datePart;
    }
    return cleanStr;
  } catch {
    return String(dateStr);
  }
}

export const CustomerPortalView: React.FC<CustomerPortalViewProps> = ({
  type,
  id,
  onGoToLogin,
}) => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchLiveStatement = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);

    try {
      // 1. Only query local backend proxy if running on dev server with Express API
      if (!isStaticOrNetlifyEnv()) {
        try {
          const baseUrl = getBackendBaseUrl();
          const res = await fetch(`${baseUrl}/api/public/statement?type=${type}&id=${id}`);
          if (res.ok) {
            const json = await res.json();
            if (json.success && json.data) {
              setData(json.data);
              setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
              setLoading(false);
              setRefreshing(false);
              return;
            }
          }
        } catch {
          // Fall through to direct Turso multi-database search
        }
      }

      // 2. Query ALL Turso databases directly (Primary, Secondary, Alidion2, Dedicated, Backups)
      try {
        const tableName = type === 'supplier' ? 'suppliers' : type === 'debtor' ? 'debtors' : 'installments';
        const searchRes = await queryAllDatabasesForAccount(tableName, id);

        if (searchRes && searchRes.row) {
          const row = searchRes.row;
          if (type === 'debtor') {
            let history = [];
            try {
              history = row.history ? (typeof row.history === 'string' ? JSON.parse(row.history) : row.history) : [];
            } catch {}

            const remainingAmount = Number(row.amount || 0);
            let paidAmount = 0;
            if (Array.isArray(history)) {
              paidAmount = history
                .filter((h: any) => h && h.type === 'pay')
                .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
            }
            const totalAmount = remainingAmount + paidAmount;

            setData({
              id: Number(row.id),
              name: String(row.name || ''),
              phone: String(row.phone || ''),
              amount: totalAmount,
              paidAmount,
              remainingAmount,
              debtDate: String(row.created_at || row.createdAt || row.last_debt_date || new Date().toISOString()),
              notes: String(row.notes || ''),
              history,
              userId: Number(row.user_id || row.userId || 1),
              updatedAt: String(row.created_at || row.createdAt || new Date().toISOString()),
              branchName: 'دفتر الديون والأقساط',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          } else if (type === 'supplier') {
            let history = [];
            try {
              history = row.history ? (typeof row.history === 'string' ? JSON.parse(row.history) : row.history) : [];
            } catch {}

            const remainingAmount = Number(row.amount || 0);
            let paidAmount = 0;
            if (Array.isArray(history)) {
              paidAmount = history
                .filter((h: any) => h && (h.type === 'pay_supplier' || h.type === 'pay'))
                .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
            }
            const totalAmount = remainingAmount + paidAmount;

            setData({
              id: Number(row.id),
              name: String(row.name || ''),
              phone: String(row.phone || ''),
              companyName: String(row.company_name || row.companyName || ''),
              amount: totalAmount,
              paidAmount,
              remainingAmount,
              itemType: String(row.item_type || row.itemType || ''),
              notes: String(row.notes || ''),
              userId: Number(row.user_id || row.userId || 1),
              history,
              updatedAt: String(row.created_at || row.createdAt || new Date().toISOString()),
              branchName: 'نظام الموردين والدائنين',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          } else {
            let payments = [];
            try {
              payments = row.payments ? (typeof row.payments === 'string' ? JSON.parse(row.payments) : row.payments) : [];
            } catch {}

            setData({
              id: Number(row.id),
              debtorName: String(row.name || row.debtorName || ''),
              phoneNumber: String(row.phone || row.phoneNumber || ''),
              itemName: String(row.item || row.itemName || ''),
              totalAmount: Number(row.total_amount || row.totalAmount || 0),
              downPayment: Number(row.down_payment || row.downPayment || 0),
              remainingAmount: Number(row.remaining_amount || row.remainingAmount || 0),
              monthlyInstallment: Number(row.monthly_installment_amount || row.monthlyInstallment || 0),
              registrationDate: String(row.registration_date || row.registrationDate || ''),
              nextDueDate: String(row.next_due_date || row.nextDueDate || ''),
              status: String(row.status || 'active'),
              notes: String(row.notes || ''),
              payments,
              userId: Number(row.user_id || row.userId || 1),
              updatedAt: String(row.created_at || row.createdAt || new Date().toISOString()),
              guarantorName: String(row.guarantor_name || row.guarantorName || ''),
              guarantorPhone: String(row.guarantor_phone || row.guarantorPhone || ''),
              branchName: 'نظام الأقساط المباشر',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          }
        }

        // 3. Fallback to positional queryTurso if queryAllDatabasesForAccount didn't return
        if (type === 'debtor') {
          const queryRes = await queryTurso(
            `SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
            [id, String(id), `%${id}%`]
          );
          const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

          if (rows.length > 0) {
            const row = rows[0];
            const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
            let history = [];
            try {
              history = val(7) ? JSON.parse(String(val(7))) : [];
            } catch {}

            const remainingAmount = Number(val(3) || 0);
            let paidAmount = 0;
            if (Array.isArray(history)) {
              paidAmount = history
                .filter((h: any) => h && h.type === 'pay')
                .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
            }
            const totalAmount = remainingAmount + paidAmount;

            setData({
              id: Number(val(0)),
              name: String(val(1) || ''),
              phone: String(val(2) || ''),
              amount: totalAmount,
              paidAmount,
              remainingAmount,
              debtDate: String(val(6) || new Date().toISOString()),
              notes: '',
              history,
              userId: Number(val(5) || 1),
              updatedAt: String(val(6) || new Date().toISOString()),
              branchName: 'دفتر الديون والأقساط',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          }
        } else if (type === 'supplier') {
          const queryRes = await queryTurso(
            `SELECT id, name, phone, company_name, amount, item_type, notes, user_id, history, created_at FROM suppliers WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
            [id, String(id), `%${id}%`]
          );
          const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

          if (rows.length > 0) {
            const row = rows[0];
            const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
            let history = [];
            try {
              history = val(8) ? JSON.parse(String(val(8))) : [];
            } catch {}

            const remainingAmount = Number(val(4) || 0);
            let paidAmount = 0;
            if (Array.isArray(history)) {
              paidAmount = history
                .filter((h: any) => h && (h.type === 'pay_supplier' || h.type === 'pay'))
                .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
            }
            const totalAmount = remainingAmount + paidAmount;

            setData({
              id: Number(val(0)),
              name: String(val(1) || ''),
              phone: String(val(2) || ''),
              companyName: String(val(3) || ''),
              amount: totalAmount,
              paidAmount,
              remainingAmount,
              itemType: String(val(5) || ''),
              notes: String(val(6) || ''),
              userId: Number(val(7) || 1),
              history,
              updatedAt: String(val(9) || new Date().toISOString()),
              branchName: 'نظام الموردين والدائنين',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          }
        } else {
          const queryRes = await queryTurso(
            `SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, status, notes, payments, user_id, created_at, guarantor_name, guarantor_phone FROM installments WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
            [id, String(id), `%${id}%`]
          );
          const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

          if (rows.length > 0) {
            const row = rows[0];
            const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
            let payments = [];
            try {
              payments = val(12) ? JSON.parse(String(val(12))) : [];
            } catch {}

            setData({
              id: Number(val(0)),
              debtorName: String(val(1) || ''),
              phoneNumber: String(val(2) || ''),
              itemName: String(val(3) || ''),
              totalAmount: Number(val(4) || 0),
              downPayment: Number(val(5) || 0),
              remainingAmount: Number(val(6) || 0),
              monthlyInstallment: Number(val(7) || 0),
              registrationDate: String(val(8) || ''),
              nextDueDate: String(val(9) || ''),
              status: String(val(10) || 'active'),
              notes: String(val(11) || ''),
              payments,
              userId: Number(val(13) || 1),
              updatedAt: String(val(14) || new Date().toISOString()),
              guarantorName: String(val(15) || ''),
              guarantorPhone: String(val(16) || ''),
              branchName: 'نظام الأقساط المباشر',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          }
        }
      } catch (tursoErr) {
        console.warn('Direct Turso query failed, attempting local cache fallback...', tursoErr);
      }

      // Fallback: Local storage check
      if (typeof window !== 'undefined' && window.localStorage) {
        if (type === 'debtor') {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('debtors_user_') || key === 'local_debtors')) {
              try {
                const debtors = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(debtors)) {
                  const found = debtors.find((d: any) => Number(d.id) === Number(id));
                  if (found) {
                    const history = found.history || [];
                    const remainingAmount = Number(found.amount || 0);
                    const paidAmount = history
                      .filter((h: any) => h && h.type === 'pay')
                      .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
                    const totalAmount = remainingAmount + paidAmount;

                    setData({
                      id: Number(found.id),
                      name: String(found.name || ''),
                      phone: String(found.phone || ''),
                      amount: totalAmount,
                      paidAmount,
                      remainingAmount,
                      debtDate: found.createdAt || new Date().toISOString(),
                      notes: '',
                      history,
                      userId: found.userId || 1,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      branchName: 'دفتر الديون والأقساط',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        } else if (type === 'supplier') {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('suppliers_user_') || key === 'local_suppliers')) {
              try {
                const suppliers = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(suppliers)) {
                  const found = suppliers.find((s: any) => Number(s.id) === Number(id));
                  if (found) {
                    const history = found.history || [];
                    const remainingAmount = Number(found.amount || 0);
                    const paidAmount = history
                      .filter((h: any) => h && (h.type === 'pay_supplier' || h.type === 'pay'))
                      .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
                    const totalAmount = remainingAmount + paidAmount;

                    setData({
                      id: Number(found.id),
                      name: String(found.name || ''),
                      phone: String(found.phone || ''),
                      companyName: String(found.companyName || ''),
                      amount: totalAmount,
                      paidAmount,
                      remainingAmount,
                      itemType: String(found.itemType || ''),
                      notes: String(found.notes || ''),
                      userId: found.userId || 1,
                      history,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      branchName: 'نظام الموردين والدائنين',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        } else {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('installments_user_') || key === 'local_installments')) {
              try {
                const insts = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(insts)) {
                  const found = insts.find((item: any) => Number(item.id) === Number(id));
                  if (found) {
                    setData({
                      id: Number(found.id),
                      debtorName: String(found.name || ''),
                      phoneNumber: String(found.phone || ''),
                      itemName: String(found.item || ''),
                      totalAmount: Number(found.totalAmount || 0),
                      downPayment: Number(found.downPayment || 0),
                      remainingAmount: Number(found.remainingAmount || 0),
                      monthlyInstallment: Number(found.monthlyInstallmentAmount || 0),
                      registrationDate: String(found.registrationDate || ''),
                      nextDueDate: String(found.nextDueDate || ''),
                      status: String(found.status || 'active'),
                      notes: String(found.notes || ''),
                      payments: found.payments || [],
                      userId: found.userId || 1,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      guarantorName: String(found.guarantorName || ''),
                      guarantorPhone: String(found.guarantorPhone || ''),
                      branchName: 'نظام الأقساط المباشر',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        }
      }

      setError('لم يتم العثور على سجل كشف الحساب المطلوب');
    } catch (err: any) {
      console.error('Failed to load customer portal statement:', err);
      setError('تعذر جلب كشف الحساب التفاعلي. يرجى التأكد من الاتصال بالإنترنت.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLiveStatement();
  }, [type, id]);

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center justify-center p-4 dir-rtl font-sans">
        <div className="bg-white border border-slate-200/80 rounded-3xl p-8 max-w-sm w-full text-center shadow-lg">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center mx-auto mb-4 animate-spin">
            <RefreshCw className="w-6 h-6 text-slate-600" />
          </div>
          <h2 className="text-base font-bold text-slate-900 mb-1">جاري جلب كشف الحساب...</h2>
          <p className="text-slate-500 text-xs">يتم الاتصال بقاعدة البيانات لجلب أحدث البيانات المحدثة</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center justify-center p-4 dir-rtl font-sans">
        <div className="bg-white border border-rose-200 rounded-3xl p-8 max-w-sm w-full text-center shadow-lg">
          <div className="w-12 h-12 bg-rose-50 rounded-2xl border border-rose-200 flex items-center justify-center mx-auto mb-3 text-rose-600">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-slate-900 mb-1">تعذر العثور على الحساب</h2>
          <p className="text-slate-500 text-xs mb-5">{error || 'السجل غير موجود أو تم تحويله'}</p>
          <button
            onClick={() => fetchLiveStatement(true)}
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs"
          >
            <RefreshCw className="w-4 h-4" />
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  // Calculate percentages and metrics
  const isInstallment = type === 'installment';
  const isSupplier = type === 'supplier';

  const name = isSupplier ? data.name : isInstallment ? data.debtorName : data.name;
  const phone = isSupplier ? data.phone : isInstallment ? data.phoneNumber : data.phone;
  const totalAmount = isSupplier ? data.amount : isInstallment ? data.totalAmount : data.amount;
  const remainingAmount = data.remainingAmount ?? 0;
  const paidAmount = isSupplier
    ? data.paidAmount ?? 0
    : isInstallment
    ? totalAmount - remainingAmount
    : data.paidAmount ?? (totalAmount - remainingAmount);

  const percentage = totalAmount > 0 ? Math.min(100, Math.round((paidAmount / totalAmount) * 100)) : 0;
  const rawTransactions = isInstallment ? data.payments || [] : data.history || [];

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 font-sans dir-rtl pb-12 selection:bg-slate-900 selection:text-white print:bg-white print:pb-0">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 py-3 print:hidden shadow-2xs">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div>
              <h1 className="text-sm font-bold text-slate-900 leading-tight">كشف حساب مالي رسمي</h1>
              <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                <Building2 className="w-3 h-3 text-slate-400" />
                <span>{data.branchName || (isSupplier ? 'نظام الموردين والدائنين' : 'دفتر الديون والأقساط')}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchLiveStatement(true)}
              disabled={refreshing}
              title="تحديث البيانات"
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer border border-slate-200"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              <span>تحديث البيانات</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-2xl mx-auto px-3 sm:px-4 pt-4 sm:pt-6 space-y-4">
        {/* Customer & Account Info Card */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <div className="text-[11px] font-bold text-slate-400 mb-1 flex items-center gap-1.5">
                <span className="font-mono">رقم الحساب: #{data.id}</span>
                <span>•</span>
                <span>{isSupplier ? 'حساب دائن (مورد)' : isInstallment ? 'عقد أجهزة وأقساط' : 'حساب مدين'}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">{name}</h2>
              {phone && (
                <div className="flex items-center gap-1.5 mt-1 text-slate-600 text-xs font-mono dir-ltr justify-end sm:justify-start">
                  <span>{phone}</span>
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                </div>
              )}
            </div>

            <div className="bg-slate-50 px-3 py-2 rounded-2xl border border-slate-200/70 text-right self-start">
              <span className="text-[10px] text-slate-400 font-semibold block">حالة الحساب</span>
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>معتمد ومحدث آلياً</span>
              </span>
            </div>
          </div>

          {/* Supplier Additional Info */}
          {isSupplier && (data.companyName || data.itemType) && (
            <div className="grid grid-cols-2 gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/60 text-xs">
              {data.companyName && (
                <div>
                  <span className="text-slate-400 block mb-0.5 text-[11px]">الجهة / الشركة:</span>
                  <span className="font-bold text-slate-800">{data.companyName}</span>
                </div>
              )}
              {data.itemType && (
                <div>
                  <span className="text-slate-400 block mb-0.5 text-[11px]">نوع البضاعة / التعامل:</span>
                  <span className="font-bold text-slate-800">{data.itemType}</span>
                </div>
              )}
            </div>
          )}

          {/* Installment Additional Info */}
          {isInstallment && (
            <div className="grid grid-cols-2 gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/60 text-xs">
              <div>
                <span className="text-slate-400 block mb-0.5 text-[11px]">السلعة / المادة:</span>
                <span className="font-bold text-slate-800">{data.itemName || 'مشتريات آجل'}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5 text-[11px]">تاريخ الاستحقاق القادم:</span>
                <span className="font-semibold text-slate-700">{formatPortalDate(data.nextDueDate)}</span>
              </div>
            </div>
          )}

          {/* Financial Summary Table */}
          <div className="grid grid-cols-3 gap-2.5 pt-1">
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 text-center">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">
                {isSupplier ? 'إجمالي التعامل' : 'الإجمالي الكلي'}
              </span>
              <div className="text-sm sm:text-base font-black font-mono text-slate-900">
                {formatNumber(totalAmount)} <span className="text-[10px] font-normal text-slate-500">د.ع</span>
              </div>
            </div>

            <div className="bg-emerald-50/70 p-3.5 rounded-2xl border border-emerald-200/80 text-center">
              <span className="text-[11px] font-bold text-emerald-800 block mb-1">
                {isSupplier ? 'المسدد للمورد' : 'المسدد الكلي'}
              </span>
              <div className="text-sm sm:text-base font-black font-mono text-emerald-700">
                {formatNumber(paidAmount)} <span className="text-[10px] font-normal text-emerald-600">د.ع</span>
              </div>
            </div>

            <div className="bg-slate-900 text-white p-3.5 rounded-2xl border border-slate-900 text-center shadow-2xs">
              <span className="text-[11px] font-bold text-slate-300 block mb-1">
                {isSupplier ? 'المتبقي للمورد' : 'المتبقي النهائي'}
              </span>
              <div className="text-sm sm:text-base font-black font-mono text-white">
                {formatNumber(remainingAmount)} <span className="text-[10px] font-normal text-slate-300">د.ع</span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="pt-2 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 text-[11px] flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-slate-500" />
                {isSupplier ? 'نسبة تسديد حساب المورد:' : 'نسبة تسديد الحساب:'}
              </span>
              <span className="font-mono font-bold text-slate-900 text-xs">{percentage}%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden border border-slate-200/80 p-0.5">
              <div
                className="bg-slate-900 h-full rounded-full transition-all duration-700 ease-out"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        </div>

        {/* Transaction History Section */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>سجل الحركات والتسديدات</span>
            </h3>
            <span className="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-md border border-slate-200">
              {rawTransactions.length} حركة
            </span>
          </div>

          {rawTransactions.length === 0 ? (
            <div className="text-center py-8 text-slate-400 space-y-1.5">
              <FileText className="w-8 h-8 mx-auto text-slate-300" />
              <p className="text-xs font-medium text-slate-500">لا توجد حركات سداد أو إضافة سابقة مسجلة</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {rawTransactions.map((tx: any, idx: number) => {
                const txType = tx.type || (isSupplier ? 'add_debt' : isInstallment ? 'pay' : 'add');
                const isSupplierPay = isSupplier && (txType === 'pay_supplier' || txType === 'pay');
                const isPay = !isSupplier && txType === 'pay';
                const isInitial = txType === 'initial';
                const txAmount = Number(tx.amount || 0);

                let badgeText = isSupplier ? 'إضافة دين / بضاعة' : 'إضافة دين جديد';
                let badgeStyle = 'bg-slate-100 text-slate-800 border-slate-200';
                let icon = <PlusCircle className="w-4 h-4 text-slate-600" />;
                let prefix = '+';

                if (isSupplierPay) {
                  badgeText = 'تسديد دفعة للمورد';
                  badgeStyle = 'bg-emerald-50 text-emerald-800 border-emerald-200/80';
                  icon = <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
                  prefix = '-';
                } else if (isPay) {
                  badgeText = 'تسديد دفعة مالية';
                  badgeStyle = 'bg-emerald-50 text-emerald-800 border-emerald-200/80';
                  icon = <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
                  prefix = '-';
                } else if (isInitial) {
                  badgeText = 'فتح حساب - رصيد أولي';
                  badgeStyle = 'bg-blue-50 text-blue-800 border-blue-200/80';
                  icon = <CreditCard className="w-4 h-4 text-blue-600" />;
                  prefix = '+';
                }

                const rawNote = (tx.notes || tx.description || '').trim();
                const isGenericNote =
                  !rawNote ||
                  rawNote === 'فتح حساب وتسجيل الرصيد الأولي' ||
                  rawNote === 'رصيد أولي' ||
                  rawNote === 'تسديد دفعة' ||
                  rawNote === 'إضافة مبلغ جديد';
                const formattedDate = formatPortalDate(tx.date || tx.createdAt);

                return (
                  <div
                    key={tx.id || idx}
                    className="p-3.5 bg-slate-50/70 hover:bg-slate-50 rounded-2xl border border-slate-200/80 transition-colors flex items-center justify-between gap-3 text-start"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 ${badgeStyle}`}>
                        {icon}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${badgeStyle}`}>
                            {badgeText}
                          </span>
                          <span className="text-xs font-mono text-slate-500 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            {formattedDate}
                          </span>
                        </div>

                        {!isGenericNote && (
                          <div className="text-xs text-slate-600 font-medium mt-1 truncate">
                            {rawNote}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="text-left shrink-0">
                      <div className={`text-sm font-black font-mono ${isSupplierPay || isPay ? 'text-emerald-700' : 'text-slate-900'}`}>
                        {prefix}{formatNumber(txAmount)} <span className="text-[10px] font-normal text-slate-500">د.ع</span>
                      </div>
                      {tx.remainingAfter !== undefined && (
                        <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                          المتبقي: {formatNumber(tx.remainingAfter)} د.ع
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Option 2: Prominent, Elegant App Branding & Subscriber Acquisition Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-lg space-y-4 text-start">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-700/60 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-300 text-slate-950 flex items-center justify-center font-black text-xl shadow-md shrink-0">
                <BookOpen className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-extrabold tracking-tight text-white">دفتر الديون والأقساط®</h3>
                  <span className="text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full">
                    حقوق التطبيق محفوظة
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  النظام الذكي لإدارة الديون، الأقساط المباشرة، وكشوفات حساب الموردين
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (onGoToLogin) {
                  onGoToLogin();
                } else {
                  window.location.href = 'https://aldion2-dafterappp.netlify.app';
                }
              }}
              className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0 active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-slate-900" />
              <span>انضم الآن واحصل على حسابك</span>
              <ArrowLeft className="w-4 h-4 text-slate-900" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs text-slate-300 pt-1">
            <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/50">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>كشوفات حساب تفاعلية آمنة عبر QR</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/50">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>إشعارات تسديد وتذكير عبر الواتساب</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/50">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>حفظ سحابي ومزامنة فائقة السرعة</span>
            </div>
          </div>
        </div>

        {/* Clean Document Security Sub-Footer */}
        <div className="pt-1 text-center text-xs text-slate-500 space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-slate-400 text-[11px]">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>كشف حساب مالي رسمي محمي ومحدث آلياً</span>
            {lastUpdated && <span>(آخر تحديث: {lastUpdated})</span>}
          </div>
          <p className="text-[11px] text-slate-400">
            جميع الحقوق محفوظة © دفتر الديون والأقساط • {data.branchName || 'حسابات معتمدة'}
          </p>
        </div>
      </main>
    </div>
  );
};
