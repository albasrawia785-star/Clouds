import React, { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import {
  X,
  Search,
  Printer,
  Trash2,
  Download,
  Upload,
  FileText,
  Eye,
  Check,
  AlertTriangle,
  ChevronRight,
  ChevronLeft,
  ChevronsRight,
  ChevronsLeft,
  Loader2,
} from 'lucide-react';
import { Invoice, PaymentMethod } from '../types';
import { formatIqd, getInvoiceTotalIqd, getPaymentMethodLabel } from '../utils/storage';

interface InventoryModalProps {
  isOpen: boolean;
  isLoading?: boolean;
  onClose: () => void;
  invoices: Invoice[];
  onLoadInvoice: (invoice: Invoice, autoPrint?: boolean) => void;
  onDeleteInvoice: (id: string) => void;
  onImportInvoices: (imported: Invoice[]) => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

const PAGE_SIZE_OPTIONS = [25, 50, 100] as const;

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  isLoading = false,
  onClose,
  invoices,
  onLoadInvoice,
  onDeleteInvoice,
  onImportInvoices,
  onNotify,
}) => {
  const [query, setQuery] = useState('');
  const deferredQuery = useDeferredValue(query);
  const [paymentFilter, setPaymentFilter] = useState<'all' | PaymentMethod>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(50);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const tableScrollRef = useRef<HTMLDivElement>(null);

  const filteredInvoices = useMemo(() => {
    const q = deferredQuery.trim().toLowerCase();
    return invoices.filter((inv) => {
      if (paymentFilter !== 'all' && inv.paymentMethod !== paymentFilter) {
        return false;
      }
      if (!q) return true;
      const inSerial = inv.serialNumber.toLowerCase().includes(q);
      const inName = inv.customerName.toLowerCase().includes(q);
      const inPhone = inv.customerPhone.toLowerCase().includes(q);
      const inNotes = inv.customerNotes.toLowerCase().includes(q);
      const inItems = inv.items.some((item) => item.name.toLowerCase().includes(q));
      return inSerial || inName || inPhone || inNotes || inItems;
    });
  }, [invoices, deferredQuery, paymentFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredInvoices.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);

  // Reset to page 1 when filter or search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [deferredQuery, paymentFilter, pageSize]);

  // Clamp page if items were deleted on the last page
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [currentPage, totalPages]);

  const paginatedInvoices = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredInvoices.slice(start, start + pageSize);
  }, [filteredInvoices, safePage, pageSize]);

  const pageNumbers = useMemo(() => {
    const maxButtons = 5;
    if (totalPages <= maxButtons) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    const half = Math.floor(maxButtons / 2);
    let start = Math.max(1, safePage - half);
    const end = Math.min(totalPages, start + maxButtons - 1);
    start = Math.max(1, end - maxButtons + 1);
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }, [safePage, totalPages]);

  const goToPage = (page: number) => {
    const clamped = Math.max(1, Math.min(totalPages, page));
    setCurrentPage(clamped);
    tableScrollRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalSalesIqd = useMemo(() => {
    return filteredInvoices.reduce((sum, inv) => sum + getInvoiceTotalIqd(inv), 0);
  }, [filteredInvoices]);

  const rangeStart = filteredInvoices.length === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const rangeEnd = Math.min(filteredInvoices.length, safePage * pageSize);

  const handleExportJson = () => {
    try {
      const payload = {
        app: 'AlQaisi-POS',
        version: 1,
        exportedAt: new Date().toISOString(),
        invoices,
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: 'application/json;charset=utf-8',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const today = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `alqaisi-pos-backup-${today}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onNotify('success', `تم تصدير النسخة الاحتياطية (${invoices.length} فاتورة) بنجاح`);
    } catch {
      onNotify('error', 'حدث خطأ أثناء تصدير النسخة الاحتياطية');
    }
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onerror = () => {
      onNotify('error', 'فشل قراءة ملف النسخة الاحتياطية');
    };
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const rawList: unknown = Array.isArray(parsed) ? parsed : parsed?.invoices;
        if (!Array.isArray(rawList)) {
          onNotify('error', 'صيغة ملف النسخة الاحتياطية غير صحيحة');
          return;
        }
        const validInvoices = rawList.filter(
          (item): item is Invoice =>
            Boolean(item) &&
            typeof item === 'object' &&
            typeof (item as Invoice).id === 'string' &&
            typeof (item as Invoice).serialNumber === 'string' &&
            Array.isArray((item as Invoice).items)
        );
        if (validInvoices.length === 0 && rawList.length > 0) {
          onNotify('error', 'لم يتم العثور على فواتير صالحة داخل الملف');
          return;
        }
        onImportInvoices(validInvoices);
      } catch {
        onNotify('error', 'تعذر قراءة ملف JSON — تأكد من سلامة الملف');
      } finally {
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };
    reader.readAsText(file, 'utf-8');
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0A1B36]/60 p-3 sm:p-5 print:hidden"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="inventory-modal-title"
    >
      <div
        className="w-full max-w-5xl max-h-[90vh] bg-white rounded-2xl shadow-2xl border border-[#C3D8EE] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#102E5A] text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-[#FFD000]" />
            <h2 id="inventory-modal-title" className="text-lg font-bold">
              سجل الفواتير والجرد
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary KPI Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 px-6 py-4 bg-[#F2F7FC] border-b border-[#D2E2F2] shrink-0">
          <div className="rounded-xl bg-white border border-[#CBDDF0] px-4 py-3">
            <div className="text-xs font-bold text-[#4A6587]">عدد الفواتير المعروضة</div>
            <div className="text-2xl font-extrabold text-[#0E2A52] tabular-nums mt-0.5">
              {filteredInvoices.length.toLocaleString('en-US')}
              <span className="text-xs font-semibold text-[#5D7B9E] mr-1.5">
                من أصل {invoices.length.toLocaleString('en-US')}
              </span>
            </div>
          </div>

          <div className="rounded-xl bg-white border border-[#CBDDF0] px-4 py-3">
            <div className="text-xs font-bold text-[#4A6587]">إجمالي المبيعات (دينار عراقي)</div>
            <div className="text-2xl font-extrabold text-[#289643] tabular-nums mt-0.5">
              {formatIqd(totalSalesIqd)}
              <span className="text-xs font-bold text-[#4A6587] mr-1.5">د.ع</span>
            </div>
          </div>
        </div>

        {/* Search, Filter & Backup Toolbar */}
        <div className="px-6 py-3.5 bg-white border-b border-[#DCE8F5] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[240px]">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-[#5D7B9E] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث بالاسم، الهاتف، رقم الفاتورة (#0001)، أو الصنف..."
                className="w-full pr-9 pl-3 py-2 rounded-lg border border-[#B5CDE8] bg-[#F8FBFF] text-sm font-semibold text-[#0E2A52] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1669C9]"
              />
            </div>

            {/* Payment filter segmented buttons */}
            <div className="flex items-center gap-1 p-1 bg-[#EBF2F9] rounded-lg">
              {(
                [
                  { id: 'all', label: 'الكل' },
                  { id: 'cash', label: 'نقداً' },
                  { id: 'card', label: 'بطاقة' },
                  { id: 'transfer', label: 'تحويل' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setPaymentFilter(tab.id)}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    paymentFilter === tab.id
                      ? 'bg-[#102E5A] text-white shadow-xs'
                      : 'text-[#35537A] hover:text-[#0E2A52]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Backup Export / Import */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleExportJson}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#EAF3FD] hover:bg-[#D7E9FC] text-[#1258B8] border border-[#B5CDE8] text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>تصدير JSON</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleImportJson}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#F4EEFA] hover:bg-[#E7DBF4] text-[#733999] border border-[#D4BBE8] text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Upload className="w-4 h-4" />
              <span>استيراد JSON</span>
            </button>
          </div>
        </div>

        {/* Invoices Table */}
        <div ref={tableScrollRef} className="overflow-y-auto flex-1">
          {isLoading ? (
            <div className="py-16 px-6 text-center space-y-2.5">
              <Loader2 className="w-10 h-10 text-[#1669C9] mx-auto animate-spin" />
              <div className="text-base font-bold text-[#0E2A52]">
                جارٍ تحميل سجل الفواتير من قاعدة البيانات المحلية...
              </div>
            </div>
          ) : filteredInvoices.length === 0 ? (
            <div className="py-16 px-6 text-center space-y-2">
              <FileText className="w-12 h-12 text-[#A5C4E8] mx-auto" />
              <div className="text-base font-bold text-[#0E2A52]">
                {invoices.length === 0
                  ? 'لا توجد فواتير محفوظة في السجل بعد'
                  : 'لا توجد نتائج تطابق بحثك'}
              </div>
              <p className="text-sm text-[#5D7B9E]">
                {invoices.length === 0
                  ? 'عند الضغط على "حفظ الفاتورة" أو "طباعة الفاتورة" ستُحفظ هنا تلقائياً برقم تسلسلي.'
                  : 'جرب البحث برقم فاتورة آخر أو امسح نص البحث لعرض جميع الفواتير.'}
              </p>
            </div>
          ) : (
            <table className="w-full text-right border-collapse">
              <thead className="bg-[#102E5A] text-white text-xs sticky top-0 z-10">
                <tr>
                  <th className="py-3 px-4 font-bold whitespace-nowrap">رقم الفاتورة</th>
                  <th className="py-3 px-3 font-bold whitespace-nowrap">التاريخ والوقت</th>
                  <th className="py-3 px-3 font-bold">الزبون والهاتف</th>
                  <th className="py-3 px-3 font-bold">الأصناف</th>
                  <th className="py-3 px-3 font-bold text-center whitespace-nowrap">الدفع</th>
                  <th className="py-3 px-3 font-bold text-center whitespace-nowrap">الإجمالي (د.ع)</th>
                  <th className="py-3 px-4 font-bold text-center whitespace-nowrap">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DCE8F5] text-sm">
                {paginatedInvoices.map((inv, idx) => {
                  const isConfirmingDelete = confirmDeleteId === inv.id;
                  const invTotalIqd = getInvoiceTotalIqd(inv);
                  return (
                    <tr
                      key={inv.id}
                      className={idx % 2 === 0 ? 'bg-white hover:bg-[#F5FAFF]' : 'bg-[#F8FBFF] hover:bg-[#EDF5FD]'}
                    >
                      <td className="py-3 px-4 font-extrabold text-[#1258B8] tabular-nums whitespace-nowrap">
                        {inv.serialNumber}
                      </td>
                      <td className="py-3 px-3 text-xs font-semibold text-[#35537A] whitespace-nowrap tabular-nums">
                        <div dir="ltr" className="text-right">
                          {inv.dateDisplay}
                        </div>
                        <div className="text-[#5D7B9E]">{inv.timeDisplay}</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-[#0E2A52]">
                          {inv.customerName || 'زبون نقدي'}
                        </div>
                        {inv.customerPhone && (
                          <div dir="ltr" className="text-xs text-[#4A6587] text-right tabular-nums">
                            {inv.customerPhone}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 max-w-[220px]">
                        <div className="text-xs font-semibold text-[#1D3B68] truncate">
                          {inv.items.map((it) => it.name || 'صنف').join('، ')}
                        </div>
                        <div className="text-[11px] text-[#5D7B9E]">
                          {inv.items.length} {inv.items.length === 1 ? 'صنف' : 'أصناف'}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-center text-xs font-bold text-[#1D3B68] whitespace-nowrap">
                        {getPaymentMethodLabel(inv.paymentMethod)}
                      </td>
                      <td className="py-3 px-3 text-center font-extrabold text-[#289643] tabular-nums whitespace-nowrap">
                        {formatIqd(invTotalIqd)}{' '}
                        <span className="text-xs font-bold text-[#4A6587]">د.ع</span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {isConfirmingDelete ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <span className="text-xs font-bold text-[#D11A2A] flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              حذف؟
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteInvoice(inv.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-2 py-1 rounded-md bg-[#D11A2A] text-white text-xs font-bold hover:bg-[#B01220] cursor-pointer"
                              title="تأكيد الحذف"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2 py-1 rounded-md bg-[#EBF2F9] text-[#1D3B68] text-xs font-bold hover:bg-[#D7E5F4] cursor-pointer"
                              title="تراجع"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                onLoadInvoice(inv, false);
                                onClose();
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#EAF3FD] hover:bg-[#D4E7FC] text-[#1258B8] text-xs font-bold transition-colors cursor-pointer"
                              title="عرض الفاتورة في الشاشة"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>عرض</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                onLoadInvoice(inv, true);
                                onClose();
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1669C9] hover:bg-[#1055A8] text-white text-xs font-bold transition-colors cursor-pointer"
                              title="إعادة طباعة الفاتورة"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>طباعة</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(inv.id)}
                              className="p-1.5 rounded-lg text-[#D11A2A] hover:bg-[#FEECEC] transition-colors cursor-pointer"
                              title="حذف الفاتورة"
                              aria-label="حذف الفاتورة"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination Footer Bar */}
        {!isLoading && filteredInvoices.length > 0 && (
          <div className="px-6 py-3 bg-[#F2F7FC] border-t border-[#D2E2F2] flex flex-wrap items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-3 text-xs font-bold text-[#35537A] tabular-nums">
              <span>
                عرض {rangeStart} – {rangeEnd} من أصل {filteredInvoices.length.toLocaleString('en-US')} فاتورة
              </span>
              <span className="text-[#A5C4E8]" aria-hidden="true">|</span>
              <label className="inline-flex items-center gap-1.5">
                <span>لكل صفحة:</span>
                <select
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                  className="px-2 py-1 rounded-md border border-[#B5CDE8] bg-white text-[#0E2A52] font-bold text-xs focus:outline-none focus:ring-2 focus:ring-[#1669C9] cursor-pointer"
                >
                  {PAGE_SIZE_OPTIONS.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {totalPages > 1 && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={safePage === 1}
                  onClick={() => goToPage(1)}
                  className="p-1.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] hover:bg-[#EAF3FD] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة الأولى"
                  aria-label="الصفحة الأولى"
                >
                  <ChevronsRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={safePage === 1}
                  onClick={() => goToPage(safePage - 1)}
                  className="p-1.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] hover:bg-[#EAF3FD] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة السابقة"
                  aria-label="الصفحة السابقة"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {pageNumbers.map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => goToPage(num)}
                    className={`min-w-[32px] h-8 px-2 rounded-lg text-xs font-extrabold tabular-nums transition-colors cursor-pointer ${
                      num === safePage
                        ? 'bg-[#102E5A] text-white border border-[#102E5A]'
                        : 'bg-white text-[#1D3B68] border border-[#B5CDE8] hover:bg-[#EAF3FD]'
                    }`}
                  >
                    {num}
                  </button>
                ))}

                <button
                  type="button"
                  disabled={safePage === totalPages}
                  onClick={() => goToPage(safePage + 1)}
                  className="p-1.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] hover:bg-[#EAF3FD] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة التالية"
                  aria-label="الصفحة التالية"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={safePage === totalPages}
                  onClick={() => goToPage(totalPages)}
                  className="p-1.5 rounded-lg border border-[#B5CDE8] bg-white text-[#0E2A52] hover:bg-[#EAF3FD] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  title="الصفحة الأخيرة"
                  aria-label="الصفحة الأخيرة"
                >
                  <ChevronsLeft className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
