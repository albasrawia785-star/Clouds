import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { AppLayoutTheme, Currency, FilterType, User } from '../types';
import { formatNumber, formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { getUserBranchDisplayName, getUserRoleDisplayName } from '../utils/userUtils';
import { useI18n } from '../i18n/index.tsx';

export type HeaderMode = 'debts' | 'creditors' | 'installments' | 'suppliers';

interface HeaderCardProps {
  currentUser: User;
  debtorsCount: number;
  totalAmount: number;
  creditorsCount?: number;
  totalCreditorsRemaining?: number;
  installmentsCount?: number;
  totalInstallmentsRemaining?: number;
  suppliersCount?: number;
  totalSuppliersRemaining?: number;
  headerMode?: HeaderMode;
  mode?: HeaderMode;
  filter?: FilterType;
  onHeaderModeChange?: (mode: HeaderMode) => void;
  onModeChange?: (mode: HeaderMode) => void;
  onCurrencyChange?: (curr: Currency) => void;
  onLogout: () => void;
  isSaving?: boolean;
  searchTerm?: string;
  onSearchChange?: (val: string) => void;
  onSecretAdminUnlock?: () => void;
  layoutTheme?: AppLayoutTheme;
  onToggleTheme?: () => void;
  onRefreshData?: () => void;
  isRefreshingData?: boolean;
}

export const HeaderCard: React.FC<HeaderCardProps> = React.memo(({
  currentUser,
  debtorsCount,
  totalAmount,
  creditorsCount = 0,
  totalCreditorsRemaining = 0,
  installmentsCount = 0,
  totalInstallmentsRemaining = 0,
  suppliersCount = 0,
  totalSuppliersRemaining = 0,
  headerMode,
  mode,
  filter,
  onHeaderModeChange,
  onModeChange,
  onCurrencyChange,
  onLogout,
  isSaving = false,
  searchTerm = '',
  onSearchChange,
  onSecretAdminUnlock,
  layoutTheme = 'fintech',
  onToggleTheme,
  onRefreshData,
  isRefreshingData = false,
}) => {
  const { t, formatMoney, getCurrencySymbol, currency, setCurrency } = useI18n();
  const currentMode: HeaderMode = headerMode || mode || 'debts';
  const isCreditors = currentMode === 'creditors';
  const isInstallments = currentMode === 'installments';
  const isSuppliers = currentMode === 'suppliers';

  const allowed = currentUser.allowedModules || 'both';
  const isModeAllowed = (m: HeaderMode): boolean => {
    if (currentUser.role === 'admin') return true;
    if (allowed === 'both' || allowed === 'all') return true;
    if (m === 'debts') return allowed === 'debts' || allowed === 'debts_installments' || allowed === 'debts_suppliers';
    if (m === 'creditors') return allowed === 'creditors' || allowed === 'debts' || allowed === 'debts_installments' || allowed === 'debts_suppliers';
    if (m === 'installments') return allowed === 'installments' || allowed === 'debts_installments' || allowed === 'installments_suppliers';
    if (m === 'suppliers') return allowed === 'suppliers' || allowed === 'debts_suppliers' || allowed === 'installments_suppliers';
    return true;
  };

  const allowedModesCount = (['debts', 'creditors', 'installments', 'suppliers'] as HeaderMode[]).filter(isModeAllowed).length;
  const canSwitchModules = currentUser.role === 'admin' || allowedModesCount > 1;

  const handleSwitchMode = (newMode: HeaderMode) => {
    if (onHeaderModeChange) onHeaderModeChange(newMode);
    if (onModeChange) onModeChange(newMode);
    setIsDropdownOpen(false);
  };

  const [isSearchOpen, setIsSearchOpen] = useState(Boolean(searchTerm));
  const [localSearchInput, setLocalSearchInput] = useState(searchTerm);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<any>(null);

  const [secretClicks, setSecretClicks] = useState(0);
  const secretTimerRef = useRef<any>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [isCurrencyDropdownOpen, setIsCurrencyDropdownOpen] = useState(false);
  const [pendingCurrency, setPendingCurrency] = useState<Currency | null>(null);
  const currencyDropdownRef = useRef<HTMLDivElement>(null);

  const handleSwitchCurrency = (newCurr: Currency) => {
    setIsCurrencyDropdownOpen(false);
    const currentNormalized: Currency = currency === 'USD' ? 'USD' : 'IQD';
    if (newCurr === currentNormalized) return;
    setPendingCurrency(newCurr);
  };

  const handleConfirmSwitchCurrency = () => {
    if (!pendingCurrency) return;
    setCurrency(pendingCurrency);
    if (onCurrencyChange) onCurrencyChange(pendingCurrency);
    setPendingCurrency(null);
  };

  // Sync with external searchTerm if changed externally
  useEffect(() => {
    setLocalSearchInput(searchTerm);
    if (searchTerm) {
      setIsSearchOpen(true);
    }
  }, [searchTerm]);

  const handleSearchInputChange = (val: string) => {
    setLocalSearchInput(val);
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      if (onSearchChange) {
        onSearchChange(val);
      }
    }, 180);
  };

  const handleClearSearch = () => {
    setLocalSearchInput('');
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    if (onSearchChange) onSearchChange('');
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (currencyDropdownRef.current && !currencyDropdownRef.current.contains(e.target as Node)) {
        setIsCurrencyDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTitleTripleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSecretClicks((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        if (secretTimerRef.current) clearTimeout(secretTimerRef.current);
        if (onSecretAdminUnlock) {
          onSecretAdminUnlock();
        }
        return 0;
      }
      if (secretTimerRef.current) clearTimeout(secretTimerRef.current);
      secretTimerRef.current = setTimeout(() => {
        setSecretClicks(0);
      }, 1200);
      return next;
    });
  };

  // When search is opened, focus the input
  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchOpen]);

  const handleToggleSearch = () => {
    if (isSearchOpen) {
      handleClearSearch();
      setIsSearchOpen(false);
    } else {
      setIsSearchOpen(true);
    }
  };

  const currentTotal = isSuppliers ? totalSuppliersRemaining : isInstallments ? totalInstallmentsRemaining : totalAmount;
  const formattedMoneyString = formatMoney(currentTotal);
  const digitsCount = String(Math.round(Math.abs(currentTotal))).length;

  return (
    <div
      id="mainHeaderCard"
      className={`text-white px-3.5 sm:px-4 header-safe-top pb-3.5 sm:pb-4 rounded-b-3xl border-b relative z-20 text-start select-none transition-colors duration-300 ${
        isSuppliers
          ? 'bg-gradient-to-br from-amber-950 via-amber-900 to-slate-950 border-amber-800/60'
          : isInstallments
          ? 'bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950 border-emerald-800/60'
          : isCreditors
          ? 'bg-gradient-to-r from-red-950 via-rose-700 to-rose-500 border-rose-500/60 shadow-lg shadow-rose-950/40'
          : 'bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 border-slate-800/80'
      }`}
    >
      {/* Row 1: Branch Name & Action Controls */}
      <div className="flex justify-between items-center gap-2 relative z-30 mb-2.5">
        {/* Branch Name Display (Click 3 times for secret admin) */}
        <div
          id="headerBranchNameDisplay"
          onClick={handleTitleTripleClick}
          className="flex items-center gap-2 cursor-pointer select-none py-0.5 group min-w-0 flex-1 text-start"
          title={getUserBranchDisplayName(currentUser, t)}
        >
          <div className="text-start min-w-0 flex-1">
            <h1 className="font-black text-xs sm:text-sm md:text-base text-white tracking-tight truncate leading-tight">
              {getUserBranchDisplayName(currentUser, t)}
            </h1>
            <span className={`text-[10px] font-medium block truncate leading-tight mt-0.5 ${isCreditors ? 'text-rose-100' : 'text-slate-400'}`}>
              {getUserRoleDisplayName(currentUser, t)}
            </span>
          </div>
        </div>

        {/* Controls: Refresh & Search Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Desktop / Computer Sync & Refresh Data Button */}
          {onRefreshData && (
            <button
              id="headerRefreshDataBtn"
              type="button"
              onClick={onRefreshData}
              disabled={isRefreshingData}
              title="تحديث ومزامنة كافة البيانات من السحابة فوراً"
              className={`hidden sm:flex items-center justify-center gap-1.5 px-2.5 h-8 rounded-xl text-xs font-bold transition-all cursor-pointer border select-none ${
                isRefreshingData
                  ? 'bg-emerald-600/90 border-emerald-400 text-white shadow-md shadow-emerald-600/30 cursor-wait'
                  : isCreditors
                  ? 'bg-white/15 hover:bg-white/25 border-white/20 text-white active:scale-95'
                  : 'bg-white/10 hover:bg-white/20 border-white/15 text-slate-200 hover:text-white active:scale-95'
              }`}
            >
              <i
                className={`fa-solid fa-arrows-rotate text-[11px] ${
                  isRefreshingData ? 'animate-spin text-white' : 'text-emerald-400'
                }`}
              ></i>
              <span className="text-[11px] whitespace-nowrap">
                {isRefreshingData ? 'جارِ التحديث...' : 'تحديث البيانات'}
              </span>
            </button>
          )}

          {/* Search Button */}
          {onSearchChange && (
            <button
              id="headerSearchBtn"
              type="button"
              onClick={handleToggleSearch}
              title={isSearchOpen ? t('common.close', 'إغلاق البحث') : t('common.search', 'بحث')}
              className={`w-7.5 h-7.5 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs transition-all cursor-pointer relative border ${
                isSearchOpen || localSearchInput || searchTerm
                  ? isInstallments
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-md shadow-emerald-600/30 font-bold scale-105'
                    : isCreditors
                    ? 'bg-rose-800 border-rose-300 text-white shadow-md shadow-rose-950/40 font-bold scale-105'
                    : 'bg-blue-600 border-blue-400 text-white shadow-md shadow-blue-600/30 font-bold scale-105'
                  : isCreditors
                  ? 'bg-white/15 hover:bg-white/25 border-white/20 text-white active:scale-95'
                  : 'bg-white/8 hover:bg-white/15 border-white/10 text-slate-300 active:scale-95'
              }`}
            >
              <i className="fa-solid fa-magnifying-glass text-[11px] sm:text-[11.5px]"></i>
              {(localSearchInput || searchTerm) && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900 animate-pulse"></span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Expandable Live Search Input */}
      {isSearchOpen && onSearchChange && (
        <div className="relative z-10 mb-2.5 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="relative flex items-center">
            <input
              ref={searchInputRef}
              type="text"
              id="headerSearchInput"
              className={`w-full pl-8 pr-9 py-2 bg-slate-900/90 text-white placeholder:text-slate-400 rounded-xl text-xs font-medium outline-none shadow-inner border border-slate-700/80 transition-all ${
                isInstallments
                  ? 'focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30'
                  : isCreditors
                  ? 'focus:border-rose-400 focus:ring-2 focus:ring-rose-400/30'
                  : isSuppliers
                  ? 'focus:border-amber-500 focus:ring-2 focus:ring-amber-500/30'
                  : 'focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30'
              }`}
              placeholder={
                isInstallments
                  ? t('common.searchPlaceholder', "ابحث بالاسم أو السلعة أو الهاتف...")
                  : isCreditors
                  ? "ابحث بالاسم أو رقم هاتف الدائن..."
                  : isSuppliers
                  ? "ابحث باسم المورد أو الشركة أو الهاتف..."
                  : t('common.searchPlaceholder', "ابحث بالاسم أو رقم الهاتف...")
              }
              value={localSearchInput}
              onChange={(e) => handleSearchInputChange(e.target.value)}
            />
            <i className="fa-solid fa-magnifying-glass absolute right-3 text-slate-400 text-xs pointer-events-none"></i>
            {localSearchInput ? (
              <button
                type="button"
                onClick={handleClearSearch}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title={t('common.clear', "مسح البحث")}
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleToggleSearch}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title={t('common.close', "إغلاق البحث")}
              >
                <i className="fa-solid fa-chevron-up text-[10px]"></i>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Row 2: Outstanding Balance / Remaining Installments / Suppliers / Creditors & Compact Dropdown */}
      <div className="flex items-center justify-between gap-2 relative z-10 pt-2 border-t border-white/10 min-w-0">
        <div className="text-start min-w-0 flex-1">
          <div className={`text-[10px] sm:text-[10.5px] font-medium flex items-center gap-1.5 truncate ${isCreditors ? 'text-rose-100' : 'text-slate-400'}`}>
            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isCreditors ? 'bg-white' : isSuppliers ? 'bg-amber-400' : isInstallments ? 'bg-emerald-400' : filter === 'paid_only' ? 'bg-emerald-400' : 'bg-blue-400'}`}></span>
            <span className="truncate">
              {isCreditors
                ? 'إجمالي الديون القائمة عليك (يطلبونك)'
                : isSuppliers
                ? 'إجمالي ديون الموردين'
                : isInstallments
                ? t('header.totalInstallments', 'إجمالي الأقساط المتبقية')
                : filter === 'paid_only'
                ? `ديون تم تسديدها بالكامل (0 ${getCurrencySymbol()})`
                : t('header.totalDebts', 'إجمالي الديون القائمة (لك)')}
            </span>
          </div>
          <div
            className={`font-bold tracking-tight font-mono text-white leading-tight mt-0.5 truncate select-all text-start ${
              digitsCount > 10
                ? 'text-[12px] sm:text-[13px] md:text-sm'
                : digitsCount > 7
                ? 'text-[13px] sm:text-[14px] md:text-[15px]'
                : 'text-[14.5px] sm:text-[15.5px] md:text-base'
            }`}
            id="totalAmount"
            title={formattedMoneyString}
          >
            <span className="truncate inline-block text-start">{formattedMoneyString}</span>
          </div>
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {isSaving && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-[10px] sm:text-[11px]">
              <i className="fa-solid fa-spinner animate-spin text-[10px] text-blue-400"></i>
              <span className="hidden xs:inline">{t('header.savingCloud', 'جارِ الحفظ...')}</span>
            </div>
          )}

          {/* COMPACT CURRENCY DROPDOWN (IQD / USD) */}
          <div className="relative z-30" ref={currencyDropdownRef}>
            <button
              type="button"
              id="headerCurrencyDropdownBtn"
              onClick={() => {
                setIsCurrencyDropdownOpen((prev) => !prev);
                setIsDropdownOpen(false);
              }}
              className={`px-2 sm:px-2.5 py-1 rounded-xl flex items-center gap-1 border shadow-xs transition-all cursor-pointer text-[11px] sm:text-xs font-bold select-none active:scale-95 whitespace-nowrap ${
                currency === 'USD'
                  ? 'bg-emerald-900/95 hover:bg-emerald-800 border-emerald-400/70 text-emerald-100 ring-1 ring-emerald-400/35'
                  : 'bg-slate-800/95 hover:bg-slate-700 border-slate-500/60 text-slate-100 ring-1 ring-white/10'
              }`}
              title="تبديل العملة (دينار عراقي / دولار أمريكي)"
            >
              <div
                className={`w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-md flex items-center justify-center text-[9px] sm:text-[10px] shrink-0 font-black ${
                  currency === 'USD'
                    ? 'bg-emerald-400 text-slate-950'
                    : 'bg-blue-500/90 text-white'
                }`}
              >
                {currency === 'USD' ? '$' : 'د'}
              </div>
              <span>{currency === 'USD' ? 'دولار' : 'دينار'}</span>
              <i
                className={`fa-solid fa-chevron-down text-[8px] transition-transform ${
                  isCurrencyDropdownOpen ? 'rotate-180' : ''
                }`}
              ></i>
            </button>

            {isCurrencyDropdownOpen && (
              <div className="absolute top-full left-0 mt-1.5 w-48 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-1 text-start">
                <div className="px-2 py-1 text-[10px] font-bold text-slate-400 border-b border-slate-800/80">
                  تبديل عملة النظام:
                </div>

                {/* Option 1: IQD (دينار عراقي) */}
                <button
                  type="button"
                  id="selectCurrencyIQDBtn"
                  onClick={() => handleSwitchCurrency('IQD')}
                  className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                    currency !== 'USD'
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-[10px] font-black text-blue-300">
                      د.ع
                    </span>
                    <span>الدينار العراقي (د.ع)</span>
                  </div>
                  {currency !== 'USD' && <i className="fa-solid fa-check text-xs"></i>}
                </button>

                {/* Option 2: USD (دولار أمريكي) */}
                <button
                  type="button"
                  id="selectCurrencyUSDBtn"
                  onClick={() => handleSwitchCurrency('USD')}
                  className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                    currency === 'USD'
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-[11px] font-black text-emerald-300">
                      $
                    </span>
                    <span>الدولار الأمريكي ($)</span>
                  </div>
                  {currency === 'USD' && <i className="fa-solid fa-check text-xs"></i>}
                </button>
              </div>
            )}
          </div>

          {/* COMPACT TOP/LEFT DROPDOWN (OLD MODE) */}
          {canSwitchModules && (
            <div className="relative z-30" ref={dropdownRef}>
              <button
                type="button"
                id="headerModeDropdownBtn"
                onClick={() => {
                  setIsDropdownOpen((prev) => !prev);
                  setIsCurrencyDropdownOpen(false);
                }}
                className={`px-2 sm:px-2.5 py-1 rounded-xl flex items-center gap-1 sm:gap-1.5 border shadow-xs transition-all cursor-pointer text-[11px] sm:text-xs font-bold select-none active:scale-95 whitespace-nowrap ${
                  isCreditors
                    ? 'bg-rose-800/90 hover:bg-rose-800 border-rose-300/80 text-white ring-1 ring-rose-300/30 shadow-xs'
                    : isSuppliers
                    ? 'bg-amber-900/90 hover:bg-amber-800 border-amber-400/60 text-amber-100 ring-1 ring-amber-400/30'
                    : isInstallments
                    ? 'bg-emerald-900/90 hover:bg-emerald-800 border-emerald-400/60 text-emerald-100 ring-1 ring-emerald-400/30'
                    : 'bg-slate-800/95 hover:bg-slate-700 border-blue-400/50 text-blue-100 ring-1 ring-blue-400/25'
                }`}
                title="تبديل النظام المعروض"
              >
                <div className={`w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-md flex items-center justify-center text-[9px] sm:text-[10px] shrink-0 ${
                  isCreditors
                    ? 'bg-white text-rose-700 font-black'
                    : isSuppliers
                    ? 'bg-amber-400 text-slate-950 font-black'
                    : isInstallments
                    ? 'bg-emerald-400 text-slate-950 font-black'
                    : 'bg-blue-500 text-white font-black'
                }`}>
                  <i className={`fa-solid ${isCreditors ? 'fa-hand-holding-dollar' : isSuppliers ? 'fa-truck-field' : isInstallments ? 'fa-clock-rotate-left' : 'fa-users'}`}></i>
                </div>
                <span>
                  {isCreditors
                    ? 'ديون عليه'
                    : isSuppliers
                    ? 'الموردين والشركات'
                    : isInstallments
                    ? 'نظام الأقساط'
                    : 'دفتر الديون'}
                </span>
                <i className={`fa-solid fa-chevron-down text-[9px] transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`}></i>
              </button>

              {/* Dropdown Options Menu */}
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-1.5 w-56 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-1 text-start">
                  <div className="px-2 py-1 text-[10px] font-bold text-slate-400 border-b border-slate-800/80">
                    تبديل النظام المعروض:
                  </div>

                  {/* Option 1: Debts (دفتر الديون - لك) */}
                  {isModeAllowed('debts') && (
                    <button
                      type="button"
                      id="selectModeDebtsBtn"
                      onClick={() => handleSwitchMode('debts')}
                      className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        currentMode === 'debts'
                          ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                          : 'text-slate-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <i className="fa-solid fa-users text-xs text-blue-400"></i>
                        <span>دفتر الديون (لك)</span>
                      </div>
                      {currentMode === 'debts' && <i className="fa-solid fa-check text-xs"></i>}
                    </button>
                  )}

                  {/* Option 2: Creditors (ديون عليه - يطلبونك) */}
                  {isModeAllowed('creditors') && (
                    <button
                      type="button"
                      id="selectModeCreditorsBtn"
                      onClick={() => handleSwitchMode('creditors')}
                      className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        currentMode === 'creditors'
                          ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-xs'
                          : 'text-slate-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <i className="fa-solid fa-hand-holding-dollar text-xs text-rose-400"></i>
                        <span>ديون عليه (يطلبونك)</span>
                      </div>
                      {currentMode === 'creditors' && <i className="fa-solid fa-check text-xs"></i>}
                    </button>
                  )}

                  {/* Option 3: Installments */}
                  {isModeAllowed('installments') && (
                    <button
                      type="button"
                      id="selectModeInstallmentsBtn"
                      onClick={() => handleSwitchMode('installments')}
                      className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        currentMode === 'installments'
                          ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs'
                          : 'text-slate-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <i className="fa-solid fa-file-invoice-dollar text-xs text-emerald-400"></i>
                        <span>نظام الأقساط</span>
                      </div>
                      {currentMode === 'installments' && <i className="fa-solid fa-check text-xs"></i>}
                    </button>
                  )}

                  {/* Option 4: Suppliers */}
                  {isModeAllowed('suppliers') && (
                    <button
                      type="button"
                      id="selectModeSuppliersBtn"
                      onClick={() => handleSwitchMode('suppliers')}
                      className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        currentMode === 'suppliers'
                          ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-xs'
                          : 'text-slate-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <i className="fa-solid fa-truck-field text-xs text-amber-400"></i>
                        <span>الموردين والشركات</span>
                      </div>
                      {currentMode === 'suppliers' && <i className="fa-solid fa-check text-xs"></i>}
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Currency Switch Confirmation Modal */}
      {pendingCurrency && typeof document !== 'undefined' && createPortal(
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setPendingCurrency(null)}
          dir="rtl"
        >
          <div
            className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 text-start"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header Banner */}
            <div
              className={`px-4 py-3.5 flex items-center justify-between text-white ${
                pendingCurrency === 'USD'
                  ? 'bg-gradient-to-r from-emerald-700 to-teal-600'
                  : 'bg-gradient-to-r from-blue-700 to-indigo-600'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center font-black text-sm">
                  {pendingCurrency === 'USD' ? '$' : 'د.ع'}
                </div>
                <div>
                  <h3 className="font-black text-sm leading-tight">
                    تأكيد تحويل العملة
                  </h3>
                  <p className="text-[11px] text-white/85 font-medium mt-0.5">
                    {pendingCurrency === 'USD'
                      ? 'الانتقال إلى نظام الدولار الأمريكي ($)'
                      : 'الانتقال إلى نظام الدينار العراقي (د.ع)'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPendingCurrency(null)}
                className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/90 transition-colors cursor-pointer"
                title="إغلاق"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {/* Body */}
            <div className="p-4 space-y-3.5">
              {/* Transition Visual */}
              <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700/60">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shrink-0 ${
                      currency === 'USD'
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300'
                        : 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                    }`}
                  >
                    {currency === 'USD' ? '$' : 'د.ع'}
                  </span>
                  <div className="truncate">
                    <span className="block text-[10px] text-slate-400 font-bold">العملة الحالية</span>
                    <span className="block text-xs font-black text-slate-700 dark:text-slate-200 truncate">
                      {currency === 'USD' ? 'الدولار ($)' : 'الدينار (د.ع)'}
                    </span>
                  </div>
                </div>

                <div className="w-7 h-7 rounded-full bg-slate-200/70 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-300 shrink-0">
                  <i className="fa-solid fa-arrow-left text-xs"></i>
                </div>

                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shrink-0 ${
                      pendingCurrency === 'USD'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-blue-600 text-white'
                    }`}
                  >
                    {pendingCurrency === 'USD' ? '$' : 'د.ع'}
                  </span>
                  <div className="truncate">
                    <span className="block text-[10px] text-slate-400 font-bold">العملة الجديدة</span>
                    <span className="block text-xs font-black text-slate-900 dark:text-white truncate">
                      {pendingCurrency === 'USD' ? 'الدولار ($)' : 'الدينار (د.ع)'}
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                {pendingCurrency === 'USD'
                  ? 'هل أنت متأكد من التحويل إلى عملة الدولار الأمريكي ($)؟ سيتم عرض وإدارة سجلات ومجاميع الدولار فقط بشكل مستقل تماماً عن سجلات الدينار.'
                  : 'هل أنت متأكد من التحويل إلى عملة الدينار العراقي (د.ع)؟ سيتم عرض وإدارة سجلات ومجاميع الدينار فقط بشكل مستقل تماماً عن سجلات الدولار.'}
              </p>

              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/50 text-[11px] text-amber-800 dark:text-amber-300 font-bold">
                <i className="fa-solid fa-shield-halved text-amber-600 dark:text-amber-400 shrink-0"></i>
                <span>جميع بيانات العملتين محفوظة ومزامنة سحابياً بأمان تام.</span>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  id="confirmSwitchCurrencyBtn"
                  onClick={handleConfirmSwitchCurrency}
                  className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-black text-white shadow-md transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5 ${
                    pendingCurrency === 'USD'
                      ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                      : 'bg-blue-600 hover:bg-blue-700 shadow-blue-600/20'
                  }`}
                >
                  <i className="fa-solid fa-check"></i>
                  <span>
                    نعم، تحويل إلى {pendingCurrency === 'USD' ? 'الدولار ($)' : 'الدينار (د.ع)'}
                  </span>
                </button>
                <button
                  type="button"
                  id="cancelSwitchCurrencyBtn"
                  onClick={() => setPendingCurrency(null)}
                  className="py-2.5 px-4 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-all active:scale-95 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
});

HeaderCard.displayName = 'HeaderCard';
