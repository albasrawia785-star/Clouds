export interface DeletionEvent {
  id: string;
  entityType: 'debtor' | 'creditor' | 'installment' | 'supplier' | 'transaction';
  entityName: string;
  details?: string;
  amount?: number;
  deletedAt: string;
  timestamp: number;
  extraInfo?: string;
  snapshotData?: any;
}

const STORAGE_KEY = 'local_deletions_log';
const MAX_DELETIONS_LOG_SIZE = 100;

export const DELETIONS_UPDATED_EVENT = 'deletions_log_updated';

export const getDeletionEvents = (): DeletionEvent[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to load deletion logs:', err);
    return [];
  }
};

export const saveDeletionEvents = (events: DeletionEvent[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(events.slice(0, MAX_DELETIONS_LOG_SIZE)));
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed to save deletion logs:', err);
  }
};

export const logDeletionEvent = (event: Omit<DeletionEvent, 'id' | 'deletedAt' | 'timestamp'>): DeletionEvent | null => {
  try {
    const now = new Date();
    const newEvent: DeletionEvent = {
      ...event,
      id: `del_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      deletedAt: now.toISOString(),
      timestamp: now.getTime(),
    };

    const existing = getDeletionEvents();
    const updated = [newEvent, ...existing].slice(0, MAX_DELETIONS_LOG_SIZE);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
    return newEvent;
  } catch (err) {
    console.error('Failed to log deletion event:', err);
    return null;
  }
};

export const removeDeletionEvent = (id: string): void => {
  try {
    const existing = getDeletionEvents();
    const updated = existing.filter((e) => e.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed to remove deletion log:', err);
  }
};

export const clearDeletionEvents = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY);
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed to clear deletion logs:', err);
  }
};

