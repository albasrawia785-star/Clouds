import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Debtor, InstallmentRecord, Supplier, NumberFormat } from '../types';
import { formatNumber, formatFullDateTime } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { getDeletionEvents, DELETIONS_UPDATED_EVENT, removeDeletionEvent } from '../utils/deletionLogger';

export interface UnifiedOperation {
  id: string;
  module: 'debts' | 'creditors' | 'installments' | 'suppliers' | 'deletions';
  type:
    | 'debt_add'
    | 'debt_pay'
    | 'debt_new'
    | 'creditor_add'
    | 'creditor_pay'
    | 'creditor_new'
    | 'installment_create'
    | 'installment_pay'
    | 'supplier_invoice'
    | 'supplier_pay'
    | 'deletion';
  title: string;
  personName: string;
  subTitle?: string;
  amount?: number;
  date: string;
  timestamp: number;
  note?: string;
  status: 'completed' | 'error' | 'warning';
  extraInfo?: string;
  snapshotData?: any;
  rawEntityType?: string;
}

interface OperationsLogSectionProps {
  debtors?: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  currencySymbol?: string;
  numberFormat?: NumberFormat;
  onRestoreDeletion?: (eventId: string, snapshotData: any, entityType: string) => Promise<void> | void;
  onConfirmDeletion?: (eventId: string) => Promise<void> | void;
}

const MAX_OPERATIONS_LIMIT = 50;
const INITIAL_LAZY_BATCH = 15;
const LAZY_INCREMENT_STEP = 15;

export const OperationsLogSection: React.FC<OperationsLogSectionProps> = ({
  debtors = [],
  installments = [],
  suppliers = [],
  currencySymbol = 'د.ع',
  numberFormat = 'english',
  onRestoreDeletion,
  onConfirmDeletion,
}) => {
  const [activeFilter, setActiveFilter] = useState<'debts' | 'creditors' | 'installments' | 'suppliers' | 'deletions'>('debts');
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [visibleCount, setVisibleCount] = useState<number>(INITIAL_LAZY_BATCH);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // Listen to deletion log updates and storage events to instantly refresh the deletion tab list
  useEffect(() => {
    const handleUpdate = () => {
      setRefreshKey((k) => k + 1);
    };

    window.addEventListener(DELETIONS_UPDATED_EVENT, handleUpdate);
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'local_deletions_log') {
        setRefreshKey((k) => k + 1);
      }
    };
    window.addEventListener('storage', handleStorage);

    return () => {
      window.removeEventListener(DELETIONS_UPDATED_EVENT, handleUpdate);
      window.removeEventListener('storage', handleStorage);
    };
  }, []);

  // Reset lazy visible count whenever user switches categories
  useEffect(() => {
    setVisibleCount(INITIAL_LAZY_BATCH);
  }, [activeFilter]);

  // Helper to safely parse dates to timestamp
  const parseTimestamp = (dateStr?: string | null): number => {
    if (!dateStr) return 0;
    const t = new Date(dateStr).getTime();
    return isNaN(t) ? 0 : t;
  };

  // Compile all operations dynamically from existing cached state with 0 cloud calls
  const allRawOperations = useMemo<UnifiedOperation[]>(() => {
    const list: UnifiedOperation[] = [];

    // 1. Debtors & Creditors Operations
    for (const debtor of debtors) {
      const isCreditor = debtor.type === 'creditor';

      if (Array.isArray(debtor.history)) {
        for (const tx of debtor.history) {
          const isPay = tx.type === 'pay';

          if (isCreditor) {
            // ديون عليه (الدائنين)
            list.push({
              id: `creditor_tx_${tx.id || Math.random()}_${debtor.id}`,
              module: 'creditors',
              type: isPay ? 'creditor_pay' : 'creditor_add',
              title: isPay ? 'تسديد مستحقات دائن' : 'قيد مبلغ مستحق لدائن',
              personName: debtor.name || 'دائن',
              subTitle: debtor.phone || undefined,
              amount: Number(tx.amount || 0),
              date: tx.date || new Date().toISOString(),
              timestamp: parseTimestamp(tx.date),
              note: tx.note,
              status: 'completed',
              extraInfo: isPay ? 'تم سداد المستحق' : 'تم قيد المبلغ في الحساب',
            });
          } else {
            // ديون لي (الزبائن)
            list.push({
              id: `debt_tx_${tx.id || Math.random()}_${debtor.id}`,
              module: 'debts',
              type: isPay ? 'debt_pay' : 'debt_add',
              title: isPay ? 'تسديد دفعة دين' : 'إضافة دين جديد',
              personName: debtor.name || 'عميل',
              subTitle: debtor.phone || undefined,
              amount: Number(tx.amount || 0),
              date: tx.date || new Date().toISOString(),
              timestamp: parseTimestamp(tx.date),
              note: tx.note,
              status: 'completed',
              extraInfo: isPay ? 'تم السداد بنجاح' : 'تم قيد الدين في الحساب',
            });
          }
        }
      }

      // Initial debtor or creditor registration if no transactions yet
      if ((!debtor.history || debtor.history.length === 0) && debtor.createdAt) {
        if (isCreditor) {
          list.push({
            id: `creditor_new_${debtor.id}`,
            module: 'creditors',
            type: 'creditor_new',
            title: 'تسجيل حساب دائن جديد',
            personName: debtor.name || 'دائن',
            subTitle: debtor.phone || undefined,
            amount: Number(debtor.amount || 0),
            date: debtor.createdAt,
            timestamp: parseTimestamp(debtor.createdAt),
            note: debtor.notes,
            status: 'completed',
            extraInfo: 'رصيد افتتاحي أولي',
          });
        } else {
          list.push({
            id: `debt_new_${debtor.id}`,
            module: 'debts',
            type: 'debt_new',
            title: 'تسجيل عميل مدين جديد',
            personName: debtor.name || 'عميل',
            subTitle: debtor.phone || undefined,
            amount: Number(debtor.amount || 0),
            date: debtor.createdAt,
            timestamp: parseTimestamp(debtor.createdAt),
            note: debtor.notes,
            status: 'completed',
            extraInfo: 'رصيد افتتاحي أولي',
          });
        }
      }
    }

    // 2. Installments Operations
    for (const inst of installments) {
      // Installment creation
      const instCreatedDate = inst.createdAt || inst.registrationDate || new Date().toISOString();
      list.push({
        id: `inst_reg_${inst.id}`,
        module: 'installments',
        type: 'installment_create',
        title: 'تسجيل عقد قسط جديد',
        personName: inst.name || 'مشتري',
        subTitle: inst.item ? `سلعة: ${inst.item}` : (inst.phone || undefined),
        amount: Number(inst.totalAmount || 0),
        date: instCreatedDate,
        timestamp: parseTimestamp(instCreatedDate),
        status: 'completed',
        extraInfo: inst.downPayment > 0 ? `مقدمة: ${formatNumber(inst.downPayment, numberFormat)} ${currencySymbol}` : undefined,
      });

      // Installment payments
      if (Array.isArray(inst.payments)) {
        for (const p of inst.payments) {
          list.push({
            id: `inst_pay_${p.id || Math.random()}_${inst.id}`,
            module: 'installments',
            type: 'installment_pay',
            title: 'تسديد دفعة قسط شهري',
            personName: inst.name || 'مشتري',
            subTitle: inst.item ? `قسط: ${inst.item}` : (inst.phone || undefined),
            amount: Number(p.amount || 0),
            date: p.date || new Date().toISOString(),
            timestamp: parseTimestamp(p.date),
            note: p.notes,
            status: 'completed',
            extraInfo: p.remainingAfter !== undefined ? `المتبقي: ${formatNumber(p.remainingAfter, numberFormat)} ${currencySymbol}` : undefined,
          });
        }
      }
    }

    // 3. Suppliers Operations
    for (const sup of suppliers) {
      if (Array.isArray(sup.history)) {
        for (const stx of sup.history) {
          const isPayment = stx.type === 'pay';
          list.push({
            id: `sup_tx_${stx.id || Math.random()}_${sup.id}`,
            module: 'suppliers',
            type: isPayment ? 'supplier_pay' : 'supplier_invoice',
            title: isPayment ? 'تسديد دفعة للمورد' : 'فاتورة مشتريات من مورد',
            personName: sup.name || 'مورد',
            subTitle: sup.companyName || sup.phone || undefined,
            amount: Number(stx.amount || 0),
            date: stx.date || new Date().toISOString(),
            timestamp: parseTimestamp(stx.date),
            note: stx.note,
            status: 'completed',
            extraInfo: stx.invoiceNumber ? `رقم الفاتورة: #${stx.invoiceNumber}` : undefined,
          });
        }
      }
    }

    // Sort strictly by timestamp descending (most recent first)
    list.sort((a, b) => b.timestamp - a.timestamp);

    return list;
  }, [debtors, installments, suppliers, numberFormat, currencySymbol, refreshKey]);

  // Specific categorized lists (capped up to 50 operations)
  const debtsOps = useMemo(() => {
    return allRawOperations.filter((op) => op.module === 'debts').slice(0, MAX_OPERATIONS_LIMIT);
  }, [allRawOperations]);

  const creditorsOps = useMemo(() => {
    return allRawOperations.filter((op) => op.module === 'creditors').slice(0, MAX_OPERATIONS_LIMIT);
  }, [allRawOperations]);

  const installmentsOps = useMemo(() => {
    return allRawOperations.filter((op) => op.module === 'installments').slice(0, MAX_OPERATIONS_LIMIT);
  }, [allRawOperations]);

  const suppliersOps = useMemo(() => {
    return allRawOperations.filter((op) => op.module === 'suppliers').slice(0, MAX_OPERATIONS_LIMIT);
  }, [allRawOperations]);

  const deletionsOps = useMemo<UnifiedOperation[]>(() => {
    const events = getDeletionEvents();
    return events.map((e) => {
      let entityTypeAr = 'عنصر';
      if (e.entityType === 'debtor') entityTypeAr = 'حساب مدين';
      else if (e.entityType === 'creditor') entityTypeAr = 'حساب دائن';
      else if (e.entityType === 'installment') entityTypeAr = 'عقد قسط';
      else if (e.entityType === 'supplier') entityTypeAr = 'حساب مورد';
      else if (e.entityType === 'transaction') entityTypeAr = 'دفعة / حركة';

      return {
        id: e.id,
        module: 'deletions' as const,
        type: 'deletion' as const,
        title: `حذف ${entityTypeAr}`,
        personName: e.entityName || 'عنصر محذوف',
        subTitle: e.details,
        amount: e.amount,
        date: e.deletedAt,
        timestamp: e.timestamp,
        status: 'warning' as const,
        extraInfo: e.extraInfo || 'سجل حذف محلي',
        snapshotData: e.snapshotData,
        rawEntityType: e.entityType,
      };
    }).slice(0, MAX_OPERATIONS_LIMIT);
  }, [refreshKey]);

  // Filter operations based on user tab selection (shows operations for that category)
  const currentDisplayedOperations = useMemo(() => {
    switch (activeFilter) {
      case 'creditors':
        return creditorsOps;
      case 'installments':
        return installmentsOps;
      case 'suppliers':
        return suppliersOps;
      case 'deletions':
        return deletionsOps;
      case 'debts':
      default:
        return debtsOps;
    }
  }, [activeFilter, debtsOps, creditorsOps, installmentsOps, suppliersOps, deletionsOps]);

  // Lazy Column slice: only render visibleCount items in the DOM
  const visibleOperations = useMemo(() => {
    return currentDisplayedOperations.slice(0, visibleCount);
  }, [currentDisplayedOperations, visibleCount]);

  // IntersectionObserver for automatic lazy column infinite scroll
  useEffect(() => {
    const target = sentinelRef.current;
    if (!target) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setVisibleCount((prev) => {
            if (prev < currentDisplayedOperations.length) {
              return Math.min(prev + LAZY_INCREMENT_STEP, currentDisplayedOperations.length);
            }
            return prev;
          });
        }
      },
      { threshold: 0.1, rootMargin: '120px' }
    );

    observer.observe(target);
    return () => observer.disconnect();
  }, [currentDisplayedOperations.length, visibleCount]);

  // Operation style mapping
  const getOpBadge = (op: UnifiedOperation) => {
    switch (op.type) {
      case 'debt_pay':
        return {
          icon: 'fa-solid fa-hand-holding-dollar',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200/80',
          badgeText: 'تسديد دين',
        };
      case 'debt_add':
      case 'debt_new':
        return {
          icon: 'fa-solid fa-plus',
          bg: 'bg-blue-50 text-blue-700 border-blue-200/80',
          badgeText: 'دين لي',
        };
      case 'creditor_pay':
        return {
          icon: 'fa-solid fa-handshake-angle',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200/80',
          badgeText: 'تسديد دائن',
        };
      case 'creditor_add':
      case 'creditor_new':
        return {
          icon: 'fa-solid fa-file-invoice',
          bg: 'bg-amber-50 text-amber-800 border-amber-200/80',
          badgeText: 'ديون عليه',
        };
      case 'installment_pay':
        return {
          icon: 'fa-solid fa-calendar-check',
          bg: 'bg-indigo-50 text-indigo-700 border-indigo-200/80',
          badgeText: 'دفعة قسط',
        };
      case 'installment_create':
        return {
          icon: 'fa-solid fa-file-invoice-dollar',
          bg: 'bg-purple-50 text-purple-700 border-purple-200/80',
          badgeText: 'عقد قسط',
        };
      case 'supplier_pay':
        return {
          icon: 'fa-solid fa-receipt',
          bg: 'bg-teal-50 text-teal-700 border-teal-200/80',
          badgeText: 'تسديد مورد',
        };
      case 'supplier_invoice':
        return {
          icon: 'fa-solid fa-truck-ramp-box',
          bg: 'bg-amber-50 text-amber-800 border-amber-200/80',
          badgeText: 'فاتورة مورد',
        };
      case 'deletion':
        return {
          icon: 'fa-solid fa-trash-can',
          bg: 'bg-rose-50 text-rose-700 border-rose-200/80',
          badgeText: 'عملية حذف',
        };
      default:
        return {
          icon: 'fa-solid fa-circle-info',
          bg: 'bg-slate-50 text-slate-700 border-slate-200',
          badgeText: 'عملية',
        };
    }
  };

  return (
    <div className="space-y-3 text-start select-none">
      {/* Filter Tabs */}
      <div className="flex items-center justify-between gap-2 pb-1">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none flex-1">
          {[
            { key: 'debts', label: `ديون لي (${debtsOps.length})`, icon: 'fa-solid fa-scale-balanced' },
            { key: 'creditors', label: `ديون عليه (${creditorsOps.length})`, icon: 'fa-solid fa-handshake-angle' },
            { key: 'installments', label: `الأقساط (${installmentsOps.length})`, icon: 'fa-solid fa-calendar-days' },
            { key: 'suppliers', label: `الموردين (${suppliersOps.length})`, icon: 'fa-solid fa-boxes-stacked' },
            { key: 'deletions', label: `عمليات الحذف (${deletionsOps.length})`, icon: 'fa-solid fa-trash-can' },
          ].map((tab) => {
            const isActive = activeFilter === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveFilter(tab.key as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 border ${
                  isActive
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <i className={`${tab.icon} text-[10px]`}></i>
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Operations List Container (Lazy Column rendering) */}
      <div className="space-y-2">
        {currentDisplayedOperations.length === 0 ? (
          <div className="py-10 px-4 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center text-lg mb-2">
              <i className="fa-solid fa-inbox"></i>
            </div>
            <div className="text-xs font-bold text-slate-700">لا توجد عمليات مسجلة في هذا القسم</div>
            <div className="text-[11px] text-slate-400 mt-1">
              ستظهر هنا حركات هذا القسم فور تسجيل أي عملية
            </div>
          </div>
        ) : (
          <>
            {visibleOperations.map((op, idx) => {
              const badge = getOpBadge(op);
              return (
                <div
                  key={op.id || idx}
                  className="p-3 bg-white rounded-2xl border border-slate-200/80 hover:border-slate-300 shadow-2xs hover:shadow-xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-start animate-in fade-in duration-150"
                >
                  {/* Left side: Icon + Title + Name + Subtitle */}
                  <div className="flex items-start sm:items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-2xl border flex items-center justify-center text-sm shrink-0 shadow-2xs ${badge.bg}`}
                    >
                      <i className={badge.icon}></i>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                          {op.personName}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${badge.bg}`}
                        >
                          {badge.badgeText}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5 flex-wrap">
                        <span>{op.title}</span>
                        {op.subTitle && (
                          <>
                            <span className="text-slate-300">•</span>
                            <span className="font-mono text-slate-600">{op.subTitle}</span>
                          </>
                        )}
                        {op.note && (
                          <>
                            <span className="text-slate-300">•</span>
                            <span className="italic text-slate-500 truncate max-w-[180px]">"{op.note}"</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right side: Amount + Date & Extra info + Restore Button */}
                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 shrink-0 gap-1 text-end">
                    {op.amount !== undefined ? (
                      <div
                        className={`text-xs sm:text-sm font-black font-mono tracking-tight ${
                          op.type === 'debt_pay' || op.type === 'creditor_pay' || op.type === 'installment_pay' || op.type === 'supplier_pay'
                            ? 'text-emerald-600'
                            : 'text-slate-900'
                        }`}
                      >
                        {formatNumber(op.amount, numberFormat)} {currencySymbol}
                      </div>
                    ) : null}

                    <div className="text-[10px] sm:text-[11px] font-mono text-slate-400">
                      {formatFullDateTime(op.date, numberFormat)}
                    </div>

                    {op.extraInfo && (
                      <div className="text-[10px] text-slate-400 hidden sm:block">
                        {op.extraInfo}
                      </div>
                    )}

                    {op.module === 'deletions' && (
                      <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                        {op.snapshotData && onRestoreDeletion && (
                          <button
                            type="button"
                            disabled={restoringId === op.id || confirmingId === op.id}
                            onClick={async () => {
                              try {
                                setRestoringId(op.id);
                                await onRestoreDeletion(op.id, op.snapshotData, op.rawEntityType || '');
                              } finally {
                                setRestoringId(null);
                                setRefreshKey((k) => k + 1);
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                            title="التراجع عن عملية الحذف وإعادة البيانات"
                          >
                            {restoringId === op.id ? (
                              <>
                                <i className="fa-solid fa-spinner animate-spin text-[11px]"></i>
                                <span>جاري الاستعادة...</span>
                              </>
                            ) : (
                              <>
                                <i className="fa-solid fa-rotate-left text-[11px]"></i>
                                <span>تراجع عن الحذف</span>
                              </>
                            )}
                          </button>
                        )}

                        <button
                          type="button"
                          disabled={restoringId === op.id || confirmingId === op.id}
                          onClick={async () => {
                            try {
                              setConfirmingId(op.id);
                              if (onConfirmDeletion) {
                                await onConfirmDeletion(op.id);
                              } else {
                                removeDeletionEvent(op.id);
                              }
                            } finally {
                              setConfirmingId(null);
                              setRefreshKey((k) => k + 1);
                            }
                          }}
                          className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200/80 active:bg-rose-200 text-rose-700 font-bold text-xs shadow-2xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                          title="تأكيد الحذف النهائي وإزالة السجل من القائمة"
                        >
                          {confirmingId === op.id ? (
                            <>
                              <i className="fa-solid fa-spinner animate-spin text-[11px]"></i>
                              <span>جاري التأكيد...</span>
                            </>
                          ) : (
                            <>
                              <i className="fa-solid fa-trash-can text-[11px]"></i>
                              <span>تأكيد الحذف</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Lazy Column Sentinel & Load More trigger */}
            {visibleCount < currentDisplayedOperations.length && (
              <div className="pt-2 text-center space-y-2">
                <div ref={sentinelRef} className="h-2 w-full" />
                <button
                  type="button"
                  onClick={() =>
                    setVisibleCount((prev) =>
                      Math.min(prev + LAZY_INCREMENT_STEP, currentDisplayedOperations.length)
                    )
                  }
                  className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all shadow-2xs inline-flex items-center gap-2 cursor-pointer"
                >
                  <i className="fa-solid fa-angles-down text-[11px] text-indigo-600"></i>
                  <span>
                    عرض المزيد ({Math.min(LAZY_INCREMENT_STEP, currentDisplayedOperations.length - visibleCount)} متبقية)
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    ({visibleOperations.length} من {currentDisplayedOperations.length})
                  </span>
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

