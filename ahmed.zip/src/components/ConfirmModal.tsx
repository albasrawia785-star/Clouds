import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmLabel,
  cancelLabel = 'تراجع',
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0A1B36]/60 p-4 print:hidden"
      onClick={onCancel}
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
    >
      <div
        className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-[#C3D8EE] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#FFF5F5] border-b border-[#F8D7DA]">
          <div className="flex items-center gap-2 text-[#D11A2A] font-extrabold text-base">
            <AlertTriangle className="w-5 h-5" />
            <h3 id="confirm-modal-title">{title}</h3>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="p-1 rounded-lg text-[#7A353B] hover:bg-[#FCE3E5] transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 text-sm font-semibold text-[#1D3B68] leading-relaxed">{message}</div>

        <div className="flex items-center justify-end gap-2.5 px-5 py-3.5 bg-[#F8FBFF] border-t border-[#DCE8F5]">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-xl border border-[#B5CDE8] bg-white hover:bg-[#F2F7FC] text-[#1D3B68] font-bold text-sm transition-colors cursor-pointer"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-5 py-2 rounded-xl bg-[#D11A2A] hover:bg-[#B01220] text-white font-bold text-sm transition-colors cursor-pointer shadow-xs"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};
