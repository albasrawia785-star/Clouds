import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n/index.tsx';
import { formatAmountInput, parseFormattedNumber } from '../utils/formatters';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';

interface AddDebtorModalProps {
  isOpen: boolean;
  defaultType?: 'debtor' | 'creditor';
  showTypeSwitcher?: boolean;
  onClose: () => void;
  onSave: (name: string, phone: string, amount: number, debtDate?: string, notes?: string, type?: 'debtor' | 'creditor') => Promise<void>;
}

export const AddDebtorModal: React.FC<AddDebtorModalProps> = ({
  isOpen,
  defaultType = 'debtor',
  showTypeSwitcher = false,
  onClose,
  onSave
}) => {
  const { t, currency } = useI18n();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [debtType, setDebtType] = useState<'debtor' | 'creditor'>(defaultType);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setDebtType(defaultType);
      setError(null);
    }
  }, [isOpen, defaultType]);

  useModalKeyboardAdjust(isOpen);

  if (!isOpen) return null;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmountStr(formatAmountInput(e.target.value));
    if (error) setError(null);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError(debtType === 'creditor' ? 'يرجى كتابة اسم الدائن أولاً' : t('modals.enterDebtorNameError', 'يرجى كتابة اسم المدين أولاً'));
      return;
    }

    const trimmedPhone = phone.trim();
    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError(t('modals.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
      return;
    }

    const numericAmount = parseFormattedNumber(amountStr);
    if (!amountStr.trim() || isNaN(numericAmount) || numericAmount <= 0) {
      setError(debtType === 'creditor' ? 'يرجى كتابة المبلغ المستحق أولاً (يجب أن يكون أكبر من 0)' : 'يرجى كتابة مبلغ الدين أولاً (يجب أن يكون أكبر من 0)');
      return;
    }

    try {
      setIsSubmitting(true);
      await onSave(
        trimmedName,
        trimmedPhone,
        numericAmount,
        debtDate ? new Date(debtDate).toISOString() : undefined,
        notes.trim() || undefined,
        debtType
      );
      setName('');
      setPhone('');
      setAmountStr('');
      setDebtDate(new Date().toISOString().split('T')[0]);
      setNotes('');
      onClose();
    } catch (err: any) {
      setError(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء الحفظ'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const isCreditor = debtType === 'creditor';

  return (
    <div
      id="addModal"
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center z-50 p-0 sm:p-4 animate-in fade-in duration-150 text-start"
    >
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md shadow-2xl relative border border-slate-100 max-h-[92dvh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className={`px-5 py-4 text-white flex items-center justify-between shrink-0 transition-colors duration-300 ${
          isCreditor
            ? 'bg-gradient-to-r from-rose-700 via-rose-800 to-slate-900'
            : 'bg-gradient-to-r from-blue-700 via-indigo-800 to-slate-900'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center text-white border border-white/10">
              <i className={`fa-solid ${isCreditor ? 'fa-hand-holding-dollar' : 'fa-user-plus'} text-base`}></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">
                {isCreditor ? 'إضافة دين عليّ (دائن جديد)' : t('debtors.addDebtor', 'إضافة مدين جديد')}
              </h2>
              <p className="text-[10.5px] text-white/80 mt-0.5 font-medium">
                {isCreditor ? 'تسجيل مبلغ أو شخص يطلبك مالاً في الدفتر' : t('debtors.addDebtorSubtitle', 'تسجيل حساب دين جديد في الدفتر')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form id="addDebtorForm" onSubmit={handleSubmit} className="p-5 pb-28 sm:pb-5 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{error}</span>
            </div>
          )}

          {/* Type Segmented Switcher (Only if enabled) */}
          {showTypeSwitcher && (
            <div className="bg-slate-100 p-1 rounded-2xl flex items-center gap-1 border border-slate-200/80">
              <button
                type="button"
                onClick={() => setDebtType('debtor')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  debtType === 'debtor'
                    ? 'bg-white text-blue-700 shadow-xs border border-slate-200/80 font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-arrow-up-right-from-square text-blue-600"></i>
                <span>دين لي (أطلبه)</span>
              </button>
              <button
                type="button"
                onClick={() => setDebtType('creditor')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  debtType === 'creditor'
                    ? 'bg-rose-600 text-white shadow-xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-hand-holding-dollar"></i>
                <span>دين عليّ (يطلبني)</span>
              </button>
            </div>
          )}

          {/* Debtor/Creditor Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className={`fa-solid fa-user ${isCreditor ? 'text-rose-600' : 'text-blue-600'} text-xs`}></i>
              <span>{isCreditor ? 'اسم الشخص / الدائن (الذي يطلبك)' : t('debts.debtorName', 'اسم المدين')}</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              id="modalName"
              className={`w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm outline-none font-medium transition-all ${
                isCreditor
                  ? 'focus:border-rose-600 focus:ring-2 focus:ring-rose-500/20'
                  : 'focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20'
              }`}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              onFocus={handleInputFocus}
              required
            />
          </div>

          {/* Phone Number */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-phone text-slate-400 text-xs"></i>
              <span>{t('debts.phoneNumber', 'رقم الهاتف')} ({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="tel"
              id="modalPhone"
              dir="ltr"
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-mono font-medium"
              maxLength={11}
              value={phone}
              onChange={handlePhoneChange}
              onFocus={handleInputFocus}
            />
          </div>

          {/* Initial Debt Amount */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className={`fa-solid fa-money-bill-wave ${isCreditor ? 'text-rose-600' : 'text-blue-600'} text-xs`}></i>
              <span>{isCreditor ? 'المبلغ المستحق عليك له' : t('debts.initialDebtAmount', 'مبلغ الدين الأولي')} ({currency})</span>
              <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                id="modalAmount"
                dir="ltr"
                inputMode="numeric"
                placeholder="0"
                required
                className={`w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-sm outline-none font-black font-mono transition-all ${
                  isCreditor
                    ? 'focus:border-rose-600 focus:ring-2 focus:ring-rose-500/20 text-rose-700'
                    : 'focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800'
                }`}
                value={amountStr}
                onChange={handleAmountChange}
                onFocus={handleInputFocus}
              />
            </div>
          </div>

          {/* Debt Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className={`fa-solid fa-calendar-day ${isCreditor ? 'text-rose-600' : 'text-blue-600'} text-xs`}></i>
              <span>{t('debts.debtRegistrationDate', 'تاريخ تسجيل الدين')}</span>
            </label>
            <input
              type="date"
              id="modalDate"
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-mono"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
              onFocus={handleInputFocus}
            />
          </div>

          {/* Notes Field (Optional) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-note-sticky text-slate-400 text-xs"></i>
              <span>{t('common.notes', 'ملاحظات')} ({t('common.optional', 'اختياري')})</span>
            </label>
            <textarea
              id="modalNotes"
              rows={2}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all resize-none font-medium"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              onFocus={handleInputFocus}
              maxLength={250}
            />
          </div>

          {/* Actions */}
          <div className="pt-3 pb-1 flex items-center gap-2">
            <button
              type="submit"
              id="btnSaveSubmit"
              disabled={isSubmitting}
              className={`flex-1 py-3 px-4 rounded-xl text-white text-xs font-extrabold shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 ${
                isCreditor
                  ? 'bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 shadow-rose-600/20'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-blue-600/20'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري الحفظ...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{isCreditor ? 'حفظ الدين (عليّ)' : t('debtors.saveDebtor', 'حفظ المدين')}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
