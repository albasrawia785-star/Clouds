import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import bcrypt from 'bcryptjs';
import { User, ManagerModuleAccess, SupervisorPermissions } from '../types';
import { queryTurso, setLocalSession, queryCustomTursoDirect, getLocalDatabases, saveOfflineUserVault, findMatchingOfflineUser, fetchDatabasesFromCloud } from '../services/turso';
import { useI18n } from '../i18n/index.tsx';
import { setSecuredPassword, getSecuredPassword } from '../utils/sanitize';
import { verifyMasterAdminEmergencyVault, THIRD_DATABASE_CONFIG, SECONDARY_DATABASE_CONFIG } from '../aldion';
import { sanitizeTextInput } from '../utils/securityShield';


interface LoginOverlayProps {
  onLoginSuccess: (user: User) => void;
  initialErrorMessage?: string | null;
}

export const LoginOverlay: React.FC<LoginOverlayProps> = ({
  onLoginSuccess,
  initialErrorMessage,
}) => {
  const { t, language, setLanguage, dir } = useI18n();

  // Mode: 'login' | 'register'
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Register multi-step state:
  // Step 1: Phone number (رقم الهاتف 11 رقم)
  // Step 2: Password (كلمة المرور) & Confirm Password (تأكيد كلمة المرور)
  // Step 3: System Selection (النظام: ديون / أقساط / كلاهما)
  const [regStep, setRegStep] = useState<1 | 2 | 3>(1);
  const [regIdentifier, setRegIdentifier] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regSelectedModule, setRegSelectedModule] = useState<ManagerModuleAccess>('both');

  // Registered user modal state
  const [showTrialWelcomeModal, setShowTrialWelcomeModal] = useState(false);
  const [registeredUserObj, setRegisteredUserObj] = useState<User | null>(null);

  // Master Admin Secret Authentication Modal State (Zero-Knowledge In-Memory Vault)
  const [showMasterAdminModal, setShowMasterAdminModal] = useState(false);
  const [masterAdminPassInput, setMasterAdminPassInput] = useState('');
  const [showMasterAdminPass, setShowMasterAdminPass] = useState(false);
  const [masterAdminError, setMasterAdminError] = useState<string | null>(null);
  const [masterAdminAttempts, setMasterAdminAttempts] = useState(0);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(initialErrorMessage || null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Point 5: Anti Brute-force Lockout State
  const [lockoutRemainingSeconds, setLockoutRemainingSeconds] = useState<number>(() => {
    try {
      const until = parseInt(localStorage.getItem('login_lockout_until') || '0', 10);
      const remaining = Math.ceil((until - Date.now()) / 1000);
      return remaining > 0 ? remaining : 0;
    } catch {
      return 0;
    }
  });

  useEffect(() => {
    if (lockoutRemainingSeconds <= 0) return;
    const timer = setInterval(() => {
      setLockoutRemainingSeconds((prev) => {
        if (prev <= 1) {
          localStorage.removeItem('login_lockout_until');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [lockoutRemainingSeconds]);


  React.useEffect(() => {
    if (initialErrorMessage) {
      setErrorMessage(initialErrorMessage);
    }
  }, [initialErrorMessage]);

  // مزامنة سجل القواعد السحابية تلقائياً فور فتح شاشة تسجيل الدخول
  // لضمان تمكن أي مدير فرعي مضاف في قاعدة جديدة من الدخول فوراً من أي هاتف أو متصفح جديد
  useEffect(() => {
    fetchDatabasesFromCloud().catch(() => {});
  }, []);

  // Secret 10-clicks on title for stealth admin access
  const clickCountRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleSecretAdminClick = () => {
    clickCountRef.current += 1;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      clickCountRef.current = 0;
    }, 1500);

    if (clickCountRef.current >= 10) {
      clickCountRef.current = 0;
      setMasterAdminPassInput('');
      setMasterAdminError(null);
      setShowMasterAdminModal(true);
    }
  };

  const handleVerifyMasterAdmin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (masterAdminAttempts >= 5) {
      setMasterAdminError('تم تجاوز عدد المحاولات المسموح بها! يرجى المحاولة لاحقاً.');
      return;
    }

    const trimmedInput = sanitizeTextInput(masterAdminPassInput, 50);
    if (!trimmedInput) {
      setMasterAdminError('يرجى إدخال رمز المرور السري للمدير العام');
      return;
    }

    try {
      const isValid = verifyMasterAdminEmergencyVault(trimmedInput, bcrypt.compareSync);
      if (isValid) {
        setShowMasterAdminModal(false);
        const adminUser: User = {
          id: 1,
          username: 'admin',
          role: 'admin',
          branch_name: 'main_admin',
        };
        setLocalSession(adminUser);
        onLoginSuccess(adminUser);
      } else {
        setMasterAdminAttempts((prev) => prev + 1);
        setMasterAdminError('❌ رمز المرور غير صحيح! تم رفض الوصول.');
      }
    } catch {
      setMasterAdminError('حدث خطأ في التحقق من الرمز المشفر.');
    }
  };

  const handleInputFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setTimeout(() => {
      e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 200);
  };

  // ----------------------------------------------------
  // LOGIN HANDLER
  // ----------------------------------------------------
  const handleFailedAttempt = () => {
    const currentFails = parseInt(localStorage.getItem('login_failed_attempts') || '0', 10) + 1;
    localStorage.setItem('login_failed_attempts', String(currentFails));
    if (currentFails >= 5) {
      const cooldownSec = currentFails >= 8 ? 120 : currentFails >= 6 ? 60 : 30;
      const lockoutTimestamp = Date.now() + cooldownSec * 1000;
      localStorage.setItem('login_lockout_until', String(lockoutTimestamp));
      setLockoutRemainingSeconds(cooldownSec);
      setErrorMessage(
        `تم إيقاف محاولات الدخول مؤقتاً لمدة ${cooldownSec} ثانية بعد ${currentFails} محاولات خاطئة متتالية للحماية من التخمين.`
      );
    } else {
      setErrorMessage(
        `${t('login.invalidCredentialsError', 'رقم الهاتف أو كلمة المرور غير صحيحة!')} (محاولة ${currentFails} من 5)`
      );
    }
  };

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    // Point 5: Check anti-brute force lockout
    if (lockoutRemainingSeconds > 0) {
      setErrorMessage(
        `الحساب مقفل مؤقتاً لحمايته من محاولات التخمين. يرجى الانتظار (${lockoutRemainingSeconds}) ثانية.`
      );
      return;
    }

    const identifier = sanitizeTextInput(loginIdentifier, 60);
    const cleanIdentifier = identifier.replace(/\s+/g, '');
    const trimmedPass = sanitizeTextInput(loginPassword, 100);

    if (!identifier || !trimmedPass) {
      setErrorMessage(t('login.enterUserPassError', 'يرجى إدخال رقم الهاتف وكلمة المرور'));
      return;
    }

    try {
      setIsLoading(true);
      const userQuery = "SELECT id, username, role, branch_name, password, is_active, subscription_type, subscription_expires_at, allowed_modules, phone_or_email, is_new_registration, birth_date, layout_theme, database_id, plain_password, allow_invoice_upload, parent_manager_id, permissions FROM users WHERE LOWER(username) = LOWER(?) OR phone_or_email = ? OR branch_name = ? OR REPLACE(phone_or_email, ' ', '') = ? OR LOWER(REPLACE(username, ' ', '')) = LOWER(?);";
      const userArgs = [identifier, identifier, identifier, cleanIdentifier, cleanIdentifier];

      let res;
      try {
        res = await queryTurso(userQuery, userArgs);
      } catch {
        // Auto-migrate columns if missing
        await queryTurso("ALTER TABLE users ADD COLUMN phone_or_email TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN birth_date TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN database_id TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allow_invoice_upload INTEGER DEFAULT 1;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN parent_manager_id INTEGER;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN permissions TEXT;").catch(() => {});
        res = await queryTurso(userQuery, userArgs);
      }

      const checkRowPassword = (row: any): boolean => {
        const storedPass = row[4]?.value || '';
        const plainPass = row[14]?.value || '';
        let isMatch = false;
        if (storedPass.startsWith('$2a$') || storedPass.startsWith('$2b$') || storedPass.startsWith('$2y$')) {
          try {
            isMatch = bcrypt.compareSync(trimmedPass, storedPass);
          } catch {}
        }
        if (!isMatch && storedPass) {
          isMatch = storedPass === trimmedPass;
        }
        if (!isMatch && plainPass) {
          isMatch = plainPass === trimmedPass;
        }
        return isMatch;
      };

      const candidateList: { row: any; dbId: string | null }[] = [];
      let matchedCandidate: { row: any; dbId: string | null } | null = null;

      // ترشيد استهلاك القراءة: فحص ما إذا كان المستخدم مسجلاً بقاعدة محددة سابقاً
      const rememberedDbKey = `last_db_${cleanIdentifier.toLowerCase()}`;
      const rememberedDbId = localStorage.getItem(rememberedDbKey);

      // 1. فحص نتائج القاعدة الرئيسية أولاً
      if (res?.results?.[0]?.response?.result?.rows?.length) {
        for (const r of res.results[0].response.result.rows) {
          if (checkRowPassword(r)) {
            matchedCandidate = { row: r, dbId: null };
            break;
          }
          candidateList.push({ row: r, dbId: null });
        }
      }

      // إذا تم العثور على المستخدم ومطابقة كلمة المرور في القاعدة الرئيسية، نكتفي بها فوراً ولا نستعلم باقي السيرفرات!
      if (!matchedCandidate) {
        // إذا كان المستخدم ينتمي لقاعدة مخصصة مسجلة مسبقاً، نفحصها أولاً مباشرة
        if (rememberedDbId && rememberedDbId !== 'primary_db') {
          const customDbs = getLocalDatabases();
          const targetCustom = customDbs.find((c) => c.id === rememberedDbId);
          if (targetCustom && targetCustom.url && targetCustom.token) {
            try {
              const customRes = await queryCustomTursoDirect(
                targetCustom.url,
                targetCustom.token,
                userQuery,
                userArgs
              );
              if (customRes?.results?.[0]?.response?.result?.rows?.length) {
                for (const r of customRes.results[0].response.result.rows) {
                  if (checkRowPassword(r)) {
                    matchedCandidate = { row: r, dbId: targetCustom.id };
                    break;
                  }
                  candidateList.push({ row: r, dbId: targetCustom.id });
                }
              }
            } catch {}
          }
        }
      }

      // 2. إذا لم يتطابق، نفحص باقي القواعد كإجراء احتياطي شامل
      if (!matchedCandidate && SECONDARY_DATABASE_CONFIG.url && SECONDARY_DATABASE_CONFIG.token) {
        try {
          const secRes = await queryCustomTursoDirect(
            SECONDARY_DATABASE_CONFIG.url,
            SECONDARY_DATABASE_CONFIG.token,
            userQuery,
            userArgs
          );
          if (secRes?.results?.[0]?.response?.result?.rows?.length) {
            for (const r of secRes.results[0].response.result.rows) {
              if (checkRowPassword(r)) {
                matchedCandidate = { row: r, dbId: null };
                break;
              }
              candidateList.push({ row: r, dbId: null });
            }
          }
        } catch {}
      }

      if (!matchedCandidate && THIRD_DATABASE_CONFIG.url && THIRD_DATABASE_CONFIG.token) {
        try {
          const thirdRes = await queryCustomTursoDirect(
            THIRD_DATABASE_CONFIG.url,
            THIRD_DATABASE_CONFIG.token,
            userQuery,
            userArgs
          );
          if (thirdRes?.results?.[0]?.response?.result?.rows?.length) {
            for (const r of thirdRes.results[0].response.result.rows) {
              if (checkRowPassword(r)) {
                matchedCandidate = { row: r, dbId: 'builtin_third_alidion2' };
                break;
              }
              candidateList.push({ row: r, dbId: 'builtin_third_alidion2' });
            }
          }
        } catch {}
      }

      // دالة مساعدة للاستعلام الآمن مع الترقية التلقائية لأعمدة الجداول في القواعد المخصصة
      const queryCustomDbSafe = async (url: string, token: string) => {
        try {
          return await queryCustomTursoDirect(url, token, userQuery, userArgs);
        } catch {
          try {
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN phone_or_email TEXT;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN birth_date TEXT;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN database_id TEXT;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN plain_password TEXT;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN allow_invoice_upload INTEGER DEFAULT 1;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN parent_manager_id INTEGER;", []).catch(() => {});
            await queryCustomTursoDirect(url, token, "ALTER TABLE users ADD COLUMN permissions TEXT;", []).catch(() => {});
            return await queryCustomTursoDirect(url, token, userQuery, userArgs);
          } catch {
            return null;
          }
        }
      };

      if (!matchedCandidate) {
        let customDbs = getLocalDatabases();
        // إذا كان الجهاز أو المتصفح جديداً تماماً (لم يسجل فيه المدير العام مسبقاً)، نجلب فوراً سجل القواعد من السحابة
        if (!customDbs || customDbs.length === 0) {
          try {
            customDbs = await fetchDatabasesFromCloud();
          } catch {}
        }

        const checkedDbIds = new Set<string>();
        if (rememberedDbId) checkedDbIds.add(rememberedDbId);

        for (const cDb of (customDbs || [])) {
          if (!cDb.url || !cDb.token || checkedDbIds.has(cDb.id)) continue;
          checkedDbIds.add(cDb.id);
          try {
            const customRes = await queryCustomDbSafe(cDb.url, cDb.token);
            if (customRes?.results?.[0]?.response?.result?.rows?.length) {
              for (const r of customRes.results[0].response.result.rows) {
                if (checkRowPassword(r)) {
                  matchedCandidate = { row: r, dbId: cDb.id };
                  break;
                }
                candidateList.push({ row: r, dbId: cDb.id });
              }
            }
            if (matchedCandidate) break;
          } catch {}
        }

        // إذا لم نعثر على المستخدم بعد، نقوم بجلب أحدث القواعد المسجلة سحابياً احتياطاً للتحقق من أي قاعدة أنشئت حديثاً
        if (!matchedCandidate) {
          try {
            const freshDbs = await fetchDatabasesFromCloud();
            for (const fDb of (freshDbs || [])) {
              if (!fDb.url || !fDb.token || checkedDbIds.has(fDb.id)) continue;
              checkedDbIds.add(fDb.id);
              try {
                const freshRes = await queryCustomDbSafe(fDb.url, fDb.token);
                if (freshRes?.results?.[0]?.response?.result?.rows?.length) {
                  for (const r of freshRes.results[0].response.result.rows) {
                    if (checkRowPassword(r)) {
                      matchedCandidate = { row: r, dbId: fDb.id };
                      break;
                    }
                    candidateList.push({ row: r, dbId: fDb.id });
                  }
                }
                if (matchedCandidate) break;
              } catch {}
            }
          } catch {}
        }
      }

      if (!matchedCandidate && candidateList.length > 0) {
        for (const cand of candidateList) {
          if (checkRowPassword(cand.row)) {
            matchedCandidate = cand;
            break;
          }
        }
      }

      if (matchedCandidate) {
        const row = matchedCandidate.row;
        const matchedDbId = matchedCandidate.dbId;
        // حفظ قاعدة بيانات المستخدم لتسريع الدخول القادم وتوفير القراءات
        try {
          localStorage.setItem(`last_db_${cleanIdentifier.toLowerCase()}`, matchedDbId || 'primary_db');
          if (matchedDbId && matchedDbId !== 'primary_db') {
            const allDbs = getLocalDatabases();
            const thisDb = allDbs.find((d) => d.id === matchedDbId);
            if (thisDb) {
              localStorage.setItem(`aldion_active_db_${matchedDbId}`, JSON.stringify(thisDb));
            }
          }
        } catch {}
        // Reset brute force counters on valid login
        localStorage.removeItem('login_failed_attempts');
        localStorage.removeItem('login_lockout_until');
        setLockoutRemainingSeconds(0);

        const role = row[2]?.value || 'manager';
        const isActiveVal = row[5]?.value;
        const isActive = isActiveVal === 0 || isActiveVal === '0' || isActiveVal === false ? false : true;
        const subscriptionType = (row[6]?.value as any) || 'permanent';
        const subscriptionExpiresAt = row[7]?.value || null;
        const allowedModules = (row[8]?.value as any) || 'both';
        const phoneOrEmail = row[9]?.value || '';
        const isNewRegVal = row[10]?.value;
        const isNewRegistration = isNewRegVal === 1 || isNewRegVal === '1' || isNewRegVal === true || subscriptionType === 'trial';
        const birthDate = row[11]?.value || '';

        // Admin is always active and unaffected by subscription
        if (role !== 'admin') {
          if (!isActive) {
            if (role === 'supervisor') {
              setErrorMessage('تم إيقاف هذا الحساب من قبل مدير الفرع. يرجى مراجعة إدارة الفرع لتنشيط الحساب.');
            } else {
              setErrorMessage(t('login.accountInactiveError', 'تم إيقاف هذا الحساب من قبل الإدارة العامة. يرجى التواصل مع الإدارة لإعادة تنشيطه.'));
            }
            return;
          }

          if (role !== 'supervisor' && subscriptionType === 'monthly') {
            if (!subscriptionExpiresAt || new Date(subscriptionExpiresAt).getTime() <= Date.now()) {
              setErrorMessage(t('login.subscriptionExpiredError', 'انتهت فترة الاشتراك الشهري لهذا الحساب. يرجى مراجعة الإدارة العامة لتأكيد تجديد الاشتراك.'));
              return;
            }
          }
        }

        const parentManagerId = row[16]?.value ? parseInt(row[16].value, 10) : undefined;
        let permissions: SupervisorPermissions | undefined = undefined;
        if (row[17]?.value) {
          try {
            permissions = typeof row[17].value === 'string' ? JSON.parse(row[17].value) : row[17].value;
          } catch {}
        }

        const loggedUser: User = {
          id: parseInt(row[0].value),
          username: row[1].value,
          role,
          branch_name: row[3]?.value || row[1].value || 'الفرع الرئيسي',
          phoneOrEmail,
          password: trimmedPass,
          isActive,
          isNewRegistration,
          subscriptionType,
          subscriptionExpiresAt,
          allowedModules,
          layoutTheme: (row[12]?.value as any) || 'classic',
          birthDate,
          databaseId: row[13]?.value ? String(row[13].value) : matchedDbId || null,
          allowInvoiceUpload: row[15]?.value === undefined || row[15]?.value === null ? true : (row[15]?.value === 1 || row[15]?.value === '1' || row[15]?.value === true),
          parentManagerId,
          permissions,
        };

        // Point 2: Store secured obfuscated passwords instead of plain text
        setSecuredPassword(loggedUser.id, trimmedPass);
        setSecuredPassword(loggedUser.username, trimmedPass);
        setLocalSession(loggedUser);
        saveOfflineUserVault(loggedUser, trimmedPass);
        localStorage.removeItem(`force_logout_user_${loggedUser.id}`);
        onLoginSuccess(loggedUser);
      } else {
        // فحص الخزينة المحلية المحمية في ذاكرة الهاتف (في حال حذف المستخدم أو الجداول من السيرفر)
        const offlineMatch = findMatchingOfflineUser(identifier, trimmedPass);
        if (offlineMatch) {
          localStorage.removeItem('login_failed_attempts');
          localStorage.removeItem('login_lockout_until');
          setLockoutRemainingSeconds(0);
          setLocalSession(offlineMatch);
          localStorage.removeItem(`force_logout_user_${offlineMatch.id}`);
          onLoginSuccess(offlineMatch);
          return;
        }

        // Check local trial user cache
        const localTrialUsersRaw = localStorage.getItem('local_trial_users_cache');
        if (localTrialUsersRaw) {
          try {
            const localUsers: User[] = JSON.parse(localTrialUsersRaw);
            const matched = localUsers.find(
              (u) => (u.username === identifier || u.phoneOrEmail === identifier) && u.password === trimmedPass
            );
            if (matched) {
              setLocalSession(matched);
              setSecuredPassword(matched.id, trimmedPass);
              setSecuredPassword(matched.username, trimmedPass);
              saveOfflineUserVault(matched, trimmedPass);
              onLoginSuccess(matched);
              return;
            }
          } catch {}
        }
        handleFailedAttempt();
      }
    } catch (err: any) {
      // الوضع الصامت عند انقطاع السيرفر، انتهاء المهلة، أو حذف قاعدة البيانات
      console.warn("تعذر الاتصال بالسحابة أثناء تسجيل الدخول، جاري الفحص المحلي:", err?.message || err);
      const offlineMatch = findMatchingOfflineUser(identifier, trimmedPass);
      if (offlineMatch) {
        localStorage.removeItem('login_failed_attempts');
        localStorage.removeItem('login_lockout_until');
        setLockoutRemainingSeconds(0);
        setLocalSession(offlineMatch);
        localStorage.removeItem(`force_logout_user_${offlineMatch.id}`);
        onLoginSuccess(offlineMatch);
        return;
      }

      // إذا لم يتطابق مع أي حساب محلي أو سحابي، إظهار رسالة عدم صحة البيانات المعتادة
      handleFailedAttempt();
    } finally {
      setIsLoading(false);
    }
  };

  // ----------------------------------------------------
  // REGISTRATION VALIDATION & MULTI-STEP NAVIGATION
  // ----------------------------------------------------
  // Step 1: Phone Number (11 digits, numbers only)
  const validateStep1 = () => {
    setErrorMessage(null);
    const phone = regIdentifier.trim();

    if (!phone) {
      setErrorMessage(t('login.reqPhoneError', 'يرجى إدخال رقم الهاتف'));
      return false;
    }
    if (phone.length !== 11 || !/^\d{11}$/.test(phone)) {
      setErrorMessage(t('login.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً فقط (أرقام فقط بدون حروف أو رموز)'));
      return false;
    }
    return true;
  };

  // Step 2: Password and Confirm Password
  const validateStep2 = () => {
    setErrorMessage(null);
    const trimmedPass = regPassword.trim();
    const trimmedConfirm = regConfirmPassword.trim();

    if (!trimmedPass) {
      setErrorMessage(t('login.reqPasswordError', 'يرجى كتابة كلمة المرور'));
      return false;
    }
    if (trimmedPass.length < 3) {
      setErrorMessage(t('login.passwordMinError', 'كلمة المرور يجب ألا تقل عن 3 خانات'));
      return false;
    }
    if (trimmedConfirm && trimmedConfirm !== trimmedPass) {
      setErrorMessage(t('login.passwordMismatchError', 'كلمتا المرور غير متطابقتين'));
      return false;
    }
    return true;
  };

  const handleNextStep = () => {
    if (regStep === 1) {
      if (validateStep1()) {
        setRegStep(2);
      }
    } else if (regStep === 2) {
      if (validateStep2()) {
        handleRegister();
      }
    }
  };

  const handlePrevStep = () => {
    setErrorMessage(null);
    if (regStep > 1) {
      setRegStep(1);
    }
  };

  // ----------------------------------------------------
  // FINAL REGISTRATION SUBMIT
  // ----------------------------------------------------
  const handleRegister = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!validateStep1()) {
      setRegStep(1);
      return;
    }
    if (!validateStep2()) {
      setRegStep(2);
      return;
    }

    const trimmedIdentifier = regIdentifier.trim();
    const trimmedPass = regPassword.trim();

    try {
      setIsLoading(true);

      const nowIso = new Date().toISOString();
      const newUserId = Date.now();

      // Completely Local Trial Account (0 Cloud Row Writes / 0 Bandwidth Consumption)
      const newUser: User = {
        id: newUserId,
        username: trimmedIdentifier,
        phoneOrEmail: trimmedIdentifier,
        role: 'manager',
        branch_name: trimmedIdentifier,
        password: trimmedPass,
        isActive: true,
        isNewRegistration: true,
        subscriptionType: 'trial',
        subscriptionExpiresAt: null,
        allowedModules: regSelectedModule,
        birthDate: '',
        createdAt: nowIso,
      };

      // Store in local trial cache for persistent local trial login
      try {
        const existingRaw = localStorage.getItem('local_trial_users_cache');
        const existing: User[] = existingRaw ? JSON.parse(existingRaw) : [];
        const filtered = existing.filter(
          (u) => u.username !== trimmedIdentifier && u.phoneOrEmail !== trimmedIdentifier
        );
        filtered.push(newUser);
        localStorage.setItem('local_trial_users_cache', JSON.stringify(filtered));
      } catch (cacheErr) {
        console.warn('Could not cache local trial user:', cacheErr);
      }

      setSecuredPassword(newUserId, trimmedPass);
      setSecuredPassword(trimmedIdentifier, trimmedPass);
      setLocalSession(newUser);

      setRegisteredUserObj(newUser);
      setShowTrialWelcomeModal(true);
    } catch (err: any) {
      setErrorMessage(err?.message || t('common.errorOccurred', 'تعذر إنشاء الحساب، يرجى المحاولة مرة أخرى'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      id="loginOverlay"
      dir={dir}
      className="min-h-[100dvh] w-full flex flex-col items-center justify-between px-3.5 py-3 sm:py-5 safe-top safe-bottom bg-[#070e24] relative selection:bg-cyan-500 selection:text-white overflow-y-auto overscroll-contain select-none"
    >
      {/* 1. Subtle Circuit Background Pattern */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.06] stroke-cyan-400 fill-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <pattern id="circuit-grid-native" width="100" height="100" patternUnits="userSpaceOnUse">
          <path d="M 0 25 L 25 25 L 40 40 L 65 40 L 75 25 L 100 25" strokeWidth="1" />
          <path d="M 25 100 L 25 75 L 45 55 L 70 55 L 85 70 L 100 70" strokeWidth="1" />
          <circle cx="40" cy="40" r="1.8" className="fill-cyan-400 stroke-none" />
          <circle cx="75" cy="25" r="1.5" className="fill-blue-400 stroke-none" />
          <circle cx="45" cy="55" r="1.5" className="fill-cyan-300 stroke-none" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#circuit-grid-native)" />
      </svg>

      {/* Soft Ambient Glows */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-blue-600/10 blur-[70px] pointer-events-none" />
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-cyan-600/10 blur-[80px] pointer-events-none" />

      {/* 2. Top Language Selector (عربي | كردي) */}
      <div className="relative z-20 w-full max-w-[390px] flex justify-center items-center shrink-0">
        <div className="bg-[#0b142d] border border-slate-700/60 p-0.5 rounded-xl flex items-center gap-1 shadow-sm">
          <button
            type="button"
            id="langBtnAr"
            onClick={() => setLanguage('ar')}
            className={`px-3.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              language === 'ar'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('login.langAr', 'عربي')}
          </button>
          <button
            type="button"
            id="langBtnKu"
            onClick={() => setLanguage('ku')}
            className={`px-3.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              language === 'ku'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('login.langKu', 'كردي')}
          </button>
        </div>
      </div>

      {/* 3. Main Center Area (Brand Header + Clean Responsive Card) */}
      <div className="relative z-10 w-full max-w-[390px] flex flex-col items-center my-auto py-1">
        
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-2.5 w-full">
          {/* Logo Mark */}
          <div className="mb-1.5 filter drop-shadow-[0_4px_12px_rgba(6,182,212,0.25)]">
            <svg
              className="w-13 h-10 sm:w-16 sm:h-12"
              viewBox="0 0 120 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="logoSilver" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="60%" stopColor="#cbd5e1" />
                  <stop offset="100%" stopColor="#94a3b8" />
                </linearGradient>
                <linearGradient id="logoBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#1d4ed8" />
                </linearGradient>
                <linearGradient id="logoDarkBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563eb" />
                  <stop offset="100%" stopColor="#1e3a8a" />
                </linearGradient>
                <linearGradient id="logoCyan" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="50%" stopColor="#22d3ee" />
                  <stop offset="100%" stopColor="#38bdf8" />
                </linearGradient>
                <linearGradient id="logoPeach" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f8fafc" />
                  <stop offset="100%" stopColor="#cbd5e1" />
                </linearGradient>
                <linearGradient id="logoTeal" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0891b2" />
                  <stop offset="100%" stopColor="#0e7490" />
                </linearGradient>
              </defs>

              <polygon points="18,22 42,22 34,48 18,36" fill="url(#logoSilver)" />
              <polygon points="42,22 56,48 34,48" fill="#94a3b8" opacity="0.8" />
              <polygon points="18,36 34,48 26,74 18,66" fill="url(#logoBlue)" />
              <polygon points="26,74 34,48 48,74" fill="url(#logoDarkBlue)" />
              <polygon points="56,22 74,22 84,62 66,62" fill="url(#logoPeach)" />
              <polygon points="48,74 62,50 72,74" fill="#172554" />
              <polygon points="72,74 84,62 94,74" fill="url(#logoTeal)" />
              <polygon points="34,74 54,48 64,60 48,74" fill="url(#logoBlue)" />
              <polygon points="54,48 64,60 92,26 84,18" fill="url(#logoCyan)" />
              <polygon points="78,20 102,14 96,38 88,28" fill="url(#logoCyan)" />
            </svg>
          </div>

          <h1
            id="loginTitle"
            onClick={handleSecretAdminClick}
            className="text-lg sm:text-xl font-bold text-white tracking-wide cursor-pointer select-none"
          >
            {t('login.title', 'دفتر الديون والأقساط')}
          </h1>

          <p className="text-[11px] font-normal text-slate-300/80 mt-0.5">
            {t('login.subtitle', 'نظام إدارة الديون والأقساط والحسابات المالية')}
          </p>
        </div>

        {/* 4. Native iOS/Android Optimized Card */}
        <div className="w-full bg-[#0d162f]/95 rounded-2xl p-3.5 sm:p-4 shadow-[0_12px_32px_rgba(0,0,0,0.5)] border border-slate-700/50 relative overflow-hidden text-start">
          
          {/* Top Tabs (تسجيل الدخول / إنشاء حساب جديد) */}
          <div className="grid grid-cols-2 p-1 bg-[#081024] border border-slate-700/40 rounded-xl mb-3">
            <button
              type="button"
              id="tabSwitchLogin"
              onClick={() => {
                setAuthMode('login');
                setErrorMessage(null);
              }}
              className={`h-9 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                authMode === 'login'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <i className="fa-solid fa-right-to-bracket text-xs"></i>
              <span className="truncate">{t('login.loginTab', 'تسجيل الدخول')}</span>
            </button>

            <button
              type="button"
              id="tabSwitchRegister"
              onClick={() => {
                setAuthMode('register');
                setRegStep(1);
                setErrorMessage(null);
              }}
              className={`h-9 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                authMode === 'register'
                  ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <i className="fa-solid fa-user-plus text-xs"></i>
              <span className="truncate">{t('login.registerTab', 'إنشاء حساب جديد')}</span>
            </button>
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div className="mb-2.5 p-2 bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs font-medium rounded-xl flex items-start gap-2 animate-in fade-in duration-150">
              <i className="fa-solid fa-circle-exclamation text-rose-400 mt-0.5 shrink-0 text-xs"></i>
              <span className="leading-relaxed flex-1">{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-2.5 p-2 bg-emerald-950/70 border border-emerald-500/40 text-emerald-200 text-xs font-medium rounded-xl flex items-start gap-2 animate-in fade-in duration-150">
              <i className="fa-solid fa-circle-check text-emerald-400 mt-0.5 shrink-0 text-xs"></i>
              <span className="leading-relaxed flex-1">{successMessage}</span>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 1: LOGIN VIEW */}
          {/* ======================================================== */}
          {authMode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-3">
              {/* Field: Phone Number */}
              <div>
                <label
                  htmlFor="loginIdentifier"
                  className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                >
                  {t('login.loginIdentifier', 'رقم الهاتف')} <span className="text-cyan-400">*</span>
                </label>

                <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                  <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                    <i className="fa-solid fa-mobile-screen-button text-xs"></i>
                  </div>

                  <input
                    type="tel"
                    inputMode="numeric"
                    id="loginIdentifier"
                    dir="ltr"
                    placeholder="07XXXXXXXXX"
                    autoComplete="off"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    className="flex-1 bg-transparent text-center font-mono font-bold tracking-wider text-white text-sm outline-none px-2 h-full"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    onFocus={handleInputFocus}
                    disabled={isLoading}
                    required
                  />
                </div>
              </div>

              {/* Field: Password */}
              <div>
                <label
                  htmlFor="loginPassword"
                  className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                >
                  {t('login.password', 'كلمة المرور')}
                </label>

                <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                  <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                    <i className="fa-solid fa-lock text-xs"></i>
                  </div>

                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    id="loginPassword"
                    dir={dir}
                    autoComplete="off"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    onFocus={handleInputFocus}
                    disabled={isLoading}
                    required
                  />

                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer text-xs shrink-0 active:scale-95"
                    tabIndex={-1}
                    title={showLoginPassword ? t('login.hidePassword', 'إخفاء كلمة المرور') : t('login.showPassword', 'إظهار كلمة المرور')}
                  >
                    <i className={`fa-regular ${showLoginPassword ? 'fa-eye text-cyan-400' : 'fa-eye-slash text-slate-400'}`}></i>
                  </button>
                </div>
              </div>

              {/* Submit Login Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  id="btnLoginSubmit"
                  className="w-full h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 via-teal-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-60 disabled:pointer-events-none cursor-pointer shadow-md shadow-cyan-900/20"
                  disabled={isLoading || lockoutRemainingSeconds > 0}
                >
                  {isLoading ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>{t('login.loggingIn', 'جاري التحقق...')}</span>
                    </>
                  ) : lockoutRemainingSeconds > 0 ? (
                    <>
                      <i className="fa-solid fa-shield-halved text-amber-300 text-xs"></i>
                      <span>{`مغلق مؤقتاً (${lockoutRemainingSeconds} ثانية)`}</span>
                    </>
                  ) : (
                    <>
                      <span>{t('login.loginBtn', 'تسجيل الدخول')}</span>
                      <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                    </>
                  )}
                </button>
              </div>

              {/* Switch to Register */}
              <div className="pt-1 text-center text-xs text-slate-400">
                <span>{t('login.noAccount', 'ليس لديك حساب؟')}{' '}</span>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('register');
                    setRegStep(1);
                    setErrorMessage(null);
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-bold cursor-pointer underline-offset-2 hover:underline"
                >
                  {t('login.createAccountNow', 'إنشاء حساب جديد')}
                </button>
              </div>
            </form>
          ) : (
            /* ======================================================== */
            /* TAB 2: REGISTER VIEW (MULTI-STEP WIZARD) */
            /* ======================================================== */
            <div className="space-y-3">
              {/* Horizontal Steps Indicator:
                  1. رقم الهاتف (11 رقم)
                  2. كلمة المرور وتأكيد الحساب
              */}
              <div className="py-1 px-2 bg-[#091126] border border-slate-700/40 rounded-xl">
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400">
                  
                  {/* Step 1 Item */}
                  <button
                    type="button"
                    onClick={() => {
                      if (regStep > 1) {
                        setErrorMessage(null);
                        setRegStep(1);
                      }
                    }}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      regStep === 1
                        ? 'text-cyan-400 font-bold'
                        : 'text-emerald-400'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        regStep === 1
                          ? 'bg-cyan-500 text-slate-950 font-black'
                          : 'bg-emerald-500 text-slate-950'
                      }`}
                    >
                      {regStep > 1 ? <i className="fa-solid fa-check text-[9px]"></i> : '1'}
                    </span>
                    <span>{t('login.stepPhone', 'رقم الهاتف')}</span>
                  </button>

                  <i className={`fa-solid ${dir === 'rtl' ? 'fa-angle-left' : 'fa-angle-right'} text-[10px] text-slate-600`}></i>

                  {/* Step 2 Item */}
                  <div
                    className={`flex items-center gap-1.5 transition-colors ${
                      regStep === 2
                        ? 'text-cyan-400 font-bold'
                        : 'text-slate-500'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        regStep === 2
                          ? 'bg-cyan-500 text-slate-950 font-black'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      2
                    </span>
                    <span>{t('login.stepPassword', 'كلمة المرور')}</span>
                  </div>
                </div>
              </div>

              {/* Step Content */}
              <AnimatePresence mode="wait">
                {/* ----------------- STEP 1: PHONE NUMBER ONLY ----------------- */}
                {regStep === 1 && (
                  <motion.div
                    key="step-1"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-3"
                  >
                    {/* Phone Number Field */}
                    <div>
                      <label
                        htmlFor="regIdentifier"
                        className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                      >
                        {t('login.phoneNumberLabel', 'ادخل رقم الهاتف')} <span className="text-cyan-400">*</span>
                      </label>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                          <i className="fa-solid fa-mobile-screen-button text-xs"></i>
                        </div>

                        <input
                          type="tel"
                          inputMode="numeric"
                          maxLength={11}
                          pattern="[0-9]*"
                          id="regIdentifier"
                          dir="ltr"
                          placeholder="07XXXXXXXXX"
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-center font-mono font-bold tracking-widest text-white text-sm outline-none px-2 h-full"
                          value={regIdentifier}
                          onChange={(e) => {
                            // Strictly permit ONLY numbers 0-9 and max 11 digits
                            const digitsOnly = e.target.value.replace(/\D/g, '').slice(0, 11);
                            setRegIdentifier(digitsOnly);
                          }}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleNextStep();
                            }
                          }}
                          disabled={isLoading}
                          required
                          autoFocus
                        />

                        <span className="text-[10px] font-mono text-slate-500 shrink-0 dir-ltr">
                          {regIdentifier.length}/11
                        </span>
                      </div>
                    </div>

                    {/* Step 1 Action Button */}
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={handleNextStep}
                        className="w-full h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-cyan-900/20"
                      >
                        <span>{t('login.nextToPassword', 'متابعة')}</span>
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                      </button>
                    </div>

                    {/* Back to Login Link */}
                    <div className="pt-0.5 text-center text-xs text-slate-400">
                      <span>{t('login.haveAccount', 'لديك حساب بالفعل؟')}{' '}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('login');
                          setErrorMessage(null);
                        }}
                        className="text-cyan-400 hover:text-cyan-300 font-bold cursor-pointer underline-offset-2 hover:underline"
                      >
                        {t('login.loginTab', 'تسجيل الدخول')}
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* ----------------- STEP 2: PASSWORD + CONFIRM & SUBMIT ----------------- */}
                {regStep === 2 && (
                  <motion.div
                    key="step-2"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-3"
                  >
                    <div className="text-[11px] font-semibold text-cyan-300/90 flex items-center gap-1.5">
                      <i className="fa-solid fa-shield-halved text-xs"></i>
                      <span>{t('login.step2Title', 'تعيين كلمة المرور')}</span>
                    </div>

                    {/* Field 1: Password */}
                    <div>
                      <label
                        htmlFor="regPassword"
                        className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                      >
                        {t('login.password', 'كلمة المرور')} <span className="text-cyan-400">*</span>
                      </label>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                          <i className="fa-solid fa-lock text-xs"></i>
                        </div>

                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          id="regPassword"
                          dir={dir}
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleNextStep();
                            }
                          }}
                          disabled={isLoading}
                          required
                          autoFocus
                        />

                        <button
                          type="button"
                          onClick={() => setShowRegPassword(!showRegPassword)}
                          className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer text-xs shrink-0 active:scale-95"
                          tabIndex={-1}
                        >
                          <i className={`fa-regular ${showRegPassword ? 'fa-eye text-cyan-400' : 'fa-eye-slash text-slate-400'}`}></i>
                        </button>
                      </div>
                    </div>

                    {/* Field 2: Confirm Password */}
                    <div>
                      <label
                        htmlFor="regConfirmPassword"
                        className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                      >
                        {t('login.confirmPassword', 'تأكيد كلمة المرور')} <span className="text-cyan-400">*</span>
                      </label>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                          <i className="fa-solid fa-key text-xs"></i>
                        </div>

                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          id="regConfirmPassword"
                          dir={dir}
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                          value={regConfirmPassword}
                          onChange={(e) => setRegConfirmPassword(e.target.value)}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleNextStep();
                            }
                          }}
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    {/* Step 2 Actions */}
                    <div className="pt-1 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handlePrevStep}
                        className="h-11 px-3.5 rounded-xl font-semibold text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all flex items-center justify-center gap-1 cursor-pointer border border-slate-700/60 shrink-0 active:scale-95"
                      >
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-right' : 'fa-arrow-left'} text-xs`}></i>
                        <span>{t('login.prevStep', 'السابق')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleRegister}
                        disabled={isLoading}
                        className="flex-1 h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer shadow-md shadow-teal-900/25"
                      >
                        {isLoading ? (
                          <>
                            <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                            <span>{t('login.creatingAccount', 'جاري إنشاء الحساب...')}</span>
                          </>
                        ) : (
                          <>
                            <i className="fa-solid fa-circle-check text-xs"></i>
                            <span>{t('login.createAccountBtn', 'تأكيد وإنشاء الحساب')}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* 5. Secure Bottom Badge */}
          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-slate-400 text-[11px]">
            <i className="fa-solid fa-shield-halved text-cyan-400 text-xs"></i>
            <span>{t('login.secureBadge', 'بياناتك محفوظة وآمنة')}</span>
          </div>
        </div>
      </div>

      {/* 6. Trial Mode Welcome Modal Modal */}
      {showTrialWelcomeModal && registeredUserObj && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200 select-none overflow-y-auto safe-top safe-bottom">
          <div className="bg-[#0e1733] border border-cyan-500/40 rounded-3xl w-full max-w-sm p-5 text-center shadow-2xl relative overflow-hidden my-auto">
            {/* Soft Ambient Glows */}
            <div className="absolute -top-12 -left-12 w-32 h-32 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            {/* Badge Icon */}
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500/20 via-cyan-500/20 to-teal-500/20 border border-amber-400/40 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/10">
              <i className="fa-solid fa-crown text-2xl text-amber-400"></i>
            </div>

            {/* Title */}
            <h3 className="text-base font-black text-white mb-2 leading-tight">
              أنت الآن في الوضع التجريبي 🌟
            </h3>

            {/* Encouraging Note Box */}
            <div className="p-3.5 bg-[#081024] border border-slate-800 rounded-2xl mb-4 text-start space-y-2.5">
              <p className="text-xs text-slate-300 leading-relaxed">
                مرحباً بك! تم إنشاء حسابك بنجاح. يمكنك الآن تجربة كافة الخصائص وإدارة الحسابات والديون بسهولة واحترافية.
              </p>
              
              <div className="pt-2 border-t border-slate-800/80 flex items-start gap-2 text-amber-300/90 text-[11px] leading-relaxed">
                <i className="fa-solid fa-sparkles text-amber-400 text-xs mt-0.5 shrink-0"></i>
                <span>
                  للاستفادة من المزامنة السحابية غير المحدودة والحفاظ على بياناتك آمنة دائماً مع دعم فني مباشر، يسعدنا انضمامك واشتراكك في النسخة الكاملة!
                </span>
              </div>
            </div>

            {/* Action Button */}
            <button
              type="button"
              onClick={() => {
                setShowTrialWelcomeModal(false);
                if (registeredUserObj) {
                  onLoginSuccess(registeredUserObj);
                }
              }}
              className="w-full h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-900/30 cursor-pointer"
            >
              <span>بدء استخدام النظام</span>
              <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
            </button>
          </div>
        </div>
      )}

      {/* 7. Secret Master Admin Password Modal (Encrypted via Bcrypt) */}
      {showMasterAdminModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200 select-none overflow-y-auto safe-top safe-bottom">
          <div className="bg-[#0b1329] border border-cyan-500/50 rounded-3xl w-full max-w-sm p-5 text-center shadow-2xl relative overflow-hidden my-auto">
            {/* Ambient Glows */}
            <div className="absolute -top-12 -left-12 w-36 h-36 bg-blue-600/25 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-12 -right-12 w-36 h-36 bg-cyan-500/25 rounded-full blur-3xl pointer-events-none" />

            {/* Shield Icon */}
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600/30 to-cyan-500/30 border border-cyan-400/40 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-cyan-500/20">
              <i className="fa-solid fa-shield-halved text-2xl text-cyan-400"></i>
            </div>

            {/* Title */}
            <h3 className="text-base font-black text-white mb-1">
              التحقق من هوية المدير العام 🛡️
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              يرجى إدخال رمز المرور السري المشفر لفتح لوحة التحكم
            </p>

            {/* Error Message */}
            {masterAdminError && (
              <div className="mb-3 p-2.5 bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-semibold rounded-xl flex items-center gap-2 text-start animate-in fade-in">
                <i className="fa-solid fa-triangle-exclamation text-rose-400 shrink-0"></i>
                <span className="flex-1">{masterAdminError}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleVerifyMasterAdmin} className="space-y-3">
              <div className="relative flex items-center bg-[#060c1d] border border-cyan-500/40 focus-within:border-cyan-400 rounded-xl px-3 h-11 transition-all">
                <div className="w-5 flex items-center justify-center shrink-0 text-cyan-400">
                  <i className="fa-solid fa-key text-xs"></i>
                </div>

                <input
                  type={showMasterAdminPass ? 'text' : 'password'}
                  id="masterAdminSecretKey"
                  placeholder="رمز المرور السري..."
                  autoComplete="off"
                  autoFocus
                  className="flex-1 bg-transparent text-center font-mono font-bold tracking-wider text-white text-sm outline-none px-2 h-full"
                  value={masterAdminPassInput}
                  onChange={(e) => setMasterAdminPassInput(e.target.value)}
                />

                <button
                  type="button"
                  onClick={() => setShowMasterAdminPass(!showMasterAdminPass)}
                  className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  <i className={`fa-solid ${showMasterAdminPass ? 'fa-eye-slash' : 'fa-eye'} text-xs`}></i>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowMasterAdminModal(false);
                    setMasterAdminPassInput('');
                    setMasterAdminError(null);
                  }}
                  className="h-10 rounded-xl text-xs font-bold text-slate-300 bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                >
                  إلغاء
                </button>

                <button
                  type="submit"
                  className="h-10 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 hover:brightness-110 active:scale-95 transition-all shadow-md shadow-cyan-900/40 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <i className="fa-solid fa-unlock-keyhole text-xs"></i>
                  <span>تأكيد الدخول</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
