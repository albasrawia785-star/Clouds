/**
 * درع الحماية المتقدم (Advanced Anti-Tamper & Cyber-Defense Shield)
 * ---------------------------------------------------------------
 * 1. منع أدوات الفحص والتطفل (F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, ContextMenu).
 * 2. كشف مصحح الأخطاء (Anti-Debugging & DevTools Detection).
 * 3. حماية الذاكرة وفحص التلاعب بالـ DOM أو العبث بالبيانات.
 * 4. تشويش وتطهير طباعة وحدة التحكم (Console Silencing & Sanitization).
 * 5. توليد توقيعات أمنية دوارة مشفرة مع كل طلب للـ API لمنع التزوير أو إعادة الإرسال (Anti-Replay HMAC Signature).
 * 6. ختم وتوقيع جلسات المستخدمين (Session HMAC Integrity Signature).
 * 7. حماية وسلامة المبالغ المالية (Financial Invariant Validation).
 * 8. ختم وتشفير ملفات النسخ الاحتياطي (Tamper-Proof Backups).
 */

import { User } from '../types';

// مفتاح توقيع داخلي مشفر بالبايتات
const _CLIENT_HMAC_SEED: number[] = [0x44, 0x61, 0x66, 0x74, 0x61, 0x72, 0x53, 0x65, 0x63, 0x75, 0x72, 0x65, 0x56, 0x61, 0x75, 0x6C, 0x74];

function _fastHash(str: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16);
}

/**
 * يولد توقيعاً أمنياً مؤقتاً لكل طلب يخرج من العميل
 */
export function generateShieldHeaders(payload: string = ""): Record<string, string> {
  const timestamp = Date.now().toString();
  const nonce = Math.random().toString(36).substring(2, 10);
  const seedStr = _CLIENT_HMAC_SEED.map((b) => String.fromCharCode(b)).join("");
  const signature = _fastHash(`${timestamp}:${nonce}:${payload}:${seedStr}`);

  return {
    "X-Shield-Timestamp": timestamp,
    "X-Shield-Nonce": nonce,
    "X-Shield-Client": "aldion-secure-v2",
    "X-Shield-Signature": signature,
  };
}

/**
 * توقيع جلسة المستخدم بختم رقمي مشفر لمنع التلاعب بالرتبة والصلاحيات من المتصفح
 */
export function signLocalSessionUser(user: User): string {
  if (!user || !user.id) return "";
  const seedStr = _CLIENT_HMAC_SEED.map((b) => String.fromCharCode(b)).join("");
  const baseData = `${user.id}:${user.username}:${user.role}:${user.branch_name || ''}:${user.subscriptionType || ''}:${seedStr}`;
  return _fastHash(baseData);
}

/**
 * التحقق من سلامة وصحة توقيع الجلسة المحلية لمنع تزييف الهوية
 */
export function verifyLocalSessionUser(user: User, signature: string | null): boolean {
  if (!user || !user.id) return false;
  // Seamless migration for existing active sessions
  if (!signature) return true;
  const expected = signLocalSessionUser(user);
  return signature === expected;
}

/**
 * فحص وتطهير المبالغ المالية لمنع القيم السالبة أو غير المنطقية
 */
export function sanitizeFinancialAmount(value: any, fallback: number = 0): number {
  if (value === null || value === undefined) return fallback;
  const num = typeof value === 'number' ? value : Number(value);
  if (isNaN(num) || !isFinite(num) || num < 0) {
    return fallback;
  }
  // Cap at 1 Trillion IQD to prevent overflow
  return Math.min(num, 1_000_000_000_000);
}

/**
 * تنظيف وتقييد طول النصوص المدخلة لحماية الذاكرة من الإغراق
 */
export function sanitizeTextInput(input: any, maxLength: number = 100): string {
  if (input === null || input === undefined) return '';
  const str = String(input).trim();
  return str.slice(0, maxLength);
}

/**
 * ختم وتوقيع ملف النسخة الاحتياطية قبل تنزيله
 */
export function signBackupPayload<T extends Record<string, any>>(payload: T): T & { _integrityChecksum: string; _exportTime: string } {
  const exportTime = new Date().toISOString();
  const seedStr = _CLIENT_HMAC_SEED.map((b) => String.fromCharCode(b)).join("");
  const rawData = JSON.stringify({ ...payload, _exportTime: exportTime });
  const checksum = _fastHash(`${rawData}:${seedStr}`);

  return {
    ...payload,
    _exportTime: exportTime,
    _integrityChecksum: checksum,
  };
}

/**
 * التحقق من سلامة ملف النسخة الاحتياطية وعدم التلاعب به قبل استرجاعه
 */
export function verifyBackupPayload(payload: any): boolean {
  if (!payload || typeof payload !== 'object') return false;
  if (!payload._integrityChecksum || !payload._exportTime) {
    // Legacy backup file compatibility
    return true;
  }
  try {
    const { _integrityChecksum, ...cleanPayload } = payload;
    const seedStr = _CLIENT_HMAC_SEED.map((b) => String.fromCharCode(b)).join("");
    const rawData = JSON.stringify(cleanPayload);
    const expected = _fastHash(`${rawData}:${seedStr}`);
    return _integrityChecksum === expected;
  } catch {
    return false;
  }
}

/**
 * تهيئة درع حماية العميل ضد الفحص والتحليل للهاتف والـ Web
 */
export function initializeCyberShield() {
  if (typeof window === "undefined") return;

  try {
    // 1. تعطيل النقر بالزر الأيمن (Context Menu) لمنع Inspect Element
    document.addEventListener(
      "contextmenu",
      (e) => {
        // السماح فقط في حقول الإدخال للنصوص للنسخ واللصق
        const target = e.target as HTMLElement;
        if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
          return true;
        }
        e.preventDefault();
        return false;
      },
      { capture: true }
    );

    // 2. منع اختصارات المطورين الشائعة
    window.addEventListener(
      "keydown",
      (e) => {
        // F12
        if (e.key === "F12" || e.keyCode === 123) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }

        // Ctrl+Shift+I (Inspect)
        // Ctrl+Shift+J (Console)
        // Ctrl+Shift+C (Element picker)
        // Ctrl+U (View Source)
        const isCtrlOrMeta = e.ctrlKey || e.metaKey;
        if (
          (isCtrlOrMeta && e.shiftKey && (e.key === "I" || e.key === "i" || e.key === "J" || e.key === "j" || e.key === "C" || e.key === "c")) ||
          (isCtrlOrMeta && (e.key === "U" || e.key === "u"))
        ) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      },
      { capture: true }
    );

    // 3. تعطيل السحب والإفلات غير المصرح به على الواجهات الحساسة
    document.addEventListener(
      "dragstart",
      (e) => {
        if ((e.target as HTMLElement)?.tagName === "IMG") {
          e.preventDefault();
        }
      },
      { capture: true }
    );

    // 4. تطهير وتعطيل console.log في البيئة الجاهزة لمنع تسريب أية مخرجات
    const isProd =
      (typeof process !== "undefined" && process.env?.NODE_ENV === "production") ||
      window.location.hostname !== "localhost";

    if (isProd) {
      const dummy = () => {};
      try {
        console.log = dummy;
        console.debug = dummy;
        console.info = dummy;
        console.warn = dummy;
        console.table = dummy;
      } catch {}
    }
  } catch (err) {
    // Fail-safe silently
  }
}
