import React, { useState } from 'react';
import { Supplier, SupplierTransaction } from '../types';
import { formatNumber, formatDateArabic, formatDateDigits, formatAmountInput, parseFormattedNumber, getCurrentTimeStr, extractTimeFromDate, formatFullDateTime, hasExplicitTime, resolveRecordDateTime } from '../utils/formatters';
import { exportSingleSupplierPdf } from '../utils/pdfReportGenerator';
import { generateSingleSupplierTextReport, shareReportToPerson } from '../utils/textReportExporter';
import { useI18n } from '../i18n/index.tsx';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceImageViewerModal } from './InvoiceImageViewerModal';
import { getPortalUrl } from '../utils/qrUtils';
import { isDemoSupplier } from '../utils/mockDebtors';

interface SupplierHistoryModalProps {
  supplier: Supplier | null;
  isOpen: boolean;
  onClose: () => void;
  onAddMoreDebt: (supplierId: number, addedAmount: number, notes?: string) => void;
  onDeleteSupplier: (supplierId: number) => void;
  onUpdateTransaction?: (supplierId: number, txId: string, newAmount: number, newNotes?: string, newDate?: string, newItemType?: string, paymentMethod?: 'cash' | 'electronic') => void;
  onDeleteTransaction?: (supplierId: number, txId: string) => void;
  onUpdateSupplierItemType?: (supplierId: number, newItemType: string) => void;
  currencySymbol?: string;
}

export const SupplierHistoryModal: React.FC<SupplierHistoryModalProps> = ({
  supplier,
  isOpen,
  onClose,
  onAddMoreDebt,
  onDeleteSupplier,
  onUpdateTransaction,
  onDeleteTransaction,
  onUpdateSupplierItemType,
  currencySymbol = 'د.ع',
}) => {
  const { numberFormat } = useI18n();
  const [showAddDebtForm, setShowAddDebtForm] = useState(false);
  const [addAmount, setAddAmount] = useState('');
  const [addNotes, setAddNotes] = useState('');
  const [showBarcode, setShowBarcode] = useState<boolean>(false);

  // Item Type Editing State
  const [isEditingItemType, setIsEditingItemType] = useState(false);
  const [itemTypeInput, setItemTypeInput] = useState(supplier?.itemType || '');

  // Keep itemTypeInput synced when supplier changes
  React.useEffect(() => {
    if (supplier) {
      setItemTypeInput(supplier.itemType || '');
      setIsEditingItemType(false);
    }
  }, [supplier]);

  // Filtering & Search State
  const [filterType, setFilterType] = useState<'all' | 'add_debt' | 'pay_supplier'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<{ url: string; title: string; subtitle?: string; amount?: string } | null>(null);

  // Transaction Edit & Delete State
  const [editingTx, setEditingTx] = useState<SupplierTransaction | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [editItemType, setEditItemType] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  const [editRecordTime, setEditRecordTime] = useState<boolean>(false);
  const [editTimeMode, setEditTimeMode] = useState<'auto' | 'manual'>('auto');
  const [editTime, setEditTime] = useState<string>('');
  const [editPaymentMethod, setEditPaymentMethod] = useState<'cash' | 'electronic'>('cash');
  const [deletingTx, setDeletingTx] = useState<SupplierTransaction | null>(null);

  // Supplier Delete Confirm Modal State
  const [showDeleteSupplierConfirm, setShowDeleteSupplierConfirm] = useState(false);

  // Accordions collapse state by Month
  const [collapsedMonths, setCollapsedMonths] = useState<Record<string, boolean>>({});

  if (!isOpen || !supplier) return null;

  const currentAmount = supplier.amount || 0;
  const rawHistory = supplier.history && supplier.history.length > 0
    ? supplier.history
    : [
        {
          id: `initial-sup-${supplier.id}`,
          supplierId: supplier.id,
          type: 'initial' as const,
          amount: supplier.amount,
          balanceAfter: supplier.amount,
          date: supplier.createdAt || new Date().toISOString(),
          description: 'فتح حساب وتدوين الدين المطلوب الأولي للمورد',
        },
      ];

  // Helper for Month-Year title in Arabic
  const getMonthYearTitle = (dateStr?: string) => {
    if (!dateStr) return 'حركات سابقة';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return 'حركات سابقة';
      const monthNames = [
        'كانون الثاني (يناير)', 'شباط (فبراير)', 'آذار (مارس)', 'نيسان (أبريل)',
        'أيار (مايو)', 'حزيران (يونيو)', 'تموز (يوليو)', 'آب (أغسطس)',
        'أيلول (سبتمبر)', 'تشرين الأول (أكتوبر)', 'تشرين الثاني (نوفمبر)', 'كانون الأول (ديسمبر)'
      ];
      const mName = monthNames[d.getMonth()];
      const yStr = formatDateDigits(String(d.getFullYear()), numberFormat);
      return `${mName} ${yStr}`;
    } catch {
      return 'حركات سابقة';
    }
  };

  const handleAddDebtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(addAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى كتابة مبلغ الدين المضاف بشكل صحيح.');
      return;
    }

    onAddMoreDebt(supplier.id, numAmount, addNotes.trim() || undefined);

    setAddAmount('');
    setAddNotes('');
    setShowAddDebtForm(false);
  };

  const handleDeleteSupplierClick = () => {
    setShowDeleteSupplierConfirm(true);
  };

  const handleConfirmDeleteSupplier = () => {
    onDeleteSupplier(supplier.id);
    setShowDeleteSupplierConfirm(false);
    onClose();
  };

  // Start Editing Transaction
  const handleStartEditTx = (tx: SupplierTransaction) => {
    setEditingTx(tx);
    setEditAmount(formatAmountInput(String(tx.amount)));
    setEditItemType(tx.itemType || '');
    setEditNotes(tx.notes || '');
    setEditPaymentMethod((tx.paymentMethod as any) === 'electronic' ? 'electronic' : 'cash');
    setEditDate(tx.date ? new Date(tx.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
    const hasTime = hasExplicitTime(tx.date);
    setEditRecordTime(hasTime);
    setEditTimeMode(hasTime ? 'manual' : 'auto');
    setEditTime(extractTimeFromDate(tx.date));
  };

  // Save Edited Transaction
  const handleSaveEditTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTx) return;

    const numAmount = parseFormattedNumber(editAmount);
    if (isNaN(numAmount) || numAmount < 0) {
      alert('يرجى كتابة المبلغ المعدل بشكل صحيح.');
      return;
    }

    const fullUpdatedDate = resolveRecordDateTime(editDate, editRecordTime, editTimeMode, editTime);

    if (onUpdateTransaction) {
      onUpdateTransaction(
        supplier.id,
        editingTx.id,
        numAmount,
        editNotes.trim() || undefined,
        fullUpdatedDate,
        editItemType.trim() || undefined,
        editingTx.type === 'pay_supplier' ? editPaymentMethod : undefined
      );
    }
    setEditingTx(null);
  };

  // Confirm Delete Transaction
  const handleConfirmDeleteTx = () => {
    if (!deletingTx) return;
    if (onDeleteTransaction) {
      onDeleteTransaction(supplier.id, deletingTx.id);
    }
    setDeletingTx(null);
  };

  // Filter & Search History
  const filteredHistory = [...rawHistory]
    .filter((tx) => {
      if (filterType === 'add_debt' && tx.type === 'pay_supplier') return false;
      if (filterType === 'pay_supplier' && tx.type !== 'pay_supplier') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const descMatch = (tx.description || '').toLowerCase().includes(q);
        const notesMatch = (tx.notes || '').toLowerCase().includes(q);
        const amtMatch = String(tx.amount).includes(q);
        if (!descMatch && !notesMatch && !amtMatch) return false;
      }
      return true;
    })
    .reverse();

  // Group History into Monthly Accordions Dropdowns
  interface SupplierMonthGroup {
    monthKey: string;
    monthTitle: string;
    transactions: SupplierTransaction[];
    totalAdded: number;
    totalPaid: number;
  }

  const monthGroups: SupplierMonthGroup[] = [];
  const groupMap: Record<string, SupplierMonthGroup> = {};

  filteredHistory.forEach((tx) => {
    let monthKey = 'other';
    try {
      const d = new Date(tx.date);
      if (!isNaN(d.getTime())) {
        monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      }
    } catch {}

    if (!groupMap[monthKey]) {
      const title = getMonthYearTitle(tx.date);
      groupMap[monthKey] = {
        monthKey,
        monthTitle: title,
        transactions: [],
        totalAdded: 0,
        totalPaid: 0,
      };
      monthGroups.push(groupMap[monthKey]);
    }

    groupMap[monthKey].transactions.push(tx);
    if (tx.type === 'pay_supplier') {
      groupMap[monthKey].totalPaid += tx.amount;
    } else {
      groupMap[monthKey].totalAdded += tx.amount;
    }
  });

  const toggleMonth = (mKey: string) => {
    setCollapsedMonths((prev) => ({ ...prev, [mKey]: !(prev[mKey] ?? true) }));
  };

  const toggleAllMonths = () => {
    const allCollapsed = monthGroups.every((g) => (collapsedMonths[g.monthKey] ?? true));
    const newState: Record<string, boolean> = {};
    monthGroups.forEach((g) => {
      newState[g.monthKey] = !allCollapsed;
    });
    setCollapsedMonths(newState);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 p-4 text-white flex items-center justify-between shrink-0 border-b border-amber-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-lg shrink-0">
              <i className="fa-solid fa-file-invoice-dollar"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">
                {typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '')}
              </h3>
              <p className="text-[11px] text-slate-300 font-medium flex items-center gap-2 flex-wrap">
                {typeof supplier.companyName === 'string' && supplier.companyName.trim()
                  ? `شركة: ${supplier.companyName.trim()}`
                  : 'سجل كشف الحساب والعمليات للمورد'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => exportSingleSupplierPdf(supplier, null, undefined, numberFormat)}
              className="px-2.5 py-1.5 rounded-full bg-amber-600 hover:bg-amber-700 text-white flex items-center gap-1 text-xs font-bold transition-colors cursor-pointer"
              title="تصدير كشف حساب مورد PDF"
            >
              <i className="fa-solid fa-file-pdf text-[11px]"></i>
              <span>PDF</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                try {
                  const text = generateSingleSupplierTextReport(supplier, {
                    currencySymbol,
                  });
                  const sName = typeof supplier.name === 'string' ? supplier.name : 'مورد';
                  const cleanName = sName.replace(/[\s/\\?%*:|"<>]/g, '_');
                  await shareReportToPerson({
                    phone: supplier.phone,
                    text,
                    fileName: `كشف_مورد_${cleanName}.txt`,
                    title: `كشف حساب ${sName}`,
                  });
                } catch (e) {
                  console.error(e);
                }
              }}
              className="px-2.5 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1 text-xs font-bold transition-colors cursor-pointer"
              title="مشاركة كشف الحساب كملف نصي (.txt)"
            >
              <i className="fa-solid fa-file-lines text-[11px]"></i>
              <span>.txt</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-10 h-10 sm:w-9 sm:h-9 rounded-full bg-white/15 hover:bg-white/25 active:bg-white/35 active:scale-95 flex items-center justify-center text-white transition-all cursor-pointer touch-manipulation border border-white/10 shadow-xs"
              title="إغلاق السجل"
              aria-label="إغلاق السجل"
            >
              <i className="fa-solid fa-xmark text-sm"></i>
            </button>
          </div>
        </div>

        {/* Balance Card Banner */}
        <div className="p-4 bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent dark:from-amber-950/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-start flex-wrap gap-2">
          <div>
            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block">الدين المتبقي للمورد عليك</span>
            <span className="text-xl font-black text-amber-600 dark:text-amber-400 font-mono">
              {formatNumber(currentAmount, numberFormat)} {currencySymbol}
            </span>
          </div>
        </div>

        {/* Dedicated Independent Card/Box for Goods Type (نوع البضاعة) - Viewing Only */}
        <div className="mx-4 my-2.5 p-3 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-slate-50 dark:from-amber-950/40 dark:to-slate-800/80 rounded-2xl border border-amber-200/80 dark:border-amber-800/60 flex items-center justify-between text-start gap-3 shadow-2xs">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-8.5 h-8.5 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center justify-center text-sm shrink-0">
              <i className="fa-solid fa-boxes-packing"></i>
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400 block">نوع البضاعة / المواد الحالية</span>
              <span className="text-xs font-black text-slate-800 dark:text-slate-100 block truncate">
                {supplier.itemType && supplier.itemType.trim() ? supplier.itemType.trim() : 'غير محدد'}
              </span>
            </div>
          </div>
        </div>

        {/* QR Code Card for Supplier Statement */}
        {!isDemoSupplier(supplier) && (
          <div className="mx-4 my-1.5 p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-3 text-xs shadow-2xs">
            {/* Toggle switch for showing / hiding barcode */}
            <div className="flex items-center justify-between">
              <label
                onClick={() => setShowBarcode(!showBarcode)}
                className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2 cursor-pointer select-none"
              >
                <i className="fa-solid fa-qrcode text-amber-600 text-sm"></i>
                <span>إظهار الباركود والرابط المباشر لكشف المورد</span>
              </label>
              <button
                type="button"
                dir="ltr"
                onClick={() => setShowBarcode(!showBarcode)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  showBarcode ? 'bg-amber-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
                role="switch"
                aria-checked={showBarcode}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                    showBarcode ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {showBarcode && (
              <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700/60 animate-in fade-in duration-150">
                <div className="flex items-center gap-3 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="bg-white dark:bg-slate-900 p-1.5 rounded-xl shrink-0 border border-slate-200 dark:border-slate-700 shadow-xs">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(getPortalUrl('supplier', supplier.id))}`}
                      alt="QR Code"
                      className="w-12 h-12 object-contain rounded-md"
                      onError={(e) => {
                        e.currentTarget.src = `https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl=${encodeURIComponent(getPortalUrl('supplier', supplier.id))}`;
                      }}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-slate-100 mb-0.5">
                      <i className="fa-solid fa-qrcode text-amber-600"></i>
                      <span>بوابة كشف حساب المورد المباشر (QR)</span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono truncate dir-ltr text-left">
                      {getPortalUrl('supplier', supplier.id).replace(/^https?:\/\//, '')}
                    </div>
                    <div className="text-[10px] text-slate-400 dark:text-slate-400 mt-0.5">
                      كشف حساب رسمي محمي لمتابعة تسديدات البضائع والمستحقات
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-200 dark:border-slate-700/60">
                  <button
                    type="button"
                    onClick={async () => {
                      const link = getPortalUrl('supplier', supplier.id);
                      try {
                        await navigator.clipboard.writeText(link);
                        alert('تم نسخ رابط كشف المورد المباشر بنجاح');
                      } catch {
                        alert('تعذر نسخ الرابط');
                      }
                    }}
                    className="flex-1 py-2 px-3 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs active:scale-98"
                  >
                    <i className="fa-regular fa-copy text-xs text-amber-600"></i>
                    <span>نسخ الرابط</span>
                  </button>

                  <button
                    type="button"
                    onClick={async () => {
                      const portalUrl = getPortalUrl('supplier', supplier.id);
                      const qrImgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(portalUrl)}`;
                      try {
                        const res = await fetch(qrImgUrl);
                        const blob = await res.blob();
                        const sName = typeof supplier.name === 'string' ? supplier.name : 'مورد';
                        const cleanName = sName.replace(/[\s/\\:*?"<>|]+/g, '_');
                        const fileName = `باركود_كشف_مورد_${cleanName}_#${supplier.id}.png`;
                        const file = new File([blob], fileName, { type: 'image/png' });

                        if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [file] })) {
                          await navigator.share({
                            title: `باركود كشف حساب مورد - ${sName}`,
                            text: `رمز متابعة كشف الحساب الخاص بالمورد: ${sName}`,
                            files: [file],
                          });
                          return;
                        }

                        const blobUrl = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = blobUrl;
                        a.download = fileName;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(blobUrl);
                      } catch {
                        window.open(qrImgUrl, '_blank');
                      }
                    }}
                    className="flex-1 py-2 px-3 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs active:scale-98"
                  >
                    <i className="fa-solid fa-qrcode text-xs text-amber-600"></i>
                    <span>إرسال صورة الباركود</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Filter & Search Bar */}
        <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-start flex-wrap">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                filterType === 'all'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              الكل
            </button>
            <button
              type="button"
              onClick={() => setFilterType('add_debt')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                filterType === 'add_debt'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              الديون المضافة
            </button>
            <button
              type="button"
              onClick={() => setFilterType('pay_supplier')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                filterType === 'pay_supplier'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              التسديدات
            </button>
          </div>

          <div className="relative flex-1 min-w-[140px]">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث في السجل..."
              className="w-full pl-2 pr-7 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-white outline-none"
            />
            <i className="fa-solid fa-magnifying-glass absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]"></i>
          </div>
        </div>

        {/* History List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3 text-start">
          <div className="flex items-center justify-between gap-2 mb-1">
            <h4 className="text-xs font-black text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <span>سجل المعاملات والتسديدات ({formatNumber(filteredHistory.length, numberFormat)}):</span>
            </h4>

            {monthGroups.length > 1 && (
              <button
                type="button"
                onClick={toggleAllMonths}
                className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 rounded-lg text-[10.5px] font-bold text-slate-700 dark:text-slate-300 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
                title="طي/فتح جميع الأقسام الشهرية"
              >
                <i className="fa-solid fa-layer-group text-[10px] text-amber-500"></i>
                <span>طي/فتح الأقسام</span>
              </button>
            )}
          </div>

          {monthGroups.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
              لا توجد سجلات سابقة مطابقة لهذا العرض.
            </div>
          ) : (
            monthGroups.map((group) => {
              const isCollapsed = collapsedMonths[group.monthKey] ?? true;

              return (
                <div key={group.monthKey} className="space-y-2">
                  {/* ACCORDION HEADER FOR EACH MONTH */}
                  <div
                    onClick={() => toggleMonth(group.monthKey)}
                    className="bg-slate-100 dark:bg-slate-800/90 hover:bg-slate-200/80 dark:hover:bg-slate-700/90 transition-colors p-2.5 rounded-2xl flex items-center justify-between cursor-pointer border border-slate-200/80 dark:border-slate-700 select-none shadow-2xs"
                  >
                    <div className="flex items-center gap-2">
                      <i
                        className={`fa-solid fa-chevron-down text-[10px] text-amber-500 transition-transform duration-200 ${
                          isCollapsed ? '-rotate-90' : 'rotate-0'
                        }`}
                      ></i>
                      <span className="text-xs font-black text-slate-900 dark:text-white">
                        {group.monthTitle}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-700 font-mono">
                        {group.transactions.length}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[10.5px] font-mono">
                      {group.totalAdded > 0 && (
                        <span className="text-amber-600 dark:text-amber-400 font-bold">
                          +{formatNumber(group.totalAdded, numberFormat)} {currencySymbol}
                        </span>
                      )}
                      {group.totalPaid > 0 && (
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                          -{formatNumber(group.totalPaid, numberFormat)} {currencySymbol}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* MONTH TRANSACTIONS LIST */}
                  {!isCollapsed && (
                    <div className="space-y-2 pr-1 pl-1">
                      {group.transactions.map((tx) => {
                        const isPayment = tx.type === 'pay_supplier';
                        return (
                          <div
                            key={tx.id}
                            className={`p-3 rounded-2xl border transition-all ${
                              isPayment
                                ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 ${
                                  isPayment ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/60 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/60 dark:text-amber-300'
                                }`}>
                                  <i className={`fa-solid ${isPayment ? 'fa-arrow-down-long' : 'fa-arrow-up-long'}`}></i>
                                </div>
                                <div>
                                  <span className="text-xs font-black text-slate-900 dark:text-white block">
                                    {isPayment ? 'تسديد دفعة للمورد' : tx.type === 'initial' ? 'دين بضاعة أولي' : 'إضافة شحنة بضاعة بالأجل'}
                                  </span>
                                  <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium font-mono flex items-center gap-1">
                                      <i className="fa-regular fa-clock text-[9px] text-slate-400"></i>
                                      <span>{tx.date ? formatFullDateTime(tx.date, numberFormat) : ''}</span>
                                    </span>
                                    {isPayment && (
                                      <span className={`text-[9.5px] font-bold px-1.5 py-0.2 rounded border inline-flex items-center gap-1 ${
                                        tx.paymentMethod === 'electronic'
                                          ? 'bg-teal-100/80 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 border-teal-200/80 dark:border-teal-800/60'
                                          : 'bg-emerald-100/80 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border-emerald-200/80 dark:border-emerald-800/60'
                                      }`}>
                                        <span>{tx.paymentMethod === 'electronic' ? '💳 إلكتروني' : '💵 كاش'}</span>
                                      </span>
                                    )}
                                    {tx.itemType ? (
                                      <span className="text-[9.5px] bg-amber-100/80 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold px-1.5 py-0.2 rounded border border-amber-200/80 dark:border-amber-800/60 inline-flex items-center gap-1">
                                        <i className="fa-solid fa-box text-[8px]"></i>
                                        <span>{tx.itemType}</span>
                                      </span>
                                    ) : tx.type === 'initial' && supplier.itemType ? (
                                      <span className="text-[9.5px] bg-amber-100/80 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold px-1.5 py-0.2 rounded border border-amber-200/80 dark:border-amber-800/60 inline-flex items-center gap-1">
                                        <i className="fa-solid fa-box text-[8px]"></i>
                                        <span>{supplier.itemType}</span>
                                      </span>
                                    ) : null}
                                    {tx.invoiceImage && (
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setSelectedInvoice({
                                            url: tx.invoiceImage!,
                                            title: `فاتورة مورد - ${supplier.name}`,
                                            subtitle: `${isPayment ? 'وصل تسديد' : 'فاتورة بضاعة'} • ${tx.date ? formatFullDateTime(tx.date, numberFormat) : ''}`,
                                            amount: `${formatNumber(tx.amount, numberFormat)} ${currencySymbol}`,
                                          });
                                        }}
                                        className="text-[9.5px] bg-blue-100/80 dark:bg-blue-950/80 text-blue-800 dark:text-blue-300 font-bold px-1.5 py-0.2 rounded border border-blue-200/80 dark:border-blue-800/60 inline-flex items-center gap-1 hover:bg-blue-200 cursor-pointer transition-colors"
                                        title="عرض وتكبير صورة الفاتورة المرفقة"
                                      >
                                        <i className="fa-solid fa-receipt text-[8px] text-blue-600 dark:text-blue-400"></i>
                                        <span>فاتورة</span>
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="text-left flex items-center gap-2">
                                <div>
                                  <span className={`text-xs font-black font-mono block ${isPayment ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                                    {isPayment ? '-' : '+'}{formatNumber(tx.amount, numberFormat)} {currencySymbol}
                                  </span>
                                  <span className="text-[9.5px] text-slate-400 block font-mono">
                                    المتبقي: {formatNumber(tx.balanceAfter, numberFormat)}
                                  </span>
                                </div>

                                {/* Edit/Delete Transaction Actions */}
                                <div className="flex items-center gap-1 border-s border-slate-200 dark:border-slate-700 ps-2">
                                  {onUpdateTransaction && (
                                    <button
                                      type="button"
                                      onClick={() => handleStartEditTx(tx)}
                                      className="w-6 h-6 rounded-lg bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center text-[10px] transition-colors cursor-pointer"
                                      title="تعديل هذه الحركة"
                                    >
                                      <i className="fa-solid fa-pen"></i>
                                    </button>
                                  )}
                                  {onDeleteTransaction && (
                                    <button
                                      type="button"
                                      onClick={() => setDeletingTx(tx)}
                                      className="w-6 h-6 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center text-[10px] transition-colors cursor-pointer"
                                      title="حذف هذه الحركة"
                                    >
                                      <i className="fa-solid fa-trash-can"></i>
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>

                            {((typeof tx.notes === 'string' && tx.notes.trim()) || (typeof tx.description === 'string' && tx.description.trim())) ? (
                              <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                                <div className="p-2.5 bg-slate-100/70 dark:bg-slate-800/80 rounded-xl border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-800 dark:text-slate-200 leading-relaxed break-words font-medium space-y-1">
                                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-600 dark:text-amber-400">
                                    <i className="fa-solid fa-note-sticky text-amber-500"></i>
                                    <span>تفاصيل الملاحظات والوصل الكاملة:</span>
                                  </div>
                                  <p className="text-slate-900 dark:text-white font-bold select-text leading-relaxed whitespace-pre-wrap" dir="auto">
                                    {(typeof tx.notes === 'string' && tx.notes.trim()) ? tx.notes.trim() : String(tx.description || '').trim()}
                                  </p>
                                </div>
                              </div>
                            ) : null}

                            {/* Attached Invoice Thumbnail & Zoom button */}
                            {tx.invoiceImage && (
                              <div className="mt-2 p-2.5 bg-blue-50/60 dark:bg-blue-950/40 rounded-xl border border-blue-100 dark:border-blue-900/60 flex items-center justify-between gap-3">
                                <div
                                  onClick={() => setSelectedInvoice({
                                    url: tx.invoiceImage!,
                                    title: `فاتورة مورد - ${supplier.name}`,
                                    subtitle: `${isPayment ? 'وصل تسديد' : 'فاتورة بضاعة'} • ${tx.date ? formatFullDateTime(tx.date, numberFormat) : ''}`,
                                    amount: `${formatNumber(tx.amount, numberFormat)} ${currencySymbol}`,
                                  })}
                                  className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
                                >
                                  <img
                                    src={tx.invoiceImage}
                                    alt="صورة الفاتورة"
                                    className="w-12 h-12 object-cover rounded-lg border border-blue-200 dark:border-blue-800 shadow-2xs shrink-0 group-hover:scale-105 transition-transform"
                                  />
                                  <div className="min-w-0">
                                    <p className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1">
                                      <i className="fa-solid fa-receipt text-blue-600 dark:text-blue-400 text-[11px]"></i>
                                      <span>صورة الفاتورة / الوصل مرفقة</span>
                                    </p>
                                    <p className="text-[10px] text-slate-500 dark:text-slate-400">انقر للمعاينة والتكبير والتحميل</p>
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setSelectedInvoice({
                                    url: tx.invoiceImage!,
                                    title: `فاتورة مورد - ${supplier.name}`,
                                    subtitle: `${isPayment ? 'وصل تسديد' : 'فاتورة بضاعة'} • ${tx.date ? formatFullDateTime(tx.date, numberFormat) : ''}`,
                                    amount: `${formatNumber(tx.amount, numberFormat)} ${currencySymbol}`,
                                  })}
                                  className="h-9 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 active:scale-95 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-xs touch-manipulation"
                                  title="تكبير ومعاينة الفاتورة بكامل الشاشة"
                                >
                                  <i className="fa-solid fa-magnifying-glass-plus text-xs"></i>
                                  <span>تكبير</span>
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3 modal-footer-safe bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700/80 shrink-0 flex items-center justify-between">
          <button
            type="button"
            onClick={handleDeleteSupplierClick}
            className="text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 flex items-center gap-1 px-2.5 py-1.5 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-trash-can text-xs"></i>
            <span>حذف المورد نهائياً</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs transition-all cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>

      {/* Edit Transaction Sub-Modal */}
      {editingTx && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 w-full max-w-sm shadow-2xl text-start space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">تعديل حركة المورد</h4>
              <button
                type="button"
                onClick={() => setEditingTx(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <form onSubmit={handleSaveEditTx} className="space-y-2.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">المبلغ</label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  value={editAmount}
                  onChange={(e) => setEditAmount(formatAmountInput(e.target.value))}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              {/* Payment Method Option when editing payment to supplier */}
              {editingTx.type === 'pay_supplier' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center justify-between">
                    <span>طريقة الدفع والتسديد</span>
                    <span className="text-[10.5px] font-bold text-emerald-600 dark:text-emerald-400">
                      {editPaymentMethod === 'electronic' ? '💳 دفع إلكتروني (ماستر كارد / محفظة)' : '💵 نقداً (كاش)'}
                    </span>
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditPaymentMethod('cash')}
                      className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                        editPaymentMethod === 'cash'
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <span>💵</span>
                      <span>نقداً (كاش)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditPaymentMethod('electronic')}
                      className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                        editPaymentMethod === 'electronic'
                          ? 'bg-teal-50 dark:bg-teal-950/40 border-teal-500 text-teal-700 dark:text-teal-300 ring-2 ring-teal-500/20'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <span>💳</span>
                      <span>دفع إلكتروني</span>
                    </button>
                  </div>
                </div>
              )}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">نوع البضاعة / المواد</label>
                <input
                  type="text"
                  value={editItemType}
                  onChange={(e) => setEditItemType(e.target.value)}
                  placeholder="مثال: أجهزة كهربائية / مواد غذائية..."
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">التاريخ</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white font-mono"
                />
              </div>

              {/* Record Time Selector */}
              <RecordTimeSelector
                enabled={editRecordTime}
                onEnabledChange={setEditRecordTime}
                mode={editTimeMode}
                onModeChange={setEditTimeMode}
                time={editTime}
                onTimeChange={setEditTime}
                accentColor="amber"
                idPrefix="edit_sup_tx"
              />
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">الملاحظات / الوصل والتفاصيل</label>
                <textarea
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500/20 leading-relaxed resize-y"
                  placeholder="اكتب الملاحظات والتفاصيل الكاملة هنا..."
                />
              </div>
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  حفظ التعديلات
                </button>
                <button
                  type="button"
                  onClick={() => setEditingTx(null)}
                  className="py-2 px-3 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Transaction Confirmation Sub-Modal */}
      {deletingTx && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 w-full max-w-sm shadow-2xl text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-lg">
              <i className="fa-solid fa-trash-can"></i>
            </div>
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">تأكيد حذف الحركة</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              هل أنت أصل ومقتنع بحذف هذه الحركة بمبلغ ({formatNumber(deletingTx.amount, numberFormat)} {currencySymbol}) وإعادة احتساب رصيد المورد تلقائياً؟
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmDeleteTx}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                تأكيد الحذف
              </button>
              <button
                type="button"
                onClick={() => setDeletingTx(null)}
                className="py-2 px-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                تراجُع
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Delete Supplier Confirmation Sub-Modal */}
      {showDeleteSupplierConfirm && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 w-full max-w-sm shadow-2xl text-center space-y-3.5 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-xl shadow-xs">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h4 className="font-extrabold text-base text-slate-900 dark:text-white">تأكيد حذف المورد نهائياً</h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              هل أنت أصل ومقتنع بحذف المورد <span className="font-black text-rose-600 dark:text-rose-400">({supplier.name})</span> وكافة سجله المعاملاتي نهائياً؟
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmDeleteSupplier}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-md transition-all active:scale-95"
              >
                تأكيد الحذف النهائياً
              </button>
              <button
                type="button"
                onClick={() => setShowDeleteSupplierConfirm(false)}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* INVOICE IMAGE VIEWER MODAL */}
      <InvoiceImageViewerModal
        isOpen={Boolean(selectedInvoice)}
        onClose={() => setSelectedInvoice(null)}
        imageUrl={selectedInvoice?.url}
        title={selectedInvoice?.title}
        subtitle={selectedInvoice?.subtitle}
        amount={selectedInvoice?.amount}
      />
    </div>
  );
};
