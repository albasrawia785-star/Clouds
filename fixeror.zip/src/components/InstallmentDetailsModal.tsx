import React, { useState } from 'react';
import { InstallmentRecord, InstallmentPayment } from '../types';
import { formatNumber, formatDateDigits, formatFullDateTime } from '../utils/formatters';
import { exportSingleInstallmentPdf } from '../utils/pdfReportGenerator';
import { generateSingleInstallmentTextReport, shareReportToPerson } from '../utils/textReportExporter';
import { useI18n } from '../i18n/index.tsx';
import { InvoiceImageViewerModal } from './InvoiceImageViewerModal';
import { normalizeInvoiceImages } from '../utils/imageUtils';
import { getPortalUrl } from '../utils/qrUtils';
import { isDemoInstallment } from '../utils/mockDebtors';

interface InstallmentDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  installment: InstallmentRecord;
  onOpenSettleModal: (installment: InstallmentRecord) => void;
  onOpenEditModal?: (installment: InstallmentRecord) => void;
  onDelete: (id: number) => void;
  onUpdateInstallment?: (installment: InstallmentRecord) => Promise<void>;
}

export const InstallmentDetailsModal: React.FC<InstallmentDetailsModalProps> = ({
  isOpen,
  onClose,
  installment,
  onOpenSettleModal,
  onOpenEditModal,
  onDelete,
  onUpdateInstallment,
}) => {
  const { t, numberFormat, currency } = useI18n();
  const [selectedInvoice, setSelectedInvoice] = useState<{ url?: string; urls?: string[]; initialIndex?: number; title: string; subtitle?: string; amount?: string } | null>(null);
  const [showBarcode, setShowBarcode] = useState<boolean>(false);

  // Edit payment record state
  const [editingPayment, setEditingPayment] = useState<InstallmentPayment | null>(null);
  const [editAmountInput, setEditAmountInput] = useState<string>('');
  const [editNotesInput, setEditNotesInput] = useState<string>('');
  const [isSavingPaymentEdit, setIsSavingPaymentEdit] = useState<boolean>(false);

  const handleStartEditPayment = (p: InstallmentPayment) => {
    setEditingPayment(p);
    setEditAmountInput(String(p.amount));
    setEditNotesInput(p.notes || '');
  };

  const handleSavePaymentEdit = async () => {
    if (!editingPayment || !onUpdateInstallment) return;
    const newAmount = parseFloat(editAmountInput);
    if (isNaN(newAmount) || newAmount < 0) {
      alert('يرجى إدخال مبلغ صحيح للدفعة');
      return;
    }

    setIsSavingPaymentEdit(true);
    try {
      let currentRemaining = installment.totalAmount - (installment.downPayment || 0);
      const updatedPayments = (installment.payments || []).map((pay) => {
        const isTarget = pay.id === editingPayment.id;
        const payAmt = isTarget ? newAmount : pay.amount;
        currentRemaining = Math.max(0, currentRemaining - payAmt);
        return {
          ...pay,
          amount: payAmt,
          notes: isTarget ? editNotesInput : pay.notes,
          remainingAfter: currentRemaining,
        };
      });

      const newStatus = currentRemaining <= 0 ? 'completed' : installment.status === 'completed' ? 'active' : installment.status;

      await onUpdateInstallment({
        ...installment,
        payments: updatedPayments,
        remainingAmount: currentRemaining,
        status: newStatus,
      });

      setEditingPayment(null);
    } catch (err) {
      console.error('Failed to update payment:', err);
      alert('حدث خطأ أثناء تعديل الدفعة');
    } finally {
      setIsSavingPaymentEdit(false);
    }
  };

  if (!isOpen) return null;

  const totalPaid = installment.totalAmount - installment.remainingAmount;
  const installmentsOnlyPaid = Math.max(0, totalPaid - (installment.downPayment || 0));
  const progressPercent = Math.min(100, Math.round((totalPaid / (installment.totalAmount || 1)) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <i className="fa-solid fa-file-invoice text-base"></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">{installment.name}</h2>
              <p className="text-[11px] text-slate-300 flex items-center gap-1.5 mt-0.5">
                <span>{installment.item}</span>
                {installment.phone && (
                  <>
                    <span>•</span>
                    <span dir="ltr" className="font-mono text-emerald-300">{formatDateDigits(installment.phone, numberFormat)}</span>
                  </>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => exportSingleInstallmentPdf(installment, null, undefined, numberFormat)}
              className="px-2.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-1.5 text-xs font-bold transition-colors cursor-pointer"
              title="تصدير عقد القسط PDF"
            >
              <i className="fa-solid fa-file-pdf text-xs"></i>
              <span>PDF</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                try {
                  const text = generateSingleInstallmentTextReport(installment, {
                    currencySymbol: currency,
                  });
                  const cleanName = (installment.name || 'قسط').replace(/[\s/\\?%*:|"<>]/g, '_');
                  await shareReportToPerson({
                    phone: installment.phone,
                    text,
                    fileName: `عقد_قسط_${cleanName}.txt`,
                    title: `عقد قسط ${installment.name}`,
                  });
                } catch (e) {
                  console.error(e);
                }
              }}
              className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 text-xs font-bold transition-colors cursor-pointer"
              title="مشاركة عقد القسط كملف نصي (.txt)"
            >
              <i className="fa-solid fa-file-lines text-xs"></i>
              <span>.txt</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-white/15 hover:bg-white/25 active:bg-white/35 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer touch-manipulation border border-white/10 shadow-xs"
              title="خروج / إغلاق"
              aria-label="إغلاق تفاصيل القسط"
            >
              <i className="fa-solid fa-xmark text-base"></i>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Main Financial Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-3 rounded-xl border border-slate-100">
                <span className="text-slate-400 text-[10.5px] block font-medium">{t('installments.totalAmount', 'مبلغ الأقساط الإجمالي')}</span>
                <span className="text-sm font-black text-slate-800 font-mono mt-0.5 block">
                  {formatNumber(installment.totalAmount, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100">
                <span className="text-slate-400 text-[10.5px] block font-medium">{t('installments.downPayment', 'الدفعة المقدمة')}</span>
                <span className="text-sm font-black text-teal-700 font-mono mt-0.5 block">
                  {formatNumber(installment.downPayment, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100">
                <span className="text-slate-400 text-[10.5px] block font-medium">{t('installments.paidAmount', 'إجمالي المسدد')}</span>
                <span className="text-sm font-black text-emerald-700 font-mono mt-0.5 block">
                  {formatNumber(totalPaid, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                </span>
                {installment.downPayment > 0 && installmentsOnlyPaid > 0 && (
                  <span className="text-[9.5px] text-slate-400 block mt-0.5 truncate">
                    (مقدمة: {formatNumber(installment.downPayment, numberFormat)} + أقساط: {formatNumber(installmentsOnlyPaid, numberFormat)})
                  </span>
                )}
                {installment.downPayment > 0 && installmentsOnlyPaid === 0 && (
                  <span className="text-[9.5px] text-teal-600 font-medium block mt-0.5">
                    (الدفعة المقدمة فقط)
                  </span>
                )}
              </div>

              <div className={`p-3 rounded-xl border ${
                installment.remainingAmount <= 0
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50/70 border-rose-200 text-rose-900'
              }`}>
                <span className="text-[10.5px] block font-bold">{t('installments.remainingAmount', 'المتبقي المطلوب')}</span>
                <span className="text-sm font-black font-mono mt-0.5 block">
                  {formatNumber(installment.remainingAmount, numberFormat)} <span className="text-[10px] font-normal">{currency}</span>
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                <span>{t('installments.progressStatus', 'نسبة الإنجاز وسداد القسط')}</span>
                <span className="font-mono text-emerald-700">
                  {formatNumber(progressPercent, numberFormat)}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden flex">
                <div
                  className="h-full bg-gradient-to-r from-teal-500 to-emerald-600 transition-all duration-300 rounded-full"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* QR Code Card for Installment Statement (Real active accounts only) */}
          {!isDemoInstallment(installment) && (
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/90 shadow-xs space-y-3 text-xs">
              {/* Toggle switch for showing / hiding barcode */}
              <div className="flex items-center justify-between">
                <label
                  onClick={() => setShowBarcode(!showBarcode)}
                  className="text-xs font-bold text-slate-800 flex items-center gap-2 cursor-pointer select-none"
                >
                  <i className="fa-solid fa-qrcode text-emerald-600 text-sm"></i>
                  <span>إظهار الباركود والرابط المباشر لكشف القسط</span>
                </label>
                <button
                  type="button"
                  dir="ltr"
                  onClick={() => setShowBarcode(!showBarcode)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    showBarcode ? 'bg-emerald-600' : 'bg-slate-300'
                  }`}
                  role="switch"
                  aria-checked={showBarcode}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                      showBarcode ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {showBarcode && (
                <div className="space-y-3 pt-2 border-t border-slate-200/60 animate-in fade-in duration-150">
                  <div className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-slate-200/70">
                    <div className="bg-white p-1.5 rounded-xl shrink-0 border border-slate-200 shadow-xs">
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(getPortalUrl('installment', installment.id, installment.phone))}`}
                        alt="QR Code"
                        className="w-12 h-12 object-contain rounded-md"
                        onError={(e) => {
                          e.currentTarget.src = `https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl=${encodeURIComponent(getPortalUrl('installment', installment.id, installment.phone))}`;
                        }}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-0.5">
                        <i className="fa-solid fa-qrcode text-emerald-600"></i>
                        <span>بوابة كشف القسط المباشر (QR)</span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono truncate dir-ltr text-left">
                        {getPortalUrl('installment', installment.id, installment.phone).replace(/^https?:\/\//, '')}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        يتيح للعميل متابعة سداد الأقساط والدفعات المتبقية مباشرة
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-200/60">
                    <button
                      type="button"
                      onClick={async () => {
                        const link = getPortalUrl('installment', installment.id, installment.phone);
                        try {
                          await navigator.clipboard.writeText(link);
                          alert('تم نسخ رابط كشف القسط المباشر بنجاح');
                        } catch {
                          alert('تعذر نسخ الرابط');
                        }
                      }}
                      className="flex-1 py-2 px-3 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs active:scale-98"
                      title="نسخ رابط كشف القسط المباشر"
                    >
                      <i className="fa-regular fa-copy text-xs text-emerald-600"></i>
                      <span>نسخ الرابط</span>
                    </button>

                    <button
                      type="button"
                      onClick={async () => {
                        const portalUrl = getPortalUrl('installment', installment.id);
                        const qrImgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(portalUrl)}`;
                        try {
                          const res = await fetch(qrImgUrl);
                          const blob = await res.blob();
                          const cleanName = (installment.name || 'قسط').replace(/[\s/\\:*?"<>|]+/g, '_');
                          const fileName = `باركود_كشف_قسط_${cleanName}_#${installment.id}.png`;
                          const file = new File([blob], fileName, { type: 'image/png' });

                          if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [file] })) {
                            await navigator.share({
                              title: `باركود كشف قسط - ${installment.name}`,
                              text: `رمز متابعة عقد القسط الخاص بالسيد: ${installment.name}`,
                              files: [file],
                            });
                            return;
                          }

                          const blobUrl = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = blobUrl;
                          a.download = fileName;
                          document.body.appendChild(a);
                          a.click();
                          document.body.removeChild(a);
                          URL.revokeObjectURL(blobUrl);
                        } catch {
                          window.open(qrImgUrl, '_blank');
                        }
                      }}
                      className="flex-1 py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs active:scale-98"
                      title="إرسال أو تحميل صورة الباركود"
                    >
                      <i className="fa-solid fa-qrcode text-xs text-emerald-600"></i>
                      <span>إرسال صورة الباركود</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Address Info */}
          {installment.address && (
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5 text-xs">
              <h3 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                <i className="fa-solid fa-location-dot text-emerald-600"></i>
                <span>{t('debtors.address', 'عنوان السكن وأقرب نقطة دالة')}</span>
              </h3>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 text-xs block">
                  {installment.address}
                </span>
              </div>
            </div>
          )}

          {/* Guarantor Info */}
          {(installment.guarantorEnabled || installment.guarantorName) && (
            <div className="p-3.5 rounded-2xl bg-purple-50/60 border border-purple-200/80 shadow-xs space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <h3 className="font-black text-purple-900 flex items-center gap-1.5 text-xs">
                  <i className="fa-solid fa-user-shield text-purple-600"></i>
                  <span>{t('installments.guarantorInfo', 'بيانات الكفيل والضامن')}</span>
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-[10px] font-bold">
                  {t('installments.guarantor', 'الكفيل')}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {installment.guarantorName && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorName', 'اسم الكفيل')}</span>
                    <span className="font-bold text-purple-950 text-xs mt-0.5 block">
                      {installment.guarantorName}
                    </span>
                  </div>
                )}

                {installment.guarantorRelation && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorRelation', 'صلة القرابة')}</span>
                    <span className="font-bold text-slate-800 text-xs mt-0.5 block">
                      {installment.guarantorRelation}
                    </span>
                  </div>
                )}

                {installment.guarantorJob && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorJob', 'مهنة الكفيل')}</span>
                    <span className="font-semibold text-slate-800 text-xs mt-0.5 block">
                      {installment.guarantorJob}
                    </span>
                  </div>
                )}

                {installment.guarantorPhone && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorPhone', 'هاتف الكفيل')}</span>
                      <span className="font-mono font-bold text-emerald-700 text-xs mt-0.5 block" dir="ltr">
                        {formatDateDigits(installment.guarantorPhone, numberFormat)}
                      </span>
                    </div>
                    <a
                      href={`tel:${installment.guarantorPhone}`}
                      className="w-7 h-7 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs transition-colors"
                      title={t('debtors.callPhone', 'اتصال بالكفيل')}
                    >
                      <i className="fa-solid fa-phone"></i>
                    </a>
                  </div>
                )}

                {installment.guarantorAddress && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100 sm:col-span-2">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorAddress', 'عنوان الكفيل')}</span>
                    <span className="font-semibold text-slate-800 text-xs mt-0.5 block">
                      {installment.guarantorAddress}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Dates Info */}
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
              <i className="fa-solid fa-calendar-plus text-slate-400 text-sm"></i>
              <div>
                <span className="text-[10.5px] text-slate-400 block">{t('installments.registrationDate', 'تاريخ التسجيل')}</span>
                <span className="font-bold text-slate-700 font-mono block">{formatDateDigits(installment.registrationDate, numberFormat)}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
              <i className="fa-solid fa-calendar-check text-emerald-600 text-sm"></i>
              <div>
                <span className="text-[10.5px] text-slate-400 block">{t('installments.dueDate', 'تاريخ الاستحقاق')}</span>
                <span className="font-bold text-slate-800 font-mono block">{formatDateDigits(installment.nextDueDate, numberFormat)}</span>
              </div>
            </div>
          </div>

          {installment.notes && (
            <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-xs text-amber-900">
              <span className="font-bold mb-0.5 flex items-center gap-1">
                <i className="fa-solid fa-note-sticky text-amber-700 text-xs"></i>
                <span>{t('common.notes', 'ملاحظات')}:</span>
              </span>
              <p className="text-[11.5px] leading-relaxed text-amber-950 font-medium">{installment.notes}</p>
            </div>
          )}

          {/* Initial Contract / Invoice Images */}
          {(() => {
            const contractImages = normalizeInvoiceImages(installment.invoiceImage, installment.invoiceImages);
            if (contractImages.length === 0) return null;
            return (
              <div className="p-3 rounded-2xl bg-blue-50/60 border border-blue-200/80 space-y-2 text-xs">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <span className="font-bold text-blue-950 block text-xs truncate">
                      {contractImages.length > 1
                        ? `صور عقد وفاتورة القسط الأساسية (${contractImages.length} صور)`
                        : 'صورة عقد / فاتورة القسط الأساسية'}
                    </span>
                    <span className="text-[10px] text-blue-700 font-mono block">انقر للمعاينة والتكبير</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedInvoice({
                      urls: contractImages,
                      initialIndex: 0,
                      title: `عقد / فاتورة قسط: ${installment.name}`,
                      subtitle: installment.item,
                      amount: `${formatNumber(installment.totalAmount, numberFormat)} ${currency}`
                    })}
                    className="h-8 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  >
                    <i className="fa-solid fa-expand text-[10px]"></i>
                    <span>استعراض الكل</span>
                  </button>
                </div>

                <div className="flex items-center gap-2 overflow-x-auto py-1">
                  {contractImages.map((imgUrl, imgIdx) => (
                    <div
                      key={imgIdx}
                      onClick={() => setSelectedInvoice({
                        urls: contractImages,
                        initialIndex: imgIdx,
                        title: `عقد قسط (${imgIdx + 1}): ${installment.name}`,
                        subtitle: installment.item,
                        amount: `${formatNumber(installment.totalAmount, numberFormat)} ${currency}`
                      })}
                      className="w-12 h-12 rounded-xl overflow-hidden border border-blue-200 bg-white shrink-0 cursor-pointer shadow-2xs hover:scale-105 transition-transform relative"
                    >
                      <img src={imgUrl} alt={`عقد ${imgIdx + 1}`} className="w-full h-full object-cover" />
                      {contractImages.length > 1 && (
                        <span className="absolute bottom-0.5 right-0.5 bg-black/60 text-white text-[8px] font-bold px-1 rounded">
                          {imgIdx + 1}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {/* Payments History */}
          <div className="space-y-2">
            <h3 className="text-xs font-black text-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <i className="fa-solid fa-clock-rotate-left text-teal-600 text-xs"></i>
                <span>{t('installments.paymentsHistory', 'سجل الدفعات والتسديدات')}</span>
              </span>
              <span className="text-[10.5px] font-normal text-slate-400 font-mono">
                ({formatNumber(installment.payments?.length || 0, numberFormat)})
              </span>
            </h3>

            {installment.payments && installment.payments.length > 0 ? (
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-100 bg-white overflow-hidden max-h-44 overflow-y-auto">
                {installment.payments.map((p, idx) => (
                  <div key={p.id || idx} className="p-2.5 flex items-center justify-between text-xs hover:bg-slate-50 gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-bold shrink-0">
                        <i className="fa-solid fa-arrow-down-left"></i>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-black text-slate-800">
                            +{formatNumber(p.amount, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                          </span>
                          <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                            p.paymentMethod === 'electronic'
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}>
                            {p.paymentMethod === 'electronic' ? '💳 إلكتروني' : '💵 كاش'}
                          </span>

                          {(() => {
                            const paymentImages = normalizeInvoiceImages(p.invoiceImage, p.invoiceImages);
                            if (paymentImages.length === 0) return null;
                            return (
                              <button
                                type="button"
                                onClick={() => setSelectedInvoice({
                                  urls: paymentImages,
                                  initialIndex: 0,
                                  title: `وصل تسديد: ${installment.name}`,
                                  subtitle: formatFullDateTime(p.date, numberFormat),
                                  amount: `+${formatNumber(p.amount, numberFormat)} ${currency}`
                                })}
                                className="h-6 px-2 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 active:bg-blue-200 border border-blue-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all active:scale-95 touch-manipulation shadow-2xs"
                                title="تكبير ومعاينة صور وصل التسديد"
                              >
                                <i className="fa-solid fa-magnifying-glass-plus text-[9px]"></i>
                                <span>{paymentImages.length > 1 ? `الوصول (${paymentImages.length})` : 'تكبير الوصل'}</span>
                              </button>
                            );
                          })()}

                          {onUpdateInstallment && (
                            <button
                              type="button"
                              onClick={() => handleStartEditPayment(p)}
                              className="h-6 px-2 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 active:bg-amber-200 border border-amber-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all active:scale-95 shadow-2xs"
                              title="تعديل قيمة هذه الدفعة"
                            >
                              <i className="fa-solid fa-pen text-[9px]"></i>
                              <span>تعديل</span>
                            </button>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono block truncate">
                          <i className="fa-regular fa-clock text-[9px] text-slate-400 ml-1"></i>
                          {formatFullDateTime(p.date, numberFormat)} {p.notes ? `• ${p.notes}` : ''}
                        </span>
                      </div>
                    </div>
                    <div className="text-end shrink-0">
                      <span className="text-[10px] text-slate-400 block">{t('installments.remainingAmount', 'المتبقي')}</span>
                      <span className="text-[11px] font-bold text-slate-600 font-mono">
                        {formatNumber(p.remainingAfter, numberFormat)} {currency}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center rounded-xl bg-slate-50 border border-dashed border-slate-200 text-slate-400 text-xs">
                {t('installments.noPaymentsYet', 'لم يتم تسجيل أي دفعات إضافية بعد')}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 modal-footer-safe bg-slate-50 border-t border-slate-100 flex items-center gap-2 shrink-0">


          {onOpenEditModal && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenEditModal(installment);
              }}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              title={t('common.edit', 'تعديل')}
            >
              <i className="fa-solid fa-pen-to-square text-xs text-emerald-600"></i>
              <span>{t('common.edit', 'تعديل')}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              onClose();
              onDelete(installment.id);
            }}
            className="py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            title={t('common.delete', 'حذف')}
          >
            <i className="fa-solid fa-trash-can text-xs"></i>
            <span>{t('common.delete', 'حذف')}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          >
            {t('common.close', 'إغلاق')}
          </button>
        </div>
      </div>

      {/* Invoice Lightbox Modal */}
      <InvoiceImageViewerModal
        isOpen={Boolean(selectedInvoice)}
        onClose={() => setSelectedInvoice(null)}
        imageUrl={selectedInvoice?.url}
        imageUrls={selectedInvoice?.urls}
        initialIndex={selectedInvoice?.initialIndex ?? 0}
        title={selectedInvoice?.title}
        subtitle={selectedInvoice?.subtitle}
        amountText={selectedInvoice?.amount}
      />

      {/* Edit Payment Modal Dialog */}
      {editingPayment && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-slate-200 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xs">
                  <i className="fa-solid fa-pen text-xs"></i>
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">تعديل مبلغ الدفعة المسجلة</h3>
                  <p className="text-[10px] text-slate-400">تصحيح الخطأ في القيمة المسددة</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingPayment(null)}
                className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  مبلغ الدفعة ({currency})
                </label>
                <input
                  type="number"
                  step="any"
                  value={editAmountInput}
                  onChange={(e) => setEditAmountInput(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none"
                  placeholder="أدخل مبلغ الدفعة الصحيح..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  ملاحظات أو بيان الدفعة
                </label>
                <input
                  type="text"
                  value={editNotesInput}
                  onChange={(e) => setEditNotesInput(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 rounded-xl text-xs font-semibold text-slate-900 outline-none"
                  placeholder="ملاحظات توضيحية اختيارية..."
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={handleSavePaymentEdit}
                disabled={isSavingPaymentEdit}
                className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isSavingPaymentEdit ? (
                  <i className="fa-solid fa-spinner animate-spin text-xs"></i>
                ) : (
                  <i className="fa-solid fa-check text-xs"></i>
                )}
                <span>حفظ التعديل</span>
              </button>
              <button
                type="button"
                onClick={() => setEditingPayment(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

