import React, { useState, useEffect, useMemo } from 'react';
import { useI18n } from '../i18n/index.tsx';
import { Debtor } from '../types';
import { formatAmountInput, parseFormattedNumber, getCurrentTimeStr, resolveRecordDateTime } from '../utils/formatters';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceAttachmentField } from './InvoiceAttachmentField';
import { checkNameDuplicate, ExistingNameRecord } from '../utils/nameDuplicateChecker';
import { NameDuplicateAlert } from './NameDuplicateAlert';

interface AddDebtorModalProps {
  isOpen: boolean;
  defaultType?: 'debtor' | 'creditor';
  showTypeSwitcher?: boolean;
  allowInvoiceUpload?: boolean;
  requireCustomerPhone?: boolean;
  onClose: () => void;
  onSave: (name: string, phone: string, amount: number, debtDate?: string, notes?: string, type?: 'debtor' | 'creditor', invoiceImage?: string) => Promise<void>;
  existingDebtors?: Debtor[];
  onSelectExistingDebtor?: (debtor: Debtor) => void;
}

export const AddDebtorModal: React.FC<AddDebtorModalProps> = ({
  isOpen,
  defaultType = 'debtor',
  showTypeSwitcher = false,
  allowInvoiceUpload = true,
  requireCustomerPhone = false,
  onClose,
  onSave,
  existingDebtors = [],
  onSelectExistingDebtor,
}) => {
  const { t, currency } = useI18n();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(true);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [debtTime, setDebtTime] = useState(() => getCurrentTimeStr());
  const [notes, setNotes] = useState('');
  const [invoiceImage, setInvoiceImage] = useState<string | undefined>(undefined);
  const [debtType, setDebtType] = useState<'debtor' | 'creditor'>(defaultType);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allowDuplicateName, setAllowDuplicateName] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setName('');
      setPhone('');
      setAmountStr('');
      setNotes('');
      setDebtType(defaultType);
      setRecordTime(true);
      setTimeMode('auto');
      setDebtTime(getCurrentTimeStr());
      setInvoiceImage(undefined);
      setError(null);
      setAllowDuplicateName(false);
    }
  }, [isOpen, defaultType]);

  // Existing records pool matching current selected type
  const candidateRecords: ExistingNameRecord[] = useMemo(() => {
    if (!existingDebtors || existingDebtors.length === 0) return [];
    return existingDebtors
      .filter((d) => (d.type || 'debtor') === debtType)
      .map((d) => ({
        id: d.id,
        name: d.name,
        phone: d.phone,
        amount: d.amount,
        type: d.type || 'debtor',
      }));
  }, [existingDebtors, debtType]);

  const nameCheckResult = useMemo(() => {
    return checkNameDuplicate(name, candidateRecords);
  }, [name, candidateRecords]);

  useModalKeyboardAdjust(isOpen);

  if (!isOpen) return null;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmountStr(formatAmountInput(e.target.value));
    if (error) setError(null);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError(debtType === 'creditor' ? 'يرجى كتابة اسم الدائن أولاً' : t('modals.enterDebtorNameError', 'يرجى كتابة اسم المدين أولاً'));
      return;
    }

    if (nameCheckResult.hasExactMatch && !allowDuplicateName) {
      setError(`يوجد حساب مسجل مسبقاً باسم "${nameCheckResult.exactMatch?.name}". يرجى فتح حسابه بدلاً من تكرار الاسم أو تفعيل خيار السماح بالتكرار أدناه.`);
      return;
    }

    const trimmedPhone = phone.trim();
    if (requireCustomerPhone && !trimmedPhone) {
      setError('رقم هاتف العميل إلزامي بتوجيه من الإدارة العامة، يرجى إدخال رقم الهاتف للمتابعة');
      return;
    }
    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError(
        requireCustomerPhone
          ? 'رقم هاتف العميل إلزامي ويجب أن يتكون من 11 رقماً'
          : t('modals.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)')
      );
      return;
    }

    const numericAmount = parseFormattedNumber(amountStr);
    if (!amountStr.trim() || isNaN(numericAmount) || numericAmount <= 0) {
      setError(debtType === 'creditor' ? 'يرجى كتابة المبلغ المستحق أولاً (يجب أن يكون أكبر من 0)' : 'يرجى كتابة مبلغ الدين أولاً (يجب أن يكون أكبر من 0)');
      return;
    }

    try {
      setIsSubmitting(true);
      const formattedDateTime = resolveRecordDateTime(debtDate, recordTime, timeMode, debtTime);
      await onSave(
        trimmedName,
        trimmedPhone,
        numericAmount,
        formattedDateTime,
        notes.trim() || undefined,
        debtType,
        invoiceImage
      );
      setName('');
      setPhone('');
      setAmountStr('');
      setDebtDate(new Date().toISOString().split('T')[0]);
      setDebtTime(getCurrentTimeStr());
      setNotes('');
      setInvoiceImage(undefined);
      onClose();
    } catch (err: any) {
      setError(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء الحفظ'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const isCreditor = debtType === 'creditor';

  return (
    <div
      id="addModal"
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center z-50 p-0 sm:p-4 animate-in fade-in duration-150 text-start"
    >
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md shadow-2xl relative border border-slate-100 max-h-[92dvh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className={`px-5 py-4 text-white flex items-center justify-between shrink-0 transition-colors duration-300 ${
          isCreditor
            ? 'bg-gradient-to-r from-rose-700 via-rose-800 to-slate-900'
            : 'bg-gradient-to-r from-blue-700 via-indigo-800 to-slate-900'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center text-white border border-white/10">
              <i className={`fa-solid ${isCreditor ? 'fa-hand-holding-dollar' : 'fa-user-plus'} text-base`}></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">
                {isCreditor ? 'إضافة دين عليّ (دائن جديد)' : t('debtors.addDebtor', 'إضافة مدين جديد')}
              </h2>
              <p className="text-[10.5px] text-white/80 mt-0.5 font-medium">
                {isCreditor ? 'تسجيل مبلغ أو شخص يطلبك مالاً في الدفتر' : t('debtors.addDebtorSubtitle', 'تسجيل حساب دين جديد في الدفتر')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-white/15 hover:bg-white/25 active:bg-white/35 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer touch-manipulation border border-white/10 shadow-xs"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form id="addDebtorForm" onSubmit={handleSubmit} className="p-5 pb-28 sm:pb-5 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{error}</span>
            </div>
          )}

          {/* Type Segmented Switcher (Only if enabled) */}
          {showTypeSwitcher && (
            <div className="bg-slate-100 p-1 rounded-2xl flex items-center gap-1 border border-slate-200/80">
              <button
                type="button"
                onClick={() => setDebtType('debtor')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  debtType === 'debtor'
                    ? 'bg-white text-blue-700 shadow-xs border border-slate-200/80 font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-arrow-up-right-from-square text-blue-600"></i>
                <span>دين لي (أطلبه)</span>
              </button>
              <button
                type="button"
                onClick={() => setDebtType('creditor')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  debtType === 'creditor'
                    ? 'bg-rose-600 text-white shadow-xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-hand-holding-dollar"></i>
                <span>دين عليّ (يطلبني)</span>
              </button>
            </div>
          )}

          {/* Debtor/Creditor Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className={`fa-solid fa-user ${isCreditor ? 'text-rose-600' : 'text-blue-600'} text-xs`}></i>
              <span>{isCreditor ? 'اسم الشخص / الدائن (الذي يطلبك)' : t('debts.debtorName', 'اسم المدين')}</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              id="modalName"
              className={`w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm outline-none font-medium transition-all ${
                isCreditor
                  ? 'focus:border-rose-600 focus:ring-2 focus:ring-rose-500/20'
                  : 'focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20'
              }`}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              onFocus={handleInputFocus}
              required
            />
            <NameDuplicateAlert
              checkResult={nameCheckResult}
              currency={currency}
              onSelectExisting={(rec) => {
                const found = existingDebtors?.find((d) => d.id === rec.id);
                if (found && onSelectExistingDebtor) {
                  onSelectExistingDebtor(found);
                }
              }}
              allowSameNameAnyway={allowDuplicateName}
              onToggleAllowSameName={setAllowDuplicateName}
            />
          </div>

          {/* Phone Number */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <i className={`fa-solid fa-phone ${requireCustomerPhone ? 'text-blue-600' : 'text-slate-400'} text-xs`}></i>
                <span>{t('debts.phoneNumber', 'رقم الهاتف')}</span>
                {requireCustomerPhone && <span className="text-rose-500 font-extrabold">*</span>}
              </span>
              <span className={`text-[10.5px] font-bold px-2 py-0.5 rounded-md transition-colors ${
                requireCustomerPhone
                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                  : 'text-slate-400'
              }`}>
                {requireCustomerPhone ? 'إلزامي بتوجيه الإدارة' : t('common.optional', 'اختياري')}
              </span>
            </label>
            <input
              type="tel"
              id="modalPhone"
              dir="ltr"
              required={requireCustomerPhone}
              className={`w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border rounded-xl text-sm outline-none focus:ring-2 text-slate-800 transition-all font-mono font-medium ${
                requireCustomerPhone
                  ? 'border-blue-300 focus:border-blue-600 focus:ring-blue-500/20'
                  : 'border-slate-200 focus:border-blue-600 focus:ring-blue-500/20'
              }`}
              maxLength={11}
              placeholder=""
              value={phone}
              onChange={handlePhoneChange}
              onFocus={handleInputFocus}
            />
          </div>

          {/* Initial Debt Amount */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className={`fa-solid fa-money-bill-wave ${isCreditor ? 'text-rose-600' : 'text-blue-600'} text-xs`}></i>
              <span>{isCreditor ? 'المبلغ المستحق عليك له' : t('debts.initialDebtAmount', 'مبلغ الدين الأولي')} ({currency})</span>
              <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                id="modalAmount"
                dir="ltr"
                inputMode="numeric"
                placeholder="0"
                required
                className={`w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-sm outline-none font-black font-mono transition-all ${
                  isCreditor
                    ? 'focus:border-rose-600 focus:ring-2 focus:ring-rose-500/20 text-rose-700'
                    : 'focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800'
                }`}
                value={amountStr}
                onChange={handleAmountChange}
                onFocus={handleInputFocus}
              />
            </div>
          </div>

          {/* Debt Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className={`fa-solid fa-calendar-day ${isCreditor ? 'text-rose-600' : 'text-blue-600'} text-xs`}></i>
              <span>{t('debts.debtRegistrationDate', 'تاريخ تسجيل الدين')}</span>
            </label>
            <input
              type="date"
              id="modalDate"
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-mono"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
              onFocus={handleInputFocus}
            />
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={debtTime}
            onTimeChange={setDebtTime}
            accentColor={isCreditor ? 'rose' : 'blue'}
            idPrefix="add_debtor"
          />

          {/* Notes Field (Optional) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-note-sticky text-slate-400 text-xs"></i>
              <span>{t('common.notes', 'ملاحظات')}</span>
            </label>
            <textarea
              id="modalNotes"
              rows={2}
              placeholder=""
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all resize-none font-medium"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              onFocus={handleInputFocus}
              maxLength={250}
            />
          </div>

          {/* Invoice Attachment Field */}
          <InvoiceAttachmentField
            value={invoiceImage}
            onChange={setInvoiceImage}
            allowUpload={allowInvoiceUpload}
            label={isCreditor ? 'صورة فاتورة / وصل الدين (اختياري)' : 'صورة فاتورة / وصل الدين الأولي (اختياري)'}
          />

          {/* Actions */}
          <div className="flex items-center gap-2.5 pt-3 border-t border-slate-100 pb-[max(0.75rem,calc(env(safe-area-inset-bottom)+0.5rem))]">
            <button
              type="submit"
              id="btnSaveSubmit"
              disabled={isSubmitting}
              className={`flex-1 min-h-[48px] py-3 px-4 rounded-xl text-white text-xs sm:text-sm font-extrabold shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 touch-manipulation ${
                isCreditor
                  ? 'bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 active:from-rose-800 active:to-rose-900 shadow-rose-600/20'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 active:from-blue-800 active:to-indigo-800 shadow-blue-600/20'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري الحفظ...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{isCreditor ? 'حفظ الدين (عليّ)' : t('debtors.saveDebtor', 'حفظ المدين')}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="min-h-[48px] py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 active:scale-[0.98] text-slate-700 text-xs sm:text-sm font-bold transition-all cursor-pointer touch-manipulation border border-slate-200/50"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
