import React from 'react';
import { Supplier } from '../types';
import { useI18n } from '../i18n/index.tsx';

interface SupplierSettleCompleteModalProps {
  isOpen: boolean;
  supplier: Supplier | null;
  onKeep?: () => void;
  onKeepWithHistory?: () => void;
  onKeepAndClearHistory?: () => void;
  onDelete: () => void;
  isLoading?: boolean;
}

export const SupplierSettleCompleteModal: React.FC<SupplierSettleCompleteModalProps> = ({
  isOpen,
  supplier,
  onKeep,
  onKeepWithHistory,
  onKeepAndClearHistory,
  onDelete,
  isLoading = false,
}) => {
  const { t, currencySymbol = 'د.ع' } = useI18n();

  if (!isOpen || !supplier) return null;

  const handleKeepWithHistory = () => {
    if (onKeepWithHistory) {
      onKeepWithHistory();
    } else if (onKeep) {
      onKeep();
    }
  };

  const handleKeepAndClearHistory = () => {
    if (onKeepAndClearHistory) {
      onKeepAndClearHistory();
    } else if (onKeep) {
      onKeep();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 select-none">
      <div
        className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl relative border border-slate-100 dark:border-slate-800 text-center animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Success Icon */}
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-2xl mx-auto mb-3 shadow-sm border border-emerald-100 dark:border-emerald-900/50">
          <i className="fa-solid fa-circle-check"></i>
        </div>

        <span className="text-[11px] font-bold bg-emerald-100/70 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 px-3 py-1 rounded-full inline-block mb-2">
          {t('suppliers.settledBadge', 'خالص الذمة 100%')}
        </span>

        <h3 className="font-black text-base sm:text-lg text-slate-800 dark:text-white mb-1.5">
          {t('suppliers.settledTitle', 'تم تسديد كامل دين المورد')}
        </h3>

        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3 leading-relaxed">
          {t('suppliers.settledDesc', 'تم تسديد جميع المستحقات المترتبة لصالح المورد')}{' '}
          <span className="font-bold text-slate-800 dark:text-slate-200">{supplier.name}</span>{' '}
          {t('suppliers.settledBalanceIs', 'بالكامل وأصبح الرصيد')}{' '}
          <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">0 {currencySymbol}</span>.
        </p>

        <p className="text-[11.5px] font-semibold text-slate-600 dark:text-slate-300 mb-4 bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
          {t('suppliers.settlePrompt', 'يرجى تحديد الإجراء المطلوب لحساب المورد:')}
        </p>

        {/* 3 Action Buttons */}
        <div className="flex flex-col gap-2.5 text-start">
          {/* Option 1: Keep with old history */}
          <button
            type="button"
            onClick={handleKeepWithHistory}
            disabled={isLoading}
            className="w-full p-3 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 hover:bg-blue-100/80 dark:hover:bg-blue-900/40 active:scale-[0.99] border border-blue-200/80 dark:border-blue-900/50 transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center text-sm shrink-0 shadow-xs">
                <i className="fa-solid fa-box-archive"></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-blue-950 dark:text-blue-200 group-hover:text-blue-900 flex items-center justify-between">
                  <span>{t('suppliers.keepWithHistory', 'الاحتفاظ بالمورد مع سجلاته القديمة')}</span>
                  <i className="fa-solid fa-chevron-left text-[10px] text-blue-400 group-hover:translate-x-[-2px] transition-transform"></i>
                </div>
                <p className="text-[10px] text-blue-700/80 dark:text-blue-300/70 mt-0.5 leading-tight">
                  {t('suppliers.keepWithHistoryDesc', 'الإبقاء عليه في السجل كخالص الذمة مع حفظ الفواتير والدفعات السابقة')}
                </p>
              </div>
            </div>
          </button>

          {/* Option 2: Keep supplier but clear old history */}
          <button
            type="button"
            onClick={handleKeepAndClearHistory}
            disabled={isLoading}
            className="w-full p-3 rounded-2xl bg-teal-50/70 dark:bg-teal-950/30 hover:bg-teal-100/80 dark:hover:bg-teal-900/40 active:scale-[0.99] border border-teal-200/80 dark:border-teal-900/50 transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center text-sm shrink-0 shadow-xs">
                <i className="fa-solid fa-rotate-right"></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-teal-950 dark:text-teal-200 group-hover:text-teal-900 flex items-center justify-between">
                  <span>{t('suppliers.keepAndClear', 'الاحتفاظ بالمورد مع حذف سجلاته القديمة')}</span>
                  <i className="fa-solid fa-chevron-left text-[10px] text-teal-400 group-hover:translate-x-[-2px] transition-transform"></i>
                </div>
                <p className="text-[10px] text-teal-700/80 dark:text-teal-300/70 mt-0.5 leading-tight">
                  {t('suppliers.keepAndClearDesc', 'الإبقاء على بيانات المورد وتصفير الرصيد وبدء صفحة جديدة')}
                </p>
              </div>
            </div>
          </button>

          {/* Option 3: Permanently delete supplier */}
          <button
            type="button"
            onClick={onDelete}
            disabled={isLoading}
            className="w-full p-3 rounded-2xl bg-rose-50/60 dark:bg-rose-950/30 hover:bg-rose-100/80 dark:hover:bg-rose-900/40 active:scale-[0.99] border border-rose-200/80 dark:border-rose-900/50 transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center text-sm shrink-0 shadow-xs">
                <i className="fa-regular fa-trash-can"></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-rose-950 dark:text-rose-200 group-hover:text-rose-900 flex items-center justify-between">
                  <span>{t('suppliers.deletePermanently', 'حذف المورد نهائياً')}</span>
                  <i className="fa-solid fa-chevron-left text-[10px] text-rose-400 group-hover:translate-x-[-2px] transition-transform"></i>
                </div>
                <p className="text-[10px] text-rose-700/80 dark:text-rose-300/70 mt-0.5 leading-tight">
                  {t('suppliers.deletePermanentlyDesc', 'إزالة حساب المورد وكافة سجلاته وحركاته نهائياً من قاعدة البيانات')}
                </p>
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
