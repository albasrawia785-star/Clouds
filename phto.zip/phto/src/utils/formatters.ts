import { getPortalUrl } from './qrUtils';

export function toEnglishDigits(str: string | number | null | undefined): string {
  if (str === null || str === undefined) return '';
  const arabicToEnglishMap: Record<string, string> = {
    '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
    '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
    '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
    '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  };
  return String(str).replace(/[٠-٩۰-۹]/g, (d) => arabicToEnglishMap[d] || d);
}

export function toArabicDigits(str: string | number | null | undefined): string {
  if (str === null || str === undefined) return '';
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(str).replace(/[0-9]/g, (d) => arabicDigits[parseInt(d, 10)]);
}

export function formatNumber(
  num: number | string | null | undefined,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (num === null || num === undefined) return format === 'arabic' ? '٠' : '0';
  const clean = toEnglishDigits(num);
  if (isNaN(Number(clean))) return format === 'arabic' ? '٠' : '0';
  const formatted = Number(clean).toLocaleString('en-US');
  return format === 'arabic' ? toArabicDigits(formatted) : formatted;
}

export function parseFormattedNumber(val: string | number | null | undefined): number {
  if (!val) return 0;
  const englishVal = toEnglishDigits(val);
  return parseFloat(String(englishVal).replace(/,/g, '')) || 0;
}

export function formatAmountInput(value: string): string {
  const englishVal = toEnglishDigits(value);
  const rawValue = englishVal.replace(/[^0-9]/g, '');
  if (rawValue === '') return '';
  return parseInt(rawValue, 10).toLocaleString('en-US');
}

export function formatDateDigits(
  dateStr?: string | null,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (!dateStr) return '';
  try {
    const rawDate = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr.split(' ')[0];
    const parts = rawDate.split('-');
    let cleanFormatted = rawDate;
    if (parts.length === 3) {
      const [year, month, day] = parts;
      if (year.length === 4) {
        cleanFormatted = `${year}/${month.padStart(2, '0')}/${day.padStart(2, '0')}`;
      }
    } else {
      const parsed = new Date(dateStr);
      if (!isNaN(parsed.getTime())) {
        const y = parsed.getFullYear();
        const m = String(parsed.getMonth() + 1).padStart(2, '0');
        const d = String(parsed.getDate()).padStart(2, '0');
        cleanFormatted = `${y}/${m}/${d}`;
      }
    }
    const normalized = toEnglishDigits(cleanFormatted);
    return format === 'arabic' ? toArabicDigits(normalized) : normalized;
  } catch {
    return dateStr;
  }
}

export function formatIraqiPhoneNumber(phone: string): string {
  if (!phone) return "";
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('07')) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.length === 10 && cleaned.startsWith('7')) {
    cleaned = '964' + cleaned;
  }
  return cleaned;
}

export function buildWhatsAppReminderUrl(
  phone: string,
  debtorName?: string,
  amount?: number,
  isCreditor: boolean = false,
  mastercardNumber?: string,
  enableElectronicPayment?: boolean,
  debtorId?: number,
  isDemo?: boolean
): string {
  const formattedPhone = formatIraqiPhoneNumber(phone);
  let text = '';
  const shouldIncludeCard = enableElectronicPayment !== false && mastercardNumber && mastercardNumber.trim();
  const paymentBlock = (!isCreditor && shouldIncludeCard)
    ? `\n\n━━━━━━━━━━━━━━━━━━━\nطرق التسديد المتاحة:\n• نقداً (كاش)\n• إلكترونياً (ماستر كارد):\n💳 رقم الماستر كارد: ${mastercardNumber.trim()}\n(يرجى إرسال إشعار التحويل بعد الإيداع لتأكيد السداد)\n━━━━━━━━━━━━━━━━━━━`
    : '';

  const isDemoAcc = isDemo || (typeof debtorId === 'number' && debtorId < 0) || phone.includes('*') || phone.includes('X');
  const portalBlock = (isDemoAcc || !debtorId)
    ? ''
    : `\n\nللاطلاع على تفاصيل حسابك والدفعات:\n${getPortalUrl('debtor', debtorId)}`;

  if (isCreditor) {
    text = amount && amount > 0 && debtorName
      ? `إشعار مطابقة رصيد حساب دائن\n\nالسيد/ ${debtorName}\nتحية طيبة وبعد،\n\nنود إشعاركم بمطابقة رصيد حسابكم المالي المسجل لدينا:\n\n• إجمالي الرصيد المستحق لكم: (${formatNumber(amount)} د.ع)${portalBlock}\n\nشاكرين لكم حسن التعاون.`
      : "إشعار مطابقة رصيد حساب دائن.";
  } else {
    text = amount && amount > 0 && debtorName
      ? `إشعار تذكير بمستحقات مالية\n\nالسيد/ ${debtorName}\nتحية طيبة وبعد،\n\nنود تذكيركم بمراجعة الحساب القائم بذمتكم والبالغ قدره (${formatNumber(amount)} د.ع) لغرض التسديد.${paymentBlock}${portalBlock}\n\nشاكرين ومقدرين حسن تعاونكم معنا.`
      : "إشعار تذكير بمراجعة الحساب والتسديد.";
  }
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodeURIComponent(text)}`;
}

/**
 * Calculates number of full elapsed days from a date string to now
 */
export function calculateDaysElapsed(dateStr?: string | null): number {
  if (!dateStr) return 0;
  const parsed = new Date(dateStr).getTime();
  if (isNaN(parsed)) return 0;
  const diffMs = Date.now() - parsed;
  if (diffMs <= 0) return 0;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Formats elapsed days count into natural Arabic text
 */
export function formatDaysElapsedArabic(days: number): string {
  if (days <= 0) return "أقل من يوم";
  if (days === 1) return "يوم واحد";
  if (days === 2) return "يومان";
  if (days >= 3 && days <= 10) return `${days} أيام`;
  return `${days} يوماً`;
}

/**
 * Formats ISO date into readable short date (YYYY/MM/DD)
 */
export function formatDateArabic(dateStr?: string | null): string {
  if (!dateStr) return "";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "";
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}/${m}/${day}`;
  } catch {
    return "";
  }
}

/**
 * Checks if a user is an Admin or has a Permanent / Exempt subscription
 * (Admins, usernames containing 'admin', branch_name containing 'admin', ID 1, permanent accounts, etc.)
 */
export function isUserAdminOrPermanent(user: {
  id?: number;
  role?: string;
  username?: string;
  branch_name?: string;
  subscriptionType?: string;
  isGuest?: boolean;
} | null | undefined): boolean {
  if (!user) return true; // Safe fallback
  if (user.role === 'admin' || user.id === 1 || user.id === 999999 || user.isGuest) return true;
  if (user.subscriptionType === 'permanent' || user.subscriptionType === 'local_permanent' || user.subscriptionType === 'trial' || user.role === 'trial') return true;
  
  const uname = (user.username || '').toLowerCase();
  const bname = (user.branch_name || '').toLowerCase();
  if (uname.includes('admin') || bname.includes('admin')) return true;

  return false;
}

/**
 * Calculates remaining days until subscription expires
 */
export function getSubscriptionDaysRemaining(expiresAt?: string | null): number {
  if (!expiresAt) return 0;
  const parsed = new Date(expiresAt).getTime();
  if (isNaN(parsed)) return 0;
  const diffMs = parsed - Date.now();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Checks if a monthly/yearly subscription has expired.
 * Supports overloaded calls: isSubscriptionExpired(type, expiresAt) OR isSubscriptionExpired(expiresAt)
 */
export function isSubscriptionExpired(typeOrExpiresAt?: string | null, expiresAtArg?: string | null): boolean {
  let subscriptionType = typeOrExpiresAt;
  let expiresAt = expiresAtArg;

  // Handle single-argument call where only expiresAt is provided
  if (typeOrExpiresAt && expiresAtArg === undefined) {
    if (typeOrExpiresAt.includes('-') || typeOrExpiresAt.includes('/') || typeOrExpiresAt.includes('T') || !isNaN(Number(typeOrExpiresAt))) {
      subscriptionType = 'monthly';
      expiresAt = typeOrExpiresAt;
    }
  }

  if (!subscriptionType || subscriptionType === 'permanent' || subscriptionType === 'local_permanent' || subscriptionType === 'trial') return false;
  if (subscriptionType !== 'monthly' && subscriptionType !== 'yearly') return false;
  if (!expiresAt) return false;
  try {
    const expDate = new Date(expiresAt);
    if (isNaN(expDate.getTime())) return false;
    // If only date string (YYYY-MM-DD), set to end of that day (23:59:59.999)
    if (expiresAt.length <= 10) {
      expDate.setHours(23, 59, 59, 999);
    }
    return expDate.getTime() < Date.now();
  } catch {
    return false;
  }
}

/**
 * Formats ISO date into readable date only (YYYY/MM/DD)
 */
export function formatDateOnly(
  dateStr?: string | null,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr || '';

    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');

    const formattedStr = `${y}/${m}/${day}`;
    return format === 'arabic' ? toArabicDigits(formattedStr) : formattedStr;
  } catch {
    return dateStr || '';
  }
}

/**
 * Returns the current local time formatted as "HH:mm" (24h)
 */
export function getCurrentTimeStr(): string {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Extracts "HH:mm" from a date string, or returns current local time
 */
export function extractTimeFromDate(dateStr?: string | null): string {
  if (!dateStr) return getCurrentTimeStr();
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return getCurrentTimeStr();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
  } catch {
    return getCurrentTimeStr();
  }
}

/**
 * Combines date string (YYYY-MM-DD) and time string (HH:mm) into a standard ISO 8601 string
 */
export function combineDateAndTime(dateStr?: string | null, timeStr?: string | null): string {
  const now = new Date();
  if (!dateStr) {
    return now.toISOString();
  }
  // If dateStr already includes time and no explicit timeStr is provided
  if (dateStr.includes('T') && dateStr.length > 10 && !timeStr) {
    return new Date(dateStr).toISOString();
  }

  const cleanDate = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr;
  const cleanTime = timeStr && timeStr.includes(':')
    ? timeStr
    : `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  try {
    const [year, month, day] = cleanDate.split('-').map(Number);
    const [hours, minutes] = cleanTime.split(':').map(Number);
    if (!isNaN(year) && !isNaN(month) && !isNaN(day)) {
      const d = new Date(
        year,
        month - 1,
        day,
        isNaN(hours) ? now.getHours() : hours,
        isNaN(minutes) ? now.getMinutes() : minutes,
        now.getSeconds()
      );
      return d.toISOString();
    }
  } catch {}

  return now.toISOString();
}

/**
 * Checks if a date string has an explicit time component (not a plain date-only string)
 */
export function hasExplicitTime(dateStr?: string | null): boolean {
  if (!dateStr) return false;
  const trimmed = dateStr.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return false;
  if (/^\d{4}\/\d{2}\/\d{2}$/.test(trimmed)) return false;
  return trimmed.includes('T') || trimmed.includes(':') || trimmed.includes(' ');
}

/**
 * Resolves the final date string based on whether time recording is enabled
 * - If recordTimeEnabled is false: returns the clean date string (YYYY-MM-DD)
 * - If recordTimeEnabled is true:
 *    - if timeMode is 'auto': combines date with current device time
 *    - if timeMode is 'manual': combines date with manualTime
 */
export function resolveRecordDateTime(
  dateStr: string,
  recordTimeEnabled: boolean,
  timeMode: 'auto' | 'manual',
  manualTime?: string
): string {
  if (!dateStr) {
    return new Date().toISOString();
  }
  const cleanDate = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr;
  if (!recordTimeEnabled) {
    return cleanDate;
  }
  if (timeMode === 'manual' && manualTime) {
    return combineDateAndTime(cleanDate, manualTime);
  }
  return combineDateAndTime(cleanDate, getCurrentTimeStr());
}

/**
 * Formats time portion into readable 12-hour format with AM/PM (ص/م)
 */
export function formatTimeOnly(
  dateStr?: string | null,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    let hours = d.getHours();
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'م' : 'ص';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const formattedHours = String(hours).padStart(2, '0');
    const result = `${formattedHours}:${minutes} ${ampm}`;
    return format === 'arabic' ? toArabicDigits(result) : result;
  } catch {
    return '';
  }
}

/**
 * Formats ISO date into readable full date and time (YYYY/MM/DD • HH:MM ص/م)
 */
export function formatFullDateTime(
  dateStr?: string | null,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr || '';

    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const formattedDate = `${y}/${m}/${day}`;

    // If string is strictly date only (e.g. YYYY-MM-DD), return date only
    const hasTime = dateStr.includes('T') || dateStr.includes(':') || dateStr.includes(' ');
    if (!hasTime) {
      return format === 'arabic' ? toArabicDigits(formattedDate) : formattedDate;
    }

    let hours = d.getHours();
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'م' : 'ص';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const formattedHours = String(hours).padStart(2, '0');

    const formattedTime = `${formattedHours}:${minutes} ${ampm}`;
    const result = `${formattedDate} • ${formattedTime}`;

    return format === 'arabic' ? toArabicDigits(result) : result;
  } catch {
    return dateStr || '';
  }
}


