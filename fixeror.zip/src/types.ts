export type SubscriptionType = 'permanent' | 'local_permanent' | 'yearly' | 'monthly' | 'trial';
export type ManagerModuleAccess =
  | 'both'
  | 'all'
  | 'debts'
  | 'installments'
  | 'suppliers'
  | 'creditors'
  | 'debts_installments'
  | 'debts_suppliers'
  | 'installments_suppliers';

export type AppLayoutTheme =
  | 'classic'
  | 'fintech'
  | 'bento'
  | 'ledger'
  | 'minimal_luxury'
  | 'floating_glass'
  | 'compact_dense'
  | 'timeline'
  | 'retail_modern'
  | 'studio_analytics';

export interface DatabaseAccount {
  id: string;
  name: string;
  url: string;
  token: string;
  description?: string;
  isDefault?: boolean;
  isDedicated?: boolean;
  connectionMode?: 'dual_sync' | 'isolated';
  storageLocation?: 'default' | 'isolated';
  createdAt?: string;
}

export interface User {
  id: number;
  username: string;
  name?: string;
  role: 'admin' | 'manager' | string;
  branch_name: string;
  phoneOrEmail?: string;
  password?: string;
  isActive?: boolean;
  isNewRegistration?: boolean;
  subscriptionType?: SubscriptionType;
  subscriptionExpiresAt?: string | null;
  allowedModules?: ManagerModuleAccess;
  layoutTheme?: AppLayoutTheme;
  databaseId?: string | null;
  birthYear?: string;
  birthDate?: string;
  securityAnswer?: string;
  isSuspended?: boolean;
  suspendMessage?: string;
  allowInvoiceUpload?: boolean;
  allowSupervisorManagement?: boolean;
  createdAt?: string;
  isGuest?: boolean;
  parentManagerId?: number; // للمشرف: معرف مدير الحساب الذي يتبعه
  permissions?: SupervisorPermissions; // أذونات المشرف المحددة
}

export interface SupervisorPermissions {
  canAddDebts: boolean;           // إضافة ديون جديدة
  canAddPayments: boolean;        // تسجيل تسديدات الديون
  canEditDebtors: boolean;        // تعديل بيانات المدين
  canDeleteDebtors: boolean;      // حذف مدين أو حركة
  canManageInstallments: boolean; // إضافة وتسديد الأقساط
  canManageSuppliers: boolean;    // إضافة وتسديد الموردين
  canViewReports: boolean;        // الاطلاع على شاشة التقارير
  canUploadInvoices: boolean;     // إرفاق وتصوير الفواتير
  canExportData: boolean;         // تصدير PDF ومشاركة الكشوفات
}

export const DEFAULT_SUPERVISOR_PERMISSIONS: SupervisorPermissions = {
  canAddDebts: true,
  canAddPayments: true,
  canEditDebtors: true,
  canDeleteDebtors: true,
  canManageInstallments: true,
  canManageSuppliers: true,
  canViewReports: true,
  canUploadInvoices: true,
  canExportData: true,
};

export const FULL_SUPERVISOR_PERMISSIONS: SupervisorPermissions = {
  canAddDebts: true,
  canAddPayments: true,
  canEditDebtors: true,
  canDeleteDebtors: true,
  canManageInstallments: true,
  canManageSuppliers: true,
  canViewReports: true,
  canUploadInvoices: true,
  canExportData: true,
};

export const ADD_AND_PAY_ONLY_PERMISSIONS: SupervisorPermissions = {
  canAddDebts: true,
  canAddPayments: true,
  canEditDebtors: false,
  canDeleteDebtors: false,
  canManageInstallments: true,
  canManageSuppliers: true,
  canViewReports: true,
  canUploadInvoices: true,
  canExportData: true,
};

export const VIEW_ONLY_SUPERVISOR_PERMISSIONS: SupervisorPermissions = {
  canAddDebts: false,
  canAddPayments: false,
  canEditDebtors: false,
  canDeleteDebtors: false,
  canManageInstallments: false,
  canManageSuppliers: false,
  canViewReports: true,
  canUploadInvoices: false,
  canExportData: false,
};

export interface SupervisorUser {
  id: number;
  username: string;
  name: string;
  plainPassword?: string;
  password?: string;
  parentManagerId: number;
  branchName: string;
  isActive: boolean;
  permissions: SupervisorPermissions;
  createdAt: string;
}

export interface DebtorTransaction {
  id: string;
  debtorId: number;
  type: 'initial' | 'add' | 'pay';
  amount: number;
  balanceAfter: number;
  date: string;
  description?: string;
  notes?: string;
  paymentMethod?: 'cash' | 'electronic' | string;
  invoiceImage?: string;
  invoiceImages?: string[];
  performedBy?: string;
}

export interface Debtor {
  id: number;
  name: string;
  phone: string;
  amount: number;
  status: string;
  userId: number;
  createdAt?: string;
  lastDebtDate?: string;
  dueDate?: string; // موعد/تاريخ التسديد المتوقع المخصص للعميل
  notes?: string;
  history?: DebtorTransaction[];
  isDemo?: boolean;
  type?: 'debtor' | 'creditor';
  invoiceImage?: string;
  invoiceImages?: string[];
}

// ----------------------------------------------------
// نظام الأقساط المنفصل (Independent Installments System)
// ----------------------------------------------------

export interface InstallmentPayment {
  id: string;
  installmentId: number;
  amount: number;
  date: string; // YYYY-MM-DD or ISO
  remainingAfter: number;
  notes?: string;
  paymentMethod?: 'cash' | 'electronic' | string;
  invoiceImage?: string;
  invoiceImages?: string[];
  performedBy?: string;
}

export type InstallmentStatus = 'active' | 'due' | 'overdue' | 'completed';

export interface InstallmentRecord {
  id: number;
  name: string;              // 1. الاسم
  phone: string;             // 2. رقم الهاتف (11 رقم)
  item: string;              // 3. السلعة
  totalAmount: number;       // 4. مبلغ الأقساط (الإجمالي)
  downPayment: number;       // 5. الدفعة المقدمة
  remainingAmount: number;   // المتبقي = الإجمالي - المقدمة - مجموع التسديدات
  monthlyInstallmentAmount?: number; // القسط الشهري المتفق عليه (اختياري/افتراضي)
  registrationDate: string;  // 6. تاريخ التسجيل (YYYY-MM-DD)
  nextDueDate: string;       // تاريخ الاستحقاق القادم (بعد شهر من التسجيل أو من آخر دفعة)
  userId: number;            // معرف المستخدم / الفرع
  status: InstallmentStatus; // 'active' | 'due' | 'overdue' | 'completed'
  nationalId?: string;       // البطاقة الوطنية (اختياري - 12 رقم)
  address?: string;          // عنوان السكن وأقرب نقطة دالة
  guarantorEnabled?: boolean;// هل تم تفعيل بيانات الكفيل
  guarantorName?: string;    // اسم الكفيل
  guarantorAddress?: string; // عنوان الكفيل
  guarantorJob?: string;     // مهنة الكفيل
  guarantorRelation?: string;// صلة القرابة بينه وبين صاحب الأقساط
  guarantorPhone?: string;   // رقم هاتف الكفيل (11 رقم)
  notes?: string;
  payments?: InstallmentPayment[];
  createdAt?: string;
  isDemo?: boolean;
  invoiceImage?: string;
  invoiceImages?: string[];
}

export interface Manager {
  id: number;
  username: string;
  branch: string;
  phoneOrEmail?: string;
  isActive: boolean;
  isNewRegistration?: boolean;
  subscriptionType: SubscriptionType;
  subscriptionExpiresAt?: string | null;
  allowedModules?: ManagerModuleAccess;
  layoutTheme?: AppLayoutTheme;
  databaseId?: string | null;
  createdAt?: string;
  plainPassword?: string;
  securityAnswer?: string;
  birthDate?: string;
  isSuspended?: boolean;
  suspendMessage?: string;
  allowInvoiceUpload?: boolean;
  allowSupervisorManagement?: boolean;
}

export type TabType = 'home' | 'installments' | 'reports' | 'overdue' | 'settings' | 'managers' | 'supervisors';

export type FilterType = 'all' | 'debtors_only' | 'paid_only' | 'high_debt' | 'debts_on_me' | 'debts_on_me_paid';

export type InstallmentFilterType = 'all' | 'due_and_overdue' | 'due' | 'overdue' | 'active' | 'completed';

export type ViewMode = 'cards' | 'list';

export interface OutboxAction {
  id: string;
  userId: number;
  type:
    | 'ADD_DEBTOR'
    | 'UPDATE_DEBTOR'
    | 'TRANSACTION_DEBT'
    | 'DELETE_DEBTOR'
    | 'ADD_INSTALLMENT'
    | 'UPDATE_INSTALLMENT'
    | 'SETTLE_INSTALLMENT_PAYMENT'
    | 'DELETE_INSTALLMENT'
    | 'ADD_SUPPLIER'
    | 'UPDATE_SUPPLIER'
    | 'TRANSACTION_SUPPLIER'
    | 'DELETE_SUPPLIER';
  payload: any;
  timestamp: number;
}

export interface DebtStats {
  totalAdded: number;
  totalPaid: number;
}

export type Language = 'ar' | 'ku';
export type Currency = 'IQD';
export type NumberFormat = 'english' | 'arabic';
export type AppFontSize = 'small' | 'default' | 'medium' | 'large' | 'xlarge';

export interface AppSettings {
  enableDebtAlerts: boolean;
  alertDaysThreshold: number; // e.g. 1, 2, 7 days
  highDebtThreshold: number; // e.g. 25000 IQD
  numberFormat?: NumberFormat; // 'english' (123) or 'arabic' (١٢٣)
  language?: Language; // 'ar' | 'ku'
  currency?: Currency; // 'IQD'
  layoutTheme?: AppLayoutTheme; // 'classic' | 'fintech' | 'bento' | 'ledger' | 'minimal_luxury' | 'floating_glass' | 'compact_dense' | 'timeline' | 'retail_modern' | 'studio_analytics'
  fontSize?: AppFontSize; // 'small' | 'default' | 'medium' | 'large' | 'xlarge'
  enableUpdateNotice?: boolean;
  updateNoticeMessage?: string;
  updateNoticeTargetVersion?: string; // e.g. 'v3.5'
  updateNoticeTargetUser?: string; // 'all' or specific manager username/id
  globalEmergencyFreeze?: boolean; // إيقاف لحظي شامل لجميع المدراء
  globalEmergencyFreezeMessage?: string; // نص رسالة الإيقاف العام
  companyName?: string; // اسم الشركة أو المكتب أو المحل للتقارير
  companyPhone?: string; // رقم هاتف المحل أو الشركة
  companyAddress?: string; // عنوان المحل أو الشركة
  enableElectronicPayment?: boolean; // تفعيل أو إيقاف خيار الدفع الإلكتروني والماستر كارد
  mastercardNumber?: string; // رقم الماستر كارد أو بطاقة الدفع الإلكتروني
  electronicPaymentNotes?: string; // ملاحظات إضافية للدفع الإلكتروني
  sensitiveActionLockEnabled?: boolean; // قفل أمان العمليات الحساسة وتأكيد الحذف
  sensitiveActionPin?: string; // رمز الأمان أو كلمة السر المخصصة للتأكيد (افتراضياً 1)
  sensitiveActionProtectManagers?: boolean; // حماية حذف وتعديل المدراء
  sensitiveActionProtectDebtors?: boolean; // حماية حذف وتعديل سجلات المدينين
  sensitiveActionProtectReset?: boolean; // حماية تصفير البيانات
  requireCustomerPhone?: boolean; // إلزام إدخال رقم هاتف العميل لجميع الفروع (متزامن سحابياً)
  enablePortalLinkInWhatsApp?: boolean; // إظهار أو إخفاء رابط كشف الحساب عند إرسال رسائل الواتساب
}

export interface SupplierTransaction {
  id: string;
  supplierId?: number;
  type: 'debt' | 'pay' | 'initial' | 'add_debt' | 'pay_supplier';
  amount: number;
  balanceAfter?: number;
  date: string;
  notes?: string;
  description?: string;
  itemType?: string;
  performedBy?: string;
  managerName?: string;
  paymentMethod?: 'cash' | 'electronic' | string;
  invoiceImage?: string;
  invoiceImages?: string[];
}

export interface Supplier {
  id: number;
  name: string;
  companyName?: string;
  phone?: string;
  notes?: string;
  totalDebt?: number;
  totalPaid?: number;
  amount?: number;
  createdAt?: string;
  updatedAt?: string;
  history?: SupplierTransaction[];
  userId?: number;
  itemType?: string;
  status?: string;
  lastTransactionDate?: string;
  isDemo?: boolean;
  invoiceImage?: string;
  invoiceImages?: string[];
}

export interface SettledStorageStats {
  settledDebtors: number;
  settledCreditors: number;
  settledInstallments: number;
  settledSuppliers: number;
  totalSettled: number;
  crossDbTotal?: number;
  databasesCount?: number;
  isOverLimit: boolean;
  limitThreshold: number;
  breakdownByDb?: {
    dbId: string;
    dbName: string;
    settledDebtors: number;
    settledInstallments: number;
    settledSuppliers: number;
    total: number;
  }[];
}


