import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  AppSettings,
  Debtor,
  User,
  InstallmentRecord,
  Manager,
  SubscriptionType,
  ManagerModuleAccess,
  Supplier,
} from '../types';
import { formatNumber } from '../utils/formatters';
import { sanitizeSupplier } from '../services/turso';
import { useI18n } from '../i18n/index.tsx';
import { verifyIntegrityHash } from '../utils/sanitize';
import {
  executeExportBackup,
  buildFullBackupPayload,
  countBackupAttachedImages,
  shareBackupPdf,
  shareBackupTxt,
} from '../utils/backupExport';
import {
  initDriveAuth,
  googleSignIn,
  googleSignOut,
  getDriveAccessToken,
  getDriveUser,
  uploadBackupToGoogleDrive,
  listDriveBackups,
  downloadDriveBackupContent,
  deleteDriveBackupFile,
  GoogleDriveFile,
  GoogleDriveUser,
} from '../services/googleDrive';

interface BackupRestoreSectionProps {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  managers?: Manager[];
  settings: AppSettings;
  onImportBackup?: (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace',
    importedManagers?: Manager[],
    importedSuppliers?: Supplier[]
  ) => Promise<void>;
  onImportDebtors?: (importedDebtors: Debtor[], mode: 'merge' | 'replace') => Promise<void>;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
  flat?: boolean;
  allowInvoiceUpload?: boolean;
}

interface ImportPreview {
  fileName: string;
  exportDate?: string;
  sourceBranch?: string;
  managersCount: number;
  managersList: Manager[];
  debtorsCount: number;
  totalDebt: number;
  creditorsCount: number;
  totalCreditorDebt: number;
  debtorsList: Debtor[];
  installmentsCount: number;
  totalInstallmentsRemaining: number;
  installmentsList: InstallmentRecord[];
  suppliersCount: number;
  totalSuppliersDebt: number;
  suppliersList: Supplier[];
  integrityStatus?: 'verified' | 'tampered' | 'legacy';
  imagesCount: number;
}

export const BackupRestoreSection: React.FC<BackupRestoreSectionProps> = ({
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  managers = [],
  settings,
  onImportBackup,
  onImportDebtors,
  onShowToast,
  flat = false,
  allowInvoiceUpload,
}) => {
  const { t, numberFormat, getCurrencySymbol, dir } = useI18n();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Permission: check if current manager is allowed to attach / view invoice photos
  const canUploadInvoices = useMemo(() => {
    if (allowInvoiceUpload !== undefined) return allowInvoiceUpload;
    if (!currentUser) return true;
    if (currentUser.role === 'admin' || currentUser.username?.toLowerCase() === 'admin') return true;
    const val = currentUser.allowInvoiceUpload;
    if (val === false || val === 0 || (val as any) === '0' || (val as any) === 'false') {
      return false;
    }
    return true;
  }, [currentUser, allowInvoiceUpload]);

  // Tab state: 'drive' | 'local'
  const [activeTab, setActiveTab] = useState<'drive' | 'local'>('drive');

  // Local drag & drop / export state
  const [isDragging, setIsDragging] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingTxt, setIsExportingTxt] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [preview, setPreview] = useState<ImportPreview | null>(null);

  // Google Drive state
  const [googleUser, setGoogleUser] = useState<GoogleDriveUser | null>(() => getDriveUser());
  const [googleToken, setGoogleToken] = useState<string | null>(() => getDriveAccessToken());
  const [isConnectingDrive, setIsConnectingDrive] = useState(false);
  const [isUploadingToDrive, setIsUploadingToDrive] = useState(false);
  const [isLoadingDriveFiles, setIsLoadingDriveFiles] = useState(false);
  const [driveFiles, setDriveFiles] = useState<GoogleDriveFile[]>([]);
  const [selectedDriveFileForRestore, setSelectedDriveFileForRestore] = useState<string | null>(null);
  const driveFilesRef = useRef<HTMLDivElement>(null);

  // Destructive user confirmation for deleting a Google Drive file
  const [driveDeleteConfirmFile, setDriveDeleteConfirmFile] = useState<GoogleDriveFile | null>(null);
  const [isDeletingDriveFile, setIsDeletingDriveFile] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);

  const isAdmin = currentUser.role === 'admin';
  const branchDisplayName =
    currentUser.branch_name || currentUser.username || (isAdmin ? 'الإدارة العامة' : 'الفرع الحالي');
  const currSym = getCurrencySymbol();

  // Listen to Google Auth state
  useEffect(() => {
    const unsubscribe = initDriveAuth((user, token) => {
      setGoogleUser(user);
      setGoogleToken(token);
      if (token) {
        fetchDriveFiles(token);
      }
    });
    return () => unsubscribe();
  }, []);

  // Fetch drive files list
  const fetchDriveFiles = async (token?: string) => {
    const activeToken = token || googleToken;
    if (!activeToken) return;
    try {
      setIsLoadingDriveFiles(true);
      const files = await listDriveBackups(activeToken);
      setDriveFiles(files);
    } catch (err: any) {
      console.warn('Could not list drive backups:', err);
      if (err?.message?.includes('انتهت صلاحية')) {
        setGoogleToken(null);
        onShowToast('انتهت صلاحية جلسة Google Drive، يرجى تسجيل الدخول مجدداً لتجديدها', 'info');
      }
    } finally {
      setIsLoadingDriveFiles(false);
    }
  };

  // Google Sign In handler
  // Google Sign In handler
  const handleConnectGoogleDrive = async () => {
    try {
      setIsConnectingDrive(true);
      const result = await googleSignIn();
      if (!result) {
        // User closed the popup, cancel gracefully
        return;
      }
      setGoogleUser(result.user);
      setGoogleToken(result.accessToken);
      onShowToast(
        `تم ربط حساب Google Drive بنجاح: ${result.user.email || result.user.displayName}`,
        'success'
      );
      await fetchDriveFiles(result.accessToken);
    } catch (err: any) {
      if (
        err?.code === 'auth/popup-closed-by-user' ||
        err?.message?.includes('popup-closed-by-user') ||
        err?.code === 'auth/cancelled-popup-request'
      ) {
        // User cancelled without completing; do not show error
        return;
      }
      if (
        err?.code === 'auth/popup-blocked' ||
        err?.message?.includes('popup-blocked')
      ) {
        onShowToast('تم حظر النافذة المنبثقة من قبل المتصفح. يُرجى السماح بالنوافذ المنبثقة للمتابعة.', 'info');
        return;
      }
      console.error('Google Sign-in failed:', err);
      onShowToast(`تعذر الاتصال بـ Google Drive: ${err?.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setIsConnectingDrive(false);
    }
  };

  // Google Sign Out handler
  const handleDisconnectGoogleDrive = async () => {
    try {
      await googleSignOut();
      setGoogleUser(null);
      setGoogleToken(null);
      setDriveFiles([]);
      onShowToast('تم فصل حساب Google بنجاح', 'info');
    } catch (err: any) {
      console.error('Sign-out error:', err);
    }
  };

  // ----------------------------------------------------
  // 1. GOOGLE DRIVE BACKUP UPLOAD
  // ----------------------------------------------------
  const handleUploadBackupToDrive = async () => {
    let token = googleToken;
    if (!token) {
      try {
        const signinRes = await googleSignIn();
        if (!signinRes) return;
        token = signinRes.accessToken;
        setGoogleUser(signinRes.user);
        setGoogleToken(token);
      } catch (err: any) {
        if (
          err?.code === 'auth/popup-closed-by-user' ||
          err?.message?.includes('popup-closed-by-user')
        ) {
          return;
        }
        onShowToast(`يجب تسجيل الدخول بـ Google للمتابعة: ${err?.message || ''}`, 'error');
        return;
      }
    }

    try {
      setIsUploadingToDrive(true);
      const { payload, jsonStr, fileName, summary } = await buildFullBackupPayload({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });

      const description = `نسخة احتياطية شاملة (${summary.debtorsCount} مدينين • ${summary.creditorsCount} دائنين • ${summary.installmentsCount} أقساط • ${summary.suppliersCount} موردين${canUploadInvoices && summary.imagesCount ? ` • ${summary.imagesCount} صورة مرفقة` : ''})`;

      await uploadBackupToGoogleDrive(token, fileName, jsonStr, description);

      onShowToast(
        canUploadInvoices && summary.imagesCount
          ? `تم رفع النسخة الاحتياطية بنجاح إلى Google Drive (${summary.imagesCount} صورة مرفقة محفوظة)`
          : `تم رفع النسخة الاحتياطية بنجاح إلى Google Drive`,
        'success'
      );

      await fetchDriveFiles(token);
    } catch (err: any) {
      console.error('Drive upload failed:', err);
      if (err?.message?.includes('انتهت صلاحية')) {
        setGoogleToken(null);
      }
      onShowToast(`فشل رفع النسخة إلى Google Drive: ${err?.message || 'خطأ'}`, 'error');
    } finally {
      setIsUploadingToDrive(false);
    }
  };

  // ----------------------------------------------------
  // 2. GOOGLE DRIVE RESTORE & DOWNLOAD
  // ----------------------------------------------------
  const handleRestoreFromGoogleDrive = async (file: GoogleDriveFile) => {
    let token = googleToken;
    if (!token) {
      try {
        const signinRes = await googleSignIn();
        if (!signinRes) return;
        token = signinRes.accessToken;
        setGoogleUser(signinRes.user);
        setGoogleToken(token);
      } catch (err: any) {
        if (
          err?.code === 'auth/popup-closed-by-user' ||
          err?.message?.includes('popup-closed-by-user')
        ) {
          return;
        }
        onShowToast('يجب تسجيل الدخول بـ Google لاستعادة النسخة', 'error');
        return;
      }
    }

    try {
      setSelectedDriveFileForRestore(file.id);
      const parsedData = await downloadDriveBackupContent(token, file.id);
      await processParsedBackup(parsedData, file.name);
    } catch (err: any) {
      console.error('Drive download failed:', err);
      onShowToast(`تعذر تنزيل النسخة من Google Drive: ${err?.message || 'خطأ'}`, 'error');
    } finally {
      setSelectedDriveFileForRestore(null);
    }
  };

  // Delete Drive file with confirmed user action
  const handleConfirmDeleteDriveFile = async () => {
    if (!driveDeleteConfirmFile || !googleToken) return;
    try {
      setIsDeletingDriveFile(true);
      await deleteDriveBackupFile(googleToken, driveDeleteConfirmFile.id);
      onShowToast(`تم حذف النسخة "${driveDeleteConfirmFile.name}" من Google Drive بنجاح`, 'success');
      setDriveDeleteConfirmFile(null);
      await fetchDriveFiles(googleToken);
    } catch (err: any) {
      console.error('Delete drive file failed:', err);
      onShowToast(`فشل حذف الملف من Google Drive: ${err?.message || 'خطأ'}`, 'error');
    } finally {
      setIsDeletingDriveFile(false);
    }
  };

  // ----------------------------------------------------
  // 3. EXPORT LOCAL BACKUP (JSON / PDF / TXT)
  // ----------------------------------------------------
  const handleExportBackup = async () => {
    try {
      setIsExporting(true);
      const result = await executeExportBackup({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });

      if (result.success) {
        const imgNotice = canUploadInvoices && result.imagesCount ? ` • ${result.imagesCount} صورة مرفقة` : '';
        if (isAdmin) {
          onShowToast(
            `${t('common.success', 'تم التصدير بنجاح')} (${result.summary.managersCount} مدراء • ${result.summary.debtorsCount} مدينين • ${result.summary.creditorsCount} دائنين • ${result.summary.installmentsCount} أقساط • ${result.summary.suppliersCount} موردين${imgNotice})`,
            'success'
          );
        } else {
          onShowToast(
            `${t('common.success', 'تم تصدير النسخة الاحتياطية للفرع بنجاح')} (${result.summary.debtorsCount} مدينين • ${result.summary.creditorsCount} دائنين • ${result.summary.installmentsCount} أقساط • ${result.summary.suppliersCount} موردين${imgNotice})`,
            'success'
          );
        }
      }
    } catch (err: any) {
      console.error('Error exporting backup:', err);
      onShowToast(`${t('common.error', 'خطأ')}: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPdf = async () => {
    try {
      setIsExportingPdf(true);
      await shareBackupPdf({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      onShowToast('تم تصدير كشف الحسابات الرسمي (PDF) بنجاح', 'success');
    } catch (err: any) {
      onShowToast(`فشل تصدير PDF: ${err?.message || ''}`, 'error');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleExportTxt = async () => {
    try {
      setIsExportingTxt(true);
      await shareBackupTxt({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      onShowToast('تم تصدير كشف الحسابات النصي بنجاح', 'success');
    } catch (err: any) {
      onShowToast(`فشل تصدير التقرير النصي: ${err?.message || ''}`, 'error');
    } finally {
      setIsExportingTxt(false);
    }
  };

  // ----------------------------------------------------
  // 4. PARSE & PROCESS BACKUP (LOCAL OR DRIVE)
  // ----------------------------------------------------
  const processParsedBackup = async (parsed: any, fileName: string) => {
    let rawDebtorsList: any[] = [];
    let rawInstallmentsList: any[] = [];
    let rawManagersList: any[] = [];
    let rawSuppliersList: any[] = [];
    let exportDate: string | undefined;
    let sourceBranch: string | undefined;

    if (Array.isArray(parsed)) {
      rawDebtorsList = parsed;
    } else if (parsed && typeof parsed === 'object') {
      if (Array.isArray(parsed.debtors)) {
        rawDebtorsList = parsed.debtors;
      }
      if (Array.isArray(parsed.installments)) {
        rawInstallmentsList = parsed.installments;
      }
      if (Array.isArray(parsed.managers)) {
        rawManagersList = parsed.managers;
      }
      if (Array.isArray(parsed.suppliers)) {
        rawSuppliersList = parsed.suppliers;
      }
      exportDate = parsed.exportDateFormatted || parsed.exportTimestamp;
      sourceBranch = parsed.branchName;
    } else {
      throw new Error('صيغة ملف النسخة الاحتياطية غير مدعومة');
    }

    if (
      rawDebtorsList.length === 0 &&
      rawInstallmentsList.length === 0 &&
      rawManagersList.length === 0 &&
      rawSuppliersList.length === 0
    ) {
      throw new Error('الملف لا يحتوي على أي سجلات للمدينين، الأقساط، الموردين أو المدراء');
    }

    const cleanedManagers: Manager[] = rawManagersList.map((item, index) => ({
      id: Number(item.id) || Date.now() + 5000 + index,
      username: String(item.username || '').trim() || `manager_${index + 1}`,
      branch: String(item.branch || item.branch_name || '').trim() || `فرع ${index + 1}`,
      isActive: item.isActive !== undefined ? Boolean(item.isActive) : true,
      subscriptionType: (item.subscriptionType as SubscriptionType) || 'permanent',
      subscriptionExpiresAt: item.subscriptionExpiresAt || null,
      allowedModules: (item.allowedModules as ManagerModuleAccess) || 'both',
      plainPassword: String(item.plainPassword || item.password || '').trim(),
      createdAt: item.createdAt || new Date().toISOString(),
    }));

    const cleanedDebtors: Debtor[] = rawDebtorsList.map((item, index) => {
      const name = String(item.name || '').trim();
      if (!name) {
        throw new Error(`اسم المدين غير صالح في السجل #${index + 1}`);
      }
      const amount = Math.max(0, Number(item.amount) || 0);
      const phone = String(item.phone || '').trim();
      const status = String(item.status || (amount === 0 ? 'cleared' : 'active'));
      const debtType: 'debtor' | 'creditor' = item.type === 'creditor' ? 'creditor' : 'debtor';

      const historyCleaned = Array.isArray(item.history)
        ? item.history.map((h: any, hIdx: number) => ({
            id: String(h?.id || `tx_${index}_${hIdx}_${Date.now()}`),
            debtorId: Number(item.id) || Date.now() + index,
            type: h?.type || 'add',
            amount: Number(h?.amount) || 0,
            balanceAfter: Number(h?.balanceAfter) || 0,
            date: h?.date || new Date().toISOString(),
            description: h?.description || '',
            notes: h?.notes || '',
            paymentMethod: h?.paymentMethod || 'cash',
            invoiceImage: h?.invoiceImage || undefined,
          }))
        : [];

      return {
        id: Number(item.id) || Date.now() + index,
        name,
        phone,
        amount,
        status,
        userId: currentUser.id,
        createdAt: item.createdAt || new Date().toISOString(),
        lastDebtDate: item.lastDebtDate,
        history: historyCleaned,
        type: debtType,
        invoiceImage: item.invoiceImage || undefined,
      };
    });

    const cleanedInstallments: InstallmentRecord[] = rawInstallmentsList.map((item, index) => {
      const name = String(item.name || '').trim();
      const phone = String(item.phone || '').trim();
      const itm = String(item.item || 'Item').trim();
      const totalAmount = Math.max(0, Number(item.totalAmount) || 0);
      const downPayment = Math.max(0, Number(item.downPayment) || 0);
      const remainingAmount = Number.isFinite(Number(item.remainingAmount))
        ? Number(item.remainingAmount)
        : Math.max(0, totalAmount - downPayment);
      const registrationDate = item.registrationDate || new Date().toISOString().slice(0, 10);
      const nextDueDate = item.nextDueDate || registrationDate;
      const status = item.status || (remainingAmount <= 0 ? 'completed' : 'active');

      const paymentsCleaned = Array.isArray(item.payments)
        ? item.payments.map((p: any, pIdx: number) => ({
            id: String(p?.id || `pay_${index}_${pIdx}_${Date.now()}`),
            installmentId: Number(item.id) || Date.now() + 1000 + index,
            amount: Number(p?.amount) || 0,
            date: p?.date || new Date().toISOString().slice(0, 10),
            remainingAfter: Number(p?.remainingAfter) || 0,
            notes: p?.notes || '',
            paymentMethod: p?.paymentMethod || 'cash',
            invoiceImage: p?.invoiceImage || undefined,
          }))
        : [];

      return {
        id: Number(item.id) || Date.now() + 1000 + index,
        name: name || `قسط ${index + 1}`,
        phone,
        item: itm,
        totalAmount,
        downPayment,
        remainingAmount,
        monthlyInstallmentAmount: item.monthlyInstallmentAmount
          ? Number(item.monthlyInstallmentAmount)
          : undefined,
        registrationDate,
        nextDueDate,
        userId: currentUser.id,
        status,
        notes: item.notes || '',
        payments: paymentsCleaned,
        invoiceImage: item.invoiceImage || undefined,
        createdAt: item.createdAt || new Date().toISOString(),
      };
    });

    const cleanedSuppliers: Supplier[] = rawSuppliersList.map((item, index) => {
      const name = String(item.name || '').trim();
      if (!name) {
        throw new Error(`اسم المورد غير صالح في السجل #${index + 1}`);
      }
      return sanitizeSupplier({
        id: Number(item.id) || Date.now() + 3000 + index,
        name,
        companyName: item.companyName ? String(item.companyName).trim() : '',
        phone: item.phone ? String(item.phone).trim() : '',
        notes: item.notes ? String(item.notes).trim() : '',
        itemType: item.itemType ? String(item.itemType).trim() : '',
        amount: Math.max(0, Number(item.amount) || Number(item.totalDebt) || 0),
        totalDebt: Math.max(0, Number(item.totalDebt) || Number(item.amount) || 0),
        totalPaid: Math.max(0, Number(item.totalPaid) || 0),
        status: item.status || 'active',
        userId: currentUser.id,
        createdAt: item.createdAt || new Date().toISOString(),
        lastTransactionDate: item.lastTransactionDate,
        history: Array.isArray(item.history) ? item.history : [],
        invoiceImage: item.invoiceImage || undefined,
      });
    });

    const myDebtorsList = cleanedDebtors.filter((d) => d.type !== 'creditor');
    const myCreditorsList = cleanedDebtors.filter((d) => d.type === 'creditor');

    const totalDebt = myDebtorsList.reduce((sum, d) => sum + d.amount, 0);
    const totalCreditorDebt = myCreditorsList.reduce((sum, d) => sum + d.amount, 0);
    const totalInstallmentsRemaining = cleanedInstallments.reduce(
      (sum, i) => sum + (i.remainingAmount || 0),
      0
    );
    const totalSuppliersDebt = cleanedSuppliers.reduce((sum, s) => sum + (s.amount || 0), 0);

    const imagesCount = countBackupAttachedImages(parsed);

    let integrityStatus: 'verified' | 'tampered' | 'legacy' = 'legacy';
    if (parsed && parsed.integrityChecksum) {
      try {
        const isValid = await verifyIntegrityHash(
          {
            debtorsCount: rawDebtorsList.length,
            installmentsCount: rawInstallmentsList.length,
            suppliersCount: rawSuppliersList.length,
            managersCount: rawManagersList.length,
            totalDebt,
            totalCreditorDebt,
            exportTimestamp: parsed.exportTimestamp || '',
          },
          parsed.integrityChecksum
        );
        integrityStatus = isValid ? 'verified' : 'tampered';
      } catch {
        integrityStatus = 'legacy';
      }
    }

    setPreview({
      fileName,
      exportDate,
      sourceBranch,
      managersCount: cleanedManagers.length,
      managersList: cleanedManagers,
      debtorsCount: myDebtorsList.length,
      totalDebt,
      creditorsCount: myCreditorsList.length,
      totalCreditorDebt,
      debtorsList: cleanedDebtors,
      installmentsCount: cleanedInstallments.length,
      totalInstallmentsRemaining,
      installmentsList: cleanedInstallments,
      suppliersCount: cleanedSuppliers.length,
      totalSuppliersDebt,
      suppliersList: cleanedSuppliers,
      integrityStatus,
      imagesCount,
    });

    const imgPreviewNotice = canUploadInvoices && imagesCount ? ` (${imagesCount} صورة مرفقة)` : '';
    onShowToast(
      `معاينة النسخة: ${cleanedManagers.length} مدراء • ${myDebtorsList.length} مدينين • ${myCreditorsList.length} دائنين • ${cleanedInstallments.length} أقساط • ${cleanedSuppliers.length} موردين${imgPreviewNotice}`,
      'info'
    );
  };

  const processSelectedFile = (file: File) => {
    if (!file.name.endsWith('.json') && file.type !== 'application/json') {
      onShowToast(t('backup.invalidJson', 'يرجى اختيار ملف نسخة احتياطية بصيغة JSON (.json)'), 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          throw new Error('الملف فارغ');
        }
        const parsed = JSON.parse(text);
        await processParsedBackup(parsed, file.name);
      } catch (parseErr: any) {
        console.error('JSON Parse error:', parseErr);
        onShowToast(`خطأ في قراءة الملف: ${parseErr.message || ''}`, 'error');
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      onShowToast('حدث خطأ أثناء قراءة الملف', 'error');
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.readAsText(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  // ----------------------------------------------------
  // 5. CONFIRM & EXECUTE IMPORT
  // ----------------------------------------------------
  const handleConfirmImport = async () => {
    if (!preview) return;
    try {
      setIsImporting(true);
      if (onImportBackup) {
        await onImportBackup(
          preview.debtorsList,
          preview.installmentsList,
          importMode,
          preview.managersList,
          preview.suppliersList
        );
      } else if (onImportDebtors) {
        await onImportDebtors(preview.debtorsList, importMode);
      }
      setPreview(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      console.error('Import execution error:', err);
    } finally {
      setIsImporting(false);
    }
  };

  const handleCancelImport = () => {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const myDebtors = debtors.filter((d) => !d.isDemo && d.type !== 'creditor');
  const myCreditors = debtors.filter((d) => !d.isDemo && d.type === 'creditor');

  const currentTotalDebt = myDebtors.reduce((sum, d) => sum + (d.amount || 0), 0);
  const currentTotalCreditorDebt = myCreditors.reduce((sum, d) => sum + (d.amount || 0), 0);
  const currentTotalInstallmentsRemaining = installments.reduce(
    (sum, i) => sum + (Number(i.remainingAmount) || 0),
    0
  );
  const currentTotalSuppliersDebt = suppliers.reduce(
    (sum, s) => sum + (Number(s.amount) || Number(s.totalDebt) || 0),
    0
  );

  // Total current attached images count
  const currentTotalImages = countBackupAttachedImages({
    debtors,
    installments,
    suppliers,
  });

  return (
    <div
      className={
        flat
          ? 'space-y-4'
          : 'bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4'
      }
      dir={dir}
    >
      {/* Section Header */}
      {!flat && (
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 text-white flex items-center justify-center text-base font-bold shadow-md shadow-indigo-100">
              <i className="fa-brands fa-google-drive"></i>
            </div>
            <div>
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <span>
                  {isAdmin
                    ? 'النسخ الاحتياطي والاستيراد الشامل (Google Drive والمحلي)'
                    : `النسخ الاحتياطي السحابي والمحلي (${branchDisplayName})`}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    isAdmin
                      ? 'bg-purple-50 text-purple-700 border-purple-100'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-100'
                  }`}
                >
                  {isAdmin ? 'الإدارة العامة' : 'الفرع'}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {canUploadInvoices
                  ? 'حفظ واسترجاع كافة سجلات المدينين والدائنين والأقساط والموردين مع الصور المرفقة للفواتير'
                  : 'حفظ واسترجاع كافة سجلات المدينين والدائنين والأقساط والموردين'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Overview Data Metrics */}
      <div className={`grid grid-cols-2 ${canUploadInvoices ? 'sm:grid-cols-5' : 'sm:grid-cols-4'} gap-2 bg-slate-50 border border-slate-200/60 rounded-2xl p-3 text-xs`}>
        <div className="space-y-1 px-1">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">المدينون (لي):</span>
            <span className="font-bold font-mono text-slate-900 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {formatNumber(myDebtors.length, numberFormat)}
            </span>
          </div>
          <div className="text-[11px] font-bold text-blue-700 truncate">
            {formatNumber(currentTotalDebt, numberFormat)} {currSym}
          </div>
        </div>

        <div className="space-y-1 px-1 border-s border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">الدائنون (عليّ):</span>
            <span className="font-bold font-mono text-rose-900 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {formatNumber(myCreditors.length, numberFormat)}
            </span>
          </div>
          <div className="text-[11px] font-bold text-rose-700 truncate">
            {formatNumber(currentTotalCreditorDebt, numberFormat)} {currSym}
          </div>
        </div>

        <div className="space-y-1 px-1 border-s border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">الأقساط:</span>
            <span className="font-bold font-mono text-emerald-900 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {formatNumber(installments.length, numberFormat)}
            </span>
          </div>
          <div className="text-[11px] font-bold text-emerald-700 truncate">
            {formatNumber(currentTotalInstallmentsRemaining, numberFormat)} {currSym}
          </div>
        </div>

        <div className="space-y-1 px-1 border-s border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">الموردون:</span>
            <span className="font-bold font-mono text-amber-900 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {formatNumber(suppliers.length, numberFormat)}
            </span>
          </div>
          <div className="text-[11px] font-bold text-amber-700 truncate">
            {formatNumber(currentTotalSuppliersDebt, numberFormat)} {currSym}
          </div>
        </div>

        {canUploadInvoices && (
          <div className="space-y-1 px-1 col-span-2 sm:col-span-1 border-t sm:border-t-0 sm:border-s border-slate-200 pt-1.5 sm:pt-0">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-1">
                <i className="fa-solid fa-receipt text-indigo-500"></i>
                <span>الصور المرفقة:</span>
              </span>
              <span className="font-bold font-mono text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200">
                {currentTotalImages}
              </span>
            </div>
            <div className="text-[10px] text-emerald-700 font-bold truncate">
              محفوظة بجودة عالية
            </div>
          </div>
        )}
      </div>

      {/* Modern Tabs Switcher */}
      <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-2xl">
        <button
          type="button"
          onClick={() => setActiveTab('drive')}
          className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'drive'
              ? 'bg-white text-indigo-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>نسخ واستعادة عبر Google Drive</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('local')}
          className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'local'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <i className="fa-solid fa-file-arrow-up text-blue-600 text-xs"></i>
          <span>نسخ محلي (ملف JSON / تقارير)</span>
        </button>
      </div>

      {/* ------------------------------------------------------------------ */}
      {/* TAB 1: GOOGLE DRIVE BACKUP & RESTORE */}
      {/* ------------------------------------------------------------------ */}
      {activeTab === 'drive' && (
        <div className="space-y-4">
          {/* Header matching user's design reference */}
          <div className="flex items-start justify-between gap-4 pt-1">
            <div className="space-y-1">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-snug">
                النسخ الاحتياطي عبر Google Drive
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 font-medium">
                حفظ واستعادة بياناتك
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-100/90 text-blue-500 flex items-center justify-center text-xl shrink-0 shadow-2xs">
              <i className="fa-solid fa-cloud"></i>
            </div>
          </div>

          <hr className="border-slate-100 my-1" />

          {/* Google Account Section Title */}
          <div className="text-sm font-bold text-slate-900">
            حساب Google
          </div>

          {/* Card 1: ربط حساب Google */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 space-y-3.5 shadow-2xs">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                  ربط حساب Google
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {googleUser ? 'الحساب متصل بنجاح وجاهز للمزامنة' : 'اربط حسابك للبدء'}
                </p>
              </div>

              {/* Status Circle Icon */}
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] shrink-0 font-bold transition-all ${
                  googleUser
                    ? 'bg-emerald-500 text-white shadow-xs'
                    : 'border-2 border-emerald-500 text-emerald-500'
                }`}
              >
                <i className="fa-solid fa-check"></i>
              </div>
            </div>

            {!googleUser || !googleToken ? (
              <button
                type="button"
                onClick={handleConnectGoogleDrive}
                disabled={isConnectingDrive}
                className="w-full bg-white hover:bg-slate-50 active:scale-[0.99] text-slate-800 border border-slate-300 rounded-2xl py-3 px-4 font-bold text-xs sm:text-sm shadow-2xs hover:shadow-xs transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
              >
                {isConnectingDrive ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin text-blue-600"></i>
                    <span>جاري الاتصال بـ Google...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                    <span>تسجيل الدخول باستخدام Google</span>
                  </>
                )}
              </button>
            ) : (
              <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5 min-w-0">
                  {googleUser.photoURL ? (
                    <img
                      src={googleUser.photoURL}
                      alt={googleUser.displayName || 'Google'}
                      className="w-8 h-8 rounded-full border border-emerald-300"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs">
                      {(googleUser.displayName || googleUser.email || 'G')[0].toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 flex items-center gap-1.5 truncate">
                      <span>{googleUser.displayName || 'حساب Google'}</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span className="text-[10px] text-emerald-700 font-normal">متصل</span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono truncate">
                      {googleUser.email}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => fetchDriveFiles()}
                    disabled={isLoadingDriveFiles}
                    title="تحديث قائمة النسخ من درايف"
                    className="w-8 h-8 rounded-xl bg-white hover:bg-slate-100 text-slate-600 flex items-center justify-center border border-slate-200 cursor-pointer transition-colors"
                  >
                    <i className={`fa-solid fa-arrows-rotate text-xs ${isLoadingDriveFiles ? 'fa-spin' : ''}`}></i>
                  </button>
                  <button
                    type="button"
                    onClick={handleDisconnectGoogleDrive}
                    className="text-xs text-rose-600 hover:text-rose-700 hover:underline px-2 py-1 font-bold cursor-pointer"
                  >
                    فصل الحساب
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Card 2: النسخ الاحتياطي (Light modern card without navy blue - بدون لون الكحلي كما طلب المستخدم) */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 space-y-3.5 shadow-2xs">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                  النسخ الاحتياطي
                </h3>
                <i className="fa-solid fa-shield-halved text-blue-600 text-sm"></i>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-1">
                احفظ نسخة من بياناتك على Google Drive لاستعادتها عند الحاجة.
              </p>
            </div>

            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={handleUploadBackupToDrive}
                disabled={isUploadingToDrive}
                className="w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white py-3.5 px-4 rounded-2xl font-bold text-xs sm:text-sm shadow-xs hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isUploadingToDrive ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin text-sm"></i>
                    <span>جاري حفظ ورفع النسخة إلى Google Drive...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-brands fa-google-drive text-sm"></i>
                    <span>حفظ نسخة على Google Drive</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!googleToken) {
                    handleConnectGoogleDrive();
                  } else {
                    fetchDriveFiles();
                    driveFilesRef.current?.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="w-full bg-slate-50 hover:bg-slate-100 active:scale-[0.99] text-slate-800 border border-slate-300 rounded-2xl py-3 px-4 font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <i className="fa-solid fa-clock-rotate-left text-xs text-slate-500"></i>
                <span>استعادة نسخة من Google Drive</span>
              </button>
            </div>
          </div>

          {/* List of Backups on Google Drive */}
          <div ref={driveFilesRef} className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200/70 pb-2.5">
              <div className="flex items-center gap-2">
                <i className="fa-brands fa-google-drive text-blue-600 text-sm"></i>
                <span className="font-bold text-xs text-slate-900">
                  النسخ الاحتياطية المتوفرة على Google Drive
                </span>
                <span className="text-[10px] font-mono font-bold bg-white text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
                  {driveFiles.length} نسخة
                </span>
              </div>

              {googleToken && (
                <button
                  type="button"
                  onClick={() => fetchDriveFiles()}
                  disabled={isLoadingDriveFiles}
                  className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-bold cursor-pointer"
                >
                  <i className={`fa-solid fa-arrows-rotate text-[11px] ${isLoadingDriveFiles ? 'fa-spin' : ''}`}></i>
                  <span>تحديث</span>
                </button>
              )}
            </div>

            {isLoadingDriveFiles && driveFiles.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">
                <i className="fa-solid fa-spinner fa-spin text-lg text-blue-600 mb-2 block"></i>
                <span>جاري البحث عن النسخ الاحتياطية في Google Drive...</span>
              </div>
            ) : !googleToken ? (
              <div className="py-6 text-center text-slate-500 text-xs space-y-2">
                <i className="fa-solid fa-lock text-slate-400 text-lg"></i>
                <p>قم بتسجيل الدخول بـ Google لاستعراض النسخ المحفوظة على درايف</p>
              </div>
            ) : driveFiles.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs space-y-1">
                <i className="fa-regular fa-folder-open text-slate-400 text-xl mb-1 block"></i>
                <p className="font-bold text-slate-700">لا توجد نسخ احتياطية محفوظة على Google Drive حتى الآن</p>
                <p className="text-[11px] text-slate-400">
                  {canUploadInvoices
                    ? 'انقر على الزر الأزرق بالأعلى لرفع أول نسخة احتياطية شاملة لكافة الأنظمة والصور'
                    : 'انقر على الزر الأزرق بالأعلى لرفع أول نسخة احتياطية شاملة لكافة السجلات والأنظمة'}
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto no-scrollbar pr-0.5">
                {driveFiles.map((file) => {
                  const isCurrentRestoring = selectedDriveFileForRestore === file.id;
                  const dateStr = file.createdTime
                    ? new Date(file.createdTime).toLocaleString('ar-IQ', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : 'تاريخ غير محدد';

                  const sizeKb = file.size ? Math.round(Number(file.size) / 1024) : 0;
                  const sizeDisplay =
                    sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)} ميغابايت` : `${sizeKb} كيلوبايت`;

                  return (
                    <div
                      key={file.id}
                      className="bg-white border border-slate-200/90 hover:border-blue-300 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors shadow-2xs"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <i className="fa-solid fa-file-code text-blue-600 text-xs"></i>
                          <span className="font-bold text-xs text-slate-900 truncate dir-ltr text-right">
                            {file.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-slate-500">
                          <span className="flex items-center gap-1">
                            <i className="fa-regular fa-calendar text-[10px]"></i>
                            <span>{dateStr}</span>
                          </span>
                          {file.size && (
                            <span className="font-mono text-slate-600 bg-slate-100 px-1.5 py-0.2 rounded text-[10px]">
                              {sizeDisplay}
                            </span>
                          )}
                          {canUploadInvoices && (
                            <span className="text-emerald-700 font-bold text-[10.5px]">
                              ✅ تشمل الصور
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* Restore button */}
                        <button
                          type="button"
                          onClick={() => handleRestoreFromGoogleDrive(file)}
                          disabled={isCurrentRestoring}
                          className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white py-1.5 px-3 rounded-lg font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                        >
                          {isCurrentRestoring ? (
                            <>
                              <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                              <span>جاري التنزيل...</span>
                            </>
                          ) : (
                            <>
                              <i className="fa-solid fa-rotate-left text-xs"></i>
                              <span>استعادة النسخة</span>
                            </>
                          )}
                        </button>

                        {/* Delete from Drive button (triggers Workspace-mandated confirmation dialog) */}
                        <button
                          type="button"
                          onClick={() => setDriveDeleteConfirmFile(file)}
                          title="حذف من Google Drive"
                          className="w-8 h-8 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 flex items-center justify-center cursor-pointer transition-colors"
                        >
                          <i className="fa-solid fa-trash-can text-xs"></i>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Privacy & Trust Badge */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1 px-1 text-[11px] text-slate-500">
            <div className="flex items-center gap-1.5">
              <i className="fa-solid fa-shield-halved text-emerald-600"></i>
              <span>تطبيق دفتر ديون والأقساط • حماية وتشفير Google Drive (صلاحية drive.file الآمنة)</span>
            </div>
            <button
              type="button"
              onClick={() => setIsPrivacyModalOpen(true)}
              className="text-blue-600 hover:text-blue-800 underline font-medium cursor-pointer"
            >
              سياسة الخصوصية وأمان البيانات
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TAB 2: LOCAL EXPORT & IMPORT (JSON, PDF, TXT) */}
      {/* ------------------------------------------------------------------ */}
      {activeTab === 'local' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Card 1: Local JSON Export */}
            <div className="bg-slate-50/70 border border-slate-200/70 rounded-2xl p-4 flex flex-col justify-between hover:border-blue-200 transition-all">
              <div>
                <div className="flex items-center gap-2 font-bold text-xs text-slate-800 mb-1">
                  <i className="fa-solid fa-file-code text-blue-600"></i>
                  <span>
                    {isAdmin ? 'تصدير ملف نسخة احتياطية (JSON)' : 'نسخة احتياطية للفرع (JSON)'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {canUploadInvoices
                    ? 'تنزيل ملف JSON شامل مشفر يحتوي على كافة المدينين والأقساط والموردين والصور المرفقة للاسترجاع في أي وقت بدون إنترنت.'
                    : 'تنزيل ملف JSON شامل مشفر يحتوي على كافة المدينين والأقساط والموردين للاسترجاع في أي وقت بدون إنترنت.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleExportBackup}
                disabled={isExporting}
                className="mt-3.5 w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isExporting ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i>
                    <span>جاري التصدير...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-download text-xs"></i>
                    <span>تنزيل ملف النسخة (.json)</span>
                  </>
                )}
              </button>
            </div>

            {/* Card 2: Local JSON Import */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-4 flex flex-col justify-between transition-all ${
                isDragging
                  ? 'border-purple-500 bg-purple-50/50'
                  : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 font-bold text-xs text-slate-800 mb-1">
                  <i className="fa-solid fa-cloud-arrow-up text-purple-600"></i>
                  <span>استيراد واسترجاع ملف محلي (.json)</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {canUploadInvoices
                    ? 'اسحب وأفلت ملف النسخة الاحتياطية (.json) هنا أو انقر لاختياره لاسترجاع ديون وأقساط وحسابات الموردين والصور المرفقة.'
                    : 'اسحب وأفلت ملف النسخة الاحتياطية (.json) هنا أو انقر لاختياره لاسترجاع ديون وأقساط وحسابات الموردين.'}
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileInputChange}
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="mt-3.5 w-full bg-white hover:bg-slate-100 active:scale-[0.99] text-slate-700 border border-slate-200/80 py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <i className="fa-solid fa-folder-open text-xs text-slate-500"></i>
                <span>اختيار ملف النسخة من الجهاز</span>
              </button>
            </div>
          </div>

          {/* Reports Export (PDF & TXT) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={handleExportPdf}
              disabled={isExportingPdf}
              className="bg-white hover:bg-slate-50 active:scale-[0.99] border border-slate-200 rounded-xl p-3 flex items-center gap-3 cursor-pointer transition-all shadow-2xs text-right"
            >
              <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-sm shrink-0">
                <i className="fa-solid fa-file-pdf"></i>
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-slate-900">
                  تصدير كشف حسابات عام (PDF)
                </div>
                <div className="text-[10.5px] text-slate-500 truncate">
                  كشف رسمي للطباعة أو الإرسال بصيغة PDF
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={handleExportTxt}
              disabled={isExportingTxt}
              className="bg-white hover:bg-slate-50 active:scale-[0.99] border border-slate-200 rounded-xl p-3 flex items-center gap-3 cursor-pointer transition-all shadow-2xs text-right"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-sm shrink-0">
                <i className="fa-solid fa-file-lines"></i>
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-slate-900">
                  تصدير تقرير نصي ومشاركة (TXT)
                </div>
                <div className="text-[10.5px] text-slate-500 truncate">
                  تقرير نصي مرتب متوافق مع الملاحظات والواتساب
                </div>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* IMPORT PREVIEW & CONFIRMATION DIALOG (FOR LOCAL OR DRIVE RESTORE) */}
      {/* ------------------------------------------------------------------ */}
      {preview && (
        <div className="mt-4 p-4 rounded-2xl bg-amber-50/70 border border-amber-200 animate-in fade-in zoom-in-95 duration-150 space-y-3.5">
          <div className="flex items-center justify-between border-b border-amber-200/80 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center text-xs shadow-xs">
                <i className="fa-solid fa-file-invoice"></i>
              </div>
              <div>
                <div className="font-extrabold text-xs text-slate-900">
                  معاينة محتويات النسخة قبل الاسترجاع
                </div>
                <div className="text-[10.5px] text-slate-500 truncate max-w-[280px] font-mono">
                  {preview.fileName}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCancelImport}
              className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer transition-colors"
              title="إلغاء"
            >
              <i className="fa-solid fa-xmark text-sm"></i>
            </button>
          </div>

          {/* Cryptographic Integrity Status */}
          {preview.integrityStatus === 'verified' && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-xs text-emerald-900 flex items-center gap-2">
              <i className="fa-solid fa-shield-check text-emerald-600 text-sm shrink-0"></i>
              <span className="font-bold">
                {canUploadInvoices
                  ? 'تم التحقق من التوقيع الرقمي بنجاح: البيانات والصور مطابقة للأصل 100% ولم يتم التلاعب بها.'
                  : 'تم التحقق من التوقيع الرقمي بنجاح: البيانات مطابقة للأصل 100% ولم يتم التلاعب بها.'}
              </span>
            </div>
          )}
          {preview.integrityStatus === 'tampered' && (
            <div className="bg-rose-50 border border-rose-300 rounded-xl p-2.5 text-xs text-rose-900 flex items-center gap-2">
              <i className="fa-solid fa-triangle-exclamation text-rose-600 text-sm shrink-0"></i>
              <span className="font-bold">
                تنبيه أمني: التوقيع الرقمي للملف غير متطابق؛ قد يكون الملف عُدّل يدوياً خارج النظام.
              </span>
            </div>
          )}

          {/* Attached Images Confirmation Banner */}
          {canUploadInvoices && (
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200/90 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs">
                  <i className="fa-solid fa-receipt"></i>
                </div>
                <div>
                  <span className="font-bold text-indigo-950 block">
                    الصور المرفقة (فواتير، وصولات، ومستندات):
                  </span>
                  <span className="text-[11px] text-indigo-700">
                    {preview.imagesCount > 0
                      ? `تحتوي هذه النسخة على ${preview.imagesCount} صورة مرفقة سيتم استعادتها وربطها بسجلاتها بالكامل.`
                      : 'لا توجد صور مرفقة في هذه النسخة.'}
                  </span>
                </div>
              </div>
              <span className="font-extrabold font-mono text-sm text-indigo-800 bg-white px-2.5 py-1 rounded-lg border border-indigo-200">
                {preview.imagesCount} صورة
              </span>
            </div>
          )}

          {/* Backup Summary Badges */}
          <div className={`grid grid-cols-2 ${isAdmin ? 'sm:grid-cols-4' : 'sm:grid-cols-3'} gap-2 text-xs`}>
            {isAdmin && (
              <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
                <span className="text-[10.5px] text-slate-400 block mb-0.5">المدراء والفروع</span>
                <span className="font-extrabold font-mono text-sm text-purple-800">
                  {preview.managersCount}
                </span>
              </div>
            )}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">المدينين (لي)</span>
              <span className="font-extrabold font-mono text-sm text-slate-800">
                {preview.debtorsCount}{' '}
                <span className="text-[10px] text-blue-700">
                  ({formatNumber(preview.totalDebt, numberFormat)} {currSym})
                </span>
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">الدائنين (عليّ)</span>
              <span className="font-extrabold font-mono text-sm text-rose-700">
                {preview.creditorsCount}{' '}
                <span className="text-[10px] text-rose-600">
                  ({formatNumber(preview.totalCreditorDebt, numberFormat)} {currSym})
                </span>
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">عقود الأقساط</span>
              <span className="font-extrabold font-mono text-sm text-emerald-800">
                {preview.installmentsCount}{' '}
                <span className="text-[10px] text-emerald-700">
                  ({formatNumber(preview.totalInstallmentsRemaining, numberFormat)} {currSym})
                </span>
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">الموردين والشركات</span>
              <span className="font-extrabold font-mono text-sm text-amber-800">
                {preview.suppliersCount}{' '}
                <span className="text-[10px] text-amber-700">
                  ({formatNumber(preview.totalSuppliersDebt, numberFormat)} {currSym})
                </span>
              </span>
            </div>
          </div>

          {/* Import Mode Selector */}
          <div className="bg-white p-3 rounded-xl border border-amber-200/60 space-y-2">
            <span className="text-[11px] font-bold text-slate-700 block">طريقة التطبيق:</span>
            <div className="space-y-1.5">
              <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                <input
                  type="radio"
                  name="importMode"
                  value="merge"
                  checked={importMode === 'merge'}
                  onChange={() => setImportMode('merge')}
                  className="text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-bold text-slate-800">دمج مع البيانات الحالية (Merge)</span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {canUploadInvoices
                      ? 'إضافة السجلات والحركات والصور الجديدة وتحديث المبالغ دون مسح السجلات القديمة'
                      : 'إضافة السجلات والحركات الجديدة وتحديث المبالغ دون مسح السجلات القديمة'}
                  </span>
                </div>
              </label>

              <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-rose-50/50 transition-colors">
                <input
                  type="radio"
                  name="importMode"
                  value="replace"
                  checked={importMode === 'replace'}
                  onChange={() => setImportMode('replace')}
                  className="text-rose-600 focus:ring-rose-500 w-4 h-4 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-bold text-rose-700">
                    استبدال البيانات الحالية بالكامل (Replace)
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {canUploadInvoices
                      ? 'مسح السجلات السابقة وتعيين محتويات هذه النسخة والصور المرفقة مكانها تماماً'
                      : 'مسح السجلات السابقة وتعيين محتويات هذه النسخة مكانها تماماً'}
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleConfirmImport}
              disabled={isImporting}
              className={`flex-1 text-white py-2.5 px-4 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 ${
                importMode === 'replace'
                  ? 'bg-rose-600 hover:bg-rose-700'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              {isImporting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i>
                  <span>
                    {canUploadInvoices
                      ? 'جاري استرجاع البيانات والصور...'
                      : 'جاري استرجاع البيانات...'}
                  </span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>
                    {canUploadInvoices
                      ? 'تأكيد واسترجاع البيانات والصور المرفقة'
                      : 'تأكيد واسترجاع كافة البيانات'}
                  </span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleCancelImport}
              disabled={isImporting}
              className="bg-slate-200/80 hover:bg-slate-300 active:scale-95 text-slate-700 py-2.5 px-4 rounded-xl font-bold text-xs transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* GOOGLE WORKSPACE DESTRUCTIVE CONFIRMATION MODAL (MANDATORY REQUIREMENT) */}
      {/* ------------------------------------------------------------------ */}
      {driveDeleteConfirmFile && (
        <div
          className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm select-none animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white dark:bg-slate-900 border border-rose-300 dark:border-rose-800 rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-4 text-right animate-scaleUp">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950 text-rose-600 flex items-center justify-center text-xl mx-auto">
              <i className="fa-solid fa-trash-can"></i>
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                تأكيد حذف النسخة من Google Drive
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                هل أنت متأكد من رغبتك في حذف ملف النسخة الاحتياطية التالي من حساب Google Drive الخاص بك؟
              </p>
              <div className="mt-2 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-mono font-bold text-slate-800 dark:text-slate-200 truncate dir-ltr">
                {driveDeleteConfirmFile.name}
              </div>
            </div>

            <div className="p-2.5 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-[11px] text-rose-800 dark:text-rose-300">
              ⚠️ تنبيه: هذا الإجراء سيقوم بحذف الملف نهائياً من Google Drive ولا يمكن التراجع عنه.
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleConfirmDeleteDriveFile}
                disabled={isDeletingDriveFile}
                className="flex-1 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white py-2.5 px-4 rounded-xl font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeletingDriveFile ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                    <span>جاري الحذف...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-trash-can text-xs"></i>
                    <span>نعم، حذف الملف من درايف</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setDriveDeleteConfirmFile(null)}
                disabled={isDeletingDriveFile}
                className="bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-300 py-2.5 px-3 rounded-xl font-bold text-xs cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Privacy Policy & Security Modal */}
      {isPrivacyModalOpen && (
        <div
          className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm select-none animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 text-right animate-scaleUp max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center text-lg">
                  <i className="fa-solid fa-shield-check"></i>
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                    سياسة الخصوصية وأمان البيانات
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    تطبيق دفتر ديون والأقساط
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPrivacyModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
                title="إغلاق"
              >
                <i className="fa-solid fa-xmark text-sm"></i>
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <div className="bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-800/50 rounded-2xl p-3.5 space-y-1">
                <span className="font-bold text-blue-900 dark:text-blue-300 block">
                  نطاق الصلاحيات المستخدمة (drive.file):
                </span>
                <p className="text-[11.5px] text-blue-800 dark:text-blue-200">
                  يطلب التطبيق فقط صلاحية الوصول إلى ملفات النسخ الاحتياطية التي ينشئها بنفسه على Google Drive. لا يمكن للتطبيق الوصول إلى أو قراءة أو تعديل أي ملفات أو صور أو مستندات شخصية أخرى خاصة بك على درايف.
                </p>
              </div>

              <div className="space-y-2 pt-1">
                <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                  كيف يتم حفظ وحماية بياناتك؟
                </h4>
                <ul className="space-y-1.5 list-disc list-inside text-[11.5px] pr-1">
                  <li>يتم حفظ نسخك الاحتياطية حصرياً داخل مجلد مخصص باسم «نسخ_دفتر_الديون_والأقساط» في حساب Google Drive الخاص بك.</li>
                  <li>بياناتك المالية وسجلات الديون مشفرة ولا يتم تخزينها أو مشاركتها مع أي جهات خارجية.</li>
                  <li>تتم المصادقة عبر بروتوكول OAuth 2.0 المباشر والموثوق من شركة Google.</li>
                  <li>يمكنك فصل حسابك أو حذف أي نسخة احتياطية من درايف في أي وقت بنقرة واحدة.</li>
                </ul>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setIsPrivacyModalOpen(false)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all cursor-pointer shadow-xs"
              >
                فهمت وموافق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
