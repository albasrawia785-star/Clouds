import React, { useState, useEffect } from 'react';

export interface InvoiceImageViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl?: string | null;
  imageUrls?: string[] | null;
  initialIndex?: number;
  title?: string;
  subtitle?: string;
  amountText?: string;
  amount?: string;
}

export const InvoiceImageViewerModal: React.FC<InvoiceImageViewerModalProps> = ({
  isOpen,
  onClose,
  imageUrl,
  imageUrls,
  initialIndex = 0,
  title = 'صورة الفاتورة المرفقة',
  subtitle,
  amountText,
  amount,
}) => {
  const displayAmount = amountText || amount;

  // Build effective list of images
  const allImages = React.useMemo(() => {
    const list: string[] = [];
    if (Array.isArray(imageUrls)) {
      imageUrls.forEach((img) => {
        if (img && typeof img === 'string' && img.trim() && !list.includes(img.trim())) {
          list.push(img.trim());
        }
      });
    }
    if (imageUrl && typeof imageUrl === 'string' && imageUrl.trim()) {
      const trimmed = imageUrl.trim();
      if (!list.includes(trimmed)) {
        list.unshift(trimmed);
      }
    }
    return list;
  }, [imageUrl, imageUrls]);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = React.useRef({ x: 0, y: 0, panX: 0, panY: 0 });

  useEffect(() => {
    if (isOpen) {
      setZoom(1);
      setRotation(0);
      setPan({ x: 0, y: 0 });
      if (initialIndex >= 0 && initialIndex < allImages.length) {
        setCurrentIndex(initialIndex);
      } else {
        setCurrentIndex(0);
      }
    }
  }, [isOpen, initialIndex, allImages.length]);

  const activeImage = allImages[currentIndex] || imageUrl || (imageUrls && imageUrls[0]);

  const handlePrev = () => {
    if (allImages.length <= 1) return;
    setZoom(1);
    setRotation(0);
    setPan({ x: 0, y: 0 });
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : allImages.length - 1));
  };

  const handleNext = () => {
    if (allImages.length <= 1) return;
    setZoom(1);
    setRotation(0);
    setPan({ x: 0, y: 0 });
    setCurrentIndex((prev) => (prev < allImages.length - 1 ? prev + 1 : 0));
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowRight') {
        handlePrev();
      } else if (e.key === 'ArrowLeft') {
        handleNext();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, allImages.length]);

  if (!isOpen || !activeImage) return null;

  const handleZoomIn = () => {
    setZoom((z) => Math.min(5, +(z + 0.5).toFixed(1)));
  };

  const handleZoomOut = () => {
    setZoom((z) => {
      const next = Math.max(0.75, +(z - 0.5).toFixed(1));
      if (next <= 1) setPan({ x: 0, y: 0 });
      return next;
    });
  };

  const handleReset = () => {
    setZoom(1);
    setRotation(0);
    setPan({ x: 0, y: 0 });
  };

  const handleRotate = () => {
    setRotation((r) => (r + 90) % 360);
  };

  const handleToggleZoom = () => {
    if (zoom > 1) {
      handleReset();
    } else {
      setZoom(2.2);
    }
  };

  // Pointer & Touch Drag Handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    if (zoom <= 1) return;
    setIsDragging(true);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      panX: pan.x,
      panY: pan.y,
    };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || zoom <= 1) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    setPan({
      x: dragStartRef.current.panX + dx,
      y: dragStartRef.current.panY + dy,
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isDragging) {
      setIsDragging(false);
      try {
        (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
      } catch {}
    }
  };

  const handleDownload = () => {
    try {
      if (!activeImage) return;
      const link = document.createElement('a');
      link.href = activeImage;
      const cleanTitle = (title || 'فاتورة').replace(/[\s/\\?%*:|"<>]/g, '_');
      const ext = activeImage.startsWith('data:image/webp') ? 'webp' : 'jpg';
      link.download = `${cleanTitle}_${currentIndex + 1}_${Date.now()}.${ext}`;
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 200);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[9999] bg-slate-950/95 backdrop-blur-md flex flex-col justify-between items-center select-none animate-in fade-in duration-200"
      onClick={onClose}
    >
      {/* Top Header Bar with APK Safe Area */}
      <div
        className="w-full max-w-4xl px-4 pt-[max(0.85rem,calc(env(safe-area-inset-top)+0.5rem))] pb-3 sm:py-4 flex items-center justify-between gap-3 text-white z-20 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 sm:w-9 sm:h-9 rounded-2xl bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center shrink-0 shadow-xs">
            <i className="fa-solid fa-receipt text-base sm:text-sm"></i>
          </div>
          <div className="min-w-0">
            <h3 className="font-bold text-sm sm:text-base text-white truncate flex items-center gap-2">
              <span>{title}</span>
              {allImages.length > 1 && (
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 border border-indigo-500/40">
                  صورة {currentIndex + 1} من {allImages.length}
                </span>
              )}
              {displayAmount && (
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {displayAmount}
                </span>
              )}
            </h3>
            {subtitle && (
              <p className="text-xs text-slate-400 truncate mt-0.5 font-mono" dir="auto">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Action Buttons: Download & Exit */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleDownload}
            className="h-11 sm:h-10 px-3.5 sm:px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 active:scale-95 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md touch-manipulation"
            title="تحميل الصورة بالجودة العالية"
          >
            <i className="fa-solid fa-download text-xs"></i>
            <span className="hidden sm:inline">تحميل</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-11 h-11 sm:w-10 sm:h-10 rounded-xl bg-white/10 hover:bg-white/20 active:bg-white/30 active:scale-95 text-slate-200 hover:text-white flex items-center justify-center transition-all cursor-pointer border border-white/10 shadow-md touch-manipulation"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>
      </div>

      {/* Main Image Stage with Drag & Pan */}
      <div
        className="flex-1 w-full max-w-5xl p-2 sm:p-4 flex items-center justify-between overflow-hidden relative touch-none"
        onClick={(e) => e.stopPropagation()}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
      >
        {/* Previous Image Arrow */}
        {allImages.length > 1 && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            className="z-30 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-slate-900/80 hover:bg-blue-600 border border-white/20 text-white flex items-center justify-center shadow-2xl transition-all cursor-pointer shrink-0 active:scale-90"
            title="الصورة السابقة"
          >
            <i className="fa-solid fa-chevron-right text-base sm:text-lg"></i>
          </button>
        )}

        {/* Center Active Image */}
        <div className="flex-1 flex items-center justify-center overflow-hidden h-full">
          <div
            className={`transition-transform ease-out flex items-center justify-center max-w-full max-h-full ${
              isDragging ? 'duration-0 cursor-grabbing' : zoom > 1 ? 'duration-150 cursor-grab' : 'duration-200 cursor-zoom-in'
            }`}
            style={{
              transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoom}) rotate(${rotation}deg)`,
            }}
            onDoubleClick={handleToggleZoom}
          >
            <img
              src={activeImage}
              alt={title}
              className="max-w-[92vw] max-h-[72vh] object-contain rounded-2xl shadow-2xl border border-white/10 select-none pointer-events-none"
              draggable={false}
            />
          </div>
        </div>

        {/* Next Image Arrow */}
        {allImages.length > 1 && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            className="z-30 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-slate-900/80 hover:bg-blue-600 border border-white/20 text-white flex items-center justify-center shadow-2xl transition-all cursor-pointer shrink-0 active:scale-90"
            title="الصورة التالية"
          >
            <i className="fa-solid fa-chevron-left text-base sm:text-lg"></i>
          </button>
        )}

        {zoom > 1 ? (
          <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-md text-[11px] text-slate-200 px-3 py-1.5 rounded-full border border-white/15 pointer-events-none shadow-lg flex items-center gap-1.5 z-20">
            <i className="fa-solid fa-hand-pointer text-[10px] text-blue-400"></i>
            <span>اسحب بإصبعك للتحريك وقراءة الأسماء</span>
          </div>
        ) : (
          <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-xs text-[10.5px] text-slate-300 px-2.5 py-1 rounded-full border border-white/10 pointer-events-none hidden sm:flex items-center gap-1.5 z-20">
            <i className="fa-solid fa-magnifying-glass-plus text-[10px] text-slate-400"></i>
            <span>انقر نقراً مزدوجاً للتكبير السريع</span>
          </div>
        )}
      </div>

      {/* Floating Bottom Toolbar with Correct LTR, Ergonomic Touch Sizes & APK Safe Area */}
      <div
        className="mb-[max(1.25rem,calc(env(safe-area-inset-bottom)+0.75rem))] sm:mb-6 px-3.5 py-2 sm:py-2.5 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl flex items-center gap-2 text-white z-20 backdrop-blur-md"
        dir="ltr"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={handleZoomOut}
          disabled={zoom <= 0.75}
          className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 active:scale-95 disabled:opacity-30 text-slate-200 flex items-center justify-center text-sm transition-all cursor-pointer touch-manipulation shadow-xs"
          title="تصغير"
        >
          <i className="fa-solid fa-magnifying-glass-minus"></i>
        </button>

        <span className="font-mono text-xs sm:text-sm font-bold px-2 py-0.5 text-slate-100 min-w-[52px] text-center select-none bg-slate-800/80 rounded-lg border border-slate-700/50">
          {Math.round(zoom * 100)}%
        </span>

        <button
          type="button"
          onClick={handleZoomIn}
          disabled={zoom >= 5}
          className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 active:scale-95 disabled:opacity-30 text-slate-200 flex items-center justify-center text-sm transition-all cursor-pointer touch-manipulation shadow-xs"
          title="تكبير"
        >
          <i className="fa-solid fa-magnifying-glass-plus"></i>
        </button>

        <div className="w-px h-6 bg-slate-700/80 mx-1"></div>

        <button
          type="button"
          onClick={handleRotate}
          className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 active:scale-95 text-slate-200 flex items-center justify-center text-sm transition-all cursor-pointer touch-manipulation shadow-xs"
          title="تدوير 90 درجة"
        >
          <i className="fa-solid fa-rotate-right"></i>
        </button>

        <button
          type="button"
          onClick={handleReset}
          className="h-10 sm:h-9 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 active:scale-95 text-slate-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer touch-manipulation shadow-xs border border-slate-700/60"
          title="إعادة ضبط الحجم والتدوير"
        >
          <i className="fa-solid fa-arrows-rotate text-[11px] text-blue-400"></i>
          <span>استعادة</span>
        </button>
      </div>
    </div>
  );
};
