import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  User,
  Phone,
  FileText,
  Plus,
  Trash2,
  Printer,
  Save,
  Eye,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Info,
  Banknote,
  CreditCard,
  ArrowLeftRight,
  Calendar,
  Clock,
} from 'lucide-react';
import {
  AppSettings,
  Invoice,
  InvoiceItem,
  PaperSize,
  PaymentMethod,
  ToastMessage,
} from './types';
import {
  WARRANTY_OPTIONS,
  collectProductSuggestions,
  createDemoItems,
  createEmptyItem,
  formatDateYYYYMMDD,
  formatIqd,
  formatSerialNumber,
  formatTimeArabic12h,
  generateId,
  getNextSerialNumber,
  loadSettings,
  parseNumericInput,
  saveLastSerial,
  saveSettings,
} from './utils/storage';
import { numberToArabicIqdWords } from './utils/arabicTafqeet';
import {
  dbBulkPutInvoices,
  dbDeleteInvoice,
  dbInitAndLoadInvoices,
  dbLoadBannerImage,
  dbPutInvoice,
  dbSaveBannerImage,
} from './utils/invoiceDb';
import { HeaderBanner } from './components/HeaderBanner';
import { SettingsModal } from './components/SettingsModal';
import { InventoryModal } from './components/InventoryModal';
import { ConfirmModal } from './components/ConfirmModal';
import { PrintPreviewModal } from './components/PrintPreviewModal';
import { InvoiceReceipt } from './components/InvoiceReceipt';

export default function App() {
  // Persistent state (settings load synchronously; invoices & banner hydrate from IndexedDB)
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isLoadingInvoices, setIsLoadingInvoices] = useState<boolean>(true);

  // Live clock updated every second
  const [now, setNow] = useState<Date>(() => new Date());

  // Active invoice form state
  const [activeInvoiceId, setActiveInvoiceId] = useState<string | null>(null);
  const [activeSerialNumber, setActiveSerialNumber] = useState<string | null>(null);
  const [activeNumericSerial, setActiveNumericSerial] = useState<number | null>(null);
  const [loadedDateDisplay, setLoadedDateDisplay] = useState<string | null>(null);
  const [loadedTimeDisplay, setLoadedTimeDisplay] = useState<string | null>(null);
  const [isSavedClean, setIsSavedClean] = useState<boolean>(false);

  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerNotes, setCustomerNotes] = useState<string>('');
  const [items, setItems] = useState<InvoiceItem[]>(() => createDemoItems());
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');

  // Modals & UI feedback state (pure React state — no URL routing for EXE compatibility)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [printRequestSeq, setPrintRequestSeq] = useState(0);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const isPrintingRef = useRef<boolean>(false);
  const lastHandledPrintSeqRef = useRef<number>(0);

  // Hydrate invoices and custom banner from IndexedDB (with seamless localStorage migration)
  useEffect(() => {
    let cancelled = false;
    const hydrate = async () => {
      try {
        const [loadedInvoices, dbBanner] = await Promise.all([
          dbInitAndLoadInvoices(),
          dbLoadBannerImage(),
        ]);
        if (cancelled) return;
        setInvoices(loadedInvoices);

        if (dbBanner) {
          setSettings((prev) => ({ ...prev, bannerImage: dbBanner }));
        } else {
          const currentSettings = loadSettings();
          if (currentSettings.bannerImage) {
            const moved = await dbSaveBannerImage(currentSettings.bannerImage);
            if (moved) {
              saveSettings({ ...currentSettings, bannerImage: null });
            }
          }
        }
      } finally {
        if (!cancelled) {
          setIsLoadingInvoices(false);
        }
      }
    };
    void hydrate();
    return () => {
      cancelled = true;
    };
  }, []);

  // Update live clock every 1 second
  useEffect(() => {
    const timer = window.setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Toast helper
  const notify = useCallback((type: ToastMessage['type'], text: string) => {
    const id = generateId();
    setToasts((prev) => [...prev.slice(-2), { id, type, text }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3400);
  }, []);

  // Derived totals (Iraqi Dinar only)
  const totalIqd = useMemo(() => {
    return items.reduce((sum, item) => {
      const qty = Number.isFinite(item.quantity) ? item.quantity : 0;
      const price = Number.isFinite(item.unitPrice) ? item.unitPrice : 0;
      return sum + Math.round(qty * price);
    }, 0);
  }, [items]);

  const totalPieces = useMemo(() => {
    return items.reduce((sum, item) => {
      const hasContent =
        item.name.trim() !== '' || item.unitPrice > 0 || item.notes.trim() !== '';
      if (!hasContent) return sum;
      return sum + (Number.isFinite(item.quantity) ? item.quantity : 0);
    }, 0);
  }, [items]);

  const activeItemCount = useMemo(() => {
    return items.filter(
      (item) => item.name.trim() !== '' || item.unitPrice > 0 || item.notes.trim() !== ''
    ).length;
  }, [items]);

  const tafqeetText = useMemo(() => numberToArabicIqdWords(totalIqd), [totalIqd]);

  const productSuggestions = useMemo(() => collectProductSuggestions(invoices), [invoices]);

  const displayDate = loadedDateDisplay ?? formatDateYYYYMMDD(now);
  const displayTime = loadedTimeDisplay ?? formatTimeArabic12h(now);
  const displaySerial =
    activeSerialNumber ?? formatSerialNumber(getNextSerialNumber(invoices));

  const markDirty = () => {
    if (isSavedClean) setIsSavedClean(false);
  };

  // Item handlers
  const handleAddItem = () => {
    setItems((prev) => [...prev, createEmptyItem()]);
    markDirty();
  };

  const handleRemoveItem = (id: string) => {
    setItems((prev) => {
      const next = prev.filter((item) => item.id !== id);
      return next.length > 0 ? next : [createEmptyItem()];
    });
    markDirty();
  };

  const handleUpdateItem = <K extends keyof InvoiceItem>(
    id: string,
    field: K,
    value: InvoiceItem[K]
  ) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
    markDirty();
  };

  // Save invoice to IndexedDB (O(1) single-record write)
  const persistCurrentInvoice = useCallback(
    async (showToast: boolean): Promise<Invoice | null> => {
      const nonEmptyItems = items.filter(
        (it) => it.name.trim() !== '' || it.unitPrice > 0 || it.notes.trim() !== ''
      );
      if (nonEmptyItems.length === 0) {
        notify('error', 'يرجى إدخال صنف واحد على الأقل قبل حفظ الفاتورة');
        return null;
      }

      const timestamp = new Date();
      const dateStr = loadedDateDisplay ?? formatDateYYYYMMDD(timestamp);
      const timeStr = loadedTimeDisplay ?? formatTimeArabic12h(timestamp);

      let targetNumericSerial = activeNumericSerial;
      let targetSerialStr = activeSerialNumber;
      let targetId = activeInvoiceId;

      if (!targetId || !targetNumericSerial || !targetSerialStr) {
        targetNumericSerial = getNextSerialNumber(invoices);
        targetSerialStr = formatSerialNumber(targetNumericSerial);
        targetId = generateId();
      }

      const computedTotalIqd = nonEmptyItems.reduce(
        (sum, it) => sum + Math.round((Number(it.quantity) || 0) * (Number(it.unitPrice) || 0)),
        0
      );

      const invoiceRecord: Invoice = {
        id: targetId,
        serialNumber: targetSerialStr,
        numericSerial: targetNumericSerial,
        createdAt: timestamp.toISOString(),
        dateDisplay: dateStr,
        timeDisplay: timeStr,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerNotes: customerNotes.trim(),
        items: nonEmptyItems,
        paymentMethod,
        totalIqd: computedTotalIqd,
      };

      const existingIdx = invoices.findIndex((inv) => inv.id === targetId);
      const updatedList =
        existingIdx >= 0
          ? invoices.map((inv) => (inv.id === targetId ? invoiceRecord : inv))
          : [invoiceRecord, ...invoices];

      const savedOk = await dbPutInvoice(invoiceRecord, updatedList);
      if (!savedOk) {
        notify('error', 'تعذر حفظ الفاتورة في قاعدة البيانات المحلية');
        return null;
      }

      saveLastSerial(
        Math.max(
          targetNumericSerial,
          updatedList.reduce((m, i) => Math.max(m, i.numericSerial || 0), 0)
        )
      );

      setInvoices(updatedList);
      setActiveInvoiceId(targetId);
      setActiveNumericSerial(targetNumericSerial);
      setActiveSerialNumber(targetSerialStr);
      setLoadedDateDisplay(dateStr);
      setLoadedTimeDisplay(timeStr);
      setIsSavedClean(true);

      if (showToast) {
        notify(
          'success',
          existingIdx >= 0
            ? `تم تحديث الفاتورة رقم ${targetSerialStr} بنجاح`
            : `تم حفظ الفاتورة رقم ${targetSerialStr} بنجاح`
        );
      }

      return invoiceRecord;
    },
    [
      items,
      loadedDateDisplay,
      loadedTimeDisplay,
      activeNumericSerial,
      activeSerialNumber,
      activeInvoiceId,
      invoices,
      customerName,
      customerPhone,
      customerNotes,
      paymentMethod,
      notify,
    ]
  );

  // Wait for Cairo font + any uploaded banner image in #printable-receipt-root before spooling
  const waitForPrintReadiness = useCallback(async () => {
    // 1. Wait for web fonts (capped at 500ms so offline printing never stalls)
    if (typeof document !== 'undefined' && document.fonts?.ready) {
      await Promise.race([
        document.fonts.ready.catch(() => undefined),
        new Promise((resolve) => window.setTimeout(resolve, 500)),
      ]);
    }

    // 2. Ensure all images inside the print container are fully decoded
    const printRoot = document.getElementById('printable-receipt-root');
    if (printRoot) {
      const imgs = Array.from(printRoot.querySelectorAll('img'));
      if (imgs.length > 0) {
        await Promise.race([
          Promise.all(
            imgs.map((img) => {
              if (img.complete && img.naturalWidth > 0) return Promise.resolve();
              return typeof img.decode === 'function'
                ? img.decode().catch(() => undefined)
                : new Promise<void>((resolve) => {
                    img.onload = () => resolve();
                    img.onerror = () => resolve();
                  });
            })
          ),
          new Promise((resolve) => window.setTimeout(resolve, 800)),
        ]);
      }
    }

    // 3. Double animation frame guarantees layout + paint commit before printer snapshot
    await new Promise<void>((resolve) => {
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => resolve());
      });
    });
  }, []);

  // Execute physical print (Electron USB/cable direct API or browser window.print)
  const triggerPrintEngine = useCallback(async () => {
    if (isPrintingRef.current) return;
    isPrintingRef.current = true;
    setIsPrinting(true);

    const originalTitle = document.title;
    const safeSerial = displaySerial.replace(/[^0-9A-Za-z#-]/g, '');
    document.title = `فاتورة ${safeSerial} - أحمد القيسي للإطارات والبطاريات`;

    const releaseLock = () => {
      document.title = originalTitle;
      isPrintingRef.current = false;
      setIsPrinting(false);
    };

    try {
      await waitForPrintReadiness();

      const electronPrint = window.electronAPI?.printInvoice;
      if (typeof electronPrint === 'function') {
        const result = await electronPrint({
          deviceName: settings.selectedPrinter || undefined,
          silent: settings.silentPrint,
          printBackground: true,
          landscape: settings.paperSize === 'A5_LANDSCAPE',
          pageSize: settings.paperSize === 'A4_PORTRAIT' ? 'A4' : 'A5',
        });
        if (!result?.success) {
          notify(
            'error',
            result?.failureReason
              ? `فشلت الطباعة: ${result.failureReason}`
              : 'لم تكتمل عملية الطباعة — تأكد من توصيل كيبل الطابعة وتشغيلها'
          );
        } else if (settings.silentPrint) {
          notify('success', 'تم إرسال الفاتورة إلى الطابعة مباشرة بنجاح');
        }
        releaseLock();
      } else {
        // Browser USB/cable print via system print dialog
        let released = false;
        const finishBrowserPrint = () => {
          if (released) return;
          released = true;
          window.removeEventListener('afterprint', finishBrowserPrint);
          releaseLock();
        };
        window.addEventListener('afterprint', finishBrowserPrint);

        // Fallback safety release in case an embedded viewer suppresses afterprint
        const safetyTimer = window.setTimeout(finishBrowserPrint, 2500);
        try {
          window.print();
        } finally {
          window.setTimeout(() => {
            window.clearTimeout(safetyTimer);
            finishBrowserPrint();
          }, 400);
        }
      }
    } catch {
      notify('error', 'حدث خطأ أثناء الاتصال بالطابعة — تحقق من توصيل الكيبل');
      releaseLock();
    }
  }, [
    displaySerial,
    waitForPrintReadiness,
    settings.selectedPrinter,
    settings.silentPrint,
    settings.paperSize,
    notify,
  ]);

  // Guaranteed one-shot post-render print trigger (never fires spuriously on setting/serial changes)
  useEffect(() => {
    if (printRequestSeq === 0 || printRequestSeq === lastHandledPrintSeqRef.current) {
      return;
    }
    lastHandledPrintSeqRef.current = printRequestSeq;
    void triggerPrintEngine();
  }, [printRequestSeq, triggerPrintEngine]);

  const handleSaveInvoice = () => {
    void persistCurrentInvoice(true);
  };

  const executeActualPrint = async () => {
    if (isPrintingRef.current) return;
    setIsPrintPreviewOpen(false);
    if (!isSavedClean || !activeInvoiceId) {
      const saved = await persistCurrentInvoice(false);
      if (!saved) return;
      notify('info', `تم حفظ الفاتورة ${saved.serialNumber} وإرسالها للطباعة`);
    }
    setPrintRequestSeq((seq) => seq + 1);
  };

  const handlePrintInvoice = () => {
    if (isPrintingRef.current) return;
    if (activeItemCount === 0) {
      notify('error', 'يرجى إدخال صنف واحد على الأقل قبل معاينة أو طباعة الفاتورة');
      return;
    }

    const isSilentElectron =
      typeof window !== 'undefined' &&
      typeof window.electronAPI?.printInvoice === 'function' &&
      settings.silentPrint;

    if (isSilentElectron) {
      void executeActualPrint();
    } else {
      setIsPrintPreviewOpen(true);
    }
  };

  const handleTestPrint = async (draftSettings: AppSettings) => {
    await handleSaveSettings(draftSettings);
    setIsSettingsOpen(false);
    setPrintRequestSeq((seq) => seq + 1);
  };

  const handleQuickPaperSizeChange = (paperSize: PaperSize) => {
    setSettings((prev) => ({ ...prev, paperSize }));
    const existingLocal = loadSettings();
    saveSettings({ ...existingLocal, paperSize });
  };

  // Reset form for a fresh invoice
  const handleConfirmCancelInvoice = () => {
    setActiveInvoiceId(null);
    setActiveSerialNumber(null);
    setActiveNumericSerial(null);
    setLoadedDateDisplay(null);
    setLoadedTimeDisplay(null);
    setIsSavedClean(false);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerNotes('');
    setItems([createEmptyItem()]);
    setPaymentMethod('cash');
    setIsCancelConfirmOpen(false);
    notify('info', 'تم تفريغ الحقول لبدء فاتورة جديدة');
  };

  // Load saved invoice from Inventory modal
  const handleLoadInvoice = (invoice: Invoice, autoPrint = false) => {
    setActiveInvoiceId(invoice.id);
    setActiveSerialNumber(invoice.serialNumber);
    setActiveNumericSerial(invoice.numericSerial);
    setLoadedDateDisplay(invoice.dateDisplay);
    setLoadedTimeDisplay(invoice.timeDisplay);
    setCustomerName(invoice.customerName);
    setCustomerPhone(invoice.customerPhone);
    setCustomerNotes(invoice.customerNotes);
    setItems(invoice.items.length > 0 ? invoice.items.map((it) => ({ ...it })) : [createEmptyItem()]);
    setPaymentMethod(invoice.paymentMethod);
    setIsSavedClean(true);

    if (autoPrint) {
      setPrintRequestSeq((seq) => seq + 1);
    } else {
      notify('info', `تم فتح الفاتورة رقم ${invoice.serialNumber}`);
    }
  };

  const handleDeleteInvoice = async (id: string) => {
    const target = invoices.find((inv) => inv.id === id);
    const updated = invoices.filter((inv) => inv.id !== id);
    const deletedOk = await dbDeleteInvoice(id, updated);
    if (!deletedOk) {
      notify('error', 'تعذر حذف الفاتورة من قاعدة البيانات المحلية');
      return;
    }
    setInvoices(updated);
    if (activeInvoiceId === id) {
      setActiveInvoiceId(null);
      setActiveSerialNumber(null);
      setActiveNumericSerial(null);
      setIsSavedClean(false);
    }
    notify('info', `تم حذف الفاتورة ${target?.serialNumber ?? ''}`);
  };

  const handleImportInvoices = async (imported: Invoice[]) => {
    const byId = new Map<string, Invoice>();
    for (const inv of invoices) byId.set(inv.id, inv);
    for (const inv of imported) byId.set(inv.id, inv);
    const merged = Array.from(byId.values()).sort(
      (a, b) => (b.numericSerial || 0) - (a.numericSerial || 0)
    );
    const savedOk = await dbBulkPutInvoices(imported, merged);
    if (!savedOk) {
      notify('error', 'تعذر حفظ الفواتير المستوردة في قاعدة البيانات');
      return;
    }
    const maxSerial = merged.reduce((m, i) => Math.max(m, i.numericSerial || 0), 0);
    setInvoices(merged);
    saveLastSerial(maxSerial);
    notify('success', `تم استيراد ${imported.length} فاتورة بنجاح (الإجمالي: ${merged.length})`);
  };

  const handleSaveSettings = async (nextSettings: AppSettings) => {
    const bannerSavedInDb = await dbSaveBannerImage(nextSettings.bannerImage);
    const localPayload: AppSettings = bannerSavedInDb
      ? { ...nextSettings, bannerImage: null }
      : nextSettings;

    const ok = saveSettings(localPayload);
    if (!ok) {
      notify('error', 'فشل حفظ الإعدادات — قد تكون الصورة المختارة كبيرة جداً');
      return;
    }
    setSettings(nextSettings);
    notify('success', 'تم حفظ إعدادات النظام بنجاح');
  };

  const pageCssRule =
    settings.paperSize === 'A4_PORTRAIT'
      ? '@page { size: A4 portrait; margin: 8mm; }'
      : '@page { size: A5 landscape; margin: 5mm; }';

  return (
    <div className="pos-page-wrapper min-h-screen bg-[#F1F5F9] text-[#0F172A] flex flex-col">
      {/* Dynamic @page paper size rule */}
      <style>{pageCssRule}</style>

      {/* ================================================================
          INTERACTIVE ENTERPRISE POS WORKSPACE (Hidden on Print)
         ================================================================ */}
      <div className="print:hidden flex flex-col min-h-screen">
        {/* 1. COMPACT COMMERCIAL APPLICATION HEADER */}
        <HeaderBanner
          bannerImage={settings.bannerImage}
          serialNumber={displaySerial}
          isSavedInvoice={Boolean(activeSerialNumber)}
          dateDisplay={displayDate}
          timeDisplay={displayTime}
          savedCount={invoices.length}
          onOpenInventory={() => setIsInventoryOpen(true)}
          onOpenPreview={() => setIsPrintPreviewOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />

        {/* Mobile/Tablet compact date-time strip (shown only below lg where header hides it) */}
        <div className="lg:hidden bg-white border-b border-[#E2E8F0] px-4 py-2 flex items-center justify-between text-xs font-bold text-[#334155] tabular-nums">
          <span>
            فاتورة <strong dir="ltr" className="text-[#0E2A52]">{displaySerial}</strong>
          </span>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-[#64748B]" />
              <span dir="ltr">{displayDate}</span>
            </span>
            <span className="inline-flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-[#64748B]" />
              <span>{displayTime}</span>
            </span>
          </div>
        </div>

        {/* 2. MAIN TWO-COLUMN POS DESKTOP WORKSPACE */}
        <main className="flex-1 w-full max-w-[1380px] mx-auto px-4 sm:px-6 py-5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* RIGHT WORKSPACE (8–9 cols): Customer Details + Items Ledger */}
            <div className="lg:col-span-8 xl:col-span-9 space-y-4">
              {/* Customer Details Bar */}
              <section
                aria-label="بيانات الزبون"
                className="bg-white rounded-xl border border-[#D8E1EC] shadow-[0_1px_2px_rgba(15,23,42,0.04)] p-4"
              >
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label
                      htmlFor="customer-name"
                      className="flex items-center gap-1.5 text-xs font-bold text-[#475569] mb-1.5"
                    >
                      <User className="w-3.5 h-3.5 text-[#64748B]" />
                      <span>اسم الزبون</span>
                    </label>
                    <input
                      id="customer-name"
                      type="text"
                      value={customerName}
                      onChange={(e) => {
                        setCustomerName(e.target.value);
                        markDirty();
                      }}
                      placeholder="زبون نقدي (أو اكتب الاسم)"
                      className="w-full h-10 px-3 rounded-lg bg-[#F8FAFC] hover:bg-white focus:bg-white border border-[#CBD5E1] focus:border-[#0E2A52] text-[#0F172A] font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-[#0E2A52]/15"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="customer-phone"
                      className="flex items-center gap-1.5 text-xs font-bold text-[#475569] mb-1.5"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#64748B]" />
                      <span>رقم الهاتف</span>
                    </label>
                    <input
                      id="customer-phone"
                      type="text"
                      dir="ltr"
                      value={customerPhone}
                      onChange={(e) => {
                        setCustomerPhone(e.target.value);
                        markDirty();
                      }}
                      placeholder="0770 000 0000"
                      className="w-full h-10 px-3 rounded-lg bg-[#F8FAFC] hover:bg-white focus:bg-white border border-[#CBD5E1] focus:border-[#0E2A52] text-[#0F172A] font-semibold text-sm text-right tabular-nums transition-colors focus:outline-none focus:ring-2 focus:ring-[#0E2A52]/15"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="customer-notes"
                      className="flex items-center gap-1.5 text-xs font-bold text-[#475569] mb-1.5"
                    >
                      <FileText className="w-3.5 h-3.5 text-[#64748B]" />
                      <span>ملاحظات الفاتورة</span>
                    </label>
                    <input
                      id="customer-notes"
                      type="text"
                      value={customerNotes}
                      onChange={(e) => {
                        setCustomerNotes(e.target.value);
                        markDirty();
                      }}
                      placeholder="مثال: زبون مميز، رقم السيارة..."
                      className="w-full h-10 px-3 rounded-lg bg-[#F8FAFC] hover:bg-white focus:bg-white border border-[#CBD5E1] focus:border-[#0E2A52] text-[#0F172A] font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-[#0E2A52]/15"
                    />
                  </div>
                </div>
              </section>

              {/* Items Ledger Table */}
              <section
                aria-label="جدول الأصناف"
                className="bg-white rounded-xl border border-[#D8E1EC] shadow-[0_1px_2px_rgba(15,23,42,0.04)] overflow-hidden"
              >
                {/* Section Header */}
                <div className="px-4 py-3 border-b border-[#E2E8F0] flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm font-extrabold text-[#0E2A52]">تفاصيل الأصناف</h2>
                    <span className="text-xs font-semibold text-[#64748B] tabular-nums">
                      · {activeItemCount} صنف · {totalPieces} قطعة
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0E2A52] hover:bg-[#173B6F] text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة صنف</span>
                  </button>
                </div>

                {/* Datalists for product autocomplete & warranty options */}
                <datalist id="product-suggestions">
                  {productSuggestions.map((prod) => (
                    <option key={prod} value={prod} />
                  ))}
                </datalist>
                <datalist id="warranty-options">
                  {WARRANTY_OPTIONS.map((w) => (
                    <option key={w} value={w} />
                  ))}
                </datalist>

                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-[#F8FAFC] border-b border-[#DCE4EE] text-xs font-bold text-[#475569]">
                        <th className="py-2.5 px-3 text-center w-[42px]">ت</th>
                        <th className="py-2.5 px-3 text-right min-w-[210px]">الصنف / البيان</th>
                        <th className="py-2.5 px-2 text-center w-[76px]">الكمية</th>
                        <th className="py-2.5 px-2 text-center w-[132px] whitespace-nowrap">
                          سعر الوحدة (د.ع)
                        </th>
                        <th className="py-2.5 px-2 text-center w-[112px]">الضمان</th>
                        <th className="py-2.5 px-3 text-center w-[136px] whitespace-nowrap">
                          المجموع (د.ع)
                        </th>
                        <th className="py-2.5 px-2 text-right w-[135px]">ملاحظات</th>
                        <th className="py-2.5 px-2 w-[42px]">
                          <span className="sr-only">حذف</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E8EEF5] text-sm">
                      {items.map((item, idx) => {
                        const rowTotal = Math.round(
                          (Number.isFinite(item.quantity) ? item.quantity : 0) *
                            (Number.isFinite(item.unitPrice) ? item.unitPrice : 0)
                        );
                        const isLastRow = idx === items.length - 1;

                        return (
                          <tr
                            key={item.id}
                            className="group hover:bg-[#F8FAFC] transition-colors"
                          >
                            {/* 1. Index */}
                            <td className="py-2 px-3 text-center text-xs font-bold text-[#64748B] tabular-nums">
                              {idx + 1}
                            </td>

                            {/* 2. Product Name (Right aligned for natural Arabic reading) */}
                            <td className="py-2 px-2">
                              <input
                                type="text"
                                list="product-suggestions"
                                value={item.name}
                                onChange={(e) => handleUpdateItem(item.id, 'name', e.target.value)}
                                placeholder="اسم الإطار أو البطارية..."
                                className="w-full h-9 px-2.5 rounded-md bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-[#CBD5E1] focus:border-[#0E2A52] text-[#0F172A] font-bold text-sm text-right focus:outline-none transition-colors"
                              />
                            </td>

                            {/* 3. Quantity */}
                            <td className="py-2 px-1.5">
                              <input
                                type="number"
                                min={1}
                                step={1}
                                value={item.quantity === 0 ? '' : item.quantity}
                                onChange={(e) => {
                                  const val = Number.parseInt(e.target.value, 10);
                                  handleUpdateItem(
                                    item.id,
                                    'quantity',
                                    Number.isFinite(val) && val >= 0 ? val : 0
                                  );
                                }}
                                className="w-full h-9 px-2 rounded-md bg-[#F8FAFC] focus:bg-white border border-[#E2E8F0] focus:border-[#0E2A52] text-[#0F172A] font-bold text-sm text-center tabular-nums focus:outline-none transition-colors"
                              />
                            </td>

                            {/* 4. Unit Price (IQD) */}
                            <td className="py-2 px-1.5">
                              <input
                                type="text"
                                inputMode="numeric"
                                value={item.unitPrice === 0 ? '' : formatIqd(item.unitPrice)}
                                onChange={(e) => {
                                  handleUpdateItem(
                                    item.id,
                                    'unitPrice',
                                    parseNumericInput(e.target.value)
                                  );
                                }}
                                placeholder="0"
                                className="w-full h-9 px-2.5 rounded-md bg-[#F8FAFC] focus:bg-white border border-[#E2E8F0] focus:border-[#0E2A52] text-[#0F172A] font-bold text-sm text-center tabular-nums focus:outline-none transition-colors"
                              />
                            </td>

                            {/* 5. Warranty */}
                            <td className="py-2 px-1.5">
                              <input
                                type="text"
                                list="warranty-options"
                                value={item.warranty}
                                onChange={(e) =>
                                  handleUpdateItem(item.id, 'warranty', e.target.value)
                                }
                                placeholder="بدون ضمان"
                                className="w-full h-9 px-2 rounded-md bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-[#CBD5E1] focus:border-[#0E2A52] text-[#334155] font-semibold text-xs sm:text-sm text-center focus:outline-none transition-colors"
                              />
                            </td>

                            {/* 6. Line Total (IQD) */}
                            <td className="py-2 px-3 text-center font-extrabold text-[#0E2A52] text-sm tabular-nums whitespace-nowrap">
                              {formatIqd(rowTotal)}
                            </td>

                            {/* 7. Notes */}
                            <td className="py-2 px-1.5">
                              <input
                                type="text"
                                value={item.notes}
                                onChange={(e) => handleUpdateItem(item.id, 'notes', e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' && isLastRow) {
                                    e.preventDefault();
                                    handleAddItem();
                                  }
                                }}
                                placeholder="ملاحظة..."
                                className="w-full h-9 px-2 rounded-md bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-[#CBD5E1] focus:border-[#0E2A52] text-[#475569] font-medium text-xs sm:text-sm text-right focus:outline-none transition-colors"
                              />
                            </td>

                            {/* 8. Remove row */}
                            <td className="py-2 px-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleRemoveItem(item.id)}
                                className="p-1.5 rounded-md text-[#94A3B8] hover:text-[#C8102E] hover:bg-[#FEF2F2] transition-colors cursor-pointer"
                                title="حذف الصف"
                                aria-label={`حذف الصف ${idx + 1}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Bottom Subtle Add-Row Affordance */}
                <div className="px-4 py-2.5 bg-[#F8FAFC] border-t border-[#E2E8F0] flex items-center justify-between">
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0E2A52] hover:text-[#C8102E] transition-colors cursor-pointer py-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة سطر جديد</span>
                  </button>
                  <span className="text-[11px] font-medium text-[#64748B]">
                    اضغط Enter في خانة الملاحظات لإضافة صنف جديد بسرعة
                  </span>
                </div>
              </section>
            </div>

            {/* LEFT CHECKOUT & ACTION RAIL (4–3 cols, sticky on desktop) */}
            <aside
              aria-label="ملخص الدفع والإجراءات"
              className="lg:col-span-4 xl:col-span-3 lg:sticky lg:top-5"
            >
              <div className="bg-white rounded-xl border border-[#D8E1EC] shadow-[0_1px_3px_rgba(15,23,42,0.06)] overflow-hidden">
                {/* Summary Header */}
                <div className="px-5 py-3.5 border-b border-[#E2E8F0] flex items-center justify-between">
                  <h2 className="text-sm font-extrabold text-[#0E2A52]">ملخص الفاتورة</h2>
                  <span dir="ltr" className="text-xs font-black text-[#C8102E] tabular-nums">
                    {displaySerial}
                  </span>
                </div>

                {/* Payment Method Segmented Control */}
                <div className="px-5 py-4 border-b border-[#E2E8F0]">
                  <div className="text-xs font-bold text-[#475569] mb-2">طريقة الدفع</div>
                  <div
                    role="radiogroup"
                    aria-label="طريقة الدفع"
                    className="grid grid-cols-3 gap-1 p-1 rounded-lg bg-[#F1F5F9] border border-[#E2E8F0]"
                  >
                    {(
                      [
                        { value: 'cash' as PaymentMethod, label: 'نقداً', icon: Banknote },
                        { value: 'card' as PaymentMethod, label: 'بطاقة', icon: CreditCard },
                        {
                          value: 'transfer' as PaymentMethod,
                          label: 'تحويل',
                          icon: ArrowLeftRight,
                        },
                      ] as const
                    ).map((opt) => {
                      const Icon = opt.icon;
                      const active = paymentMethod === opt.value;
                      return (
                        <button
                          key={opt.value}
                          type="button"
                          role="radio"
                          aria-checked={active}
                          onClick={() => {
                            setPaymentMethod(opt.value);
                            markDirty();
                          }}
                          className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                            active
                              ? 'bg-[#0E2A52] text-white shadow-xs'
                              : 'text-[#475569] hover:text-[#0F172A]'
                          }`}
                        >
                          <Icon className="w-3.5 h-3.5 shrink-0" />
                          <span>{opt.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Totals Accounting Breakdown */}
                <div className="px-5 py-4 border-b border-[#E2E8F0] space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#64748B]">عدد الأصناف</span>
                    <span className="font-bold text-[#0F172A] tabular-nums">{activeItemCount}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#64748B]">إجمالي القطع</span>
                    <span className="font-bold text-[#0F172A] tabular-nums">{totalPieces}</span>
                  </div>

                  {/* Dominant Total Display */}
                  <div className="pt-3 mt-1 border-t border-[#E2E8F0]">
                    <div className="text-xs font-bold text-[#475569]">
                      المجموع الكلي المستحق
                    </div>
                    <div className="mt-1 flex items-baseline justify-between gap-2">
                      <span className="text-3xl font-black text-[#0E2A52] tabular-nums tracking-tight">
                        {formatIqd(totalIqd)}
                      </span>
                      <span className="text-sm font-extrabold text-[#475569] whitespace-nowrap">
                        دينار عراقي
                      </span>
                    </div>
                    <p className="mt-2 text-[11.5px] font-semibold text-[#64748B] leading-relaxed bg-[#F8FAFC] border border-[#E8EEF5] rounded-lg px-2.5 py-1.5">
                      {tafqeetText}
                    </p>
                  </div>
                </div>

                {/* Strict Action Hierarchy: 1 Primary CTA > Secondary Actions > Quiet Destructive */}
                <div className="p-5 space-y-2.5">
                  {/* Primary Action */}
                  <button
                    type="button"
                    disabled={isPrinting}
                    onClick={handlePrintInvoice}
                    className="w-full py-3 px-4 rounded-xl bg-[#0E2A52] hover:bg-[#163B70] disabled:opacity-60 disabled:cursor-not-allowed active:scale-[0.99] text-white font-extrabold text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
                  >
                    <Printer className="w-4.5 h-4.5 shrink-0" />
                    <span>{isPrinting ? 'جارٍ الإرسال للطابعة...' : 'طباعة الفاتورة'}</span>
                  </button>

                  {/* Secondary Actions Row */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleSaveInvoice}
                      className="py-2.5 px-3 rounded-lg bg-[#157347] hover:bg-[#115E3A] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <Save className="w-4 h-4 shrink-0" />
                      <span>حفظ الفاتورة</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsPrintPreviewOpen(true)}
                      className="py-2.5 px-3 rounded-lg bg-white hover:bg-[#F8FAFC] border border-[#CBD5E1] text-[#0E2A52] font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <Eye className="w-4 h-4 shrink-0 text-[#475569]" />
                      <span>معاينة الوصل</span>
                    </button>
                  </div>

                  {/* Destructive Action (Quiet & Deliberate) */}
                  <div className="pt-2 mt-1 border-t border-[#F1F5F9]">
                    <button
                      type="button"
                      onClick={() => setIsCancelConfirmOpen(true)}
                      className="w-full py-2 px-3 rounded-lg bg-white hover:bg-[#FEF2F2] text-[#B91C1C] border border-transparent hover:border-[#FECACA] font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                      <span>إلغاء وتفريغ الفاتورة</span>
                    </button>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </main>
      </div>

      {/* ================================================================
          DEDICATED PRINT-ENGINEERED COMMERCIAL RECEIPT (Matches Preview 1-to-1)
         ================================================================ */}
      <div id="printable-receipt-root" className="hidden print:block w-full">
        <InvoiceReceipt
          settings={settings}
          serialNumber={displaySerial}
          dateDisplay={displayDate}
          timeDisplay={displayTime}
          customerName={customerName}
          customerPhone={customerPhone}
          customerNotes={customerNotes}
          items={items}
          paymentMethod={paymentMethod}
          totalIqd={totalIqd}
        />
      </div>

      {/* MODALS (Pure React State — Zero URL Routing) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={handleSaveSettings}
        onTestPrint={(draft) => void handleTestPrint(draft)}
        onNotify={notify}
      />

      <InventoryModal
        isOpen={isInventoryOpen}
        isLoading={isLoadingInvoices}
        onClose={() => setIsInventoryOpen(false)}
        invoices={invoices}
        onLoadInvoice={handleLoadInvoice}
        onDeleteInvoice={handleDeleteInvoice}
        onImportInvoices={handleImportInvoices}
        onNotify={notify}
      />

      <PrintPreviewModal
        isOpen={isPrintPreviewOpen}
        isPrinting={isPrinting}
        onClose={() => setIsPrintPreviewOpen(false)}
        onConfirmPrint={() => void executeActualPrint()}
        onChangePaperSize={handleQuickPaperSizeChange}
        settings={settings}
        serialNumber={displaySerial}
        dateDisplay={displayDate}
        timeDisplay={displayTime}
        customerName={customerName}
        customerPhone={customerPhone}
        customerNotes={customerNotes}
        items={items}
        paymentMethod={paymentMethod}
        totalIqd={totalIqd}
      />

      <ConfirmModal
        isOpen={isCancelConfirmOpen}
        title="تأكيد إلغاء الفاتورة"
        message="هل أنت متأكد من رغبتك في إلغاء الفاتورة الحالية وتفريغ جميع الحقول والأصناف لبدء فاتورة جديدة؟"
        confirmLabel="نعم، تفريغ الفاتورة"
        cancelLabel="تراجع"
        onConfirm={handleConfirmCancelInvoice}
        onCancel={() => setIsCancelConfirmOpen(false)}
      />

      {/* TOAST NOTIFICATIONS (Hidden on print) */}
      {toasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed bottom-5 left-5 z-50 flex flex-col gap-2 max-w-sm print:hidden"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border text-sm font-bold ${
                toast.type === 'success'
                  ? 'bg-[#157347] text-white border-[#115E3A]'
                  : toast.type === 'error'
                  ? 'bg-[#C8102E] text-white border-[#9E0C24]'
                  : 'bg-[#0E2A52] text-white border-[#091D3A]'
              }`}
            >
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : toast.type === 'error' ? (
                <AlertCircle className="w-5 h-5 shrink-0" />
              ) : (
                <Info className="w-5 h-5 text-[#FFD000] shrink-0" />
              )}
              <span>{toast.text}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
