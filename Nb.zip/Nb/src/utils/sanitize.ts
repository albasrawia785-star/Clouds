/**
 * Security & Sanitization Utilities
 * Provides XSS prevention, HTML escaping, and cryptographic checksum validation
 * for data integrity (anti-tampering for backups).
 */

/**
 * Escapes unsafe HTML characters to prevent XSS / HTML injection
 * when rendering dynamic user data into HTML or PDF generation templates.
 */
export function escapeHtml(unsafe: unknown): string {
  if (unsafe == null) return '';
  return String(unsafe)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Sanitizes plain text by removing null bytes, script tags, and non-printable control characters.
 */
export function sanitizePlainText(input: unknown): string {
  if (input == null) return '';
  return String(input)
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F]/g, '')
    .trim();
}

/**
 * Computes a robust cryptographic SHA-256 integrity hash for objects or strings.
 * Used to sign and verify backup files to ensure they were not tampered with.
 */
export async function computeIntegrityHash(payload: unknown): Promise<string> {
  try {
    const rawString = typeof payload === 'string' ? payload : JSON.stringify(payload);
    const encoder = new TextEncoder();
    const data = encoder.encode(rawString);

    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
      return `sha256-${hashHex}`;
    }
  } catch {
    // Fallback to deterministic hash if WebCrypto is unavailable
  }

  // Fast deterministic fallback hash
  const str = typeof payload === 'string' ? payload : JSON.stringify(payload);
  let hash1 = 0x811c9dc5;
  let hash2 = 0x27d4eb2f;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    hash1 = (hash1 ^ code) * 0x01000193;
    hash2 = (hash2 ^ (code >> 4)) * 0x01000193;
  }
  return `h-${(hash1 >>> 0).toString(16)}-${(hash2 >>> 0).toString(16)}`;
}

/**
 * Verifies if the integrity hash of a backup payload matches its expected value.
 */
export async function verifyIntegrityHash(payload: unknown, expectedHash: string): Promise<boolean> {
  if (!expectedHash) return false;
  const computed = await computeIntegrityHash(payload);
  return computed.toLowerCase() === expectedHash.toLowerCase();
}

/**
 * Secure password storage & obfuscation utilities
 * Eliminates plain-text password exposure in browser LocalStorage.
 * Seamlessly migrates existing legacy passwords on-the-fly without breaking active sessions.
 */
const SEC_PWD_PREFIX = 'sec_pwd_';
const DEVICE_SALT = 'al_dion_v3_secure_salt_785';

export function setSecuredPassword(key: string | number, plainPass: string): void {
  if (typeof window === 'undefined' || !key || !plainPass) return;
  try {
    const rawKey = String(key).replace(/^(user_pwd_|sec_pwd_)/, '');
    let obfuscated = '';
    for (let i = 0; i < plainPass.length; i++) {
      const charCode = plainPass.charCodeAt(i) ^ DEVICE_SALT.charCodeAt(i % DEVICE_SALT.length);
      obfuscated += String.fromCharCode(charCode);
    }
    const b64 = btoa(encodeURIComponent(obfuscated));
    localStorage.setItem(`${SEC_PWD_PREFIX}${rawKey}`, b64);
    // Erase plain-text legacy entry immediately for security
    localStorage.removeItem(`user_pwd_${rawKey}`);
  } catch {
    // Graceful fallback to legacy key if base64/URI encoding fails
    localStorage.setItem(`user_pwd_${String(key)}`, plainPass);
  }
}

export function getSecuredPassword(key: string | number): string {
  if (typeof window === 'undefined' || !key) return '';
  try {
    const rawKey = String(key).replace(/^(user_pwd_|sec_pwd_)/, '');
    
    // 1. Try reading the secured obfuscated password
    const securedVal = localStorage.getItem(`${SEC_PWD_PREFIX}${rawKey}`);
    if (securedVal) {
      const obfuscated = decodeURIComponent(atob(securedVal));
      let plain = '';
      for (let i = 0; i < obfuscated.length; i++) {
        const charCode = obfuscated.charCodeAt(i) ^ DEVICE_SALT.charCodeAt(i % DEVICE_SALT.length);
        plain += String.fromCharCode(charCode);
      }
      return plain;
    }

    // 2. Backward compatibility: if legacy plaintext exists, migrate it to secured storage
    const legacyVal = localStorage.getItem(`user_pwd_${rawKey}`);
    if (legacyVal) {
      setSecuredPassword(rawKey, legacyVal);
      return legacyVal;
    }
  } catch {
    // If decryption error, fallback to legacy
    return localStorage.getItem(`user_pwd_${String(key)}`) || '';
  }
  return '';
}
/**
 * Symmetric Cloud & Storage Secret Cipher (encv3)
 * Encrypts sensitive fields (plain_password, custom DB URLs & tokens) before storing
 * in cloud tables (users.plain_password, databases_registry) or browser LocalStorage.
 * Seamlessly supports legacy unencrypted values on read without breaking existing accounts.
 */
const CLOUD_CIPHER_PREFIX = 'encv3:';
const _VAULT_KEY_SHARDS: number[] = [
  0x7a, 0x3f, 0x91, 0xc4, 0x58, 0xe2, 0x1b, 0x6d,
  0xa9, 0x47, 0xd0, 0x85, 0x2e, 0xf3, 0x64, 0xb8,
  0x19, 0xc7, 0x82, 0x5a, 0xe6, 0x31, 0x9c, 0x4f,
  0xd5, 0x73, 0x28, 0xae, 0x61, 0xf9, 0x0c, 0x8b,
];

function _deriveStreamByte(nonce: Uint8Array, index: number): number {
  const shardA = _VAULT_KEY_SHARDS[index & 31];
  const shardB = _VAULT_KEY_SHARDS[(index * 7 + 3) & 31];
  const n0 = nonce[index & 7];
  const n1 = nonce[(index + 3) & 7];
  const n2 = nonce[(index + 5) & 7];

  let h = (0x9e3779b9 ^ (index * 0x85ebca6b) ^ (shardA << 16) ^ (shardB << 8) ^ n0 ^ (n1 << 8) ^ (n2 << 16)) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 0x85ebca6b) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35) >>> 0;
  h = (h ^ (h >>> 16)) >>> 0;
  return h & 0xff;
}

export function encryptCloudSecret(plain: string | null | undefined): string {
  if (!plain) return '';
  const str = String(plain);
  if (str.startsWith(CLOUD_CIPHER_PREFIX)) return str;

  try {
    const nonce = new Uint8Array(8);
    if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
      window.crypto.getRandomValues(nonce);
    } else {
      for (let i = 0; i < 8; i++) {
        nonce[i] = Math.floor(Math.random() * 256);
      }
    }

    const plainBytes = new TextEncoder().encode(str);
    const cipherBytes = new Uint8Array(plainBytes.length);
    for (let i = 0; i < plainBytes.length; i++) {
      cipherBytes[i] = plainBytes[i] ^ _deriveStreamByte(nonce, i);
    }

    const nonceHex = Array.from(nonce)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');

    let bin = '';
    for (let i = 0; i < cipherBytes.length; i++) {
      bin += String.fromCharCode(cipherBytes[i]);
    }
    const b64 = btoa(bin);
    return `${CLOUD_CIPHER_PREFIX}${nonceHex}:${b64}`;
  } catch {
    return str;
  }
}

export function decryptCloudSecret(stored: string | null | undefined): string {
  if (!stored) return '';
  const str = String(stored);
  if (!str.startsWith(CLOUD_CIPHER_PREFIX)) {
    return str;
  }

  try {
    const body = str.slice(CLOUD_CIPHER_PREFIX.length);
    const sepIdx = body.indexOf(':');
    if (sepIdx !== 16) return str;

    const nonceHex = body.slice(0, 16);
    const b64 = body.slice(17);

    const nonce = new Uint8Array(8);
    for (let i = 0; i < 8; i++) {
      nonce[i] = parseInt(nonceHex.slice(i * 2, i * 2 + 2), 16) || 0;
    }

    const bin = atob(b64);
    const cipherBytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
      cipherBytes[i] = bin.charCodeAt(i);
    }

    const plainBytes = new Uint8Array(cipherBytes.length);
    for (let i = 0; i < cipherBytes.length; i++) {
      plainBytes[i] = cipherBytes[i] ^ _deriveStreamByte(nonce, i);
    }

    return new TextDecoder().decode(plainBytes);
  } catch {
    return str;
  }
}
