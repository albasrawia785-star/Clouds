/**
 * Local-First Lightweight Error & System Event Logger
 * Stores recent client-side errors and warnings in localStorage only.
 * Consumes 0 bytes of cloud storage and 0 cloud reads/writes.
 */

export interface SystemErrorEvent {
  id: string;
  type: 'error' | 'warning' | 'info';
  message: string;
  details?: string;
  timestamp: string; // ISO
}

const LOCAL_STORAGE_ERRORS_KEY = 'aldion_local_system_errors';
const MAX_LOCAL_ERRORS = 10;

export function getLocalSystemErrors(): SystemErrorEvent[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_ERRORS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function logLocalSystemError(
  message: string,
  type: 'error' | 'warning' | 'info' = 'error',
  details?: string
): void {
  if (typeof window === 'undefined') return;
  try {
    const current = getLocalSystemErrors();
    const newEvent: SystemErrorEvent = {
      id: `err_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      type,
      message,
      details,
      timestamp: new Date().toISOString(),
    };

    const updated = [newEvent, ...current].slice(0, MAX_LOCAL_ERRORS);
    localStorage.setItem(LOCAL_STORAGE_ERRORS_KEY, JSON.stringify(updated));
  } catch {}
}

export function clearLocalSystemErrors(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(LOCAL_STORAGE_ERRORS_KEY);
  } catch {}
}
