import React, { useState } from 'react';
import { Manager, SubscriptionType, ManagerModuleAccess, DatabaseAccount, AppLayoutTheme } from '../types';
import { formatDateDigits, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { testDatabaseConnection, syncDatabasesToCloud } from '../services/turso';
import { LAYOUT_THEMES, getLayoutThemeMeta } from '../utils/layoutThemes';
import { ThemePickerModal } from './ThemePickerModal';
import { getSecuredPassword } from '../utils/sanitize';
import { openWhatsAppUrlDirect } from '../utils/whatsapp';


interface ManagersTabProps {
  managers: Manager[];
  databases?: DatabaseAccount[];
  globalEmergencyFreeze?: boolean;
  globalEmergencyFreezeMessage?: string;
  onRefreshDatabases?: () => Promise<void> | void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
  onCreateManager: (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType,
    subscriptionMonths?: number,
    allowedModules?: ManagerModuleAccess,
    databaseId?: string | null,
    layoutTheme?: AppLayoutTheme,
    allowInvoiceUpload?: boolean,
    allowSupervisorManagement?: boolean
  ) => Promise<void>;
  onToggleManagerStatus: (id: number, currentActive: boolean) => Promise<void>;
  onRenewSubscription: (id: number, months?: number) => Promise<void>;
  onChangeSubscriptionType?: (id: number, newType: SubscriptionType, months?: number) => Promise<void>;
  onChangeManagerModules?: (id: number, newAllowedModules: ManagerModuleAccess) => Promise<void>;
  onChangeManagerDatabase?: (id: number, databaseId: string | null) => Promise<void>;
  onChangeManagerTheme?: (id: number, newTheme: AppLayoutTheme) => Promise<void>;
  onToggleManagerInvoiceUpload?: (id: number, allowed: boolean) => Promise<void>;
  onToggleManagerSupervisorManagement?: (id: number | string, allowed: boolean) => Promise<void> | void;
  onBulkToggleManagerInvoiceUpload?: (allowed: boolean, managerIds?: number[]) => Promise<void>;
  onDeleteManager: (id: number) => void;
  onUpdateManagerPassword?: (id: number, newPass: string) => Promise<void>;
  onUpgradeNewRegistration?: (
    id: number,
    subscriptionType: SubscriptionType,
    months?: number,
    allowedModules?: ManagerModuleAccess,
    databaseId?: string | null,
    layoutTheme?: AppLayoutTheme
  ) => Promise<void>;
  onToggleGlobalFreeze?: (enable: boolean, message?: string) => Promise<void>;
  onToggleManagerSuspend?: (id: number, suspend: boolean, message?: string) => Promise<void>;
  onRefreshManagers?: () => Promise<void> | void;
  isLoading?: boolean;
}

export const ManagersTab: React.FC<ManagersTabProps> = ({
  managers,
  databases = [],
  globalEmergencyFreeze = false,
  globalEmergencyFreezeMessage = '',
  onRefreshDatabases,
  onShowToast,
  onCreateManager,
  onToggleManagerStatus,
  onRenewSubscription,
  onChangeSubscriptionType,
  onChangeManagerModules,
  onChangeManagerDatabase,
  onChangeManagerTheme,
  onToggleManagerInvoiceUpload,
  onToggleManagerSupervisorManagement,
  onBulkToggleManagerInvoiceUpload,
  onDeleteManager,
  onUpdateManagerPassword,
  onUpgradeNewRegistration,
  onToggleGlobalFreeze,
  onToggleManagerSuspend,
  onRefreshManagers,
  isLoading = false,
}) => {
  const { t, numberFormat, dir } = useI18n();

  // Active top-level sub-tab: 'active_managers' | 'new_accounts'
  const [activeTab, setActiveTab] = useState<'active_managers' | 'new_accounts'>('active_managers');

  // Suspension Modal State (for global or single manager)
  const [suspendModalOpen, setSuspendModalOpen] = useState(false);
  const [suspendTargetManager, setSuspendTargetManager] = useState<Manager | null>(null);
  const [suspendMessageInput, setSuspendMessageInput] = useState('');
  const [isSubmittingSuspend, setIsSubmittingSuspend] = useState(false);

  // Form states for creating manager manually
  const [branchName, setBranchName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [subscriptionType, setSubscriptionType] = useState<SubscriptionType>('permanent');
  const [subscriptionMonths, setSubscriptionMonths] = useState<number>(1);
  const [subscriptionYears, setSubscriptionYears] = useState<number>(1);
  const [allowedModules, setAllowedModules] = useState<ManagerModuleAccess>('both');
  const [selectedDatabaseId, setSelectedDatabaseId] = useState<string>('default');
  const [selectedLayoutTheme, setSelectedLayoutTheme] = useState<AppLayoutTheme>('classic');
  const [allowInvoiceUpload, setAllowInvoiceUpload] = useState<boolean>(true);
  const [allowSupervisorManagement, setAllowSupervisorManagement] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionInProgressId, setActionInProgressId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, boolean>>({});
  const [copiedManagerId, setCopiedManagerId] = useState<number | null>(null);
  const [shareSuccessManagerId, setShareSuccessManagerId] = useState<number | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Helper to strictly evaluate whether a manager is permitted to manage supervisors
  const isManagerSupervisorAllowed = (mgr: Manager): boolean => {
    const v: any = mgr.allowSupervisorManagement;
    return v === true || v === 1 || v === '1' || v === 'true';
  };

  // Theme Picker Modal State for selecting visual themes
  const [themePickerManager, setThemePickerManager] = useState<Manager | null>(null);

  // Inline "Add New Database" states inside modal or form
  const [showAddDbModal, setShowAddDbModal] = useState(false);
  const [newDbName, setNewDbName] = useState('');
  const [newDbUrl, setNewDbUrl] = useState('');
  const [newDbToken, setNewDbToken] = useState('');
  const [newDbDesc, setNewDbDesc] = useState('');
  const [newDbMode, setNewDbMode] = useState<'isolated' | 'dual_sync'>('isolated');
  const [newDbStorageLocation, setNewDbStorageLocation] = useState<'default' | 'isolated'>('default');
  const [isTestingNewDb, setIsTestingNewDb] = useState(false);
  const [isSavingNewDb, setIsSavingNewDb] = useState(false);
  const [newDbTestResult, setNewDbTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [newDbError, setNewDbError] = useState<string | null>(null);

  // Password editing state for Admin
  const [editingPasswordManagerId, setEditingPasswordManagerId] = useState<number | null>(null);
  const [editingPasswordInput, setEditingPasswordInput] = useState('');
  const [isSavingPasswordId, setIsSavingPasswordId] = useState<number | null>(null);

  const [filterDbId, setFilterDbId] = useState<string>('all');
  const [subTypeFilter, setSubTypeFilter] = useState<'all' | 'permanent' | 'yearly' | 'monthly'>('all');
  // Groups are closed / collapsed by default upon entering the tab
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  // Helper to strictly evaluate whether a manager is permitted to upload invoice photos
  const isManagerUploadAllowed = (mgr: Manager): boolean => {
    const v: any = mgr.allowInvoiceUpload;
    if (v === false || v === 0 || v === '0' || v === 'false') {
      return false;
    }
    return true;
  };

  // Active Cloud Sub-Managers (excluding main admin)
  const activeManagers = React.useMemo(() => {
    return managers.filter((m) => m.username?.toLowerCase() !== 'admin');
  }, [managers]);

  const [isBulkUpdatingInvoices, setIsBulkUpdatingInvoices] = useState<boolean>(false);

  const invoiceUploadStats = React.useMemo(() => {
    const list = activeManagers.length > 0 ? activeManagers : managers;
    const total = list.length;
    const allowed = list.filter(isManagerUploadAllowed).length;
    const disallowed = total - allowed;
    return { total, allowed, disallowed };
  }, [activeManagers, managers]);

  const handleBulkToggle = async (allowed: boolean) => {
    if (!onBulkToggleManagerInvoiceUpload) {
      if (onShowToast) onShowToast('خاصية التحكم الجماعي غير متوفرة', 'error');
      return;
    }
    try {
      setIsBulkUpdatingInvoices(true);
      await onBulkToggleManagerInvoiceUpload(allowed);
    } catch (err: any) {
      if (onShowToast) onShowToast(err.message || 'حدث خطأ أثناء تعديل صلاحيات الفواتير', 'error');
    } finally {
      setIsBulkUpdatingInvoices(false);
    }
  };

  const yearlyCount = React.useMemo(() => {
    return managers.filter((m) => !m.isNewRegistration && m.subscriptionType === 'yearly').length;
  }, [managers]);

  const monthlyCount = React.useMemo(() => {
    return managers.filter((m) => !m.isNewRegistration && m.subscriptionType === 'monthly').length;
  }, [managers]);

  const permanentCount = React.useMemo(() => {
    return managers.filter((m) => !m.isNewRegistration && (m.subscriptionType === 'permanent' || m.subscriptionType === 'local_permanent')).length;
  }, [managers]);

  const filteredActiveManagers = React.useMemo(() => {
    return activeManagers.filter((m) => {
      if (subTypeFilter === 'yearly') return m.subscriptionType === 'yearly';
      if (subTypeFilter === 'monthly') return m.subscriptionType === 'monthly';
      if (subTypeFilter === 'permanent') return m.subscriptionType === 'permanent' || m.subscriptionType === 'local_permanent';
      return true;
    });
  }, [activeManagers, subTypeFilter]);

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  const handleToggleAllGroups = (expand: boolean) => {
    const next: Record<string, boolean> = {};
    databaseGroups.forEach((g) => {
      next[g.id] = expand;
    });
    setExpandedGroups(next);
  };

  // Group active managers by Database
  const databaseGroups = React.useMemo(() => {
    const isDedicatedThird = (dbId: string | null | undefined) =>
      dbId === 'builtin_third_alidion2' || dbId === 'alidion2' || dbId === 'third';

    const customDbIds = new Set(databases.map((d) => d.id));

    const isCustomDb = (dbId: string | null | undefined) =>
      Boolean(dbId && customDbIds.has(dbId));

    const isDefault = (dbId: string | null | undefined) =>
      !dbId || dbId === 'default' || (!isDedicatedThird(dbId) && !isCustomDb(dbId));

    const groups: {
      id: string;
      name: string;
      url?: string;
      isMain: boolean;
      managers: Manager[];
    }[] = [
      {
        id: 'default',
        name: 'القاعدة الرئيسية (الافتراضية)',
        isMain: true,
        managers: filteredActiveManagers.filter((m) => isDefault(m.databaseId)),
      },
      {
        id: 'builtin_third_alidion2',
        name: 'القاعدة الثالثة المنفصلة (alidion2)',
        isMain: false,
        managers: filteredActiveManagers.filter((m) => isDedicatedThird(m.databaseId)),
      },
    ];

    databases.forEach((db) => {
      groups.push({
        id: db.id,
        name: db.name,
        url: db.url,
        isMain: false,
        managers: filteredActiveManagers.filter((m) => m.databaseId === db.id),
      });
    });

    return groups;
  }, [filteredActiveManagers, databases]);

  const displayedGroups = React.useMemo(() => {
    if (filterDbId === 'all') {
      return databaseGroups;
    }
    return databaseGroups.filter((g) => g.id === filterDbId);
  }, [databaseGroups, filterDbId]);

  const togglePasswordVisibility = (id: number) => {
    setRevealedPasswords((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyManagerPassword = (id: number, pwd: string) => {
    try {
      navigator.clipboard.writeText(pwd);
      setCopiedManagerId(id);
      setTimeout(() => setCopiedManagerId(null), 2000);
    } catch {
      // Fallback
    }
  };

  // Share login credentials via WhatsApp without emojis
  const handleShareCredentials = (mgr: Manager, pwd: string) => {
    const bName = mgr.branch || t('common.branch', 'الفرع');
    const message = `مرحبا بك (${bName})\nاسم المستخدم: ${mgr.username}\nالرمز السري: ${pwd}\n`;

    try {
      navigator.clipboard.writeText(message);
    } catch {}

    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
    openWhatsAppUrlDirect(url);

    setShareSuccessManagerId(mgr.id);
    setTimeout(() => setShareSuccessManagerId(null), 3000);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedBranch = branchName.trim();
    const trimmedUser = username.trim();
    const trimmedPass = password.trim();

    if (!trimmedBranch || !trimmedUser || !trimmedPass) {
      setError(t('managers.enterAllFieldsError', 'يرجى ملء جميع الحقول المطلوبة بشكل صحيح'));
      return;
    }

    if (trimmedPass.length < 3) {
      setError(t('managers.passwordMinLength', 'كلمة المرور يجب أن لا تقل عن 3 خانات'));
      return;
    }

    try {
      setIsSubmitting(true);
      await onCreateManager(
        trimmedBranch,
        trimmedUser,
        trimmedPass,
        subscriptionType,
        subscriptionType === 'monthly'
          ? subscriptionMonths
          : subscriptionType === 'yearly'
          ? subscriptionYears * 12
          : undefined,
        allowedModules,
        selectedDatabaseId === 'default' ? null : selectedDatabaseId,
        selectedLayoutTheme,
        allowInvoiceUpload,
        allowSupervisorManagement
      );

      setBranchName('');
      setUsername('');
      setPassword('');
      setSubscriptionType('permanent');
      setSubscriptionMonths(1);
      setSubscriptionYears(1);
      setAllowedModules('both');
      setSelectedDatabaseId('default');
      setSelectedLayoutTheme('classic');
      setAllowInvoiceUpload(true);
      setAllowSupervisorManagement(true);
    } catch (err: any) {
      setError(err.message || t('toast.backupError', 'حدث خطأ أثناء إضافة الحساب'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveManagerPassword = async (managerId: number) => {
    const trimmed = editingPasswordInput.trim();
    if (!trimmed) {
      setError(t('settings.enterNewPassword', 'يرجى إدخال كلمة المرور الجديدة'));
      return;
    }
    if (trimmed.length < 3) {
      setError(t('settings.passwordMin3', 'كلمة المرور يجب ألا تقل عن 3 خانات'));
      return;
    }

    try {
      setIsSavingPasswordId(managerId);
      setError(null);
      if (onUpdateManagerPassword) {
        await onUpdateManagerPassword(managerId, trimmed);
      }
      setEditingPasswordManagerId(null);
      setEditingPasswordInput('');
    } catch (err: any) {
      setError(err.message || t('settings.passwordSaveFailed', 'فشل حفظ كلمة المرور'));
    } finally {
      setIsSavingPasswordId(null);
    }
  };

  // Test new database connection helper
  const handleTestNewDb = async () => {
    if (!newDbUrl.trim() || !newDbToken.trim()) {
      setNewDbTestResult({
        ok: false,
        message: 'يرجى كتابة رابط القاعدة ومفتاح التوكن أولاً لفحص الاتصال وتهيئتها',
      });
      return;
    }
    setIsTestingNewDb(true);
    setNewDbTestResult(null);
    setNewDbError(null);
    try {
      const res = await testDatabaseConnection(newDbUrl.trim(), newDbToken.trim(), true);
      setNewDbTestResult(res);
    } catch (err: any) {
      setNewDbTestResult({
        ok: false,
        message: err?.message || 'فشل الاتصال بالقاعدة أو تهيئتها',
      });
    } finally {
      setIsTestingNewDb(false);
    }
  };

  // Save new database helper
  const handleSaveNewDb = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewDbError(null);
    const name = newDbName.trim();
    const url = newDbUrl.trim();
    const token = newDbToken.trim();

    if (!name || !url || !token) {
      setNewDbError('يرجى كتابة اسم القاعدة، رابط القاعدة (libsql://...)، ومفتاح التوكن (JWT)');
      return;
    }

    try {
      setIsSavingNewDb(true);
      const testRes = await testDatabaseConnection(url, token, true);
      if (!testRes.ok) {
        throw new Error(testRes.message || 'تعذر الاتصال بالقاعدة أو تهيئتها');
      }

      const newAcc: DatabaseAccount = {
        id: 'db_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        name,
        url,
        token,
        description: newDbDesc.trim(),
        isDedicated: newDbMode === 'isolated',
        connectionMode: newDbMode,
        storageLocation: newDbStorageLocation,
        createdAt: new Date().toISOString(),
      };

      const updated = [...databases, newAcc];
      await syncDatabasesToCloud(updated);

      if (onRefreshDatabases) {
        await onRefreshDatabases();
      }

      // Auto-select this newly created database in the active flow
      setSelectedDatabaseId(newAcc.id);

      if (onShowToast) {
        const destText = newDbStorageLocation === 'isolated' ? 'في القاعدة المنفصلة 🛡️' : 'في القاعدة الافتراضية 🌐';
        onShowToast(`تمت إضافة وتهيئة قاعدة البيانات "${newAcc.name}" وتجهيز جداول الزبائن بنجاح! وحُفظ تسجيلها ${destText}`, 'success');
      }

      // Reset and close submodal
      setNewDbName('');
      setNewDbUrl('');
      setNewDbToken('');
      setNewDbDesc('');
      setNewDbTestResult(null);
      setNewDbError(null);
      setShowAddDbModal(false);
    } catch (err: any) {
      setNewDbError(err?.message || 'حدث خطأ أثناء حفظ قاعدة البيانات');
    } finally {
      setIsSavingNewDb(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300" dir={dir}>
      {/* Top Header & Section Switcher */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm shadow-xs">
              <i className="fa-solid fa-users-gear"></i>
            </div>
            <span>إدارة الحسابات والمدراء</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            إدارة صلاحيات مدراء الحسابات، اعتماد الحسابات الجديدة، وتخصيص قواعد البيانات
          </p>
        </div>

        {/* Top Tab Switcher with Subscription Categories */}
        <div className="flex items-center gap-1.5 bg-slate-100/90 p-1.5 rounded-2xl shrink-0 flex-wrap">
          <button
            type="button"
            onClick={() => setSubTypeFilter('all')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              subTypeFilter === 'all'
                ? 'bg-white text-blue-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <i className="fa-solid fa-users text-xs"></i>
            <span>كل المدراء</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100/70 text-blue-700 font-extrabold">
              {activeManagers.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSubTypeFilter('permanent')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              subTypeFilter === 'permanent'
                ? 'bg-white text-emerald-700 shadow-xs border border-emerald-200/80 ring-2 ring-emerald-500/20'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <i className="fa-solid fa-shield-check text-xs text-emerald-600"></i>
            <span>الاشتراكات الدائمة</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-extrabold">
              {permanentCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSubTypeFilter('yearly')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              subTypeFilter === 'yearly'
                ? 'bg-white text-amber-700 shadow-xs border border-amber-200/80 ring-2 ring-amber-500/20'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <i className="fa-solid fa-calendar-check text-xs text-amber-600"></i>
            <span>الاشتراكات السنوية</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-extrabold">
              {yearlyCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSubTypeFilter('monthly')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              subTypeFilter === 'monthly'
                ? 'bg-white text-purple-700 shadow-xs border border-purple-200/80 ring-2 ring-purple-500/20'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <i className="fa-solid fa-calendar-days text-xs text-purple-600"></i>
            <span>الاشتراكات الشهرية</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 font-extrabold">
              {monthlyCount}
            </span>
          </button>
        </div>
      </div>

      {/* Global Master Freeze Banner / Switch */}
      <div className={`p-4 rounded-3xl border transition-all ${
        globalEmergencyFreeze
          ? 'bg-rose-50/90 border-rose-300 ring-2 ring-rose-400/30'
          : 'bg-slate-50/80 border-slate-200'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-lg shrink-0 shadow-xs ${
              globalEmergencyFreeze
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-slate-200 text-slate-700'
            }`}>
              <i className={`fa-solid ${globalEmergencyFreeze ? 'fa-triangle-exclamation' : 'fa-hand'}`}></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                  الإيقاف اللحظي العام (لكافة المدراء والفروع)
                </h4>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                  globalEmergencyFreeze
                    ? 'bg-rose-600 text-white animate-pulse'
                    : 'bg-slate-200 text-slate-700'
                }`}>
                  {globalEmergencyFreeze ? 'مفعّل حالياً (جميع المدراء متوقفون)' : 'معطّل (العمل طبيعي)'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {globalEmergencyFreeze
                  ? `الرسالة المعروضة للمدراء: "${globalEmergencyFreezeMessage || 'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة'}"`
                  : 'تجميد وقفل كافة صلاحيات الإضافة والتسديد لجميع مدراء الحسابات بلحظة واحدة مع إرسال رسالة توجيهية.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {globalEmergencyFreeze ? (
              <button
                type="button"
                onClick={() => onToggleGlobalFreeze && onToggleGlobalFreeze(false)}
                className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
              >
                <i className="fa-solid fa-lock-open text-xs"></i>
                <span>إلغاء الإيقاف واستئناف العمل للجميع</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setSuspendTargetManager(null);
                  setSuspendMessageInput(globalEmergencyFreezeMessage || 'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة، يرجى مراجعة الإدارة.');
                  setSuspendModalOpen(true);
                }}
                className="w-full sm:w-auto px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
              >
                <i className="fa-solid fa-hand text-xs"></i>
                <span>إيقاف لحظي لكافة المدراء</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Global Error Banner */}
      {error && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold rounded-2xl flex items-center justify-between gap-2 animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation text-rose-500 text-sm shrink-0"></i>
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-rose-500 hover:text-rose-700 cursor-pointer p-1"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SECTION: قائمة المدراء المعتمدين (Active Managers) */}
      {/* ---------------------------------------------------- */}
      <div className="space-y-6 animate-in fade-in duration-200">
          {/* Add Manager Form Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 mb-4">
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm font-bold shrink-0">
                <i className="fa-solid fa-user-plus"></i>
              </div>
              <h3 className="font-bold text-sm text-slate-900">
                {t('managers.addManagerTitle', 'إضافة مدير حساب جديد يدوياً')}
              </h3>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Branch Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('managers.branchName', 'اسم الفرع / المتجر')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={branchName}
                    onChange={(e) => setBranchName(e.target.value)}
                    placeholder="مثال: فرع الكرادة"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                    required
                  />
                </div>

                {/* Username */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('managers.username', 'اسم المستخدم')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="مثال: manager_karada"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                    required
                  />
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('managers.password', 'كلمة المرور')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="اكتب كلمة المرور..."
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-mono font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                    required
                  />
                </div>
              </div>

              {/* Subscriptions & Permissions & Database row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                {/* Subscription Type */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    نوع الاشتراك
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={subscriptionType}
                      onChange={(e) => setSubscriptionType(e.target.value as SubscriptionType)}
                      className="flex-1 bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                    >
                      <option value="permanent">دائمي (سحابي + محلي)</option>
                      <option value="yearly">سنوي (12 شهر - سحابي)</option>
                      <option value="monthly">شهري (محدد بالمدة)</option>
                      <option value="local_permanent">دائمي (تخزين محلي فقط - بدون سحابة)</option>
                    </select>

                    {subscriptionType === 'monthly' && (
                      <select
                        value={subscriptionMonths}
                        onChange={(e) => setSubscriptionMonths(Number(e.target.value))}
                        className="w-24 bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                      >
                        <option value={1}>شهر 1</option>
                        <option value={3}>3 أشهر</option>
                        <option value={6}>6 أشهر</option>
                        <option value={12}>سنة كاملة</option>
                      </select>
                    )}

                    {subscriptionType === 'yearly' && (
                      <select
                        value={subscriptionYears}
                        onChange={(e) => setSubscriptionYears(Number(e.target.value))}
                        className="w-28 bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                      >
                        <option value={1}>سنة واحدة (1)</option>
                        <option value={2}>سنتان (2)</option>
                        <option value={3}>3 سنوات (3)</option>
                      </select>
                    )}
                  </div>
                </div>

                {/* Permissions Module */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الأنظمة المصرح بها
                  </label>
                  <select
                    value={allowedModules}
                    onChange={(e) => setAllowedModules(e.target.value as ManagerModuleAccess)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                  >
                    <option value="both">كافة الأنظمة الشاملة (ديون + أقساط + موردين + ديون عليّ)</option>
                    <option value="debts_installments">دفتر ديون + نظام أقساط</option>
                    <option value="debts_suppliers">دفتر ديون + نظام الموردين</option>
                    <option value="installments_suppliers">نظام أقساط + نظام الموردين</option>
                    <option value="debts">دفتر الديون فقط (المدينين)</option>
                    <option value="installments">نظام الأقساط فقط</option>
                    <option value="suppliers">نظام الموردين فقط (الذين يطلبونك)</option>
                    <option value="creditors">سجل ديون عليّ فقط</option>
                  </select>
                </div>

                {/* Database Assignment */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      قاعدة البيانات المخصصة
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowAddDbModal(true)}
                      className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <i className="fa-solid fa-plus text-[10px]"></i>
                      <span>إضافة سيرفر جديد</span>
                    </button>
                  </div>
                  <select
                    value={selectedDatabaseId}
                    onChange={(e) => setSelectedDatabaseId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                  >
                    <option value="default">الربط بالقاعدة الافتراضية والثانوية معاً (نسخ متزامن مزدوج)</option>
                    <option value="builtin_third_alidion2">الربط بقاعدة منفصلة ومستقلة (alidion2)</option>
                    {databases.map((db) => {
                      const modeLabel = db.isDedicated || db.connectionMode === 'isolated' ? 'قاعدة منفصلة' : 'قاعدة ثانوية';
                      const locLabel = db.storageLocation === 'isolated' ? 'مسجلة في المنفصلة 🛡️' : 'مسجلة في الافتراضية 🌐';
                      return (
                        <option key={db.id} value={db.id}>
                          {`${modeLabel}: ${db.name} (${locLabel})`}
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* Visual Layout Theme */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      مظهر وتصميم الواجهة (10 تصاميم)
                    </label>
                    <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-md">
                      {getLayoutThemeMeta(selectedLayoutTheme).badge}
                    </span>
                  </div>
                  <select
                    value={selectedLayoutTheme}
                    onChange={(e) => setSelectedLayoutTheme(e.target.value as AppLayoutTheme)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                  >
                    {LAYOUT_THEMES.map((th) => (
                      <option key={th.id} value={th.id}>
                        {th.title} ({th.badge}) - {th.englishTitle}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Allow Invoice Upload Permission Checkbox */}
                <div className="sm:col-span-3 pt-1 space-y-2">
                  <label className="flex items-center gap-2 p-3 bg-slate-50 hover:bg-slate-100/80 rounded-2xl border border-slate-200/90 cursor-pointer select-none transition-colors">
                    <input
                      type="checkbox"
                      checked={allowInvoiceUpload}
                      onChange={(e) => setAllowInvoiceUpload(e.target.checked)}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer"
                    />
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                      <i className="fa-solid fa-receipt text-blue-600"></i>
                      <span>السماح لهذا المدير بإرفاق صور الفواتير</span>
                    </div>
                    <span className="text-[10px] text-slate-400 mr-auto font-normal">
                      (تحديد إمكانية تصوير ورفع وصولات الفواتير)
                    </span>
                  </label>

                  <label className="flex items-center gap-2 p-3 bg-indigo-50/60 hover:bg-indigo-50/90 rounded-2xl border border-indigo-200/90 cursor-pointer select-none transition-colors">
                    <input
                      type="checkbox"
                      checked={allowSupervisorManagement}
                      onChange={(e) => setAllowSupervisorManagement(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                    />
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                      <i className="fa-solid fa-user-shield text-indigo-600"></i>
                      <span>تفعيل خاصية إدارة وتتبع المشرفين (إضافة وتتبع الموظفين)</span>
                    </div>
                    <span className="text-[10px] text-indigo-600/80 mr-auto font-bold">
                      (إدارة وتتبع المشرفين والموظفين)
                    </span>
                  </label>
                </div>
              </div>

              {/* Submit button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2.5 px-6 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all cursor-pointer flex items-center gap-2 shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الإضافة...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-plus text-xs"></i>
                      <span>حفظ وإضافة المدير</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* General & Bulk Control for Invoice Photos Upload */}
          <div className="bg-gradient-to-r from-blue-50/70 via-indigo-50/40 to-slate-50 border border-blue-200/90 rounded-3xl p-4 shadow-xs">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3.5">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center text-base shrink-0 shadow-xs mt-0.5">
                  <i className="fa-solid fa-camera"></i>
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-bold text-slate-900">
                      صلاحية إرفاق صور الفواتير والوصولات
                    </h3>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                        {invoiceUploadStats.allowed} مسموح
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-200">
                        {invoiceUploadStats.disallowed} محجوب
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">
                        (من إجمالي {invoiceUploadStats.total} مدير)
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    تحكم جماعي وفوري: فعّل أو احجب إمكانية التقاط وإرفاق صور الفواتير لكافة مدراء الحسابات بنقرة واحدة، أو خصص كل مدير بشكل فردي من بطاقته بالأسفل.
                  </p>
                </div>
              </div>

              {/* Bulk Action Buttons */}
              <div className="flex items-center gap-2 self-stretch md:self-auto shrink-0 flex-wrap">
                <button
                  type="button"
                  disabled={isBulkUpdatingInvoices || managers.length === 0}
                  onClick={() => handleBulkToggle(true)}
                  className="flex-1 md:flex-none px-4 py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
                  title="السماح لكافة مدراء الحسابات بإرفاق صور الفواتير دفعة واحدة"
                >
                  {isBulkUpdatingInvoices ? (
                    <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                  ) : (
                    <i className="fa-solid fa-circle-check text-xs"></i>
                  )}
                  <span>السماح للجميع</span>
                </button>

                <button
                  type="button"
                  disabled={isBulkUpdatingInvoices || managers.length === 0}
                  onClick={() => handleBulkToggle(false)}
                  className="flex-1 md:flex-none px-4 py-2.5 rounded-xl font-bold text-xs bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
                  title="حجب خيار إرفاق صور الفواتير عن كافة مدراء الحسابات دفعة واحدة"
                >
                  {isBulkUpdatingInvoices ? (
                    <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                  ) : (
                    <i className="fa-solid fa-camera-slash text-xs"></i>
                  )}
                  <span>حجب عن الجميع</span>
                </button>
              </div>
            </div>
          </div>

          {/* Database Groups Filter & Collapse/Expand Bar */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            {databases.length > 0 ? (
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">تصفية حسب القاعدة:</span>
                <select
                  value={filterDbId}
                  onChange={(e) => setFilterDbId(e.target.value)}
                  className="bg-white border border-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl outline-none text-slate-800"
                >
                  <option value="all">جميع القواعد ({activeManagers.length} مدير)</option>
                  <option value="default">القاعدة الرئيسية</option>
                  {databases.map((db) => (
                    <option key={db.id} value={db.id}>
                      {db.name}
                    </option>
                  ))}
                </select>
              </div>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleToggleAllGroups(true)}
                className="px-2.5 py-1 text-[11px] font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                title="فتح وتوسيع كافة القوائم"
              >
                <i className="fa-solid fa-angles-down text-[10px]"></i>
                <span>توسيع الكل</span>
              </button>
              <button
                type="button"
                onClick={() => handleToggleAllGroups(false)}
                className="px-2.5 py-1 text-[11px] font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                title="إغلاق وطي كافة القوائم"
              >
                <i className="fa-solid fa-angles-up text-[10px]"></i>
                <span>طي الكل</span>
              </button>
            </div>
          </div>

          {/* Managers List by Groups */}
          <div className="space-y-4">
            {displayedGroups.map((group) => {
              const isExpanded = !!expandedGroups[group.id];

              return (
                <div key={group.id} className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
                  {/* Group Header */}
                  <div
                    onClick={() => toggleGroup(group.id)}
                    className="p-4 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none hover:bg-slate-100/70 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold">
                        <i className="fa-solid fa-database"></i>
                      </div>
                      <div>
                        <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                          <span>{group.name}</span>
                          <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-blue-100/70 text-blue-700">
                            {group.managers.length} {t('managers.managerPlural', 'مدراء')}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
                        {isExpanded ? 'انقر للطي' : 'انقر لعرض المدراء'}
                      </span>
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center text-slate-500 bg-slate-100/80">
                        <i className={`fa-solid fa-chevron-down text-xs transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`}></i>
                      </div>
                    </div>
                  </div>

                  {/* Group Body */}
                  {isExpanded && (
                    <div className="p-4">
                      {group.managers.length === 0 ? (
                        <div className="text-center py-6 text-slate-400 text-xs">
                          لا يوجد مدراء معينين في هذه القاعدة
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                          {group.managers.map((mgr) => {
                            const pass = mgr.plainPassword || getSecuredPassword(mgr.id) || '';
                            const isRevealed = !!revealedPasswords[mgr.id];
                            const isCopied = copiedManagerId === mgr.id;
                            const isEditingPwd = editingPasswordManagerId === mgr.id;
                            const isExpired = isSubscriptionExpired(mgr.subscriptionType, mgr.subscriptionExpiresAt);

                            return (
                              <div
                                key={mgr.id}
                                className={`rounded-2xl p-4 border transition-all space-y-3 ${
                                  mgr.isSuspended
                                    ? 'bg-rose-50/40 border-rose-300 ring-1 ring-rose-200 shadow-xs'
                                    : !mgr.isActive
                                    ? 'bg-rose-50/30 border-rose-200/80'
                                    : isExpired && mgr.subscriptionType === 'monthly'
                                    ? 'bg-amber-50/30 border-amber-200/80'
                                    : 'bg-white border-slate-200/90 shadow-2xs hover:shadow-xs'
                                }`}
                              >
                                {/* Header: Branch name & status */}
                                <div className="flex items-center justify-between gap-2">
                                  <div>
                                    <div className="font-bold text-sm text-slate-900 flex items-center gap-1.5 flex-wrap">
                                      <span>{mgr.branch}</span>
                                      {mgr.isSuspended && (
                                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-rose-600 text-white flex items-center gap-1 shadow-2xs animate-pulse">
                                          <i className="fa-solid fa-hand text-[9px]"></i>
                                          <span>موقوف لحظياً</span>
                                        </span>
                                      )}
                                    </div>
                                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                                      @{mgr.username}
                                    </div>
                                  </div>

                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span
                                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                        mgr.subscriptionType === 'permanent'
                                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                          : mgr.subscriptionType === 'yearly'
                                          ? isExpired
                                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                                            : 'bg-amber-50 text-amber-800 border-amber-200'
                                          : isExpired
                                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                                          : 'bg-purple-50 text-purple-700 border-purple-200'
                                      }`}
                                    >
                                      {mgr.subscriptionType === 'permanent'
                                        ? 'دائم'
                                        : mgr.subscriptionType === 'yearly'
                                        ? isExpired
                                          ? 'سنوي (منتهي)'
                                          : `سنوي (${getSubscriptionDaysRemaining(mgr.subscriptionExpiresAt)} يوم)`
                                        : isExpired
                                        ? 'منتهي'
                                        : `شهري (${getSubscriptionDaysRemaining(mgr.subscriptionExpiresAt)} يوم)`}
                                    </span>

                                    <button
                                      type="button"
                                      onClick={() => onToggleManagerStatus(mgr.id, mgr.isActive)}
                                      className={`text-[10px] font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer ${
                                        mgr.isActive
                                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                          : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                                      }`}
                                    >
                                      {mgr.isActive ? 'مفعل' : 'معطل'}
                                    </button>

                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        if (onToggleManagerInvoiceUpload) {
                                          const isAllowed = isManagerUploadAllowed(mgr);
                                          onToggleManagerInvoiceUpload(mgr.id, !isAllowed);
                                        }
                                      }}
                                      className={`text-[10px] font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer flex items-center gap-1 border shadow-2xs ${
                                        isManagerUploadAllowed(mgr)
                                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-300'
                                          : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300'
                                      }`}
                                      title={isManagerUploadAllowed(mgr) ? 'إرفاق الصور مسموح حالياً - انقر للحجب' : 'إرفاق الصور محجوب حالياً - انقر للسماح'}
                                    >
                                      <i className={`fa-solid ${isManagerUploadAllowed(mgr) ? 'fa-camera' : 'fa-camera-slash'}`}></i>
                                      <span>{isManagerUploadAllowed(mgr) ? 'الصور متاحة' : 'الصور محجوبة'}</span>
                                    </button>
                                  </div>
                                </div>

                                {/* Details Box */}
                                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/60 text-xs space-y-2">
                                  {/* Suspension Alert Message if suspended */}
                                  {mgr.isSuspended && (
                                    <div className="p-2 bg-rose-50 border border-rose-200 text-rose-900 rounded-xl text-[11px] font-medium flex items-start gap-1.5">
                                      <i className="fa-solid fa-hand text-rose-600 mt-0.5 shrink-0 text-xs"></i>
                                      <div className="min-w-0">
                                        <span className="font-bold">موقوف مؤقتاً: </span>
                                        <span className="text-slate-700">{mgr.suspendMessage || 'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة'}</span>
                                      </div>
                                    </div>
                                  )}

                                  {/* Phone if available */}
                                  {mgr.phoneOrEmail && (
                                    <div className="flex items-center justify-between">
                                      <span className="text-slate-500">رقم الهاتف:</span>
                                      <span className="font-semibold text-blue-700 select-all font-mono" dir="ltr">
                                        {typeof mgr.phoneOrEmail === 'object' && mgr.phoneOrEmail !== null
                                          ? ((mgr.phoneOrEmail as any).value ?? '')
                                          : String(mgr.phoneOrEmail || '')}
                                      </span>
                                    </div>
                                  )}

                                  {/* Security Answer / Favorite Animal */}
                                  {(mgr.securityAnswer || mgr.birthDate) && (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500 flex items-center gap-1">
                                        <i className="fa-solid fa-paw text-amber-600 text-[11px]"></i>
                                        <span>الحيوان المفضل:</span>
                                      </span>
                                      <span className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/80">
                                        {typeof (mgr.securityAnswer || mgr.birthDate) === 'object' && (mgr.securityAnswer || mgr.birthDate) !== null
                                          ? (((mgr.securityAnswer || mgr.birthDate) as any).value ?? '')
                                          : String(mgr.securityAnswer || mgr.birthDate || '')}
                                      </span>
                                    </div>
                                  )}

                                  {/* Creation Date if available */}
                                  {mgr.createdAt && (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500">تاريخ الإنشاء:</span>
                                      <span className="text-slate-600 font-mono text-[11px]">
                                        {formatDateDigits(mgr.createdAt)}
                                      </span>
                                    </div>
                                  )}

                                  {/* Subscription Expiry or Permanent status */}
                                  {mgr.subscriptionType === 'permanent' ? (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500 flex items-center gap-1">
                                        <i className="fa-solid fa-cloud-check text-emerald-600 text-[10px]"></i>
                                        <span>نوع الصلاحية:</span>
                                      </span>
                                      <span className="font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/80 text-[11px]">
                                        دائمي (سحابي)
                                      </span>
                                    </div>
                                  ) : mgr.subscriptionType === 'yearly' ? (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500 flex items-center gap-1">
                                        <i className="fa-solid fa-calendar-check text-amber-600 text-[11px]"></i>
                                        <span>نوع الصلاحية / الانتهاء:</span>
                                      </span>
                                      <span className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/80 font-mono text-[11px]" dir="ltr">
                                        سنوي ({formatDateDigits(mgr.subscriptionExpiresAt || '')})
                                      </span>
                                    </div>
                                  ) : mgr.subscriptionType === 'local_permanent' ? (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500 flex items-center gap-1">
                                        <i className="fa-solid fa-database text-amber-600 text-[10px]"></i>
                                        <span>نوع الصلاحية:</span>
                                      </span>
                                      <span className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/80 text-[11px]">
                                        دائمي (تخزين محلي فقط)
                                      </span>
                                    </div>
                                  ) : mgr.subscriptionExpiresAt ? (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500 flex items-center gap-1">
                                        <i className="fa-solid fa-calendar-days text-purple-600 text-[11px]"></i>
                                        <span>تاريخ الانتهاء:</span>
                                      </span>
                                      <span className="font-bold text-purple-900 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200/80 font-mono text-[11px]" dir="ltr">
                                        {formatDateDigits(mgr.subscriptionExpiresAt)}
                                      </span>
                                    </div>
                                  ) : null}

                                  {/* Modules Allowed */}
                                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                    <span className="text-slate-500">النظام المصرح:</span>
                                    <select
                                      value={mgr.allowedModules || 'both'}
                                      onChange={(e) => {
                                        if (onChangeManagerModules) {
                                          onChangeManagerModules(mgr.id, e.target.value as ManagerModuleAccess);
                                        }
                                      }}
                                      className="bg-white border border-slate-200 text-[11px] font-bold rounded-lg px-2 py-0.5 text-slate-800 outline-none max-w-[190px]"
                                    >
                                      <option value="both">كافة الأنظمة الشاملة (الكل)</option>
                                      <option value="debts_installments">ديون + أقساط</option>
                                      <option value="debts_suppliers">ديون + موردين</option>
                                      <option value="installments_suppliers">أقساط + موردين</option>
                                      <option value="debts">ديون فقط</option>
                                      <option value="installments">أقساط فقط</option>
                                      <option value="suppliers">موردين فقط</option>
                                      <option value="creditors">ديون عليّ فقط</option>
                                    </select>
                                  </div>

                                  {/* Database assignment dropdown */}
                                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                    <span className="text-slate-500">القاعدة:</span>
                                    <select
                                      value={mgr.databaseId || 'default'}
                                      onChange={(e) => {
                                        if (onChangeManagerDatabase) {
                                          onChangeManagerDatabase(mgr.id, e.target.value === 'default' ? null : e.target.value);
                                        }
                                      }}
                                      className="bg-white border border-slate-200 text-[11px] font-bold rounded-lg px-2 py-0.5 text-slate-800 outline-none"
                                    >
                                      <option value="default">الربط بالقاعدة الافتراضية والثانوية معاً (مزدوج)</option>
                                      <option value="builtin_third_alidion2">الربط بقاعدة منفصلة ومستقلة (alidion2)</option>
                                      {databases.map((db) => {
                                        const modeLabel = db.isDedicated || db.connectionMode === 'isolated' ? 'قاعدة منفصلة' : 'قاعدة ثانوية';
                                        const locLabel = db.storageLocation === 'isolated' ? 'مسجلة في المنفصلة 🛡️' : 'مسجلة في الافتراضية 🌐';
                                        return (
                                          <option key={db.id} value={db.id}>
                                            {`${modeLabel}: ${db.name} (${locLabel})`}
                                          </option>
                                        );
                                      })}
                                    </select>
                                  </div>

                                  {/* Allow Invoice Upload Permission Toggle Card */}
                                  {(() => {
                                    const allowed = isManagerUploadAllowed(mgr);
                                    return (
                                      <div className="pt-2 pb-1 border-t border-slate-200/50">
                                        <div
                                          onClick={() => {
                                            if (onToggleManagerInvoiceUpload) {
                                              onToggleManagerInvoiceUpload(mgr.id, !allowed);
                                            }
                                          }}
                                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-slate-100/90 active:bg-slate-200/70 transition-all cursor-pointer group"
                                          title={allowed ? 'انقر لحجب إرفاق الصور عن هذا المدير' : 'انقر للسماح لهذا المدير بإرفاق الصور'}
                                        >
                                          <div className="flex items-center gap-2.5 min-w-0">
                                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs transition-colors shrink-0 shadow-xs ${
                                              allowed
                                                ? 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                                                : 'bg-rose-100 text-rose-700 border border-rose-300'
                                            }`}>
                                              <i className={`fa-solid ${allowed ? 'fa-camera' : 'fa-camera-slash'}`}></i>
                                            </div>
                                            <div className="min-w-0">
                                              <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5 flex-wrap">
                                                <span>إرفاق صور الفواتير</span>
                                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border transition-colors ${
                                                  allowed
                                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                                    : 'bg-rose-50 text-rose-700 border-rose-200'
                                                }`}>
                                                  {allowed ? 'مسموح' : 'محجوب'}
                                                </span>
                                              </div>
                                              <div className="text-[10px] text-slate-500 mt-0.5 truncate">
                                                {allowed
                                                  ? 'يستطيع تصوير وإرفاق الفواتير والوصولات'
                                                  : 'محجوب عنه خيار تصوير ورفع الصور'}
                                              </div>
                                            </div>
                                          </div>

                                          <div className="flex items-center gap-2 shrink-0">
                                            <span
                                              className={`text-[10.5px] font-bold px-2.5 py-1 rounded-lg border transition-all ${
                                                allowed
                                                  ? 'bg-rose-50 text-rose-700 border-rose-200 group-hover:bg-rose-100'
                                                  : 'bg-emerald-50 text-emerald-700 border-emerald-200 group-hover:bg-emerald-100'
                                              }`}
                                            >
                                              {allowed ? 'حجب' : 'سماح'}
                                            </span>
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                if (onToggleManagerInvoiceUpload) {
                                                  onToggleManagerInvoiceUpload(mgr.id, !allowed);
                                                }
                                              }}
                                              className={`w-11 h-6 flex items-center rounded-full p-0.5 cursor-pointer transition-colors duration-200 ease-in-out shrink-0 ${
                                                allowed ? 'bg-emerald-600 justify-end' : 'bg-slate-300 justify-start'
                                              }`}
                                              title={allowed ? 'انقر لحجب إرفاق الصور عن هذا المدير' : 'انقر للسماح لهذا المدير بإرفاق الصور'}
                                            >
                                              <span className="w-5 h-5 rounded-full bg-white shadow-md transform transition-transform" />
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })()}

                                  {/* Allow Supervisor Management Permission Toggle Card */}
                                  {(() => {
                                    const allowedSup = isManagerSupervisorAllowed(mgr);
                                    const isBusy = actionInProgressId === mgr.id;

                                    const handleToggleSupervisor = async (e: React.MouseEvent) => {
                                      e.stopPropagation();
                                      e.preventDefault();
                                      if (isBusy || !onToggleManagerSupervisorManagement) return;
                                      setActionInProgressId(mgr.id);
                                      try {
                                        await onToggleManagerSupervisorManagement(mgr.id, !allowedSup);
                                      } finally {
                                        setActionInProgressId(null);
                                      }
                                    };

                                    return (
                                      <div className="pt-1 pb-1">
                                        <div
                                          onClick={handleToggleSupervisor}
                                          className={`flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer group select-none active:scale-[0.99] ${
                                            allowedSup
                                              ? 'bg-indigo-50/70 border-indigo-200/90 hover:bg-indigo-50'
                                              : 'bg-slate-50/80 border-slate-200 hover:bg-slate-100/70'
                                          } ${isBusy ? 'opacity-70 cursor-wait' : ''}`}
                                          title={allowedSup ? 'انقر لحجب خاصية المشرفين عن هذا المدير' : 'انقر لتفعيل خاصية إضافة وتتبع المشرفين لهذا المدير'}
                                        >
                                          <div className="flex items-center gap-2.5 min-w-0">
                                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs transition-colors shrink-0 shadow-xs ${
                                              allowedSup
                                                ? 'bg-indigo-600 text-white border border-indigo-500'
                                                : 'bg-slate-200 text-slate-500 border border-slate-300'
                                            }`}>
                                              {isBusy ? (
                                                <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                                              ) : (
                                                <i className="fa-solid fa-user-shield"></i>
                                              )}
                                            </div>
                                            <div className="min-w-0">
                                              <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5 flex-wrap">
                                                <span>إدارة وتتبع المشرفين</span>
                                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border transition-colors ${
                                                  allowedSup
                                                    ? 'bg-indigo-100 text-indigo-800 border-indigo-300'
                                                    : 'bg-slate-100 text-slate-600 border-slate-200'
                                                }`}>
                                                  {allowedSup ? 'مفعلة' : 'معطلة'}
                                                </span>
                                              </div>
                                              <div className="text-[10px] text-slate-500 mt-0.5 truncate">
                                                {allowedSup
                                                  ? 'يمكنه إنشاء المشرفين وتتبع سجل كافة عملياتهم'
                                                  : 'خاصية المشرفين والتتبع غير متاحة'}
                                              </div>
                                            </div>
                                          </div>

                                          <div className="flex items-center gap-2 shrink-0">
                                            <button
                                              type="button"
                                              disabled={isBusy}
                                              onClick={handleToggleSupervisor}
                                              className={`w-11 h-6 flex items-center rounded-full p-0.5 transition-colors duration-200 ease-in-out shrink-0 cursor-pointer ${
                                                allowedSup ? 'bg-indigo-600 justify-end' : 'bg-slate-300 justify-start'
                                              }`}
                                              title={allowedSup ? 'تعطيل خاصية المشرفين' : 'تفعيل خاصية المشرفين'}
                                            >
                                              <span className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${isBusy ? 'scale-90 opacity-80' : ''}`} />
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })()}

                                  {/* Password Row */}
                                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                    <span className="text-slate-500">الرمز السري:</span>
                                    {!isEditingPwd ? (
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-mono font-bold text-slate-800">
                                          {pass ? (isRevealed ? pass : '••••••••') : 'محمي'}
                                        </span>

                                        {pass && (
                                          <>
                                            <button
                                              type="button"
                                              onClick={() => togglePasswordVisibility(mgr.id)}
                                              className="p-1 text-slate-500 hover:text-slate-800 cursor-pointer"
                                              title="إظهار"
                                            >
                                              <i className={`fa-solid ${isRevealed ? 'fa-eye-slash' : 'fa-eye'} text-[11px]`}></i>
                                            </button>

                                            <button
                                              type="button"
                                              onClick={() => handleCopyManagerPassword(mgr.id, pass)}
                                              className="p-1 text-slate-500 hover:text-slate-800 cursor-pointer"
                                              title="نسخ"
                                            >
                                              <i className={`fa-solid ${isCopied ? 'fa-check text-emerald-600' : 'fa-copy'} text-[11px]`}></i>
                                            </button>

                                            <button
                                              type="button"
                                              onClick={() => handleShareCredentials(mgr, pass)}
                                              className="p-1 text-emerald-600 hover:text-emerald-800 cursor-pointer"
                                              title="مشاركة عبر واتساب"
                                            >
                                              <i className="fa-brands fa-whatsapp text-xs"></i>
                                            </button>
                                          </>
                                        )}

                                        <button
                                          type="button"
                                          onClick={() => {
                                            setEditingPasswordManagerId(mgr.id);
                                            setEditingPasswordInput(pass || '');
                                          }}
                                          className="p-1 text-blue-600 hover:text-blue-800 cursor-pointer text-[11px]"
                                          title="تعديل الرمز"
                                        >
                                          <i className="fa-solid fa-pen-to-square"></i>
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="flex items-center gap-1">
                                        <input
                                          type="text"
                                          value={editingPasswordInput}
                                          onChange={(e) => setEditingPasswordInput(e.target.value)}
                                          placeholder="رمز جديد..."
                                          className="w-24 bg-white border border-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded-md outline-none"
                                          autoFocus
                                        />
                                        <button
                                          type="button"
                                          onClick={() => handleSaveManagerPassword(mgr.id)}
                                          disabled={isSavingPasswordId === mgr.id}
                                          className="bg-blue-600 text-white px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer hover:bg-blue-700"
                                        >
                                          حفظ
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => setEditingPasswordManagerId(null)}
                                          className="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded-md text-[11px] font-bold cursor-pointer"
                                        >
                                          إلغاء
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                </div>

                                {/* Actions Row */}
                                <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                                  {/* Subscription renewal if monthly or yearly */}
                                  {mgr.subscriptionType === 'monthly' && (
                                    <button
                                      type="button"
                                      onClick={() => onRenewSubscription(mgr.id, 1)}
                                      className="py-1.5 px-3 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                                    >
                                      <i className="fa-solid fa-arrows-rotate text-[10px]"></i>
                                      <span>تجديد شهر</span>
                                    </button>
                                  )}

                                  {mgr.subscriptionType === 'yearly' && (
                                    <button
                                      type="button"
                                      onClick={() => onRenewSubscription(mgr.id, 12)}
                                      className="py-1.5 px-3 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                                    >
                                      <i className="fa-solid fa-arrows-rotate text-[10px]"></i>
                                      <span>تجديد سنة (12 شهر)</span>
                                    </button>
                                  )}

                                  {/* Switch to Permanent / Yearly / Monthly / Local Permanent */}
                                  {onChangeSubscriptionType && (
                                    <select
                                      value={mgr.subscriptionType}
                                      onChange={(e) => {
                                        const newType = e.target.value as SubscriptionType;
                                        const duration = newType === 'yearly' ? 12 : 1;
                                        onChangeSubscriptionType(mgr.id, newType, duration);
                                      }}
                                      className="bg-white border border-slate-200 text-[11px] font-bold rounded-lg px-2 py-1 text-slate-700 outline-none cursor-pointer"
                                    >
                                      <option value="permanent">دائمي (سحابي + محلي)</option>
                                      <option value="yearly">اشتراك سنوي (12 شهر)</option>
                                      <option value="monthly">اشتراك شهري</option>
                                      <option value="local_permanent">دائمي (تخزين محلي فقط)</option>
                                    </select>
                                  )}

                                  {/* Suspend / Unfreeze Manager */}
                                  {mgr.isSuspended ? (
                                    <button
                                      type="button"
                                      onClick={() => onToggleManagerSuspend && onToggleManagerSuspend(mgr.id, false)}
                                      className="py-1.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                                      title="فك الحظر واستئناف العمل"
                                    >
                                      <i className="fa-solid fa-lock-open text-[10px]"></i>
                                      <span>استئناف</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setSuspendTargetManager(mgr);
                                        setSuspendMessageInput(mgr.suspendMessage || 'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة، يرجى مراجعة الإدارة.');
                                        setSuspendModalOpen(true);
                                      }}
                                      className="py-1.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                                      title="إيقاف لحظي لهذا المدير"
                                    >
                                      <i className="fa-solid fa-hand text-[10px]"></i>
                                      <span>إيقاف لحظي</span>
                                    </button>
                                  )}

                                  {/* Delete Manager */}
                                  <button
                                    type="button"
                                    onClick={() => onDeleteManager(mgr.id)}
                                    className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-bold transition-colors cursor-pointer mr-auto"
                                    title="حذف المدير"
                                  >
                                    <i className="fa-solid fa-trash"></i>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      {/* MODAL: ADD NEW DATABASE / SERVER */}
      {showAddDbModal && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200"
          onClick={() => setShowAddDbModal(false)}
        >
          <div
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-server"></i>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">إضافة سيرفر / قاعدة بيانات جديدة</h3>
                  <p className="text-[11px] text-slate-500">ربط سيرفر Turso LibSQL وتجهيز الجداول فوراً</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowAddDbModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {newDbError && (
              <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-200/80 flex items-center gap-2">
                <i className="fa-solid fa-circle-exclamation shrink-0"></i>
                <span>{newDbError}</span>
              </div>
            )}

            {newDbTestResult && (
              <div
                className={`p-3 text-xs rounded-xl border flex items-center gap-2 ${
                  newDbTestResult.ok
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-red-50 text-red-700 border-red-200'
                }`}
              >
                <i
                  className={`fa-solid ${
                    newDbTestResult.ok ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-red-600'
                  } shrink-0`}
                ></i>
                <span>{newDbTestResult.message}</span>
              </div>
            )}

            <form onSubmit={handleSaveNewDb} className="space-y-3 text-xs">
              {/* Storage Destination: في الافتراضية أو في المنفصلة */}
              <div className="space-y-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                <label className="block text-[11px] font-bold text-slate-800">
                  مكان حفظ وتسجيل بيانات القاعدة:
                </label>
                <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setNewDbStorageLocation('default')}
                    className={`p-2 rounded-lg border text-start transition-all cursor-pointer flex items-center gap-2 ${
                      newDbStorageLocation === 'default'
                        ? 'bg-blue-50 border-blue-500 text-blue-900 font-bold ring-1 ring-blue-500/30'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <i className="fa-solid fa-server text-blue-600 text-xs shrink-0"></i>
                    <div>
                      <div className="text-[11px]">في الافتراضية</div>
                      <div className="text-[9px] text-slate-500">سيرفر النظام الافتراضي</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewDbStorageLocation('isolated')}
                    className={`p-2 rounded-lg border text-start transition-all cursor-pointer flex items-center gap-2 ${
                      newDbStorageLocation === 'isolated'
                        ? 'bg-purple-50 border-purple-500 text-purple-900 font-bold ring-1 ring-purple-500/30'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <i className="fa-solid fa-shield-halved text-purple-600 text-xs shrink-0"></i>
                    <div>
                      <div className="text-[11px]">في المنفصلة</div>
                      <div className="text-[9px] text-slate-500">معزولة في (alidion2)</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Connection Mode */}
              <div className="space-y-1">
                <label className="block text-[11px] font-bold text-slate-700">
                  نوع قاعدة البيانات:
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setNewDbMode('isolated')}
                    className={`p-2 rounded-lg border text-start transition-all cursor-pointer flex items-center gap-1.5 ${
                      newDbMode === 'isolated'
                        ? 'bg-purple-50 border-purple-400 text-purple-950 font-bold'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <i className="fa-solid fa-shield text-xs text-purple-600"></i>
                    <span className="text-[11px]">قاعدة منفصلة</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewDbMode('dual_sync')}
                    className={`p-2 rounded-lg border text-start transition-all cursor-pointer flex items-center gap-1.5 ${
                      newDbMode === 'dual_sync'
                        ? 'bg-cyan-50 border-cyan-400 text-cyan-950 font-bold'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <i className="fa-solid fa-clone text-xs text-cyan-600"></i>
                    <span className="text-[11px]">رديفة مزدوجة</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  اسم السيرفر / الفرع:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: سيرفر فرع المنصور / بغداد"
                  value={newDbName}
                  onChange={(e) => setNewDbName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  رابط السيرفر (Database URL):
                </label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  placeholder="libsql://your-db-name.turso.io"
                  value={newDbUrl}
                  onChange={(e) => setNewDbUrl(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-mono text-[11px] p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  مفتاح التوكن (Auth Token):
                </label>
                <input
                  type="password"
                  required
                  dir="ltr"
                  placeholder="eyJh..."
                  value={newDbToken}
                  onChange={(e) => setNewDbToken(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-mono text-[11px] p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  ملاحظات أو وصف (اختياري):
                </label>
                <input
                  type="text"
                  placeholder="وصف مختصر للسيرفر..."
                  value={newDbDesc}
                  onChange={(e) => setNewDbDesc(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={handleTestNewDb}
                  disabled={isTestingNewDb || isSavingNewDb}
                  className="py-2.5 px-3 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  {isTestingNewDb ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الفحص...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-bolt text-xs text-amber-500"></i>
                      <span>فحص الاتصال</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddDbModal(false)}
                    className="py-2.5 px-3 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 cursor-pointer transition-colors"
                  >
                    إلغاء
                  </button>

                  <button
                    type="submit"
                    disabled={isSavingNewDb || isTestingNewDb}
                    className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs cursor-pointer flex items-center gap-1.5 transition-all disabled:opacity-50"
                  >
                    {isSavingNewDb ? (
                      <>
                        <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                        <span>جاري الحفظ والتهيئة...</span>
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-check text-xs"></i>
                        <span>حفظ واختيار السيرفر</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* SUSPEND MODAL (GLOBAL OR SINGLE MANAGER) */}
      {suspendModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setSuspendModalOpen(false)}
        >
          <div
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4 text-right"
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-hand"></i>
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    {suspendTargetManager
                      ? `إيقاف لحظي للمدير: ${suspendTargetManager.branch || suspendTargetManager.username}`
                      : 'إيقاف لحظي عام لجميع المدراء'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {suspendTargetManager
                      ? 'سيتم حظر كافة عمليات الإضافة والتسديد والتعديل لهذا المدير فوراً.'
                      : 'سيتم حظر كافة عمليات الإضافة والتسديد لكافة الفروع والمدراء دفعة واحدة.'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSuspendModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-sm"></i>
              </button>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-700">
                نص الرسالة أو التوجيه المعروض للمدير:
              </label>
              <textarea
                rows={3}
                value={suspendMessageInput}
                onChange={(e) => setSuspendMessageInput(e.target.value)}
                placeholder="اكتب رسالة الإيقاف هنا..."
                className="w-full bg-slate-50 border border-slate-200 focus:border-rose-500 focus:bg-white text-xs font-medium p-3 rounded-xl outline-none text-slate-900 resize-none transition-all"
              />

              {/* Quick Presets */}
              <div>
                <span className="text-[10px] font-bold text-slate-500 block mb-1.5">نماذج رسائل سريعة (اضغط للاختيار):</span>
                <div className="flex flex-col gap-1.5">
                  {[
                    'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة، يرجى مراجعة الإدارة.',
                    'يرجى مراجعة الإدارة المالية فوراً لتسوية ومطابقة الحسابات.',
                    'تم إيقاف النظام مؤقتاً لأغراض الجرد والتدقيق المالي الدوري.',
                    'تم تعليق الحساب مؤقتاً، يرجى التواصل مع الإدارة العامة لفتح النظام.',
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSuspendMessageInput(preset)}
                      className="text-right text-[11px] text-slate-600 hover:text-rose-700 hover:bg-rose-50/70 p-1.5 rounded-lg border border-slate-100 hover:border-rose-200 transition-all cursor-pointer"
                    >
                      • {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSuspendModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={isSubmittingSuspend}
                onClick={async () => {
                  setIsSubmittingSuspend(true);
                  try {
                    const finalMsg =
                      suspendMessageInput.trim() ||
                      'تم إيقاف العمليات مؤقتاً بتوجيه من الإدارة العامة، يرجى مراجعة الإدارة.';
                    if (suspendTargetManager) {
                      if (onToggleManagerSuspend) {
                        await onToggleManagerSuspend(suspendTargetManager.id, true, finalMsg);
                      }
                    } else {
                      if (onToggleGlobalFreeze) {
                        await onToggleGlobalFreeze(true, finalMsg);
                      }
                    }
                    setSuspendModalOpen(false);
                  } catch (err: any) {
                    if (onShowToast) {
                      onShowToast(err?.message || 'حدث خطأ أثناء تنفيذ الإيقاف اللحظي', 'error');
                    }
                  } finally {
                    setIsSubmittingSuspend(false);
                  }
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                {isSubmittingSuspend && <i className="fa-solid fa-spinner fa-spin text-xs"></i>}
                <span>تأكيد الإيقاف الفوري</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
